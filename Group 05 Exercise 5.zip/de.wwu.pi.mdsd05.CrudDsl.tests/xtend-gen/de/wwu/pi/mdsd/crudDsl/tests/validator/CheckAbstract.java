package de.wwu.pi.mdsd.crudDsl.tests.validator;

import de.wwu.pi.mdsd.crudDsl.CrudDslInjectorProvider;
import de.wwu.pi.mdsd.crudDsl.crudDsl.CrudDslPackage;
import de.wwu.pi.mdsd.crudDsl.crudDsl.CrudModel;
import de.wwu.pi.mdsd.crudDsl.validation.CrudDslValidator;
import javax.inject.Inject;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.junit4.InjectWith;
import org.eclipse.xtext.junit4.XtextRunner;
import org.eclipse.xtext.junit4.util.ParseHelper;
import org.eclipse.xtext.junit4.validation.ValidationTestHelper;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Extension;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(XtextRunner.class)
@InjectWith(CrudDslInjectorProvider.class)
@SuppressWarnings("all")
public class CheckAbstract {
  @Inject
  @Extension
  private ParseHelper<CrudModel> _parseHelper;
  
  @Inject
  @Extension
  private ValidationTestHelper _validationTestHelper;
  
  @Test
  public void testCheckNoCycleInEntityHierarcy() {
    try {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("package test.test");
      _builder.newLine();
      _builder.newLine();
      _builder.append("abstract entity A {}");
      _builder.newLine();
      _builder.append("abstract entity B extends A {}");
      _builder.newLine();
      _builder.append("abstract entity C extends B {}");
      _builder.newLine();
      _builder.append("abstract entity D {}");
      _builder.newLine();
      final String model = _builder.toString();
      CrudModel _parse = this._parseHelper.parse(model);
      EClass _entity = CrudDslPackage.eINSTANCE.getEntity();
      String _format = String.format(CrudDslValidator.ONLY_SUPERTYPES_ARE_ABSTRACT_MESSAGE, "C");
      this._validationTestHelper.assertError(_parse, _entity, 
        CrudDslValidator.ONLY_SUPERTYPES_ARE_ABSTRACT_ERROR, _format);
      CrudModel _parse_1 = this._parseHelper.parse(model);
      EClass _entity_1 = CrudDslPackage.eINSTANCE.getEntity();
      String _format_1 = String.format(CrudDslValidator.ONLY_SUPERTYPES_ARE_ABSTRACT_MESSAGE, "D");
      this._validationTestHelper.assertError(_parse_1, _entity_1, 
        CrudDslValidator.ONLY_SUPERTYPES_ARE_ABSTRACT_ERROR, _format_1);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Test
  public void testCorrect() {
    try {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("package test.test");
      _builder.newLine();
      _builder.newLine();
      _builder.append("abstract entity A {");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("ref bs : B[*] opposite=a");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("ref bss : B[*] opposite=a2  ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("ref cs : C[*] opposite=a3");
      _builder.newLine();
      _builder.append("}");
      _builder.newLine();
      _builder.newLine();
      _builder.append("abstract entity B extends A {");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("ref a : A[1] opposite=bs");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("ref a2 : A[1] opposite=bss ");
      _builder.newLine();
      _builder.append("}");
      _builder.newLine();
      _builder.newLine();
      _builder.append("entity C extends B {");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("ref a3 : A[1] opposite=cs ");
      _builder.newLine();
      _builder.append("}");
      _builder.newLine();
      CrudModel _parse = this._parseHelper.parse(_builder);
      this._validationTestHelper.assertNoErrors(_parse);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
