package de.wwu.pi.mdsd.crudDsl.tests.validator;

import de.wwu.pi.mdsd.crudDsl.CrudDslInjectorProvider;
import de.wwu.pi.mdsd.crudDsl.crudDsl.CrudDslPackage;
import de.wwu.pi.mdsd.crudDsl.crudDsl.CrudModel;
import de.wwu.pi.mdsd.crudDsl.validation.CrudDslValidator;
import javax.inject.Inject;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.junit4.InjectWith;
import org.eclipse.xtext.junit4.XtextRunner;
import org.eclipse.xtext.junit4.util.ParseHelper;
import org.eclipse.xtext.junit4.validation.ValidationTestHelper;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Extension;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(XtextRunner.class)
@InjectWith(CrudDslInjectorProvider.class)
@SuppressWarnings("all")
public class CheckNoCycleInEntityHierarchy {
  @Inject
  @Extension
  private ParseHelper<CrudModel> _parseHelper;
  
  @Inject
  @Extension
  private ValidationTestHelper _validationTestHelper;
  
  @Test
  public void testCheckNoCycleInEntityHierarcy() {
    try {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("package test.test");
      _builder.newLine();
      _builder.newLine();
      _builder.append("entity A extends B {");
      _builder.newLine();
      _builder.append("}");
      _builder.newLine();
      _builder.newLine();
      _builder.append("entity B extends A {");
      _builder.newLine();
      _builder.append("}");
      _builder.newLine();
      final String model = _builder.toString();
      CrudModel _parse = this._parseHelper.parse(model);
      EClass _entity = CrudDslPackage.eINSTANCE.getEntity();
      this._validationTestHelper.assertError(_parse, _entity, 
        CrudDslValidator.CYCLIC_ENTITY_HIERARCHY_ERROR, 
        "B extends A");
      CrudModel _parse_1 = this._parseHelper.parse(model);
      EClass _entity_1 = CrudDslPackage.eINSTANCE.getEntity();
      this._validationTestHelper.assertError(_parse_1, _entity_1, 
        CrudDslValidator.CYCLIC_ENTITY_HIERARCHY_ERROR, 
        "A extends B");
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Test
  public void testCheckNoCycleInEntityHierarcyNoError() {
    try {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("package test.test");
      _builder.newLine();
      _builder.newLine();
      _builder.append("entity A {");
      _builder.newLine();
      _builder.append("}");
      _builder.newLine();
      _builder.newLine();
      _builder.append("entity B extends A {");
      _builder.newLine();
      _builder.append("}");
      _builder.newLine();
      _builder.newLine();
      _builder.append("entity C extends B {");
      _builder.newLine();
      _builder.append("}");
      _builder.newLine();
      CrudModel _parse = this._parseHelper.parse(_builder);
      this._validationTestHelper.assertNoErrors(_parse);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
