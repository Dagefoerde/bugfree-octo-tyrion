package de.wwu.pi.mdsd.crudDsl.tests.util;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import de.wwu.pi.mdsd.crudDsl.CrudDslInjectorProvider;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Bounds;
import de.wwu.pi.mdsd.crudDsl.crudDsl.CrudModel;
import de.wwu.pi.mdsd.crudDsl.crudDsl.EntryWindow;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Field;
import de.wwu.pi.mdsd.crudDsl.crudDsl.UIElement;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Window;
import de.wwu.pi.mdsd.crudDsl.util.ModelUtil;
import java.util.Collections;
import java.util.List;
import javax.inject.Inject;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.junit4.InjectWith;
import org.eclipse.xtext.junit4.XtextRunner;
import org.eclipse.xtext.junit4.util.ParseHelper;
import org.eclipse.xtext.junit4.validation.ValidationTestHelper;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.Pair;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(XtextRunner.class)
@InjectWith(CrudDslInjectorProvider.class)
@SuppressWarnings("all")
public class UtilTest {
  @Inject
  @Extension
  private ParseHelper<CrudModel> _parseHelper;
  
  @Inject
  @Extension
  private ValidationTestHelper _validationTestHelper;
  
  @Test
  public void testGetVertexes() {
    try {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("package test.test");
      _builder.newLine();
      _builder.newLine();
      _builder.append("entity Test {");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("att name : String");
      _builder.newLine();
      _builder.append("}");
      _builder.newLine();
      _builder.newLine();
      _builder.append("EntryWindow window for Test size= (200, 200) title \"window title\" {");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("Field someField for name bounds= (50, 60, 70, 80) ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("Field someField2 for name bounds= (51, 61, 5, 15)");
      _builder.newLine();
      _builder.append("\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("Button save createEdit bounds= (121, 60, 5, 15)");
      _builder.newLine();
      _builder.append("}");
      _builder.newLine();
      final String model = _builder.toString();
      CrudModel _parse = this._parseHelper.parse(model);
      EList<Window> _windows = _parse.getWindows();
      Window _head = IterableExtensions.<Window>head(_windows);
      final EntryWindow entryWindow = ((EntryWindow) _head);
      Iterable<Field> _allFields = ModelUtil.allFields(entryWindow);
      Field _head_1 = IterableExtensions.<Field>head(_allFields);
      final Bounds bounds = _head_1.getBounds();
      final List<Pair<Integer,Integer>> vertexes = ModelUtil.getVertexes(bounds);
      final Function1<Pair<Integer,Integer>,Boolean> _function = new Function1<Pair<Integer,Integer>,Boolean>() {
        public Boolean apply(final Pair<Integer,Integer> it) {
          boolean _and = false;
          Integer _key = it.getKey();
          boolean _equals = ((_key).intValue() == 50);
          if (!_equals) {
            _and = false;
          } else {
            Integer _value = it.getValue();
            boolean _equals_1 = ((_value).intValue() == 60);
            _and = (_equals && _equals_1);
          }
          return Boolean.valueOf(_and);
        }
      };
      boolean _exists = IterableExtensions.<Pair<Integer,Integer>>exists(vertexes, _function);
      Assert.assertTrue(_exists);
      final Function1<Pair<Integer,Integer>,Boolean> _function_1 = new Function1<Pair<Integer,Integer>,Boolean>() {
        public Boolean apply(final Pair<Integer,Integer> it) {
          boolean _and = false;
          Integer _key = it.getKey();
          boolean _equals = ((_key).intValue() == 120);
          if (!_equals) {
            _and = false;
          } else {
            Integer _value = it.getValue();
            boolean _equals_1 = ((_value).intValue() == 60);
            _and = (_equals && _equals_1);
          }
          return Boolean.valueOf(_and);
        }
      };
      boolean _exists_1 = IterableExtensions.<Pair<Integer,Integer>>exists(vertexes, _function_1);
      Assert.assertTrue(_exists_1);
      final Function1<Pair<Integer,Integer>,Boolean> _function_2 = new Function1<Pair<Integer,Integer>,Boolean>() {
        public Boolean apply(final Pair<Integer,Integer> it) {
          boolean _and = false;
          Integer _key = it.getKey();
          boolean _equals = ((_key).intValue() == 50);
          if (!_equals) {
            _and = false;
          } else {
            Integer _value = it.getValue();
            boolean _equals_1 = ((_value).intValue() == 140);
            _and = (_equals && _equals_1);
          }
          return Boolean.valueOf(_and);
        }
      };
      boolean _exists_2 = IterableExtensions.<Pair<Integer,Integer>>exists(vertexes, _function_2);
      Assert.assertTrue(_exists_2);
      final Function1<Pair<Integer,Integer>,Boolean> _function_3 = new Function1<Pair<Integer,Integer>,Boolean>() {
        public Boolean apply(final Pair<Integer,Integer> it) {
          boolean _and = false;
          Integer _key = it.getKey();
          boolean _equals = ((_key).intValue() == 120);
          if (!_equals) {
            _and = false;
          } else {
            Integer _value = it.getValue();
            boolean _equals_1 = ((_value).intValue() == 140);
            _and = (_equals && _equals_1);
          }
          return Boolean.valueOf(_and);
        }
      };
      boolean _exists_3 = IterableExtensions.<Pair<Integer,Integer>>exists(vertexes, _function_3);
      Assert.assertTrue(_exists_3);
      Pair<Integer,Integer> _pair = new Pair<Integer, Integer>(Integer.valueOf(51), Integer.valueOf(61));
      Pair<Integer,Integer> _pair_1 = new Pair<Integer, Integer>(Integer.valueOf(119), Integer.valueOf(61));
      Pair<Integer,Integer> _pair_2 = new Pair<Integer, Integer>(Integer.valueOf(51), Integer.valueOf(139));
      Pair<Integer,Integer> _pair_3 = new Pair<Integer, Integer>(Integer.valueOf(119), Integer.valueOf(139));
      Iterable<Pair<Integer,Integer>> _plus = Iterables.<Pair<Integer,Integer>>concat(vertexes, 
        Collections.<Pair<Integer, Integer>>unmodifiableList(Lists.<Pair<Integer, Integer>>newArrayList(_pair, _pair_1, _pair_2, _pair_3)));
      final Procedure1<Pair<Integer,Integer>> _function_4 = new Procedure1<Pair<Integer,Integer>>() {
        public void apply(final Pair<Integer,Integer> it) {
          Integer _key = it.getKey();
          String _plus = (_key + "-->");
          Integer _value = it.getValue();
          String _plus_1 = (_plus + _value);
          boolean _pointWithinBounds = ModelUtil.pointWithinBounds(bounds, it);
          Assert.assertTrue(_plus_1, _pointWithinBounds);
        }
      };
      IterableExtensions.<Pair<Integer,Integer>>forEach(_plus, _function_4);
      Pair<Integer,Integer> _pair_4 = new Pair<Integer, Integer>(Integer.valueOf(49), Integer.valueOf(59));
      Pair<Integer,Integer> _pair_5 = new Pair<Integer, Integer>(Integer.valueOf(121), Integer.valueOf(59));
      Pair<Integer,Integer> _pair_6 = new Pair<Integer, Integer>(Integer.valueOf(49), Integer.valueOf(141));
      Pair<Integer,Integer> _pair_7 = new Pair<Integer, Integer>(Integer.valueOf(121), Integer.valueOf(141));
      final Procedure1<Pair<Integer,Integer>> _function_5 = new Procedure1<Pair<Integer,Integer>>() {
        public void apply(final Pair<Integer,Integer> it) {
          Integer _key = it.getKey();
          String _plus = (_key + "-->");
          Integer _value = it.getValue();
          String _plus_1 = (_plus + _value);
          boolean _pointWithinBounds = ModelUtil.pointWithinBounds(bounds, it);
          Assert.assertFalse(_plus_1, _pointWithinBounds);
        }
      };
      IterableExtensions.<Pair<Integer,Integer>>forEach(Collections.<Pair<Integer, Integer>>unmodifiableList(Lists.<Pair<Integer, Integer>>newArrayList(_pair_4, _pair_5, _pair_6, _pair_7)), _function_5);
      Iterable<Field> _allFields_1 = ModelUtil.allFields(entryWindow);
      Field _head_2 = IterableExtensions.<Field>head(_allFields_1);
      Iterable<Field> _allFields_2 = ModelUtil.allFields(entryWindow);
      Iterable<Field> _tail = IterableExtensions.<Field>tail(_allFields_2);
      Field _head_3 = IterableExtensions.<Field>head(_tail);
      boolean _uiOverlaps = ModelUtil.uiOverlaps(_head_2, _head_3);
      Assert.assertTrue("should overlap", _uiOverlaps);
      EList<UIElement> _elements = entryWindow.getElements();
      UIElement _head_4 = IterableExtensions.<UIElement>head(_elements);
      EList<UIElement> _elements_1 = entryWindow.getElements();
      UIElement _last = IterableExtensions.<UIElement>last(_elements_1);
      boolean _uiOverlaps_1 = ModelUtil.uiOverlaps(_head_4, _last);
      Assert.assertFalse("should not overlap", _uiOverlaps_1);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
