package de.wwu.pi.mdsd.crudDsl.tests.validator;

import de.wwu.pi.mdsd.crudDsl.CrudDslInjectorProvider;
import de.wwu.pi.mdsd.crudDsl.crudDsl.CrudDslPackage;
import de.wwu.pi.mdsd.crudDsl.crudDsl.CrudModel;
import de.wwu.pi.mdsd.crudDsl.validation.CrudDslValidator;
import javax.inject.Inject;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.junit4.InjectWith;
import org.eclipse.xtext.junit4.XtextRunner;
import org.eclipse.xtext.junit4.util.ParseHelper;
import org.eclipse.xtext.junit4.validation.ValidationTestHelper;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Extension;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(XtextRunner.class)
@InjectWith(CrudDslInjectorProvider.class)
@SuppressWarnings("all")
public class CheckOppositesMatch {
  @Inject
  @Extension
  private ParseHelper<CrudModel> _parseHelper;
  
  @Inject
  @Extension
  private ValidationTestHelper _validationTestHelper;
  
  @Test
  public void testError() {
    try {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("package test.test");
      _builder.newLine();
      _builder.newLine();
      _builder.append("abstract entity A {");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("ref bs : B[*] opposite=a");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("ref bss : B[*] opposite=a  ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("ref cs : C[*] opposite=a");
      _builder.newLine();
      _builder.append("}");
      _builder.newLine();
      _builder.newLine();
      _builder.append("abstract entity B extends A {");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("ref a : A[1] opposite=bs");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("ref a2 : A[1] opposite=bs ");
      _builder.newLine();
      _builder.append("}");
      _builder.newLine();
      _builder.newLine();
      _builder.append("entity C extends B {");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("ref a : A[1] opposite=cs ");
      _builder.newLine();
      _builder.append("}");
      _builder.newLine();
      final String model = _builder.toString();
      CrudModel _parse = this._parseHelper.parse(model);
      EClass _reference = CrudDslPackage.eINSTANCE.getReference();
      String _format = String.format(CrudDslValidator.REFERENCE_OPPOSITES_MATCH_MESSAGE, "bs", "bss");
      this._validationTestHelper.assertError(_parse, _reference, 
        CrudDslValidator.REFERENCE_OPPOSITES_MATCH_ERROR, _format);
      CrudModel _parse_1 = this._parseHelper.parse(model);
      EClass _reference_1 = CrudDslPackage.eINSTANCE.getReference();
      String _format_1 = String.format(
        CrudDslValidator.REFERENCE_OPPOSITES_MATCH_MESSAGE, 
        "a", 
        "a2");
      this._validationTestHelper.assertError(_parse_1, _reference_1, 
        CrudDslValidator.REFERENCE_OPPOSITES_MATCH_ERROR, _format_1);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Test
  public void testCorrect() {
    try {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("package test.test");
      _builder.newLine();
      _builder.newLine();
      _builder.append("abstract entity A {");
      _builder.newLine();
      _builder.append("}");
      _builder.newLine();
      _builder.newLine();
      _builder.append("abstract entity B extends A {");
      _builder.newLine();
      _builder.append("}");
      _builder.newLine();
      _builder.newLine();
      _builder.append("entity C extends B {");
      _builder.newLine();
      _builder.append("}");
      _builder.newLine();
      CrudModel _parse = this._parseHelper.parse(_builder);
      this._validationTestHelper.assertNoErrors(_parse);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
