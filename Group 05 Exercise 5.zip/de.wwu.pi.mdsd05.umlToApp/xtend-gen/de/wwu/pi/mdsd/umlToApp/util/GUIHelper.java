package de.wwu.pi.mdsd.umlToApp.util;

import com.google.common.base.Objects;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Bounds;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Button;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Entity;
import de.wwu.pi.mdsd.crudDsl.crudDsl.EntryWindow;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Field;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Label;
import de.wwu.pi.mdsd.crudDsl.crudDsl.ListWindow;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Reference;
import de.wwu.pi.mdsd.umlToApp.util.EntityHelper;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Functions.Function0;
import org.eclipse.xtext.xbase.lib.StringExtensions;

@SuppressWarnings("all")
public class GUIHelper {
  private final static String REGEX_SPLIT_CAMEL_CASE = new Function0<String>() {
    public String apply() {
      String _plus = ("(?<=[A-Z])(?=[A-Z][a-z])" + "|");
      String _plus_1 = (_plus + 
        "(?<=[^A-Z])(?=[A-Z])");
      String _plus_2 = (_plus_1 + "|");
      String _plus_3 = (_plus_2 + 
        "(?<=[A-Za-z])(?=[^A-Za-z])");
      return _plus_3;
    }
  }.apply();
  
  public static String camelCaseToLabel(final String camelCaseString) {
    String _replaceAll = camelCaseString.replaceAll(GUIHelper.REGEX_SPLIT_CAMEL_CASE, " ");
    return _replaceAll;
  }
  
  public static String readableLabel(final Label label) {
    String _xifexpression = null;
    String _text = label.getText();
    boolean _equals = Objects.equal(_text, null);
    if (_equals) {
      String _name = label.getName();
      String _camelCaseToLabel = GUIHelper.camelCaseToLabel(_name);
      String _firstUpper = StringExtensions.toFirstUpper(_camelCaseToLabel);
      _xifexpression = _firstUpper;
    } else {
      String _text_1 = label.getText();
      _xifexpression = _text_1;
    }
    return _xifexpression;
  }
  
  public static CharSequence windowTitle(final ListWindow window) {
    CharSequence _xifexpression = null;
    String _title = window.getTitle();
    boolean _equals = Objects.equal(_title, null);
    if (_equals) {
      StringConcatenation _builder = new StringConcatenation();
      String _name = window.getName();
      String _camelCaseToLabel = GUIHelper.camelCaseToLabel(_name);
      String _firstUpper = StringExtensions.toFirstUpper(_camelCaseToLabel);
      _builder.append(_firstUpper, "");
      _xifexpression = _builder;
    } else {
      String _title_1 = window.getTitle();
      _xifexpression = _title_1;
    }
    return _xifexpression;
  }
  
  public static CharSequence readableButtonLabel(final Button button) {
    CharSequence _xifexpression = null;
    String _text = button.getText();
    boolean _equals = Objects.equal(_text, null);
    if (_equals) {
      StringConcatenation _builder = new StringConcatenation();
      String _name = button.getName();
      String _camelCaseToLabel = GUIHelper.camelCaseToLabel(_name);
      String _firstUpper = StringExtensions.toFirstUpper(_camelCaseToLabel);
      _builder.append(_firstUpper, "");
      _xifexpression = _builder;
    } else {
      String _text_1 = button.getText();
      _xifexpression = _text_1;
    }
    return _xifexpression;
  }
  
  public static CharSequence windowTitle(final EntryWindow window) {
    CharSequence _xifexpression = null;
    String _title = window.getTitle();
    boolean _equals = Objects.equal(_title, null);
    if (_equals) {
      StringConcatenation _builder = new StringConcatenation();
      String _name = window.getName();
      String _camelCaseToLabel = GUIHelper.camelCaseToLabel(_name);
      String _firstUpper = StringExtensions.toFirstUpper(_camelCaseToLabel);
      _builder.append(_firstUpper, "");
      _xifexpression = _builder;
    } else {
      String _title_1 = window.getTitle();
      _xifexpression = _title_1;
    }
    return _xifexpression;
  }
  
  public static CharSequence getAddButtonName(final Field field) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("btn_");
    String _name = field.getName();
    _builder.append(_name, "");
    _builder.append("_Add");
    return _builder;
  }
  
  public static CharSequence getEditButtonName(final Field field) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("btn_");
    String _name = field.getName();
    _builder.append(_name, "");
    _builder.append("_Edit");
    return _builder;
  }
  
  public static CharSequence getDeleteButtonName(final Field field) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("btn_");
    String _name = field.getName();
    _builder.append(_name, "");
    _builder.append("_Delete");
    return _builder;
  }
  
  public static CharSequence inheritanceTypeSelectName(final Reference ref) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("cb_select_inh_type_");
    String _name = ref.getName();
    _builder.append(_name, "");
    return _builder;
  }
  
  public static CharSequence inheritanceTypeSelectName(final Entity entity) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("cb_select_inh_type_");
    String _name = entity.getName();
    _builder.append(_name, "");
    return _builder;
  }
  
  public static CharSequence inheritanceCallOpenEntryWindow(final Entity entity, final String refToWindowClass) {
    StringConcatenation _builder = new StringConcatenation();
    {
      Iterable<Entity> _instantiableClasses = EntityHelper.getInstantiableClasses(entity);
      for(final Entity subClass : _instantiableClasses) {
        _builder.append("if(entity instanceof ");
        String _javaType = EntityHelper.javaType(subClass);
        _builder.append(_javaType, "");
        _builder.append(")");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("new ");
        String _entryWindowClassName = EntityHelper.entryWindowClassName(subClass);
        _builder.append(_entryWindowClassName, "	");
        _builder.append("(");
        _builder.append(refToWindowClass, "	");
        _builder.append(", (");
        String _name = subClass.getName();
        _builder.append(_name, "	");
        _builder.append(") entity).open();");
        _builder.newLineIfNotEmpty();
      }
    }
    return _builder;
  }
  
  public static CharSequence createSelectForInheritanceClasses(final Entity entity, final String x, final String y) {
    StringConcatenation _builder = new StringConcatenation();
    {
      Iterable<Entity> _instantiableClasses = EntityHelper.getInstantiableClasses(entity);
      for(final Entity subclass : _instantiableClasses) {
        CharSequence _inheritanceTypeSelectName = GUIHelper.inheritanceTypeSelectName(entity);
        _builder.append(_inheritanceTypeSelectName, "");
        _builder.append(".addItem(\"");
        String _name = subclass.getName();
        _builder.append(_name, "");
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("java.awt.GridBagConstraints gbc_");
    CharSequence _inheritanceTypeSelectName_1 = GUIHelper.inheritanceTypeSelectName(entity);
    _builder.append(_inheritanceTypeSelectName_1, "");
    _builder.append(" = new java.awt.GridBagConstraints();");
    _builder.newLineIfNotEmpty();
    _builder.append("gbc_");
    CharSequence _inheritanceTypeSelectName_2 = GUIHelper.inheritanceTypeSelectName(entity);
    _builder.append(_inheritanceTypeSelectName_2, "");
    _builder.append(".insets = new java.awt.Insets(0, 0, 5, 5);");
    _builder.newLineIfNotEmpty();
    _builder.append("gbc_");
    CharSequence _inheritanceTypeSelectName_3 = GUIHelper.inheritanceTypeSelectName(entity);
    _builder.append(_inheritanceTypeSelectName_3, "");
    _builder.append(".gridx = ");
    _builder.append(x, "");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    _builder.append("gbc_");
    CharSequence _inheritanceTypeSelectName_4 = GUIHelper.inheritanceTypeSelectName(entity);
    _builder.append(_inheritanceTypeSelectName_4, "");
    _builder.append(".gridy = ");
    _builder.append(y, "");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    _builder.append("getPanel().add(");
    CharSequence _inheritanceTypeSelectName_5 = GUIHelper.inheritanceTypeSelectName(entity);
    _builder.append(_inheritanceTypeSelectName_5, "");
    _builder.append(", gbc_");
    CharSequence _inheritanceTypeSelectName_6 = GUIHelper.inheritanceTypeSelectName(entity);
    _builder.append(_inheritanceTypeSelectName_6, "");
    _builder.append(");");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  public static boolean isSpaceForButtons(final Field field) {
    boolean _and = false;
    Bounds _bounds = field.getBounds();
    int _height = _bounds.getHeight();
    boolean _greaterThan = (_height > 50);
    if (!_greaterThan) {
      _and = false;
    } else {
      Bounds _bounds_1 = field.getBounds();
      int _width = _bounds_1.getWidth();
      boolean _greaterThan_1 = (_width > 50);
      _and = (_greaterThan && _greaterThan_1);
    }
    return _and;
  }
  
  public static Integer numberOfButtonsThereIsSpaceFor(final Field field) {
    boolean _isSpaceForButtons = GUIHelper.isSpaceForButtons(field);
    boolean _not = (!_isSpaceForButtons);
    if (_not) {
      return Integer.valueOf(0);
    }
    Bounds _bounds = field.getBounds();
    int _width = _bounds.getWidth();
    boolean _lessThan = (_width < 50);
    if (_lessThan) {
      return Integer.valueOf(0);
    }
    Bounds _bounds_1 = field.getBounds();
    int _width_1 = _bounds_1.getWidth();
    boolean _lessThan_1 = (_width_1 < 105);
    if (_lessThan_1) {
      return Integer.valueOf(1);
    }
    Bounds _bounds_2 = field.getBounds();
    int _width_2 = _bounds_2.getWidth();
    boolean _lessThan_2 = (_width_2 < 160);
    if (_lessThan_2) {
      return Integer.valueOf(2);
    } else {
      return Integer.valueOf(3);
    }
  }
}
