package de.wwu.pi.mdsd.umlToApp.gui;

import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import com.google.common.collect.Sets;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Attribute;
import de.wwu.pi.mdsd.crudDsl.crudDsl.AttributeType;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Bounds;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Button;
import de.wwu.pi.mdsd.crudDsl.crudDsl.ButtonKind;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Entity;
import de.wwu.pi.mdsd.crudDsl.crudDsl.EntryWindow;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Field;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Label;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Property;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Reference;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Size;
import de.wwu.pi.mdsd.crudDsl.crudDsl.UIElement;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Window;
import de.wwu.pi.mdsd.umlToApp.util.EntityHelper;
import de.wwu.pi.mdsd.umlToApp.util.GUIHelper;
import de.wwu.pi.mdsd.umlToApp.util.GeneratorWithImports;
import de.wwu.pi.mdsd.umlToApp.util.ModelAndPackageHelper;
import java.util.Collections;
import java.util.Set;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.StringExtensions;

@SuppressWarnings("all")
public class EntryWindowGenerator extends GeneratorWithImports<EntryWindow> {
  public CharSequence doGenerate(final EntryWindow window) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("package ");
    String _guiPackageString = ModelAndPackageHelper.guiPackageString(window);
    _builder.append(_guiPackageString, "");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("import java.awt.event.ActionEvent;");
    _builder.newLine();
    _builder.append("import java.awt.event.ActionListener;");
    _builder.newLine();
    _builder.append("import java.text.ParseException;");
    _builder.newLine();
    _builder.append("import java.util.*;");
    _builder.newLine();
    _builder.newLine();
    _builder.append("import javax.swing.*;");
    _builder.newLine();
    _builder.newLine();
    _builder.append("import de.wwu.pi.mdsd.framework.gui.*;");
    _builder.newLine();
    _builder.append("import de.wwu.pi.mdsd.framework.logic.ValidationException;");
    _builder.newLine();
    _builder.append(GeneratorWithImports.IMPORTS_MARKER, "");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("public class ");
    String _name = window.getName();
    _builder.append(_name, "");
    _builder.append(" extends AbstractEntryWindow<");
    Entity _entity = window.getEntity();
    String _importedType = this.importedType(_entity);
    _builder.append(_importedType, "");
    _builder.append("> ");
    Entity _entity_1 = window.getEntity();
    Set<Entity> _listingTypes = this.listingTypes(_entity_1);
    final Function1<Entity,String> _function = new Function1<Entity,String>() {
      public String apply(final Entity it) {
        String _listingInterfaceClassName = EntityHelper.listingInterfaceClassName(it);
        return _listingInterfaceClassName;
      }
    };
    String _join = IterableExtensions.<Entity>join(_listingTypes, "implements ", ", ", " ", _function);
    _builder.append(_join, "");
    _builder.append("{");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    String _logicPackageString = ModelAndPackageHelper.logicPackageString(window);
    String _plus = (_logicPackageString + ".");
    Entity _entity_2 = window.getEntity();
    String _serviceClassName = EntityHelper.serviceClassName(_entity_2);
    String _plus_1 = (_plus + _serviceClassName);
    String _imported = this.imported(_plus_1);
    _builder.append(_imported, "	");
    _builder.append(" service;");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    {
      EList<UIElement> _elements = window.getElements();
      Iterable<Field> _filter = Iterables.<Field>filter(_elements, Field.class);
      for(final Field elem : _filter) {
        _builder.append("\t");
        _builder.append("private ");
        String _inputFieldType = this.inputFieldType(elem);
        _builder.append(_inputFieldType, "	");
        _builder.append(" ");
        String _name_1 = elem.getName();
        _builder.append(_name_1, "	");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t\t\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("public ");
    String _name_2 = window.getName();
    _builder.append(_name_2, "	");
    _builder.append("(AbstractWindow parent, ");
    Entity _entity_3 = window.getEntity();
    String _javaType = EntityHelper.javaType(_entity_3);
    _builder.append(_javaType, "	");
    _builder.append(" currentEntity) {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("super(parent, currentEntity, ");
    Size _size = window.getSize();
    int _width = _size.getWidth();
    _builder.append(_width, "		");
    _builder.append(", ");
    Size _size_1 = window.getSize();
    int _height = _size_1.getHeight();
    _builder.append(_height, "		");
    _builder.append(");");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("service = ");
    String _logicPackageString_1 = ModelAndPackageHelper.logicPackageString(window);
    String _plus_2 = (_logicPackageString_1 + ".ServiceInitializer");
    String _imported_1 = this.imported(_plus_2);
    _builder.append(_imported_1, "		");
    _builder.append(".getProvider().get");
    Entity _entity_4 = window.getEntity();
    String _serviceClassName_1 = EntityHelper.serviceClassName(_entity_4);
    _builder.append(_serviceClassName_1, "		");
    _builder.append("();");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("\t");
    _builder.append("@Override");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("protected void createUIElements() {");
    _builder.newLine();
    {
      EList<UIElement> _elements_1 = window.getElements();
      for(final UIElement elem_1 : _elements_1) {
        _builder.append("\t\t");
        _builder.newLine();
        {
          if ((elem_1 instanceof Label)) {
            _builder.append("\t\t");
            _builder.newLine();
            _builder.append("\t\t");
            _builder.append("JLabel ");
            String _name_3 = elem_1.getName();
            _builder.append(_name_3, "		");
            _builder.append(" = new JLabel(\"");
            String _labelName = this.labelName(((Label) elem_1));
            _builder.append(_labelName, "		");
            _builder.append("\");");
            _builder.newLineIfNotEmpty();
            _builder.append("\t\t");
            String _name_4 = elem_1.getName();
            _builder.append(_name_4, "		");
            _builder.append(".setBounds(");
            Bounds _bounds = elem_1.getBounds();
            int _x = _bounds.getX();
            _builder.append(_x, "		");
            _builder.append(", ");
            Bounds _bounds_1 = elem_1.getBounds();
            int _y = _bounds_1.getY();
            _builder.append(_y, "		");
            _builder.append(", ");
            Bounds _bounds_2 = elem_1.getBounds();
            int _width_1 = _bounds_2.getWidth();
            _builder.append(_width_1, "		");
            _builder.append(", ");
            Bounds _bounds_3 = elem_1.getBounds();
            int _height_1 = _bounds_3.getHeight();
            _builder.append(_height_1, "		");
            _builder.append(");");
            _builder.newLineIfNotEmpty();
            _builder.append("\t\t");
            _builder.append("getPanel().add(");
            String _name_5 = elem_1.getName();
            _builder.append(_name_5, "		");
            _builder.append(");");
            _builder.newLineIfNotEmpty();
            _builder.append("\t\t");
            _builder.newLine();
            _builder.append("\t\t");
            _builder.newLine();
          } else {
            if ((elem_1 instanceof Field)) {
              {
                Property _property = ((Field) elem_1).getProperty();
                if ((_property instanceof Attribute)) {
                  _builder.append("\t\t");
                  String _name_6 = elem_1.getName();
                  _builder.append(_name_6, "		");
                  _builder.append(" = ");
                  CharSequence _initializeField = this.initializeField(((Field) elem_1));
                  _builder.append(_initializeField, "		");
                  _builder.append(";");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t\t");
                  String _name_7 = elem_1.getName();
                  _builder.append(_name_7, "		");
                  _builder.append(".setBounds(");
                  Bounds _bounds_4 = elem_1.getBounds();
                  int _x_1 = _bounds_4.getX();
                  _builder.append(_x_1, "		");
                  _builder.append(", ");
                  Bounds _bounds_5 = elem_1.getBounds();
                  int _y_1 = _bounds_5.getY();
                  _builder.append(_y_1, "		");
                  _builder.append(", ");
                  Bounds _bounds_6 = elem_1.getBounds();
                  int _width_2 = _bounds_6.getWidth();
                  _builder.append(_width_2, "		");
                  _builder.append(", ");
                  Bounds _bounds_7 = elem_1.getBounds();
                  int _height_2 = _bounds_7.getHeight();
                  _builder.append(_height_2, "		");
                  _builder.append(");");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t\t");
                  _builder.append("getPanel().add(");
                  String _name_8 = elem_1.getName();
                  _builder.append(_name_8, "		");
                  _builder.append(");");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t\t");
                  String _name_9 = elem_1.getName();
                  _builder.append(_name_9, "		");
                  _builder.append(".setColumns(10);");
                  _builder.newLineIfNotEmpty();
                } else {
                  Property _property_1 = ((Field) elem_1).getProperty();
                  if ((_property_1 instanceof Reference)) {
                    {
                      boolean _hasSingleValuedProperty = EntityHelper.hasSingleValuedProperty(((Field) elem_1));
                      if (_hasSingleValuedProperty) {
                        _builder.append("\t\t");
                        String _name_10 = elem_1.getName();
                        _builder.append(_name_10, "		");
                        _builder.append(" = ");
                        CharSequence _initializeField_1 = this.initializeField(((Field) elem_1));
                        _builder.append(_initializeField_1, "		");
                        _builder.append(";");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t\t");
                        String _name_11 = elem_1.getName();
                        _builder.append(_name_11, "		");
                        _builder.append(".setBounds(");
                        Bounds _bounds_8 = elem_1.getBounds();
                        int _x_2 = _bounds_8.getX();
                        _builder.append(_x_2, "		");
                        _builder.append(", ");
                        Bounds _bounds_9 = elem_1.getBounds();
                        int _y_2 = _bounds_9.getY();
                        _builder.append(_y_2, "		");
                        _builder.append(", ");
                        Bounds _bounds_10 = elem_1.getBounds();
                        int _width_3 = _bounds_10.getWidth();
                        _builder.append(_width_3, "		");
                        _builder.append(", ");
                        Bounds _bounds_11 = elem_1.getBounds();
                        int _height_3 = _bounds_11.getHeight();
                        _builder.append(_height_3, "		");
                        _builder.append(");");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t\t");
                        _builder.append("getPanel().add(");
                        String _name_12 = elem_1.getName();
                        _builder.append(_name_12, "		");
                        _builder.append(");");
                        _builder.newLineIfNotEmpty();
                      } else {
                        boolean _hasMultiValuedProperty = EntityHelper.hasMultiValuedProperty(((Field) elem_1));
                        if (_hasMultiValuedProperty) {
                        }
                      }
                    }
                  }
                }
              }
            } else {
              if ((elem_1 instanceof Button)) {
                {
                  ButtonKind _kind = ((Button) elem_1).getKind();
                  boolean _equals = Objects.equal(_kind, ButtonKind.CREATE_EDIT);
                  if (_equals) {
                    _builder.append("\t\t");
                    _builder.append("JButton ");
                    String _name_13 = elem_1.getName();
                    _builder.append(_name_13, "		");
                    _builder.append(" = new JButton(\"");
                    CharSequence _readableButtonLabel = GUIHelper.readableButtonLabel(((Button) elem_1));
                    _builder.append(_readableButtonLabel, "		");
                    _builder.append("\");");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t\t");
                    String _name_14 = elem_1.getName();
                    _builder.append(_name_14, "		");
                    _builder.append(".setBounds(");
                    Bounds _bounds_12 = elem_1.getBounds();
                    int _x_3 = _bounds_12.getX();
                    _builder.append(_x_3, "		");
                    _builder.append(", ");
                    Bounds _bounds_13 = elem_1.getBounds();
                    int _y_3 = _bounds_13.getY();
                    _builder.append(_y_3, "		");
                    _builder.append(", ");
                    Bounds _bounds_14 = elem_1.getBounds();
                    int _width_4 = _bounds_14.getWidth();
                    _builder.append(_width_4, "		");
                    _builder.append(", ");
                    Bounds _bounds_15 = elem_1.getBounds();
                    int _height_4 = _bounds_15.getHeight();
                    _builder.append(_height_4, "		");
                    _builder.append(");");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t\t");
                    _builder.append("getPanel().add(");
                    String _name_15 = elem_1.getName();
                    _builder.append(_name_15, "		");
                    _builder.append(");");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t\t");
                    String _name_16 = elem_1.getName();
                    _builder.append(_name_16, "		");
                    _builder.append(".addActionListener(new ActionListener() {");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t\t");
                    _builder.newLine();
                    _builder.append("\t\t");
                    _builder.append("@Override");
                    _builder.newLine();
                    _builder.append("\t\t");
                    _builder.append("public void actionPerformed(ActionEvent e) {");
                    _builder.newLine();
                    _builder.append("\t\t");
                    _builder.append("\t\t");
                    _builder.append("try {");
                    _builder.newLine();
                    _builder.append("\t\t");
                    _builder.append("\t\t\t");
                    _builder.append("saveAction();");
                    _builder.newLine();
                    _builder.append("\t\t");
                    _builder.append("\t\t");
                    _builder.append("} catch (Exception e1) {");
                    _builder.newLine();
                    _builder.append("\t\t");
                    _builder.append("\t\t\t");
                    _builder.append("JOptionPane.showMessageDialog(getPanel(), \"Could not be saved. \" + e1.getMessage());");
                    _builder.newLine();
                    _builder.append("\t\t");
                    _builder.append("\t\t");
                    _builder.append("}\t\t\t\t");
                    _builder.newLine();
                    _builder.append("\t\t");
                    _builder.append("}");
                    _builder.newLine();
                    _builder.append("\t\t");
                    _builder.append("});");
                    _builder.newLine();
                  }
                }
              }
            }
          }
        }
      }
    }
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("@Override");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("protected String getTitle() {");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("return \"");
    CharSequence _windowTitle = GUIHelper.windowTitle(window);
    _builder.append(_windowTitle, "		");
    _builder.append("\";//Edit \" + currentEntity.getClass().getSimpleName() + \" Window\";");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("@Override");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("protected boolean saveAction() throws ParseException {");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("//Read values from different fields ");
    _builder.newLine();
    {
      EList<UIElement> _elements_2 = window.getElements();
      Iterable<Field> _filter_1 = Iterables.<Field>filter(_elements_2, Field.class);
      final Function1<Field,Boolean> _function_1 = new Function1<Field,Boolean>() {
        public Boolean apply(final Field it) {
          boolean _hasSingleValuedProperty = EntityHelper.hasSingleValuedProperty(it);
          return Boolean.valueOf(_hasSingleValuedProperty);
        }
      };
      Iterable<Field> _filter_2 = IterableExtensions.<Field>filter(_filter_1, _function_1);
      for(final Field elem_2 : _filter_2) {
        _builder.append("\t\t");
        String _switchResult = null;
        Property _property_2 = elem_2.getProperty();
        final Property _switchValue = _property_2;
        boolean _matched = false;
        if (!_matched) {
          if (_switchValue instanceof Attribute) {
            final Attribute _attribute = (Attribute)_switchValue;
            _matched=true;
            Property _property_3 = elem_2.getProperty();
            AttributeType _type = ((Attribute) _property_3).getType();
            String _literal = _type.getLiteral();
            String _objectType = EntityHelper.objectType(_literal);
            _switchResult = _objectType;
          }
        }
        if (!_matched) {
          if (_switchValue instanceof Reference) {
            final Reference _reference = (Reference)_switchValue;
            _matched=true;
            Property _property_3 = elem_2.getProperty();
            Entity _type = ((Reference) _property_3).getType();
            String _name_17 = _type.getName();
            String _objectType = EntityHelper.objectType(_name_17);
            _switchResult = _objectType;
          }
        }
        _builder.append(_switchResult, "		");
        _builder.newLineIfNotEmpty();
        _builder.append("\t\t");
        _builder.append("  ");
        Property _property_3 = elem_2.getProperty();
        String _name_17 = _property_3.getName();
        _builder.append(_name_17, "		  ");
        _builder.append(" = ");
        CharSequence _retrieveValueFromFieldCode = this.retrieveValueFromFieldCode(elem_2);
        _builder.append(_retrieveValueFromFieldCode, "		  ");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t\t");
    _builder.newLine();
    _builder.append("\t\t");
    Entity _entity_5 = window.getEntity();
    Iterable<Property> _singleValueProperties = EntityHelper.singleValueProperties(_entity_5, true);
    final Function1<Property,String> _function_2 = new Function1<Property,String>() {
      public String apply(final Property it) {
        String _name = it.getName();
        return _name;
      }
    };
    final String attributeNames = IterableExtensions.<Property>join(_singleValueProperties, ", ", _function_2);
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("//validation");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("try {");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("service.validate");
    Entity _entity_6 = window.getEntity();
    String _name_18 = _entity_6.getName();
    _builder.append(_name_18, "			");
    _builder.append("(");
    _builder.append(attributeNames, "			");
    _builder.append(");");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t\t");
    String _name_19 = window.getName();
    _builder.append(_name_19, "			");
    _builder.append(".this.closeWindow();");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("} catch (ValidationException e) {");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("Util.showUserMessage(\"Validation error for \" + e.getField(), \"Validation error for \" + e.getField() + \": \" + e.getMessage());");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("return false;");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("//persist");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("currentEntity = service.save");
    Entity _entity_7 = window.getEntity();
    String _name_20 = _entity_7.getName();
    _builder.append(_name_20, "		");
    _builder.append("(currentEntity.getOid()");
    String _xifexpression = null;
    boolean _isEmpty = attributeNames.isEmpty();
    boolean _not = (!_isEmpty);
    if (_not) {
      String _plus_3 = (", " + attributeNames);
      _xifexpression = _plus_3;
    }
    _builder.append(_xifexpression, "		");
    _builder.append(");");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("//reload the listing in the parent window to make changes visible");
    _builder.newLine();
    {
      Entity _entity_8 = window.getEntity();
      Iterable<Entity> _allSuperClasses = EntityHelper.allSuperClasses(_entity_8);
      Entity _entity_9 = window.getEntity();
      Iterable<Entity> _plus_4 = Iterables.<Entity>concat(_allSuperClasses, Collections.<Entity>unmodifiableSet(Sets.<Entity>newHashSet(_entity_9)));
      for(final Entity currClass : _plus_4) {
        _builder.append("\t\t");
        _builder.append("if(getParent() instanceof ");
        String _listingInterfaceClassName = EntityHelper.listingInterfaceClassName(currClass);
        _builder.append(_listingInterfaceClassName, "		");
        _builder.append(")");
        _builder.newLineIfNotEmpty();
        _builder.append("\t\t");
        _builder.append("\t");
        _builder.append("((");
        String _listingInterfaceClassName_1 = EntityHelper.listingInterfaceClassName(currClass);
        _builder.append(_listingInterfaceClassName_1, "			");
        _builder.append(") getParent()).");
        String _listingInterfaceMethodeName = EntityHelper.listingInterfaceMethodeName(currClass);
        _builder.append(_listingInterfaceMethodeName, "			");
        _builder.append("();");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t\t");
    _builder.append("return true;");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    {
      Entity _entity_10 = window.getEntity();
      Iterable<Reference> _multiReferences = EntityHelper.multiReferences(_entity_10, true);
      final Function1<Reference,Boolean> _function_3 = new Function1<Reference,Boolean>() {
        public Boolean apply(final Reference rerference) {
          boolean _hasSubClasses = EntityHelper.hasSubClasses(rerference);
          return Boolean.valueOf(_hasSubClasses);
        }
      };
      Iterable<Reference> _filter_3 = IterableExtensions.<Reference>filter(_multiReferences, _function_3);
      for(final Reference rerference : _filter_3) {
        _builder.append("\t");
        _builder.append("javax.swing.JComboBox<String> ");
        CharSequence _inheritanceTypeSelectName = GUIHelper.inheritanceTypeSelectName(rerference);
        _builder.append(_inheritanceTypeSelectName, "	");
        _builder.append(" = new javax.swing.JComboBox<>();");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.append("@Override");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("protected void createLists() {");
    _builder.newLine();
    {
      EList<UIElement> _elements_3 = window.getElements();
      Iterable<Field> _filter_4 = Iterables.<Field>filter(_elements_3, Field.class);
      final Function1<Field,Boolean> _function_4 = new Function1<Field,Boolean>() {
        public Boolean apply(final Field field) {
          boolean _and = false;
          Property _property = field.getProperty();
          if (!(_property instanceof Reference)) {
            _and = false;
          } else {
            Property _property_1 = field.getProperty();
            boolean _isMultivalued = EntityHelper.isMultivalued(((Reference) _property_1));
            _and = ((_property instanceof Reference) && _isMultivalued);
          }
          return Boolean.valueOf(_and);
        }
      };
      Iterable<Field> _filter_5 = IterableExtensions.<Field>filter(_filter_4, _function_4);
      for(final Field elem_3 : _filter_5) {
        _builder.append("\t\t");
        _builder.append("JScrollPane scroll_");
        String _name_21 = elem_3.getName();
        _builder.append(_name_21, "		");
        _builder.append(" = new JScrollPane();");
        _builder.newLineIfNotEmpty();
        _builder.append("\t\t");
        _builder.append("scroll_");
        String _name_22 = elem_3.getName();
        _builder.append(_name_22, "		");
        _builder.append(".setBounds(");
        Bounds _bounds_16 = elem_3.getBounds();
        int _x_4 = _bounds_16.getX();
        _builder.append(_x_4, "		");
        _builder.append(", ");
        Bounds _bounds_17 = elem_3.getBounds();
        int _y_4 = _bounds_17.getY();
        _builder.append(_y_4, "		");
        _builder.append(", ");
        Bounds _bounds_18 = elem_3.getBounds();
        int _width_5 = _bounds_18.getWidth();
        _builder.append(_width_5, "		");
        _builder.append(", ");
        Bounds _bounds_19 = elem_3.getBounds();
        int _height_5 = _bounds_19.getHeight();
        _builder.append(_height_5, "		");
        {
          boolean _isSpaceForButtons = GUIHelper.isSpaceForButtons(elem_3);
          if (_isSpaceForButtons) {
            _builder.append("-25");
          }
        }
        _builder.append(");");
        _builder.newLineIfNotEmpty();
        _builder.append("\t\t");
        _builder.append("getPanel().add(scroll_");
        String _name_23 = elem_3.getName();
        _builder.append(_name_23, "		");
        _builder.append(");");
        _builder.newLineIfNotEmpty();
        _builder.append("\t\t");
        _builder.newLine();
        _builder.append("\t\t");
        String _name_24 = elem_3.getName();
        _builder.append(_name_24, "		");
        _builder.append(" = ");
        CharSequence _initializeField_2 = this.initializeField(elem_3);
        _builder.append(_initializeField_2, "		");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
        _builder.append("\t\t");
        _builder.append("scroll_");
        String _name_25 = elem_3.getName();
        _builder.append(_name_25, "		");
        _builder.append(".setViewportView(");
        String _name_26 = elem_3.getName();
        _builder.append(_name_26, "		");
        _builder.append(");");
        _builder.newLineIfNotEmpty();
        _builder.append("\t\t");
        _builder.newLine();
        {
          Integer _numberOfButtonsThereIsSpaceFor = GUIHelper.numberOfButtonsThereIsSpaceFor(elem_3);
          boolean _greaterThan = ((_numberOfButtonsThereIsSpaceFor).intValue() > 0);
          if (_greaterThan) {
            _builder.append("\t\t");
            _builder.append("//Button for List Element\t\t\t\t\t\t\t\t");
            _builder.newLine();
          }
        }
        _builder.append("\t\t");
        CharSequence _createAddButtonForField = this.createAddButtonForField(elem_3, window);
        _builder.append(_createAddButtonForField, "		");
        _builder.newLineIfNotEmpty();
        _builder.append("\t\t");
        CharSequence _createEditButtonForField = this.createEditButtonForField(elem_3, window);
        _builder.append(_createEditButtonForField, "		");
        _builder.newLineIfNotEmpty();
        _builder.append("\t\t");
        CharSequence _createDeleteButtonForField = this.createDeleteButtonForField(elem_3, window);
        _builder.append(_createDeleteButtonForField, "		");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    {
      EList<UIElement> _elements_4 = window.getElements();
      Iterable<Field> _filter_6 = Iterables.<Field>filter(_elements_4, Field.class);
      final Function1<Field,Boolean> _function_5 = new Function1<Field,Boolean>() {
        public Boolean apply(final Field it) {
          boolean _hasMultiValuedProperty = EntityHelper.hasMultiValuedProperty(it);
          return Boolean.valueOf(_hasMultiValuedProperty);
        }
      };
      Iterable<Field> _filter_7 = IterableExtensions.<Field>filter(_filter_6, _function_5);
      for(final Field elem_4 : _filter_7) {
        _builder.append("\t");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("public void ");
        CharSequence _listInitializeMethodName = this.listInitializeMethodName(elem_4);
        _builder.append(_listInitializeMethodName, "	");
        _builder.append("() {");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("\t");
        String _fieldName = this.fieldName(elem_4);
        _builder.append(_fieldName, "		");
        _builder.append(".setListData(new Vector<");
        Property _property_4 = elem_4.getProperty();
        Entity _type = ((Reference) _property_4).getType();
        String _name_27 = _type.getName();
        _builder.append(_name_27, "		");
        _builder.append(">(currentEntity.get");
        Property _property_5 = elem_4.getProperty();
        String _nameInJava = EntityHelper.nameInJava(_property_5);
        String _firstUpper = StringExtensions.toFirstUpper(_nameInJava);
        _builder.append(_firstUpper, "		");
        _builder.append("()));");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("}");
        _builder.newLine();
      }
    }
    {
      Entity _entity_11 = window.getEntity();
      Set<Entity> _listingTypes_1 = this.listingTypes(_entity_11);
      for(final Entity type : _listingTypes_1) {
        _builder.append("\t");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("@Override");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("public void ");
        String _listingInterfaceMethodeName_1 = EntityHelper.listingInterfaceMethodeName(type);
        _builder.append(_listingInterfaceMethodeName_1, "	");
        _builder.append("() {");
        _builder.newLineIfNotEmpty();
        {
          EList<UIElement> _elements_5 = window.getElements();
          Iterable<Field> _filter_8 = Iterables.<Field>filter(_elements_5, Field.class);
          final Function1<Field,Boolean> _function_6 = new Function1<Field,Boolean>() {
            public Boolean apply(final Field it) {
              boolean _hasMultiValuedProperty = EntityHelper.hasMultiValuedProperty(it);
              return Boolean.valueOf(_hasMultiValuedProperty);
            }
          };
          Iterable<Field> _filter_9 = IterableExtensions.<Field>filter(_filter_8, _function_6);
          final Function1<Field,Boolean> _function_7 = new Function1<Field,Boolean>() {
            public Boolean apply(final Field it) {
              Property _property = it.getProperty();
              Entity _type = ((Reference) _property).getType();
              boolean _equals = _type.equals(type);
              return Boolean.valueOf(_equals);
            }
          };
          Iterable<Field> _filter_10 = IterableExtensions.<Field>filter(_filter_9, _function_7);
          for(final Field elem_5 : _filter_10) {
            _builder.append("\t");
            _builder.append("\t");
            CharSequence _listInitializeMethodName_1 = this.listInitializeMethodName(elem_5);
            _builder.append(_listInitializeMethodName_1, "		");
            _builder.append("();");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("}");
        _builder.newLine();
      }
    }
    _builder.append("}");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Get types for all classes that are multi-referenced and thus a listing is presented within this window
   */
  public Set<Entity> listingTypes(final Entity entity) {
    Iterable<Reference> _multiReferences = EntityHelper.multiReferences(entity, true);
    final Function1<Reference,Entity> _function = new Function1<Reference,Entity>() {
      public Entity apply(final Reference it) {
        Entity _type = it.getType();
        return _type;
      }
    };
    Iterable<Entity> _map = IterableExtensions.<Reference, Entity>map(_multiReferences, _function);
    Set<Entity> _set = IterableExtensions.<Entity>toSet(_map);
    return _set;
  }
  
  public CharSequence initializeField(final Field f) {
    CharSequence _switchResult = null;
    Property _property = f.getProperty();
    final Property _switchValue = _property;
    boolean _matched = false;
    if (!_matched) {
      if (_switchValue instanceof Attribute) {
        final Attribute _attribute = (Attribute)_switchValue;
        _matched=true;
        StringConcatenation _builder = new StringConcatenation();
        _builder.append("new ");
        String _inputFieldType = this.inputFieldType(f);
        _builder.append(_inputFieldType, "");
        _builder.append("(");
        Property _property_1 = f.getProperty();
        String _formattedTextCode = this.getFormattedTextCode(((Attribute) _property_1));
        _builder.append(_formattedTextCode, "");
        _builder.append(")");
        _switchResult = _builder;
      }
    }
    if (!_matched) {
      if (_switchValue instanceof Reference) {
        final Reference _reference = (Reference)_switchValue;
        _matched=true;
        CharSequence _xifexpression = null;
        boolean _hasMultiValuedProperty = EntityHelper.hasMultiValuedProperty(f);
        if (_hasMultiValuedProperty) {
          StringConcatenation _builder = new StringConcatenation();
          _builder.append("new ");
          String _inputFieldType = this.inputFieldType(f);
          _builder.append(_inputFieldType, "");
          _builder.append("();");
          _builder.newLineIfNotEmpty();
          CharSequence _listInitializeMethodName = this.listInitializeMethodName(f);
          _builder.append(_listInitializeMethodName, "");
          _builder.append("()");
          _xifexpression = _builder;
        } else {
          StringConcatenation _builder_1 = new StringConcatenation();
          _builder_1.append("new ");
          String _inputFieldType_1 = this.inputFieldType(f);
          _builder_1.append(_inputFieldType_1, "");
          _builder_1.append("(new Vector<>(ServiceInitializer.getProvider().get");
          Property _property_1 = f.getProperty();
          Entity _type = ((Reference) _property_1).getType();
          String _serviceClassName = EntityHelper.serviceClassName(_type);
          _builder_1.append(_serviceClassName, "");
          _builder_1.append("().getAll()));");
          _builder_1.newLineIfNotEmpty();
          String _fieldName = this.fieldName(f);
          _builder_1.append(_fieldName, "");
          _builder_1.append(".setSelectedItem(currentEntity.get");
          Property _property_2 = f.getProperty();
          String _nameInJava = EntityHelper.nameInJava(_property_2);
          String _firstUpper = StringExtensions.toFirstUpper(_nameInJava);
          _builder_1.append(_firstUpper, "");
          _builder_1.append("())");
          _xifexpression = _builder_1;
        }
        _switchResult = _xifexpression;
      }
    }
    return _switchResult;
  }
  
  /**
   * get Input Field type
   */
  public String inputFieldType(final Field f) {
    String _switchResult = null;
    Property _property = f.getProperty();
    final Property _switchValue = _property;
    boolean _matched = false;
    if (!_matched) {
      if (_switchValue instanceof Attribute) {
        final Attribute _attribute = (Attribute)_switchValue;
        _matched=true;
        _switchResult = "JTextField";
      }
    }
    if (!_matched) {
      if (_switchValue instanceof Reference) {
        final Reference _reference = (Reference)_switchValue;
        _matched=true;
        String _xifexpression = null;
        boolean _hasSingleValuedProperty = EntityHelper.hasSingleValuedProperty(f);
        if (_hasSingleValuedProperty) {
          Property _property_1 = f.getProperty();
          Entity _type = ((Reference) _property_1).getType();
          String _importedType = this.importedType(_type);
          String _plus = ("JComboBox<" + _importedType);
          String _plus_1 = (_plus + ">");
          _xifexpression = _plus_1;
        } else {
          Property _property_2 = f.getProperty();
          Entity _type_1 = ((Reference) _property_2).getType();
          String _importedType_1 = this.importedType(_type_1);
          String _plus_2 = ("JList<" + _importedType_1);
          String _plus_3 = (_plus_2 + ">");
          _xifexpression = _plus_3;
        }
        _switchResult = _xifexpression;
      }
    }
    return _switchResult;
  }
  
  public String fieldName(final Field f) {
    String _name = f.getName();
    return _name;
  }
  
  public String labelName(final Label l) {
    String _text = l.getText();
    boolean _notEquals = (!Objects.equal(_text, null));
    if (_notEquals) {
      return l.getText();
    }
    return GUIHelper.readableLabel(l);
  }
  
  /**
   * get code for formatted text representation of property value
   */
  public String getFormattedTextCode(final Attribute a) {
    String _xblockexpression = null;
    {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("currentEntity.get");
      String _nameInJava = EntityHelper.nameInJava(a);
      String _firstUpper = StringExtensions.toFirstUpper(_nameInJava);
      _builder.append(_firstUpper, "");
      _builder.append("()");
      final String getValue = _builder.toString();
      String result = getValue;
      boolean _isDate = EntityHelper.isDate(a);
      if (_isDate) {
        StringConcatenation _builder_1 = new StringConcatenation();
        _builder_1.append("Util.DATE_TIME_FORMATTER.format(");
        _builder_1.append(result, "");
        _builder_1.append(")");
        result = _builder_1.toString();
      } else {
        boolean _isNumberObject = EntityHelper.isNumberObject(a);
        if (_isNumberObject) {
          StringConcatenation _builder_2 = new StringConcatenation();
          _builder_2.append(getValue, "");
          _builder_2.append(".toString()");
          result = _builder_2.toString();
        } else {
          boolean _isString = EntityHelper.isString(a);
          boolean _not = (!_isString);
          if (_not) {
            StringConcatenation _builder_3 = new StringConcatenation();
            _builder_3.append("String.valueOf(");
            _builder_3.append(result, "");
            _builder_3.append(")");
            result = _builder_3.toString();
          }
        }
      }
      boolean _isObject = EntityHelper.isObject(a);
      if (_isObject) {
        StringConcatenation _builder_4 = new StringConcatenation();
        _builder_4.append(getValue, "");
        _builder_4.append(" != null ? ");
        _builder_4.append(result, "");
        _builder_4.append(" : \"\"");
        result = _builder_4.toString();
      }
      _xblockexpression = (result);
    }
    return _xblockexpression;
  }
  
  /**
   * generates code to retrieve value from imput field
   */
  public CharSequence retrieveValueFromFieldCode(final Field f) {
    CharSequence _xblockexpression = null;
    {
      boolean _hasSingleValuedReference = EntityHelper.hasSingleValuedReference(f);
      if (_hasSingleValuedReference) {
        StringConcatenation _builder = new StringConcatenation();
        String _fieldName = this.fieldName(f);
        _builder.append(_fieldName, "");
        _builder.append(".getItemAt(");
        String _fieldName_1 = this.fieldName(f);
        _builder.append(_fieldName_1, "");
        _builder.append(".getSelectedIndex())");
        return _builder.toString();
      }
      StringConcatenation _builder_1 = new StringConcatenation();
      String _fieldName_2 = this.fieldName(f);
      _builder_1.append(_fieldName_2, "");
      _builder_1.append(".getText()");
      final String getText = _builder_1.toString();
      String result = getText;
      Property _property = f.getProperty();
      if ((_property instanceof Attribute)) {
        Property _property_1 = f.getProperty();
        boolean _isDate = EntityHelper.isDate(((Attribute) _property_1));
        if (_isDate) {
          StringConcatenation _builder_2 = new StringConcatenation();
          _builder_2.append("Util.DATE_TIME_FORMATTER.parse(");
          _builder_2.append(result, "");
          _builder_2.append(")");
          result = _builder_2.toString();
        } else {
          Property _property_2 = f.getProperty();
          boolean _isString = EntityHelper.isString(((Attribute) _property_2));
          boolean _not = (!_isString);
          if (_not) {
            StringConcatenation _builder_3 = new StringConcatenation();
            Property _property_3 = f.getProperty();
            String _typeInJava = EntityHelper.typeInJava(((Attribute) _property_3));
            String _objectType = EntityHelper.objectType(_typeInJava);
            _builder_3.append(_objectType, "");
            _builder_3.append(".valueOf(");
            _builder_3.append(result, "");
            _builder_3.append(")");
            result = _builder_3.toString();
          }
        }
      }
      StringConcatenation _builder_4 = new StringConcatenation();
      _builder_4.append(getText, "");
      _builder_4.append(".isEmpty() ? null : ");
      _builder_4.append(result, "");
      _xblockexpression = (_builder_4);
    }
    return _xblockexpression;
  }
  
  public CharSequence listInitializeMethodName(final Field f) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("initialize");
    String _name = f.getName();
    String _firstUpper = StringExtensions.toFirstUpper(_name);
    _builder.append(_firstUpper, "");
    return _builder;
  }
  
  public CharSequence createAddButtonForField(final Field field, final Window window) {
    CharSequence _xifexpression = null;
    Integer _numberOfButtonsThereIsSpaceFor = GUIHelper.numberOfButtonsThereIsSpaceFor(field);
    boolean _greaterThan = ((_numberOfButtonsThereIsSpaceFor).intValue() > 0);
    if (_greaterThan) {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("JButton ");
      CharSequence _addButtonName = GUIHelper.getAddButtonName(field);
      _builder.append(_addButtonName, "");
      _builder.append(" = new JButton(\"Add\");");
      _builder.newLineIfNotEmpty();
      _builder.append("\t\t\t\t\t\t\t");
      CharSequence _addButtonName_1 = GUIHelper.getAddButtonName(field);
      _builder.append(_addButtonName_1, "							");
      _builder.append(".setEnabled(!currentEntity.isNew());");
      _builder.newLineIfNotEmpty();
      _builder.append("\t\t\t\t\t\t\t");
      CharSequence _addButtonName_2 = GUIHelper.getAddButtonName(field);
      _builder.append(_addButtonName_2, "							");
      _builder.append(".setBounds(");
      Bounds _bounds = field.getBounds();
      int _x = _bounds.getX();
      _builder.append(_x, "							");
      _builder.append(",");
      Bounds _bounds_1 = field.getBounds();
      int _y = _bounds_1.getY();
      Bounds _bounds_2 = field.getBounds();
      int _height = _bounds_2.getHeight();
      int _plus = (_y + _height);
      int _minus = (_plus - 20);
      _builder.append(_minus, "							");
      _builder.append(",");
      Bounds _bounds_3 = field.getBounds();
      int _width = _bounds_3.getWidth();
      Integer _numberOfButtonsThereIsSpaceFor_1 = GUIHelper.numberOfButtonsThereIsSpaceFor(field);
      int _minus_1 = ((_numberOfButtonsThereIsSpaceFor_1).intValue() - 1);
      int _multiply = (_minus_1 * 5);
      int _minus_2 = (_width - _multiply);
      Integer _numberOfButtonsThereIsSpaceFor_2 = GUIHelper.numberOfButtonsThereIsSpaceFor(field);
      int _divide = (_minus_2 / (_numberOfButtonsThereIsSpaceFor_2).intValue());
      _builder.append(_divide, "							");
      _builder.append(",20);");
      _builder.newLineIfNotEmpty();
      _builder.append("\t\t\t\t\t\t\t");
      _builder.append("getPanel().add(");
      CharSequence _addButtonName_3 = GUIHelper.getAddButtonName(field);
      _builder.append(_addButtonName_3, "							");
      _builder.append(");");
      _builder.newLineIfNotEmpty();
      _builder.append("\t\t\t\t\t\t\t");
      CharSequence _addButtonName_4 = GUIHelper.getAddButtonName(field);
      _builder.append(_addButtonName_4, "							");
      _builder.append(".addActionListener(new ActionListener() {");
      _builder.newLineIfNotEmpty();
      _builder.append("\t\t\t\t\t\t\t\t");
      _builder.append("@Override");
      _builder.newLine();
      _builder.append("\t\t\t\t\t\t\t\t");
      _builder.append("public void actionPerformed(ActionEvent e) {");
      _builder.newLine();
      {
        Property _property = field.getProperty();
        Entity _type = ((Reference) _property).getType();
        boolean _hasSubClasses = EntityHelper.hasSubClasses(_type);
        if (_hasSubClasses) {
          _builder.append("\t\t\t\t\t\t\t\t\t");
          Property _property_1 = field.getProperty();
          Entity _type_1 = ((Reference) _property_1).getType();
          String _name = _type_1.getName();
          _builder.append(_name, "									");
          _builder.append(" entity = null;");
          _builder.newLineIfNotEmpty();
          {
            Property _property_2 = field.getProperty();
            Entity _type_2 = ((Reference) _property_2).getType();
            Iterable<Entity> _instantiableClasses = EntityHelper.getInstantiableClasses(_type_2);
            for(final Entity subClass : _instantiableClasses) {
              _builder.append("\t\t\t\t\t\t\t\t\t");
              _builder.append("if(");
              String _entryWindowClassName = EntityHelper.entryWindowClassName(subClass);
              _builder.append(_entryWindowClassName, "									");
              _builder.append(".this.");
              Property _property_3 = field.getProperty();
              CharSequence _inheritanceTypeSelectName = GUIHelper.inheritanceTypeSelectName(((Reference) _property_3));
              _builder.append(_inheritanceTypeSelectName, "									");
              _builder.append(".getSelectedItem().equals(\"");
              String _importedType = this.importedType(subClass);
              _builder.append(_importedType, "									");
              _builder.append("\"))");
              _builder.newLineIfNotEmpty();
              _builder.append("\t\t\t\t\t\t\t\t\t");
              _builder.append("\t");
              _builder.append("entity = new ");
              String _name_1 = subClass.getName();
              _builder.append(_name_1, "										");
              _builder.append("().");
              Property _property_4 = field.getProperty();
              Reference _opposite = ((Reference) _property_4).getOpposite();
              String _initializeSingleRefMethodName = EntityHelper.initializeSingleRefMethodName(_opposite);
              _builder.append(_initializeSingleRefMethodName, "										");
              _builder.append("(currentEntity);");
              _builder.newLineIfNotEmpty();
            }
          }
          _builder.append("\t\t\t\t\t\t\t\t\t");
          Property _property_5 = field.getProperty();
          Entity _type_3 = ((Reference) _property_5).getType();
          Property _property_6 = field.getProperty();
          Entity _type_4 = ((Reference) _property_6).getType();
          String _entryWindowClassName_1 = EntityHelper.entryWindowClassName(_type_4);
          String _plus_1 = (_entryWindowClassName_1 + ".this");
          CharSequence _inheritanceCallOpenEntryWindow = GUIHelper.inheritanceCallOpenEntryWindow(_type_3, _plus_1);
          _builder.append(_inheritanceCallOpenEntryWindow, "									");
          _builder.newLineIfNotEmpty();
        } else {
          _builder.append("\t\t\t\t\t\t\t\t\t");
          _builder.append("new ");
          Property _property_7 = field.getProperty();
          Entity _type_5 = ((Reference) _property_7).getType();
          String _entryWindowClassName_2 = EntityHelper.entryWindowClassName(_type_5);
          _builder.append(_entryWindowClassName_2, "									");
          _builder.append("(");
          String _name_2 = window.getName();
          _builder.append(_name_2, "									");
          _builder.append(".this, new ");
          Property _property_8 = field.getProperty();
          Entity _type_6 = ((Reference) _property_8).getType();
          String _name_3 = _type_6.getName();
          _builder.append(_name_3, "									");
          _builder.append("().");
          Property _property_9 = field.getProperty();
          Reference _opposite_1 = ((Reference) _property_9).getOpposite();
          String _initializeSingleRefMethodName_1 = EntityHelper.initializeSingleRefMethodName(_opposite_1);
          _builder.append(_initializeSingleRefMethodName_1, "									");
          _builder.append("(currentEntity)).open();");
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.append("\t\t\t\t\t\t\t\t");
      _builder.append("}");
      _builder.newLine();
      _builder.append("\t\t\t\t\t\t\t");
      _builder.append("});");
      _xifexpression = _builder;
    }
    return _xifexpression;
  }
  
  public CharSequence createEditButtonForField(final Field field, final Window window) {
    CharSequence _xifexpression = null;
    Integer _numberOfButtonsThereIsSpaceFor = GUIHelper.numberOfButtonsThereIsSpaceFor(field);
    boolean _greaterThan = ((_numberOfButtonsThereIsSpaceFor).intValue() > 1);
    if (_greaterThan) {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("JButton ");
      CharSequence _editButtonName = GUIHelper.getEditButtonName(field);
      _builder.append(_editButtonName, "");
      _builder.append(" = new JButton(\"Edit\");");
      _builder.newLineIfNotEmpty();
      _builder.append("\t\t\t\t\t\t\t");
      CharSequence _editButtonName_1 = GUIHelper.getEditButtonName(field);
      _builder.append(_editButtonName_1, "							");
      _builder.append(".setBounds(");
      Bounds _bounds = field.getBounds();
      int _x = _bounds.getX();
      Bounds _bounds_1 = field.getBounds();
      int _width = _bounds_1.getWidth();
      Integer _numberOfButtonsThereIsSpaceFor_1 = GUIHelper.numberOfButtonsThereIsSpaceFor(field);
      int _minus = ((_numberOfButtonsThereIsSpaceFor_1).intValue() - 1);
      int _multiply = (_minus * 5);
      int _minus_1 = (_width - _multiply);
      Integer _numberOfButtonsThereIsSpaceFor_2 = GUIHelper.numberOfButtonsThereIsSpaceFor(field);
      int _divide = (_minus_1 / (_numberOfButtonsThereIsSpaceFor_2).intValue());
      int _plus = (_x + _divide);
      int _plus_1 = (_plus + 5);
      _builder.append(_plus_1, "							");
      _builder.append(",");
      Bounds _bounds_2 = field.getBounds();
      int _y = _bounds_2.getY();
      Bounds _bounds_3 = field.getBounds();
      int _height = _bounds_3.getHeight();
      int _plus_2 = (_y + _height);
      int _minus_2 = (_plus_2 - 20);
      _builder.append(_minus_2, "							");
      _builder.append(",");
      Bounds _bounds_4 = field.getBounds();
      int _width_1 = _bounds_4.getWidth();
      Integer _numberOfButtonsThereIsSpaceFor_3 = GUIHelper.numberOfButtonsThereIsSpaceFor(field);
      int _minus_3 = ((_numberOfButtonsThereIsSpaceFor_3).intValue() - 1);
      int _multiply_1 = (_minus_3 * 5);
      int _minus_4 = (_width_1 - _multiply_1);
      Integer _numberOfButtonsThereIsSpaceFor_4 = GUIHelper.numberOfButtonsThereIsSpaceFor(field);
      int _divide_1 = (_minus_4 / (_numberOfButtonsThereIsSpaceFor_4).intValue());
      _builder.append(_divide_1, "							");
      _builder.append(",20);");
      _builder.newLineIfNotEmpty();
      _builder.append("\t\t\t\t\t\t\t");
      CharSequence _editButtonName_2 = GUIHelper.getEditButtonName(field);
      _builder.append(_editButtonName_2, "							");
      _builder.append(".setEnabled(!currentEntity.isNew());");
      _builder.newLineIfNotEmpty();
      _builder.append("\t\t\t\t\t\t\t");
      _builder.append("getPanel().add(");
      CharSequence _editButtonName_3 = GUIHelper.getEditButtonName(field);
      _builder.append(_editButtonName_3, "							");
      _builder.append(");");
      _builder.newLineIfNotEmpty();
      _builder.append("\t\t\t\t\t\t\t");
      CharSequence _editButtonName_4 = GUIHelper.getEditButtonName(field);
      _builder.append(_editButtonName_4, "							");
      _builder.append(".addActionListener(new ActionListener() {");
      _builder.newLineIfNotEmpty();
      _builder.append("\t\t\t\t\t\t\t\t");
      _builder.append("@Override");
      _builder.newLine();
      _builder.append("\t\t\t\t\t\t\t\t");
      _builder.append("public void actionPerformed(ActionEvent e) {");
      _builder.newLine();
      _builder.append("\t\t\t\t\t\t\t\t\t");
      Property _property = field.getProperty();
      Entity _type = ((Reference) _property).getType();
      String _name = _type.getName();
      _builder.append(_name, "									");
      _builder.append(" entity = ");
      String _name_1 = window.getName();
      _builder.append(_name_1, "									");
      _builder.append(".this.");
      String _fieldName = this.fieldName(field);
      _builder.append(_fieldName, "									");
      _builder.append(".getSelectedValue();");
      _builder.newLineIfNotEmpty();
      _builder.append("\t\t\t\t\t\t\t\t\t");
      _builder.append("if(entity == null)");
      _builder.newLine();
      _builder.append("\t\t\t\t\t\t\t\t\t\t");
      _builder.append("Util.showNothingSelected();");
      _builder.newLine();
      _builder.append("\t\t\t\t\t\t\t\t\t");
      _builder.append("else");
      _builder.newLine();
      {
        Property _property_1 = field.getProperty();
        Entity _type_1 = ((Reference) _property_1).getType();
        boolean _hasSubClasses = EntityHelper.hasSubClasses(_type_1);
        if (_hasSubClasses) {
          _builder.append("\t\t\t\t\t\t\t\t\t\t");
          Property _property_2 = field.getProperty();
          Entity _type_2 = ((Reference) _property_2).getType();
          Property _property_3 = field.getProperty();
          Entity _type_3 = ((Reference) _property_3).getType();
          String _entryWindowClassName = EntityHelper.entryWindowClassName(_type_3);
          String _plus_3 = (_entryWindowClassName + ".this");
          CharSequence _inheritanceCallOpenEntryWindow = GUIHelper.inheritanceCallOpenEntryWindow(_type_2, _plus_3);
          _builder.append(_inheritanceCallOpenEntryWindow, "										");
          _builder.newLineIfNotEmpty();
        } else {
          _builder.append("\t\t\t\t\t\t\t\t\t\t");
          _builder.append("new ");
          Property _property_4 = field.getProperty();
          Entity _type_4 = ((Reference) _property_4).getType();
          String _entryWindowClassName_1 = EntityHelper.entryWindowClassName(_type_4);
          _builder.append(_entryWindowClassName_1, "										");
          _builder.append("(");
          String _name_2 = window.getName();
          _builder.append(_name_2, "										");
          _builder.append(".this, entity).open();");
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.append("\t\t\t\t\t\t\t\t");
      _builder.append("}");
      _builder.newLine();
      _builder.append("\t\t\t\t\t\t\t");
      _builder.append("});");
      _xifexpression = _builder;
    }
    return _xifexpression;
  }
  
  public CharSequence createDeleteButtonForField(final Field field, final Window window) {
    CharSequence _xifexpression = null;
    Integer _numberOfButtonsThereIsSpaceFor = GUIHelper.numberOfButtonsThereIsSpaceFor(field);
    boolean _greaterThan = ((_numberOfButtonsThereIsSpaceFor).intValue() > 2);
    if (_greaterThan) {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("\t\t\t\t\t\t\t");
      _builder.append("JButton ");
      CharSequence _deleteButtonName = GUIHelper.getDeleteButtonName(field);
      _builder.append(_deleteButtonName, "							");
      _builder.append(" = new JButton(\"Delete\");");
      _builder.newLineIfNotEmpty();
      _builder.append("\t\t\t\t\t\t\t");
      CharSequence _deleteButtonName_1 = GUIHelper.getDeleteButtonName(field);
      _builder.append(_deleteButtonName_1, "							");
      _builder.append(".setEnabled(false);");
      _builder.newLineIfNotEmpty();
      _builder.append("\t\t\t\t\t\t\t");
      CharSequence _deleteButtonName_2 = GUIHelper.getDeleteButtonName(field);
      _builder.append(_deleteButtonName_2, "							");
      _builder.append(".setBounds(");
      Bounds _bounds = field.getBounds();
      int _x = _bounds.getX();
      Bounds _bounds_1 = field.getBounds();
      int _width = _bounds_1.getWidth();
      Integer _numberOfButtonsThereIsSpaceFor_1 = GUIHelper.numberOfButtonsThereIsSpaceFor(field);
      int _minus = ((_numberOfButtonsThereIsSpaceFor_1).intValue() - 1);
      int _multiply = (_minus * 5);
      int _minus_1 = (_width - _multiply);
      Integer _numberOfButtonsThereIsSpaceFor_2 = GUIHelper.numberOfButtonsThereIsSpaceFor(field);
      int _divide = (_minus_1 / (_numberOfButtonsThereIsSpaceFor_2).intValue());
      int _multiply_1 = (2 * _divide);
      int _plus = (_x + _multiply_1);
      Integer _numberOfButtonsThereIsSpaceFor_3 = GUIHelper.numberOfButtonsThereIsSpaceFor(field);
      int _minus_2 = ((_numberOfButtonsThereIsSpaceFor_3).intValue() - 1);
      int _multiply_2 = (_minus_2 * 5);
      int _plus_1 = (_plus + _multiply_2);
      _builder.append(_plus_1, "							");
      _builder.append(",");
      Bounds _bounds_2 = field.getBounds();
      int _y = _bounds_2.getY();
      Bounds _bounds_3 = field.getBounds();
      int _height = _bounds_3.getHeight();
      int _plus_2 = (_y + _height);
      int _minus_3 = (_plus_2 - 20);
      _builder.append(_minus_3, "							");
      _builder.append(",");
      Bounds _bounds_4 = field.getBounds();
      int _width_1 = _bounds_4.getWidth();
      Integer _numberOfButtonsThereIsSpaceFor_4 = GUIHelper.numberOfButtonsThereIsSpaceFor(field);
      int _minus_4 = ((_numberOfButtonsThereIsSpaceFor_4).intValue() - 1);
      int _multiply_3 = (_minus_4 * 5);
      int _minus_5 = (_width_1 - _multiply_3);
      Integer _numberOfButtonsThereIsSpaceFor_5 = GUIHelper.numberOfButtonsThereIsSpaceFor(field);
      int _divide_1 = (_minus_5 / (_numberOfButtonsThereIsSpaceFor_5).intValue());
      _builder.append(_divide_1, "							");
      _builder.append(",20);");
      _builder.newLineIfNotEmpty();
      _builder.append("\t\t\t\t\t\t\t");
      _builder.append("getPanel().add(");
      CharSequence _deleteButtonName_3 = GUIHelper.getDeleteButtonName(field);
      _builder.append(_deleteButtonName_3, "							");
      _builder.append(");");
      _xifexpression = _builder;
    }
    return _xifexpression;
  }
}
