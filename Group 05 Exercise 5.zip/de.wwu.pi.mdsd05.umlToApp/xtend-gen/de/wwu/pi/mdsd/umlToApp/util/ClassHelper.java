package de.wwu.pi.mdsd.umlToApp.util;

import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import de.wwu.pi.mdsd.umlToApp.util.ModelAndPackageHelper;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import org.eclipse.emf.common.util.EList;
import org.eclipse.uml2.uml.Element;
import org.eclipse.uml2.uml.Model;
import org.eclipse.uml2.uml.Property;
import org.eclipse.uml2.uml.Type;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.StringExtensions;

@SuppressWarnings("all")
public class ClassHelper {
  public static String serviceClassName(final Type clazz) {
    String _name = clazz.getName();
    String _plus = (_name + "Service");
    return _plus;
  }
  
  public static String initializeSingleRefMethodName(final Property ref) {
    String _name = ref.getName();
    String _firstUpper = StringExtensions.toFirstUpper(_name);
    String _plus = ("initialize" + _firstUpper);
    return _plus;
  }
  
  public static boolean isDate(final Property p) {
    Type _type = p.getType();
    String _name = _type.getName();
    boolean _equals = "Date".equals(_name);
    return _equals;
  }
  
  public static boolean isString(final Property p) {
    Type _type = p.getType();
    String _name = _type.getName();
    boolean _equals = "String".equals(_name);
    return _equals;
  }
  
  public static boolean isNumberObject(final Property p) {
    Type _type = p.getType();
    String _name = _type.getName();
    boolean _equals = "Integer".equals(_name);
    return _equals;
  }
  
  protected static boolean _isEntity(final Element element) {
    return false;
  }
  
  protected static boolean _isEntity(final org.eclipse.uml2.uml.Class clazz) {
    return true;
  }
  
  public static boolean hasExplicitSuperClass(final org.eclipse.uml2.uml.Class clazz) {
    EList<org.eclipse.uml2.uml.Class> _superClasses = clazz.getSuperClasses();
    boolean _isEmpty = _superClasses.isEmpty();
    boolean _not = (!_isEmpty);
    return _not;
  }
  
  public static org.eclipse.uml2.uml.Class superClass(final org.eclipse.uml2.uml.Class clazz) {
    org.eclipse.uml2.uml.Class _xifexpression = null;
    boolean _hasExplicitSuperClass = ClassHelper.hasExplicitSuperClass(clazz);
    if (_hasExplicitSuperClass) {
      EList<org.eclipse.uml2.uml.Class> _superClasses = clazz.getSuperClasses();
      org.eclipse.uml2.uml.Class _head = IterableExtensions.<org.eclipse.uml2.uml.Class>head(_superClasses);
      _xifexpression = _head;
    }
    return _xifexpression;
  }
  
  public static Iterable<org.eclipse.uml2.uml.Class> allSuperClasses(final org.eclipse.uml2.uml.Class clazz) {
    Iterable<org.eclipse.uml2.uml.Class> _xifexpression = null;
    boolean _hasExplicitSuperClass = ClassHelper.hasExplicitSuperClass(clazz);
    if (_hasExplicitSuperClass) {
      org.eclipse.uml2.uml.Class _superClass = ClassHelper.superClass(clazz);
      Iterable<org.eclipse.uml2.uml.Class> _allSuperClasses = ClassHelper.allSuperClasses(_superClass);
      org.eclipse.uml2.uml.Class _superClass_1 = ClassHelper.superClass(clazz);
      Iterable<org.eclipse.uml2.uml.Class> _plus = Iterables.<org.eclipse.uml2.uml.Class>concat(_allSuperClasses, Collections.<org.eclipse.uml2.uml.Class>unmodifiableList(Lists.<org.eclipse.uml2.uml.Class>newArrayList(_superClass_1)));
      _xifexpression = _plus;
    } else {
      List<org.eclipse.uml2.uml.Class> _emptyList = CollectionLiterals.<org.eclipse.uml2.uml.Class>emptyList();
      _xifexpression = _emptyList;
    }
    return _xifexpression;
  }
  
  public static Iterable<org.eclipse.uml2.uml.Class> getDirectSubClasses(final org.eclipse.uml2.uml.Class clazz) {
    Model _model = clazz.getModel();
    Iterable<org.eclipse.uml2.uml.Class> _allEntities = ModelAndPackageHelper.allEntities(_model);
    final Function1<org.eclipse.uml2.uml.Class,Boolean> _function = new Function1<org.eclipse.uml2.uml.Class,Boolean>() {
      public Boolean apply(final org.eclipse.uml2.uml.Class it) {
        org.eclipse.uml2.uml.Class _superClass = ClassHelper.superClass(it);
        boolean _equals = Objects.equal(_superClass, clazz);
        return Boolean.valueOf(_equals);
      }
    };
    Iterable<org.eclipse.uml2.uml.Class> _filter = IterableExtensions.<org.eclipse.uml2.uml.Class>filter(_allEntities, _function);
    return _filter;
  }
  
  public static boolean hasSubClasses(final org.eclipse.uml2.uml.Class clazz) {
    Iterable<org.eclipse.uml2.uml.Class> _directSubClasses = ClassHelper.getDirectSubClasses(clazz);
    int _size = IterableExtensions.size(_directSubClasses);
    boolean _greaterThan = (_size > 0);
    return _greaterThan;
  }
  
  public static Iterable<org.eclipse.uml2.uml.Class> getInstantiableClasses(final org.eclipse.uml2.uml.Class clazz) {
    LinkedList<org.eclipse.uml2.uml.Class> _newLinkedList = CollectionLiterals.<org.eclipse.uml2.uml.Class>newLinkedList(clazz);
    Iterable<org.eclipse.uml2.uml.Class> _directSubClasses = ClassHelper.getDirectSubClasses(clazz);
    final Function1<org.eclipse.uml2.uml.Class,Iterable<org.eclipse.uml2.uml.Class>> _function = new Function1<org.eclipse.uml2.uml.Class,Iterable<org.eclipse.uml2.uml.Class>>() {
      public Iterable<org.eclipse.uml2.uml.Class> apply(final org.eclipse.uml2.uml.Class cl) {
        Iterable<org.eclipse.uml2.uml.Class> _instantiableClasses = ClassHelper.getInstantiableClasses(cl);
        return _instantiableClasses;
      }
    };
    Iterable<Iterable<org.eclipse.uml2.uml.Class>> _map = IterableExtensions.<org.eclipse.uml2.uml.Class, Iterable<org.eclipse.uml2.uml.Class>>map(_directSubClasses, _function);
    Iterable<org.eclipse.uml2.uml.Class> _flatten = Iterables.<org.eclipse.uml2.uml.Class>concat(_map);
    Iterable<org.eclipse.uml2.uml.Class> _plus = Iterables.<org.eclipse.uml2.uml.Class>concat(_newLinkedList, _flatten);
    final Function1<org.eclipse.uml2.uml.Class,Boolean> _function_1 = new Function1<org.eclipse.uml2.uml.Class,Boolean>() {
      public Boolean apply(final org.eclipse.uml2.uml.Class cl) {
        boolean _isAbstract = cl.isAbstract();
        boolean _not = (!_isAbstract);
        return Boolean.valueOf(_not);
      }
    };
    Iterable<org.eclipse.uml2.uml.Class> _filter = IterableExtensions.<org.eclipse.uml2.uml.Class>filter(_plus, _function_1);
    Set<org.eclipse.uml2.uml.Class> _set = IterableExtensions.<org.eclipse.uml2.uml.Class>toSet(_filter);
    return _set;
  }
  
  protected static Iterable<Property> _attributes(final Void x, final boolean considerSuperclass) {
    List<Property> _emptyList = CollectionLiterals.<Property>emptyList();
    return _emptyList;
  }
  
  protected static Iterable<Property> _attributes(final org.eclipse.uml2.uml.Class clazz, final boolean considerSuperclass) {
    Iterable<Property> _xifexpression = null;
    boolean _and = false;
    if (!considerSuperclass) {
      _and = false;
    } else {
      boolean _hasExplicitSuperClass = ClassHelper.hasExplicitSuperClass(clazz);
      _and = (considerSuperclass && _hasExplicitSuperClass);
    }
    if (_and) {
      org.eclipse.uml2.uml.Class _superClass = ClassHelper.superClass(clazz);
      Iterable<Property> _attributes = ClassHelper.attributes(_superClass, true);
      EList<Property> _attributes_1 = clazz.getAttributes();
      Iterable<Property> _plus = Iterables.<Property>concat(_attributes, _attributes_1);
      _xifexpression = _plus;
    } else {
      EList<Property> _attributes_2 = clazz.getAttributes();
      _xifexpression = _attributes_2;
    }
    return _xifexpression;
  }
  
  public static Iterable<Property> primitiveAttributes(final org.eclipse.uml2.uml.Class clazz, final boolean considerSuperclass) {
    Iterable<Property> _attributes = ClassHelper.attributes(clazz, considerSuperclass);
    final Function1<Property,Boolean> _function = new Function1<Property,Boolean>() {
      public Boolean apply(final Property it) {
        boolean _and = false;
        boolean _isMultivalued = it.isMultivalued();
        boolean _not = (!_isMultivalued);
        if (!_not) {
          _and = false;
        } else {
          Type _type = it.getType();
          boolean _isEntity = ClassHelper.isEntity(_type);
          boolean _not_1 = (!_isEntity);
          _and = (_not && _not_1);
        }
        return Boolean.valueOf(_and);
      }
    };
    Iterable<Property> _filter = IterableExtensions.<Property>filter(_attributes, _function);
    return _filter;
  }
  
  public static Iterable<Property> entityReferences(final org.eclipse.uml2.uml.Class clazz, final boolean considerSuperclass) {
    Iterable<Property> _attributes = ClassHelper.attributes(clazz, considerSuperclass);
    final Function1<Property,Boolean> _function = new Function1<Property,Boolean>() {
      public Boolean apply(final Property it) {
        Type _type = it.getType();
        boolean _isEntity = ClassHelper.isEntity(_type);
        return Boolean.valueOf(_isEntity);
      }
    };
    Iterable<Property> _filter = IterableExtensions.<Property>filter(_attributes, _function);
    return _filter;
  }
  
  public static Iterable<Property> singleReferences(final org.eclipse.uml2.uml.Class clazz, final boolean considerSuperclass) {
    Iterable<Property> _entityReferences = ClassHelper.entityReferences(clazz, considerSuperclass);
    final Function1<Property,Boolean> _function = new Function1<Property,Boolean>() {
      public Boolean apply(final Property it) {
        boolean _isMultivalued = it.isMultivalued();
        boolean _not = (!_isMultivalued);
        return Boolean.valueOf(_not);
      }
    };
    Iterable<Property> _filter = IterableExtensions.<Property>filter(_entityReferences, _function);
    return _filter;
  }
  
  public static Iterable<Property> multiReferences(final org.eclipse.uml2.uml.Class clazz, final boolean considerSuperclass) {
    Iterable<Property> _entityReferences = ClassHelper.entityReferences(clazz, considerSuperclass);
    final Function1<Property,Boolean> _function = new Function1<Property,Boolean>() {
      public Boolean apply(final Property it) {
        boolean _isMultivalued = it.isMultivalued();
        return Boolean.valueOf(_isMultivalued);
      }
    };
    Iterable<Property> _filter = IterableExtensions.<Property>filter(_entityReferences, _function);
    return _filter;
  }
  
  /**
   * primitive attributes and single References
   */
  public static Iterable<Property> singleValueProperties(final org.eclipse.uml2.uml.Class clazz, final boolean considerSuperclass) {
    Iterable<Property> _primitiveAttributes = ClassHelper.primitiveAttributes(clazz, considerSuperclass);
    Iterable<Property> _singleReferences = ClassHelper.singleReferences(clazz, considerSuperclass);
    Iterable<Property> _plus = Iterables.<Property>concat(_primitiveAttributes, _singleReferences);
    return _plus;
  }
  
  public static Iterable<Property> required(final Iterable<Property> properties) {
    final Function1<Property,Boolean> _function = new Function1<Property,Boolean>() {
      public Boolean apply(final Property it) {
        boolean _isRequired = ClassHelper.isRequired(it);
        return Boolean.valueOf(_isRequired);
      }
    };
    Iterable<Property> _filter = IterableExtensions.<Property>filter(properties, _function);
    return _filter;
  }
  
  public static boolean isRequired(final Property p) {
    int _lowerBound = p.lowerBound();
    boolean _greaterEqualsThan = (_lowerBound >= 1);
    return _greaterEqualsThan;
  }
  
  public static Iterable<Property> requiredProperties(final org.eclipse.uml2.uml.Class clazz, final boolean considerSuperclass) {
    Iterable<Property> _xifexpression = null;
    if (considerSuperclass) {
      org.eclipse.uml2.uml.Class _superClass = ClassHelper.superClass(clazz);
      Iterable<Property> _singleValueProperties = ClassHelper.singleValueProperties(_superClass, considerSuperclass);
      Iterable<Property> _required = ClassHelper.required(_singleValueProperties);
      _xifexpression = _required;
    } else {
      List<Property> _emptyList = CollectionLiterals.<Property>emptyList();
      _xifexpression = _emptyList;
    }
    Iterable<Property> _singleValueProperties_1 = ClassHelper.singleValueProperties(clazz, false);
    Iterable<Property> _required_1 = ClassHelper.required(_singleValueProperties_1);
    Iterable<Property> _plus = Iterables.<Property>concat(_xifexpression, _required_1);
    return _plus;
  }
  
  public static CharSequence typeAndNameInJava(final Property p) {
    StringConcatenation _builder = new StringConcatenation();
    String _typeInJava = ClassHelper.typeInJava(p);
    _builder.append(_typeInJava, "");
    _builder.append(" ");
    String _nameInJava = ClassHelper.nameInJava(p);
    _builder.append(_nameInJava, "");
    return _builder;
  }
  
  /**
   * get the type representation of properties in Java
   * incl. multivalue type e.g. multivalued properties as List<p.javaType>
   */
  public static String typeInJava(final Property p) {
    String _xifexpression = null;
    boolean _isMultivalued = p.isMultivalued();
    if (_isMultivalued) {
      Type _type = p.getType();
      String _javaType = ClassHelper.javaType(_type);
      String _plus = ("List<" + _javaType);
      String _plus_1 = (_plus + ">");
      _xifexpression = _plus_1;
    } else {
      Type _type_1 = p.getType();
      String _javaType_1 = ClassHelper.javaType(_type_1);
      _xifexpression = _javaType_1;
    }
    return _xifexpression;
  }
  
  public static String javaType(final Type type) {
    String _name = type.getName();
    return _name;
  }
  
  public static String nameInJava(final Property p) {
    String _name = p.getName();
    return _name;
  }
  
  /**
   * get java object type for primitive java types
   */
  public static String objectType(final String javaType) {
    String _switchResult = null;
    boolean _matched = false;
    if (!_matched) {
      if (Objects.equal(javaType,"boolean")) {
        _matched=true;
        _switchResult = "Boolean";
      }
    }
    if (!_matched) {
      if (Objects.equal(javaType,"int")) {
        _matched=true;
        _switchResult = "Integer";
      }
    }
    if (!_matched) {
      if (Objects.equal(javaType,"double")) {
        _matched=true;
        _switchResult = "Double";
      }
    }
    if (!_matched) {
      _switchResult = javaType;
    }
    return _switchResult;
  }
  
  public static boolean isEntity(final Element clazz) {
    if (clazz instanceof org.eclipse.uml2.uml.Class) {
      return _isEntity((org.eclipse.uml2.uml.Class)clazz);
    } else if (clazz != null) {
      return _isEntity(clazz);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(clazz).toString());
    }
  }
  
  public static Iterable<Property> attributes(final org.eclipse.uml2.uml.Class clazz, final boolean considerSuperclass) {
    if (clazz != null) {
      return _attributes(clazz, considerSuperclass);
    } else if (clazz == null) {
      return _attributes((Void)null, considerSuperclass);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(clazz, considerSuperclass).toString());
    }
  }
}
