package de.wwu.pi.mdsd.umlToApp.gui;

import de.wwu.pi.mdsd.crudDsl.crudDsl.Entity;
import de.wwu.pi.mdsd.crudDsl.crudDsl.ListWindow;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Size;
import de.wwu.pi.mdsd.umlToApp.util.EntityHelper;
import de.wwu.pi.mdsd.umlToApp.util.GUIHelper;
import de.wwu.pi.mdsd.umlToApp.util.GeneratorWithImports;
import de.wwu.pi.mdsd.umlToApp.util.ModelAndPackageHelper;
import org.eclipse.xtend2.lib.StringConcatenation;

@SuppressWarnings("all")
public class ListWindowGenerator extends GeneratorWithImports<ListWindow> {
  public CharSequence doGenerate(final ListWindow window) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("package ");
    String _guiPackageString = ModelAndPackageHelper.guiPackageString(window);
    _builder.append(_guiPackageString, "");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("import java.util.Vector;");
    _builder.newLine();
    _builder.newLine();
    _builder.append("import de.wwu.pi.mdsd.framework.gui.AbstractListWindow;");
    _builder.newLine();
    _builder.append("import de.wwu.pi.mdsd.framework.gui.AbstractWindow;");
    _builder.newLine();
    _builder.append("//import de.wwu.pi.mdsd.framework.logic.*;");
    _builder.newLine();
    _builder.append("import ");
    String _logicPackageString = ModelAndPackageHelper.logicPackageString(window);
    _builder.append(_logicPackageString, "");
    _builder.append(".ServiceInitializer;");
    _builder.newLineIfNotEmpty();
    _builder.append(GeneratorWithImports.IMPORTS_MARKER, "");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("public class ");
    String _name = window.getName();
    _builder.append(_name, "");
    _builder.append(" extends AbstractListWindow<");
    Entity _entity = window.getEntity();
    String _importedType = this.importedType(_entity);
    _builder.append(_importedType, "");
    _builder.append("> implements ");
    Entity _entity_1 = window.getEntity();
    String _listingInterfaceClassName = EntityHelper.listingInterfaceClassName(_entity_1);
    _builder.append(_listingInterfaceClassName, "");
    _builder.append("{");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("\t");
    _builder.append("public ");
    String _name_1 = window.getName();
    _builder.append(_name_1, "	");
    _builder.append("(AbstractWindow parent) {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("super(parent,");
    Size _size = window.getSize();
    int _width = _size.getWidth();
    _builder.append(_width, "		");
    _builder.append(",");
    Size _size_1 = window.getSize();
    int _height = _size_1.getHeight();
    _builder.append(_height, "		");
    _builder.append(");");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("public String getTitle() {");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("return \"");
    CharSequence _windowTitle = GUIHelper.windowTitle(window);
    _builder.append(_windowTitle, "		");
    _builder.append("\";");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("@Override");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("public Vector<");
    Entity _entity_2 = window.getEntity();
    String _name_2 = _entity_2.getName();
    _builder.append(_name_2, "	");
    _builder.append("> getElements() {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("return new Vector<");
    Entity _entity_3 = window.getEntity();
    String _name_3 = _entity_3.getName();
    _builder.append(_name_3, "		");
    _builder.append(">(ServiceInitializer.getProvider().get");
    Entity _entity_4 = window.getEntity();
    String _serviceClassName = EntityHelper.serviceClassName(_entity_4);
    _builder.append(_serviceClassName, "		");
    _builder.append("().getAll());");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("@Override");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("public void ");
    Entity _entity_5 = window.getEntity();
    String _listingInterfaceMethodeName = EntityHelper.listingInterfaceMethodeName(_entity_5);
    _builder.append(_listingInterfaceMethodeName, "	");
    _builder.append("() {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("initializeList();");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("@Override");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("public void showEntryWindow(");
    Entity _entity_6 = window.getEntity();
    String _name_4 = _entity_6.getName();
    _builder.append(_name_4, "	");
    _builder.append(" entity) {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("//If entity is null -> initialize entity as new entity");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("//show Entity Edit Window");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("if(entity == null) {");
    _builder.newLine();
    _builder.append("\t\t\t");
    Entity _entity_7 = window.getEntity();
    CharSequence _initializeEntity = this.initializeEntity(_entity_7);
    _builder.append(_initializeEntity, "			");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t\t");
    Entity _entity_8 = window.getEntity();
    CharSequence _callOpenEntryWindow = this.callOpenEntryWindow(_entity_8);
    _builder.append(_callOpenEntryWindow, "		");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    {
      Entity _entity_9 = window.getEntity();
      boolean _hasSubClasses = EntityHelper.hasSubClasses(_entity_9);
      if (_hasSubClasses) {
        _builder.append("\t");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("javax.swing.JComboBox<String> ");
        Entity _entity_10 = window.getEntity();
        CharSequence _inheritanceTypeSelectName = GUIHelper.inheritanceTypeSelectName(_entity_10);
        _builder.append(_inheritanceTypeSelectName, "		");
        _builder.append(" = new javax.swing.JComboBox<>();");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("@Override //overrides superclass method to add a select box to the window");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("public void createContents() {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("super.createContents();");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        Entity _entity_11 = window.getEntity();
        CharSequence _createSelectForInheritanceClasses = GUIHelper.createSelectForInheritanceClasses(_entity_11, "1", "2");
        _builder.append(_createSelectForInheritanceClasses, "			");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("}");
        _builder.newLine();
      }
    }
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("//Interface that needs to be implemented, if the class references ");
    Entity _entity_12 = window.getEntity();
    String _name_5 = _entity_12.getName();
    _builder.append(_name_5, "");
    _builder.append(" objects in a list");
    _builder.newLineIfNotEmpty();
    _builder.append("interface ");
    Entity _entity_13 = window.getEntity();
    String _listingInterfaceClassName_1 = EntityHelper.listingInterfaceClassName(_entity_13);
    _builder.append(_listingInterfaceClassName_1, "");
    _builder.append(" {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("public void ");
    Entity _entity_14 = window.getEntity();
    String _listingInterfaceMethodeName_1 = EntityHelper.listingInterfaceMethodeName(_entity_14);
    _builder.append(_listingInterfaceMethodeName_1, "	");
    _builder.append("();");
    _builder.newLineIfNotEmpty();
    _builder.append("}");
    return _builder;
  }
  
  public CharSequence initializeEntity(final Entity entity) {
    StringConcatenation _builder = new StringConcatenation();
    {
      boolean _hasSubClasses = EntityHelper.hasSubClasses(entity);
      if (_hasSubClasses) {
        {
          Iterable<Entity> _instantiableClasses = EntityHelper.getInstantiableClasses(entity);
          for(final Entity subClass : _instantiableClasses) {
            _builder.append("if(");
            CharSequence _inheritanceTypeSelectName = GUIHelper.inheritanceTypeSelectName(entity);
            _builder.append(_inheritanceTypeSelectName, "");
            _builder.append(".getSelectedItem().equals(\"");
            String _importedType = this.importedType(subClass);
            _builder.append(_importedType, "");
            _builder.append("\"))");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("entity = new ");
            String _name = subClass.getName();
            _builder.append(_name, "	");
            _builder.append("();");
            _builder.newLineIfNotEmpty();
          }
        }
      } else {
        _builder.append("entity = new ");
        String _name_1 = entity.getName();
        _builder.append(_name_1, "");
        _builder.append("();");
        _builder.newLineIfNotEmpty();
      }
    }
    return _builder;
  }
  
  public CharSequence callOpenEntryWindow(final Entity entity) {
    StringConcatenation _builder = new StringConcatenation();
    {
      boolean _hasSubClasses = EntityHelper.hasSubClasses(entity);
      if (_hasSubClasses) {
        CharSequence _inheritanceCallOpenEntryWindow = GUIHelper.inheritanceCallOpenEntryWindow(entity, "this");
        _builder.append(_inheritanceCallOpenEntryWindow, "");
        _builder.newLineIfNotEmpty();
      } else {
        _builder.append("new ");
        String _entryWindowClassName = EntityHelper.entryWindowClassName(entity);
        _builder.append(_entryWindowClassName, "");
        _builder.append("(this,entity).open();");
        _builder.newLineIfNotEmpty();
      }
    }
    return _builder;
  }
}
