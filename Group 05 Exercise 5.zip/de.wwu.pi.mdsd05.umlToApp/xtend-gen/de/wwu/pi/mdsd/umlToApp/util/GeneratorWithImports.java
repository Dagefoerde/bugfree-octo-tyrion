package de.wwu.pi.mdsd.umlToApp.util;

import com.google.common.base.Objects;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Entity;
import de.wwu.pi.mdsd.umlToApp.util.ClassHelper;
import de.wwu.pi.mdsd.umlToApp.util.EntityHelper;
import de.wwu.pi.mdsd.umlToApp.util.ModelAndPackageHelper;
import java.util.HashSet;
import java.util.List;
import org.eclipse.uml2.uml.Type;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Functions.Function0;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;

@SuppressWarnings("all")
public abstract class GeneratorWithImports<T extends Object> {
  public final static String IMPORTS_MARKER = "//$GENERATED_IMPORTS_HERE$";
  
  private final HashSet<String> imports = new Function0<HashSet<String>>() {
    public HashSet<String> apply() {
      HashSet<String> _newHashSet = CollectionLiterals.<String>newHashSet();
      return _newHashSet;
    }
  }.apply();
  
  public String generate(final T object) {
    CharSequence _doGenerate = this.doGenerate(object);
    String _string = _doGenerate.toString();
    List<String> _sort = IterableExtensions.<String>sort(this.imports);
    final Function1<String,String> _function = new Function1<String,String>() {
      public String apply(final String it) {
        StringConcatenation _builder = new StringConcatenation();
        _builder.append("import ");
        _builder.append(it, "");
        _builder.append(";");
        return _builder.toString();
      }
    };
    List<String> _map = ListExtensions.<String, String>map(_sort, _function);
    String _join = IterableExtensions.join(_map, "\n");
    String _replace = _string.replace(GeneratorWithImports.IMPORTS_MARKER, _join);
    return _replace;
  }
  
  public abstract CharSequence doGenerate(final T object);
  
  public String imported(final String imp) {
    String _xblockexpression = null;
    {
      this.imports.add(imp);
      int _lastIndexOf = imp.lastIndexOf(".");
      int _plus = (_lastIndexOf + 1);
      String _substring = imp.substring(_plus);
      _xblockexpression = (_substring);
    }
    return _xblockexpression;
  }
  
  public String importedType(final Type type) {
    String _xblockexpression = null;
    {
      boolean _isEntity = ClassHelper.isEntity(type);
      if (_isEntity) {
        String _entityPackageString = ModelAndPackageHelper.entityPackageString(((org.eclipse.uml2.uml.Class) type));
        String _plus = (_entityPackageString + ".");
        String _javaType = ClassHelper.javaType(type);
        String _plus_1 = (_plus + _javaType);
        this.imported(_plus_1);
      }
      String _javaType_1 = ClassHelper.javaType(type);
      _xblockexpression = (_javaType_1);
    }
    return _xblockexpression;
  }
  
  public String importedType(final Entity entity) {
    String _xblockexpression = null;
    {
      boolean _notEquals = (!Objects.equal(entity, null));
      if (_notEquals) {
        String _entityPackageString = ModelAndPackageHelper.entityPackageString(entity);
        String _plus = (_entityPackageString + ".");
        String _javaType = EntityHelper.javaType(entity);
        String _plus_1 = (_plus + _javaType);
        this.imported(_plus_1);
      }
      String _javaType_1 = EntityHelper.javaType(entity);
      _xblockexpression = (_javaType_1);
    }
    return _xblockexpression;
  }
}
