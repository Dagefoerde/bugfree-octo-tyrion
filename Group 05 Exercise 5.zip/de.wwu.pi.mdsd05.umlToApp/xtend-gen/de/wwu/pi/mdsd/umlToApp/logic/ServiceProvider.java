package de.wwu.pi.mdsd.umlToApp.logic;

import de.wwu.pi.mdsd.umlToApp.util.ClassHelper;
import de.wwu.pi.mdsd.umlToApp.util.GeneratorWithImports;
import de.wwu.pi.mdsd.umlToApp.util.ModelAndPackageHelper;
import org.eclipse.uml2.uml.Property;
import org.eclipse.uml2.uml.Type;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.StringExtensions;

@SuppressWarnings("all")
public class ServiceProvider extends GeneratorWithImports<org.eclipse.uml2.uml.Class> {
  public CharSequence doGenerate(final org.eclipse.uml2.uml.Class clazz) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("package ");
    String _logicPackageString = ModelAndPackageHelper.logicPackageString(clazz);
    _builder.append(_logicPackageString, "");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("import java.util.Collection;");
    _builder.newLine();
    _builder.append("import java.util.Date;");
    _builder.newLine();
    _builder.append("import java.util.LinkedList;");
    _builder.newLine();
    _builder.newLine();
    _builder.append("import de.wwu.pi.mdsd.framework.logic.AbstractServiceProvider;");
    _builder.newLine();
    _builder.append("import de.wwu.pi.mdsd.framework.logic.ValidationException;");
    _builder.newLine();
    _builder.newLine();
    _builder.append(GeneratorWithImports.IMPORTS_MARKER, "");
    _builder.newLineIfNotEmpty();
    {
      Iterable<Property> _singleValueProperties = ClassHelper.singleValueProperties(clazz, true);
      final Function1<Property,Boolean> _function = new Function1<Property,Boolean>() {
        public Boolean apply(final Property it) {
          Type _type = it.getType();
          boolean _isEntity = ClassHelper.isEntity(_type);
          return Boolean.valueOf(_isEntity);
        }
      };
      Iterable<Property> _filter = IterableExtensions.<Property>filter(_singleValueProperties, _function);
      for(final Property att : _filter) {
        Type _type = att.getType();
        String tmp = this.importedType(_type);
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.newLine();
    _builder.append("public class ");
    String _serviceClassName = ClassHelper.serviceClassName(clazz);
    _builder.append(_serviceClassName, "");
    _builder.append(" extends AbstractServiceProvider<");
    String _importedType = this.importedType(clazz);
    _builder.append(_importedType, "");
    _builder.append("> {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("//Constructor");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("protected ");
    String _serviceClassName_1 = ClassHelper.serviceClassName(clazz);
    _builder.append(_serviceClassName_1, "	");
    _builder.append("() {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("super();");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("public boolean validate");
    String _name = clazz.getName();
    _builder.append(_name, "	");
    _builder.append("(");
    Iterable<Property> _singleValueProperties_1 = ClassHelper.singleValueProperties(clazz, true);
    final Function1<Property,String> _function_1 = new Function1<Property,String>() {
      public String apply(final Property it) {
        String _typeInJava = ClassHelper.typeInJava(it);
        String _objectType = ClassHelper.objectType(_typeInJava);
        String _plus = (_objectType + " ");
        String _nameInJava = ClassHelper.nameInJava(it);
        String _plus_1 = (_plus + _nameInJava);
        return _plus_1;
      }
    };
    String _join = IterableExtensions.<Property>join(_singleValueProperties_1, null, ", ", null, _function_1);
    _builder.append(_join, "	");
    _builder.append(") throws ValidationException {");
    _builder.newLineIfNotEmpty();
    {
      Iterable<Property> _singleValueProperties_2 = ClassHelper.singleValueProperties(clazz, true);
      final Function1<Property,Boolean> _function_2 = new Function1<Property,Boolean>() {
        public Boolean apply(final Property it) {
          boolean _isRequired = ClassHelper.isRequired(it);
          return Boolean.valueOf(_isRequired);
        }
      };
      Iterable<Property> _filter_1 = IterableExtensions.<Property>filter(_singleValueProperties_2, _function_2);
      for(final Property att_1 : _filter_1) {
        _builder.append("\t\t");
        _builder.append("if(");
        String _nameInJava = ClassHelper.nameInJava(att_1);
        _builder.append(_nameInJava, "		");
        _builder.append(" == null)");
        _builder.newLineIfNotEmpty();
        _builder.append("\t\t");
        _builder.append("\t");
        _builder.append("throw new ValidationException(\"");
        String _label = att_1.getLabel();
        _builder.append(_label, "			");
        _builder.append("\", \"cannot be empty\");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t\t");
    _builder.append("return true;");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    {
      boolean _isAbstract = clazz.isAbstract();
      boolean _not = (!_isAbstract);
      if (_not) {
        _builder.append("\t");
        _builder.append("public ");
        String _name_1 = clazz.getName();
        _builder.append(_name_1, "	");
        _builder.append(" save");
        String _name_2 = clazz.getName();
        _builder.append(_name_2, "	");
        _builder.append("(int id");
        Iterable<Property> _singleValueProperties_3 = ClassHelper.singleValueProperties(clazz, true);
        final Function1<Property,String> _function_3 = new Function1<Property,String>() {
          public String apply(final Property it) {
            String _typeInJava = ClassHelper.typeInJava(it);
            String _objectType = ClassHelper.objectType(_typeInJava);
            String _plus = (_objectType + " ");
            String _nameInJava = ClassHelper.nameInJava(it);
            String _plus_1 = (_plus + _nameInJava);
            return _plus_1;
          }
        };
        String _join_1 = IterableExtensions.<Property>join(_singleValueProperties_3, ", ", ", ", null, _function_3);
        _builder.append(_join_1, "	");
        _builder.append(") {");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("\t");
        String _name_3 = clazz.getName();
        _builder.append(_name_3, "		");
        _builder.append(" elem = getByOId(id);");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("if(elem == null)");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("elem = new ");
        String _name_4 = clazz.getName();
        _builder.append(_name_4, "			");
        _builder.append("();");
        _builder.newLineIfNotEmpty();
        {
          Iterable<Property> _singleValueProperties_4 = ClassHelper.singleValueProperties(clazz, true);
          for(final Property att_2 : _singleValueProperties_4) {
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("elem.set");
            String _name_5 = att_2.getName();
            String _firstUpper = StringExtensions.toFirstUpper(_name_5);
            _builder.append(_firstUpper, "		");
            _builder.append("(");
            String _name_6 = att_2.getName();
            _builder.append(_name_6, "		");
            _builder.append(");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("persist(elem);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("return elem;");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("}");
        _builder.newLine();
      }
    }
    _builder.append("\t");
    _builder.newLine();
    {
      Iterable<org.eclipse.uml2.uml.Class> _directSubClasses = ClassHelper.getDirectSubClasses(clazz);
      int _size = IterableExtensions.size(_directSubClasses);
      boolean _greaterThan = (_size > 0);
      if (_greaterThan) {
        _builder.append("\t");
        _builder.append("@Override");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("//Class has subclasses, thus getAll need to return subclasses");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("public Collection<");
        String _name_7 = clazz.getName();
        _builder.append(_name_7, "	");
        _builder.append("> getAll() {");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("Collection<");
        String _name_8 = clazz.getName();
        _builder.append(_name_8, "		");
        _builder.append("> result = new LinkedList<");
        String _name_9 = clazz.getName();
        _builder.append(_name_9, "		");
        _builder.append(">();");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("result.addAll(super.getAll());");
        _builder.newLine();
        {
          Iterable<org.eclipse.uml2.uml.Class> _directSubClasses_1 = ClassHelper.getDirectSubClasses(clazz);
          for(final org.eclipse.uml2.uml.Class curClazz : _directSubClasses_1) {
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("result.addAll(ServiceInitializer.getProvider().get");
            String _serviceClassName_2 = ClassHelper.serviceClassName(curClazz);
            _builder.append(_serviceClassName_2, "		");
            _builder.append("().getAll());");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("return result;");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("}");
        _builder.newLine();
      }
    }
    _builder.append("}");
    _builder.newLine();
    return _builder;
  }
}
