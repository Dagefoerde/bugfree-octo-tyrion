package de.wwu.pi.mdsd.umlToApp.data;

import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import de.wwu.pi.mdsd.umlToApp.util.ClassHelper;
import de.wwu.pi.mdsd.umlToApp.util.ModelAndPackageHelper;
import org.eclipse.emf.common.util.EList;
import org.eclipse.uml2.uml.Property;
import org.eclipse.uml2.uml.Type;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.StringExtensions;

@SuppressWarnings("all")
public class DataClass {
  public CharSequence generateDataClass(final org.eclipse.uml2.uml.Class clazz) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("package ");
    String _entityPackageString = ModelAndPackageHelper.entityPackageString(clazz);
    _builder.append(_entityPackageString, "");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("import java.util.*;");
    _builder.newLine();
    _builder.append("import de.wwu.pi.mdsd.framework.data.AbstractDataClass;");
    _builder.newLine();
    _builder.newLine();
    _builder.append("@SuppressWarnings(\"serial\")");
    _builder.newLine();
    _builder.append("public ");
    String _xifexpression = null;
    boolean _isAbstract = clazz.isAbstract();
    if (_isAbstract) {
      _xifexpression = "abstract ";
    }
    _builder.append(_xifexpression, "");
    _builder.append("class ");
    String _name = clazz.getName();
    _builder.append(_name, "");
    _builder.append(" ");
    String _elvis = null;
    String _superClassExtension = this.superClassExtension(clazz);
    if (_superClassExtension != null) {
      _elvis = _superClassExtension;
    } else {
      _elvis = ObjectExtensions.<String>operator_elvis(_superClassExtension, "");
    }
    _builder.append(_elvis, "");
    _builder.append("{");
    _builder.newLineIfNotEmpty();
    {
      Iterable<Property> _primitiveAttributes = ClassHelper.primitiveAttributes(clazz, false);
      for(final Property att : _primitiveAttributes) {
        _builder.append("\t");
        _builder.newLine();
        _builder.append("\t");
        String _visibilityInJava = ModelAndPackageHelper.visibilityInJava(att);
        _builder.append(_visibilityInJava, "	");
        _builder.append(" ");
        CharSequence _typeAndNameInJava = ClassHelper.typeAndNameInJava(att);
        _builder.append(_typeAndNameInJava, "	");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        CharSequence _generateGetter = this.generateGetter(att);
        _builder.append(_generateGetter, "	");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        CharSequence _generateSetter = this.generateSetter(att);
        _builder.append(_generateSetter, "	");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      Iterable<Property> _singleReferences = ClassHelper.singleReferences(clazz, false);
      for(final Property ref : _singleReferences) {
        _builder.append("\t");
        _builder.newLine();
        _builder.append("\t");
        String _visibilityInJava_1 = ModelAndPackageHelper.visibilityInJava(ref);
        _builder.append(_visibilityInJava_1, "	");
        _builder.append(" ");
        CharSequence _typeAndNameInJava_1 = ClassHelper.typeAndNameInJava(ref);
        _builder.append(_typeAndNameInJava_1, "	");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        CharSequence _generateGetter_1 = this.generateGetter(ref);
        _builder.append(_generateGetter_1, "	");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        Property _opposite = ref.getOpposite();
        CharSequence _generateSetter_1 = this.generateSetter(ref, _opposite);
        _builder.append(_generateSetter_1, "	");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      Iterable<Property> _multiReferences = ClassHelper.multiReferences(clazz, false);
      for(final Property ref_1 : _multiReferences) {
        _builder.append("\t");
        _builder.newLine();
        _builder.append("\t");
        String _visibilityInJava_2 = ModelAndPackageHelper.visibilityInJava(ref_1);
        _builder.append(_visibilityInJava_2, "	");
        _builder.append(" ");
        String _typeInJava = ClassHelper.typeInJava(ref_1);
        _builder.append(_typeInJava, "	");
        _builder.append(" ");
        String _nameInJava = ClassHelper.nameInJava(ref_1);
        _builder.append(_nameInJava, "	");
        _builder.append(" = new ArrayList<");
        Type _type = ref_1.getType();
        String _javaType = ClassHelper.javaType(_type);
        _builder.append(_javaType, "	");
        _builder.append(">();");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        CharSequence _generateGetter_2 = this.generateGetter(ref_1);
        _builder.append(_generateGetter_2, "	");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        CharSequence _generateAdder = this.generateAdder(ref_1);
        _builder.append(_generateAdder, "	");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.newLine();
    {
      Iterable<Property> _requiredProperties = ClassHelper.requiredProperties(clazz, true);
      int _size = IterableExtensions.size(_requiredProperties);
      boolean _greaterThan = (_size > 0);
      if (_greaterThan) {
        _builder.append("\t");
        _builder.append("//Constructors");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("public ");
        String _name_1 = clazz.getName();
        _builder.append(_name_1, "	");
        _builder.append("(");
        Iterable<Property> _requiredProperties_1 = ClassHelper.requiredProperties(clazz, true);
        final Function1<Property,CharSequence> _function = new Function1<Property,CharSequence>() {
          public CharSequence apply(final Property it) {
            CharSequence _typeAndNameInJava = ClassHelper.typeAndNameInJava(it);
            return _typeAndNameInJava;
          }
        };
        Iterable<CharSequence> _map = IterableExtensions.<Property, CharSequence>map(_requiredProperties_1, _function);
        String _join = IterableExtensions.join(_map, ", ");
        _builder.append(_join, "	");
        _builder.append(") {");
        _builder.newLineIfNotEmpty();
        {
          boolean _hasExplicitSuperClass = ClassHelper.hasExplicitSuperClass(clazz);
          if (_hasExplicitSuperClass) {
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("super(");
            org.eclipse.uml2.uml.Class _superClass = ClassHelper.superClass(clazz);
            Iterable<Property> _requiredProperties_2 = ClassHelper.requiredProperties(_superClass, true);
            final Function1<Property,String> _function_1 = new Function1<Property,String>() {
              public String apply(final Property it) {
                String _nameInJava = ClassHelper.nameInJava(it);
                return _nameInJava;
              }
            };
            String _join_1 = IterableExtensions.<Property>join(_requiredProperties_2, null, ", ", null, _function_1);
            _builder.append(_join_1, "		");
            _builder.append(");");
            _builder.newLineIfNotEmpty();
          } else {
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("this();");
            _builder.newLine();
          }
        }
        {
          Iterable<Property> _primitiveAttributes_1 = ClassHelper.primitiveAttributes(clazz, false);
          Iterable<Property> _required = ClassHelper.required(_primitiveAttributes_1);
          for(final Property att_1 : _required) {
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("set");
            String _nameInJava_1 = ClassHelper.nameInJava(att_1);
            String _firstUpper = StringExtensions.toFirstUpper(_nameInJava_1);
            _builder.append(_firstUpper, "		");
            _builder.append("(");
            String _nameInJava_2 = ClassHelper.nameInJava(att_1);
            _builder.append(_nameInJava_2, "		");
            _builder.append(");");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          Iterable<Property> _singleReferences_1 = ClassHelper.singleReferences(clazz, false);
          Iterable<Property> _required_1 = ClassHelper.required(_singleReferences_1);
          for(final Property ref_2 : _required_1) {
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("set");
            String _nameInJava_3 = ClassHelper.nameInJava(ref_2);
            String _firstUpper_1 = StringExtensions.toFirstUpper(_nameInJava_3);
            _builder.append(_firstUpper_1, "		");
            _builder.append("(");
            String _nameInJava_4 = ClassHelper.nameInJava(ref_2);
            _builder.append(_nameInJava_4, "		");
            _builder.append(");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("}");
        _builder.newLine();
      }
    }
    {
      Iterable<Property> _singleReferences_2 = ClassHelper.singleReferences(clazz, true);
      for(final Property ref_3 : _singleReferences_2) {
        _builder.append("\t");
        _builder.append("// Initializer for ");
        String _name_2 = ref_3.getName();
        _builder.append(_name_2, "	");
        _builder.append("; can be called when initializing a new ");
        String _name_3 = clazz.getName();
        _builder.append(_name_3, "	");
        _builder.append(". Does not take care of friend methods");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("public ");
        String _name_4 = clazz.getName();
        _builder.append(_name_4, "	");
        _builder.append(" ");
        String _initializeSingleRefMethodName = ClassHelper.initializeSingleRefMethodName(ref_3);
        _builder.append(_initializeSingleRefMethodName, "	");
        _builder.append("(");
        CharSequence _typeAndNameInJava_2 = ClassHelper.typeAndNameInJava(ref_3);
        _builder.append(_typeAndNameInJava_2, "	");
        _builder.append(") {");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("this.");
        String _nameInJava_5 = ClassHelper.nameInJava(ref_3);
        _builder.append(_nameInJava_5, "		");
        _builder.append(" = ");
        String _nameInJava_6 = ClassHelper.nameInJava(ref_3);
        _builder.append(_nameInJava_6, "		");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("return this;");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("}");
        _builder.newLine();
      }
    }
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("//Default Constructor");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("public ");
    String _name_5 = clazz.getName();
    _builder.append(_name_5, "	");
    _builder.append("() {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("super();");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("@Override");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("public String toString() {");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("return ");
    String _xifexpression_1 = null;
    boolean _hasExplicitSuperClass_1 = ClassHelper.hasExplicitSuperClass(clazz);
    if (_hasExplicitSuperClass_1) {
      _xifexpression_1 = "super.toString() + \", \" + ";
    }
    _builder.append(_xifexpression_1, "		");
    Iterable<Property> _primitiveAttributes_2 = ClassHelper.primitiveAttributes(clazz, false);
    Iterable<Property> _singleReferences_3 = ClassHelper.singleReferences(clazz, false);
    Iterable<Property> _plus = Iterables.<Property>concat(_primitiveAttributes_2, _singleReferences_3);
    final Function1<Property,CharSequence> _function_2 = new Function1<Property,CharSequence>() {
      public CharSequence apply(final Property it) {
        CharSequence _generateToStringPart = DataClass.this.generateToStringPart(it);
        return _generateToStringPart;
      }
    };
    String _join_2 = IterableExtensions.<Property>join(_plus, null, " + \", \" + ", " + ", _function_2);
    _builder.append(_join_2, "		");
    _builder.append("\"\"");
    String _xifexpression_2 = null;
    boolean _and = false;
    Iterable<Property> _primitiveAttributes_3 = ClassHelper.primitiveAttributes(clazz, true);
    int _size_1 = IterableExtensions.size(_primitiveAttributes_3);
    boolean _equals = (_size_1 == 0);
    if (!_equals) {
      _and = false;
    } else {
      Iterable<Property> _singleReferences_4 = ClassHelper.singleReferences(clazz, true);
      int _size_2 = IterableExtensions.size(_singleReferences_4);
      boolean _equals_1 = (_size_2 == 0);
      _and = (_equals && _equals_1);
    }
    if (_and) {
      _xifexpression_2 = " + getOid()";
    }
    _builder.append(_xifexpression_2, "		");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence generateAdder(final Property p) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("protected void ");
    CharSequence _adderMethodName = this.adderMethodName(p);
    _builder.append(_adderMethodName, "");
    _builder.append("(");
    Type _type = p.getType();
    String _name = _type.getName();
    _builder.append(_name, "");
    _builder.append(" elem) {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    String _nameInJava = ClassHelper.nameInJava(p);
    _builder.append(_nameInJava, "	");
    _builder.append(".add(elem);");
    _builder.newLineIfNotEmpty();
    _builder.append("}");
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence generateGetter(final Property p) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("public ");
    String _typeInJava = ClassHelper.typeInJava(p);
    _builder.append(_typeInJava, "");
    _builder.append(" get");
    String _nameInJava = ClassHelper.nameInJava(p);
    String _firstUpper = StringExtensions.toFirstUpper(_nameInJava);
    _builder.append(_firstUpper, "");
    _builder.append("() {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("return ");
    String _nameInJava_1 = ClassHelper.nameInJava(p);
    _builder.append(_nameInJava_1, "	");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    _builder.append("}");
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence generateSetter(final Property p) {
    CharSequence _generateSetter = this.generateSetter(p, null);
    return _generateSetter;
  }
  
  public CharSequence generateSetter(final Property p, final Property opposite) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("public void set");
    String _nameInJava = ClassHelper.nameInJava(p);
    String _firstUpper = StringExtensions.toFirstUpper(_nameInJava);
    _builder.append(_firstUpper, "");
    _builder.append("(");
    CharSequence _typeAndNameInJava = ClassHelper.typeAndNameInJava(p);
    _builder.append(_typeAndNameInJava, "");
    _builder.append(") {");
    _builder.newLineIfNotEmpty();
    {
      boolean _notEquals = (!Objects.equal(opposite, null));
      if (_notEquals) {
        _builder.append("\t");
        _builder.append("//do nothing, if ");
        String _nameInJava_1 = ClassHelper.nameInJava(p);
        _builder.append(_nameInJava_1, "	");
        _builder.append(" is the same");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("if(this.");
        String _nameInJava_2 = ClassHelper.nameInJava(p);
        _builder.append(_nameInJava_2, "	");
        _builder.append(" == ");
        String _nameInJava_3 = ClassHelper.nameInJava(p);
        _builder.append(_nameInJava_3, "	");
        _builder.append(")");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("return;");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("//remove old ");
        String _nameInJava_4 = ClassHelper.nameInJava(p);
        _builder.append(_nameInJava_4, "	");
        _builder.append(" from opposite");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("if(this.");
        String _nameInJava_5 = ClassHelper.nameInJava(p);
        _builder.append(_nameInJava_5, "	");
        _builder.append(" != null)");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("this.");
        String _nameInJava_6 = ClassHelper.nameInJava(p);
        _builder.append(_nameInJava_6, "		");
        _builder.append(".");
        String _name = opposite.getName();
        _builder.append(_name, "		");
        _builder.append(".remove(this.");
        String _nameInJava_7 = ClassHelper.nameInJava(p);
        _builder.append(_nameInJava_7, "		");
        _builder.append(");");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("this.");
        String _nameInJava_8 = ClassHelper.nameInJava(p);
        _builder.append(_nameInJava_8, "	");
        _builder.append(" = ");
        String _nameInJava_9 = ClassHelper.nameInJava(p);
        _builder.append(_nameInJava_9, "	");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("//unless new ");
        String _nameInJava_10 = ClassHelper.nameInJava(p);
        _builder.append(_nameInJava_10, "	");
        _builder.append(" is null add ");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("if(");
        String _nameInJava_11 = ClassHelper.nameInJava(p);
        _builder.append(_nameInJava_11, "	");
        _builder.append(" != null)");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("\t");
        String _nameInJava_12 = ClassHelper.nameInJava(p);
        _builder.append(_nameInJava_12, "		");
        _builder.append(".");
        CharSequence _adderMethodName = this.adderMethodName(opposite);
        _builder.append(_adderMethodName, "		");
        _builder.append("(this);");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.append("this.");
    String _nameInJava_13 = ClassHelper.nameInJava(p);
    _builder.append(_nameInJava_13, "	");
    _builder.append(" = ");
    String _nameInJava_14 = ClassHelper.nameInJava(p);
    _builder.append(_nameInJava_14, "	");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    _builder.append("}");
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence generateToStringPart(final Property p) {
    CharSequence _xblockexpression = null;
    {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("get");
      String _name = p.getName();
      String _firstUpper = StringExtensions.toFirstUpper(_name);
      _builder.append(_firstUpper, "");
      _builder.append("()");
      final String callToGetter = _builder.toString();
      StringConcatenation _builder_1 = new StringConcatenation();
      _builder_1.append("(");
      {
        boolean _isRequired = ClassHelper.isRequired(p);
        boolean _not = (!_isRequired);
        if (_not) {
          _builder_1.append("(");
          _builder_1.append(callToGetter, "");
          _builder_1.append("==null)?\"-\":");
        }
      }
      _builder_1.append(callToGetter, "");
      _builder_1.append(")");
      _xblockexpression = (_builder_1);
    }
    return _xblockexpression;
  }
  
  public String superClassExtension(final org.eclipse.uml2.uml.Class clazz) {
    String _xifexpression = null;
    boolean _hasExplicitSuperClass = ClassHelper.hasExplicitSuperClass(clazz);
    if (_hasExplicitSuperClass) {
      EList<org.eclipse.uml2.uml.Class> _superClasses = clazz.getSuperClasses();
      org.eclipse.uml2.uml.Class _head = IterableExtensions.<org.eclipse.uml2.uml.Class>head(_superClasses);
      String _javaType = ClassHelper.javaType(_head);
      String _plus = ("extends " + _javaType);
      _xifexpression = _plus;
    } else {
      _xifexpression = "extends AbstractDataClass";
    }
    return _xifexpression;
  }
  
  public CharSequence adderMethodName(final Property p) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("addTo");
    String _name = p.getName();
    String _firstUpper = StringExtensions.toFirstUpper(_name);
    _builder.append(_firstUpper, "");
    return _builder;
  }
}
