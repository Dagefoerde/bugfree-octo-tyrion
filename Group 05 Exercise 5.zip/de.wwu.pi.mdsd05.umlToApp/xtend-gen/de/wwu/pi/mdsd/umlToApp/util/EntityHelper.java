package de.wwu.pi.mdsd.umlToApp.util;

import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Attribute;
import de.wwu.pi.mdsd.crudDsl.crudDsl.AttributeType;
import de.wwu.pi.mdsd.crudDsl.crudDsl.CrudModel;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Entity;
import de.wwu.pi.mdsd.crudDsl.crudDsl.EntryWindow;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Field;
import de.wwu.pi.mdsd.crudDsl.crudDsl.MultiplicityKind;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Property;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Reference;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Window;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.StringExtensions;

@SuppressWarnings("all")
public class EntityHelper {
  public static String entryWindowClassName(final Entity entity) {
    EObject _eContainer = entity.eContainer();
    EList<Window> _windows = ((CrudModel) _eContainer).getWindows();
    Iterable<EntryWindow> _filter = Iterables.<EntryWindow>filter(_windows, EntryWindow.class);
    final Function1<EntryWindow,Boolean> _function = new Function1<EntryWindow,Boolean>() {
      public Boolean apply(final EntryWindow it) {
        Entity _entity = it.getEntity();
        boolean _equals = _entity.equals(entity);
        return Boolean.valueOf(_equals);
      }
    };
    Iterable<EntryWindow> _filter_1 = IterableExtensions.<EntryWindow>filter(_filter, _function);
    EntryWindow _head = IterableExtensions.<EntryWindow>head(_filter_1);
    String _name = _head.getName();
    return _name;
  }
  
  public static String serviceClassName(final Entity entity) {
    String _name = entity.getName();
    String _plus = (_name + "Service");
    return _plus;
  }
  
  public static String listingInterfaceClassName(final Entity entity) {
    String _name = entity.getName();
    String _plus = (_name + "ListingInterface");
    return _plus;
  }
  
  public static String listingInterfaceMethodeName(final Entity entity) {
    String _name = entity.getName();
    String _plus = ("initialize" + _name);
    String _plus_1 = (_plus + "Listings");
    return _plus_1;
  }
  
  public static String initializeSingleRefMethodName(final Property ref) {
    String _name = ref.getName();
    String _firstUpper = StringExtensions.toFirstUpper(_name);
    String _plus = ("initialize" + _firstUpper);
    return _plus;
  }
  
  public static boolean isDate(final Attribute a) {
    AttributeType _type = a.getType();
    String _literal = _type.getLiteral();
    boolean _equals = "Date".equals(_literal);
    return _equals;
  }
  
  public static boolean isString(final Attribute a) {
    AttributeType _type = a.getType();
    String _literal = _type.getLiteral();
    boolean _equals = "String".equals(_literal);
    return _equals;
  }
  
  public static boolean isNumberObject(final Attribute a) {
    AttributeType _type = a.getType();
    String _literal = _type.getLiteral();
    boolean _equals = "Integer".equals(_literal);
    return _equals;
  }
  
  public static boolean isObject(final Attribute a) {
    boolean _or = false;
    boolean _or_1 = false;
    boolean _isString = EntityHelper.isString(a);
    if (_isString) {
      _or_1 = true;
    } else {
      boolean _isNumberObject = EntityHelper.isNumberObject(a);
      _or_1 = (_isString || _isNumberObject);
    }
    if (_or_1) {
      _or = true;
    } else {
      boolean _isDate = EntityHelper.isDate(a);
      _or = (_or_1 || _isDate);
    }
    return _or;
  }
  
  public static boolean isMultivalued(final Reference r) {
    MultiplicityKind _multiplicity = r.getMultiplicity();
    boolean _equals = Objects.equal(_multiplicity, MultiplicityKind.MULTIPLE);
    return _equals;
  }
  
  public static boolean isSingelvalued(final Reference r) {
    MultiplicityKind _multiplicity = r.getMultiplicity();
    boolean _equals = Objects.equal(_multiplicity, MultiplicityKind.SINGLE);
    return _equals;
  }
  
  public static boolean hasExplicitSuperClass(final Entity entity) {
    Entity _superType = entity.getSuperType();
    boolean _notEquals = (!Objects.equal(_superType, null));
    return _notEquals;
  }
  
  public static Entity superClass(final Entity entity) {
    Entity _xifexpression = null;
    boolean _hasExplicitSuperClass = EntityHelper.hasExplicitSuperClass(entity);
    if (_hasExplicitSuperClass) {
      Entity _superType = entity.getSuperType();
      _xifexpression = _superType;
    }
    return _xifexpression;
  }
  
  public static Iterable<Entity> allSuperClasses(final Entity entity) {
    Iterable<Entity> _xifexpression = null;
    boolean _hasExplicitSuperClass = EntityHelper.hasExplicitSuperClass(entity);
    if (_hasExplicitSuperClass) {
      Entity _superClass = EntityHelper.superClass(entity);
      Iterable<Entity> _allSuperClasses = EntityHelper.allSuperClasses(_superClass);
      Entity _superClass_1 = EntityHelper.superClass(entity);
      Iterable<Entity> _plus = Iterables.<Entity>concat(_allSuperClasses, Collections.<Entity>unmodifiableList(Lists.<Entity>newArrayList(_superClass_1)));
      _xifexpression = _plus;
    } else {
      List<Entity> _emptyList = CollectionLiterals.<Entity>emptyList();
      _xifexpression = _emptyList;
    }
    return _xifexpression;
  }
  
  public static Iterable<Entity> getDirectSubClasses(final Entity entity) {
    EObject _eContainer = entity.eContainer();
    EList<Entity> _entities = ((CrudModel) _eContainer).getEntities();
    final Function1<Entity,Boolean> _function = new Function1<Entity,Boolean>() {
      public Boolean apply(final Entity it) {
        Entity _superType = it.getSuperType();
        boolean _equals = Objects.equal(_superType, entity);
        return Boolean.valueOf(_equals);
      }
    };
    Iterable<Entity> _filter = IterableExtensions.<Entity>filter(_entities, _function);
    return _filter;
  }
  
  public static boolean hasSubClasses(final Entity entity) {
    Iterable<Entity> _directSubClasses = EntityHelper.getDirectSubClasses(entity);
    int _size = IterableExtensions.size(_directSubClasses);
    boolean _greaterThan = (_size > 0);
    return _greaterThan;
  }
  
  public static boolean hasSubClasses(final Reference ref) {
    Entity _type = ref.getType();
    boolean _hasSubClasses = EntityHelper.hasSubClasses(_type);
    return _hasSubClasses;
  }
  
  public static Iterable<Entity> getInstantiableClasses(final Entity entity) {
    LinkedList<Entity> _newLinkedList = CollectionLiterals.<Entity>newLinkedList(entity);
    Iterable<Entity> _directSubClasses = EntityHelper.getDirectSubClasses(entity);
    final Function1<Entity,Iterable<Entity>> _function = new Function1<Entity,Iterable<Entity>>() {
      public Iterable<Entity> apply(final Entity cl) {
        Iterable<Entity> _instantiableClasses = EntityHelper.getInstantiableClasses(cl);
        return _instantiableClasses;
      }
    };
    Iterable<Iterable<Entity>> _map = IterableExtensions.<Entity, Iterable<Entity>>map(_directSubClasses, _function);
    Iterable<Entity> _flatten = Iterables.<Entity>concat(_map);
    Iterable<Entity> _plus = Iterables.<Entity>concat(_newLinkedList, _flatten);
    final Function1<Entity,Boolean> _function_1 = new Function1<Entity,Boolean>() {
      public Boolean apply(final Entity cl) {
        boolean _isAbstract = cl.isAbstract();
        boolean _not = (!_isAbstract);
        return Boolean.valueOf(_not);
      }
    };
    Iterable<Entity> _filter = IterableExtensions.<Entity>filter(_plus, _function_1);
    Set<Entity> _set = IterableExtensions.<Entity>toSet(_filter);
    return _set;
  }
  
  protected static Iterable<Property> _properties(final Void x, final boolean considerSuperclass) {
    List<Property> _emptyList = CollectionLiterals.<Property>emptyList();
    return _emptyList;
  }
  
  protected static Iterable<Property> _properties(final Entity entity, final boolean considerSuperclass) {
    Iterable<Property> _xifexpression = null;
    boolean _and = false;
    if (!considerSuperclass) {
      _and = false;
    } else {
      boolean _hasExplicitSuperClass = EntityHelper.hasExplicitSuperClass(entity);
      _and = (considerSuperclass && _hasExplicitSuperClass);
    }
    if (_and) {
      Entity _superClass = EntityHelper.superClass(entity);
      Iterable<Property> _properties = EntityHelper.properties(_superClass, true);
      EList<Property> _properties_1 = entity.getProperties();
      Iterable<Property> _plus = Iterables.<Property>concat(_properties, _properties_1);
      _xifexpression = _plus;
    } else {
      EList<Property> _properties_2 = entity.getProperties();
      _xifexpression = _properties_2;
    }
    return _xifexpression;
  }
  
  public static Iterable<Attribute> primitiveAttributes(final Entity entity, final boolean considerSuperclass) {
    Iterable<Property> _properties = EntityHelper.properties(entity, considerSuperclass);
    Iterable<Attribute> _filter = Iterables.<Attribute>filter(_properties, Attribute.class);
    return _filter;
  }
  
  public static Iterable<Reference> entityReferences(final Entity entity, final boolean considerSuperclass) {
    Iterable<Property> _properties = EntityHelper.properties(entity, considerSuperclass);
    Iterable<Reference> _filter = Iterables.<Reference>filter(_properties, Reference.class);
    return _filter;
  }
  
  public static Iterable<Reference> singleReferences(final Entity entity, final boolean considerSuperclass) {
    Iterable<Reference> _entityReferences = EntityHelper.entityReferences(entity, considerSuperclass);
    final Function1<Reference,Boolean> _function = new Function1<Reference,Boolean>() {
      public Boolean apply(final Reference it) {
        MultiplicityKind _multiplicity = it.getMultiplicity();
        boolean _equals = Objects.equal(_multiplicity, MultiplicityKind.SINGLE);
        return Boolean.valueOf(_equals);
      }
    };
    Iterable<Reference> _filter = IterableExtensions.<Reference>filter(_entityReferences, _function);
    return _filter;
  }
  
  public static Iterable<Reference> multiReferences(final Entity entity, final boolean considerSuperclass) {
    Iterable<Reference> _entityReferences = EntityHelper.entityReferences(entity, considerSuperclass);
    final Function1<Reference,Boolean> _function = new Function1<Reference,Boolean>() {
      public Boolean apply(final Reference it) {
        MultiplicityKind _multiplicity = it.getMultiplicity();
        boolean _equals = Objects.equal(_multiplicity, MultiplicityKind.MULTIPLE);
        return Boolean.valueOf(_equals);
      }
    };
    Iterable<Reference> _filter = IterableExtensions.<Reference>filter(_entityReferences, _function);
    return _filter;
  }
  
  /**
   * primitive attributes and single References
   */
  public static Iterable<Property> singleValueProperties(final Entity entity, final boolean considerSuperclass) {
    Iterable<Attribute> _primitiveAttributes = EntityHelper.primitiveAttributes(entity, considerSuperclass);
    Iterable<Reference> _singleReferences = EntityHelper.singleReferences(entity, considerSuperclass);
    Iterable<Property> _plus = Iterables.<Property>concat(_primitiveAttributes, _singleReferences);
    return _plus;
  }
  
  public static boolean hasSingleValuedProperty(final Field field) {
    Property prop = field.getProperty();
    if ((prop instanceof Attribute)) {
      return true;
    }
    if ((prop instanceof Reference)) {
      return EntityHelper.isSingelvalued(((Reference) prop));
    }
    return false;
  }
  
  public static boolean hasSingleValuedReference(final Field field) {
    Property prop = field.getProperty();
    if ((prop instanceof Reference)) {
      return EntityHelper.isSingelvalued(((Reference) prop));
    }
    return false;
  }
  
  public static boolean hasMultiValuedProperty(final Field field) {
    Property prop = field.getProperty();
    if ((prop instanceof Reference)) {
      return EntityHelper.isMultivalued(((Reference) prop));
    }
    return false;
  }
  
  public static boolean isRequired(final Attribute a) {
    boolean _isOptional = a.isOptional();
    return _isOptional;
  }
  
  /**
   * get the type representation of properties in Java
   * incl. multivalue type e.g. multivalued properties as List<p.javaType>
   */
  public static String typeInJava(final Property p) {
    String _xifexpression = null;
    if ((p instanceof Reference)) {
      String _xifexpression_1 = null;
      boolean _isMultivalued = EntityHelper.isMultivalued(((Reference) p));
      if (_isMultivalued) {
        Entity _type = ((Reference) p).getType();
        String _javaType = EntityHelper.javaType(_type);
        String _plus = ("List<" + _javaType);
        String _plus_1 = (_plus + ">");
        _xifexpression_1 = _plus_1;
      } else {
        Entity _type_1 = ((Reference) p).getType();
        String _javaType_1 = EntityHelper.javaType(_type_1);
        _xifexpression_1 = _javaType_1;
      }
      _xifexpression = _xifexpression_1;
    } else {
      AttributeType _type_2 = ((Attribute) p).getType();
      String _javaType_2 = EntityHelper.javaType(_type_2);
      _xifexpression = _javaType_2;
    }
    return _xifexpression;
  }
  
  public static String javaType(final AttributeType type) {
    String _literal = type.getLiteral();
    return _literal;
  }
  
  public static String javaType(final Entity entity) {
    String _name = entity.getName();
    return _name;
  }
  
  public static String nameInJava(final Property p) {
    String _name = p.getName();
    return _name;
  }
  
  /**
   * get java object type for primitive java types
   */
  public static String objectType(final String javaType) {
    String _switchResult = null;
    boolean _matched = false;
    if (!_matched) {
      if (Objects.equal(javaType,"String")) {
        _matched=true;
        _switchResult = "String";
      }
    }
    if (!_matched) {
      if (Objects.equal(javaType,"Integer")) {
        _matched=true;
        _switchResult = "Integer";
      }
    }
    if (!_matched) {
      if (Objects.equal(javaType,"Date")) {
        _matched=true;
        _switchResult = "Date";
      }
    }
    if (!_matched) {
      _switchResult = javaType;
    }
    return _switchResult;
  }
  
  public static Iterable<Property> properties(final Entity entity, final boolean considerSuperclass) {
    if (entity != null) {
      return _properties(entity, considerSuperclass);
    } else if (entity == null) {
      return _properties((Void)null, considerSuperclass);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(entity, considerSuperclass).toString());
    }
  }
}
