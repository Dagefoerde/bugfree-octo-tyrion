package de.wwu.pi.mdsd.umlToApp.util;

import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import de.wwu.pi.mdsd.crudDsl.crudDsl.CrudModel;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Entity;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Window;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.uml2.uml.Element;
import org.eclipse.uml2.uml.Model;
import org.eclipse.uml2.uml.Property;
import org.eclipse.uml2.uml.VisibilityKind;

@SuppressWarnings("all")
public class ModelAndPackageHelper {
  public static Iterable<org.eclipse.uml2.uml.Class> allEntities(final Model model) {
    EList<Element> _allOwnedElements = model.allOwnedElements();
    Iterable<org.eclipse.uml2.uml.Class> _filter = Iterables.<org.eclipse.uml2.uml.Class>filter(_allOwnedElements, org.eclipse.uml2.uml.Class.class);
    return _filter;
  }
  
  public static String toFolderString(final String packageName) {
    String _replace = packageName.replace(".", "/");
    return _replace;
  }
  
  public static String packageString(final org.eclipse.uml2.uml.Class clazz) {
    org.eclipse.uml2.uml.Package _package = clazz.getPackage();
    String _name = _package.getName();
    return _name;
  }
  
  public static String packageString(final CrudModel model) {
    String _name = model.getName();
    return _name;
  }
  
  public static String entityPackageString(final Entity entity) {
    EObject _eContainer = entity.eContainer();
    String _packageString = ModelAndPackageHelper.packageString(((CrudModel) _eContainer));
    String _plus = (_packageString + ".data");
    return _plus;
  }
  
  public static String logicPackageString(final Window window) {
    EObject _eContainer = window.eContainer();
    String _logicPackageString = ModelAndPackageHelper.logicPackageString(((CrudModel) _eContainer));
    return _logicPackageString;
  }
  
  public static String logicPackageString(final CrudModel model) {
    String _packageString = ModelAndPackageHelper.packageString(model);
    String _plus = (_packageString + ".logic");
    return _plus;
  }
  
  public static String guiPackageString(final Window window) {
    EObject _eContainer = window.eContainer();
    String _guiPackageString = ModelAndPackageHelper.guiPackageString(((CrudModel) _eContainer));
    return _guiPackageString;
  }
  
  public static String guiPackageString(final CrudModel model) {
    String _packageString = ModelAndPackageHelper.packageString(model);
    String _plus = (_packageString + ".gui");
    return _plus;
  }
  
  public static String entityPackageString(final org.eclipse.uml2.uml.Class clazz) {
    String _packageString = ModelAndPackageHelper.packageString(clazz);
    String _plus = (_packageString + ".data");
    return _plus;
  }
  
  public static String logicPackageString(final org.eclipse.uml2.uml.Class clazz) {
    String _packageString = ModelAndPackageHelper.packageString(clazz);
    String _plus = (_packageString + ".logic");
    return _plus;
  }
  
  public static String visibilityInJava(final VisibilityKind kind) {
    String _switchResult = null;
    boolean _matched = false;
    if (!_matched) {
      if (Objects.equal(kind,VisibilityKind.PACKAGE_LITERAL)) {
        _matched=true;
        _switchResult = "package";
      }
    }
    if (!_matched) {
      if (Objects.equal(kind,VisibilityKind.PROTECTED_LITERAL)) {
        _matched=true;
        _switchResult = "protected";
      }
    }
    if (!_matched) {
      if (Objects.equal(kind,VisibilityKind.PUBLIC_LITERAL)) {
        _matched=true;
        _switchResult = "public";
      }
    }
    if (!_matched) {
      if (Objects.equal(kind,VisibilityKind.PRIVATE_LITERAL)) {
        _matched=true;
        _switchResult = "private";
      }
    }
    return _switchResult;
  }
  
  public static String visibilityInJava(final Property p) {
    VisibilityKind _visibility = p.getVisibility();
    String _visibilityInJava = ModelAndPackageHelper.visibilityInJava(_visibility);
    return _visibilityInJava;
  }
}
