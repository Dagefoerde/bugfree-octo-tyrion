package de.wwu.pi.mdsd.umlToApp;

import com.google.common.base.Objects;
import de.wwu.pi.mdsd.crudDsl.crudDsl.CrudModel;
import de.wwu.pi.mdsd.crudDsl.crudDsl.EntryWindow;
import de.wwu.pi.mdsd.crudDsl.crudDsl.ListWindow;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Window;
import de.wwu.pi.mdsd.umlToApp.data.DataClass;
import de.wwu.pi.mdsd.umlToApp.gui.EntryWindowGenerator;
import de.wwu.pi.mdsd.umlToApp.gui.ListWindowGenerator;
import de.wwu.pi.mdsd.umlToApp.gui.StartWindowGenerator;
import de.wwu.pi.mdsd.umlToApp.logic.ServiceInitializerGen;
import de.wwu.pi.mdsd.umlToApp.logic.ServiceProvider;
import de.wwu.pi.mdsd.umlToApp.util.ClassHelper;
import de.wwu.pi.mdsd.umlToApp.util.ModelAndPackageHelper;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.uml2.uml.Model;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.generator.IFileSystemAccess;
import org.eclipse.xtext.generator.IGenerator;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@SuppressWarnings("all")
public class UmlToAppGenerator implements IGenerator {
  public static boolean isModel(final Resource input) {
    boolean _and = false;
    boolean _and_1 = false;
    EList<EObject> _contents = input.getContents();
    int _size = _contents.size();
    boolean _equals = (_size == 2);
    if (!_equals) {
      _and_1 = false;
    } else {
      CrudModel _crudModel = UmlToAppGenerator.getCrudModel(input);
      boolean _notEquals = (!Objects.equal(_crudModel, null));
      _and_1 = (_equals && _notEquals);
    }
    if (!_and_1) {
      _and = false;
    } else {
      Model _umlModel = UmlToAppGenerator.getUmlModel(input);
      boolean _notEquals_1 = (!Objects.equal(_umlModel, null));
      _and = (_and_1 && _notEquals_1);
    }
    return _and;
  }
  
  public static CrudModel getCrudModel(final Resource input) {
    EList<EObject> _contents = input.getContents();
    EObject _head = IterableExtensions.<EObject>head(_contents);
    return ((CrudModel) _head);
  }
  
  public static Model getUmlModel(final Resource input) {
    EList<EObject> _contents = input.getContents();
    Iterable<EObject> _tail = IterableExtensions.<EObject>tail(_contents);
    EObject _head = IterableExtensions.<EObject>head(_tail);
    return ((Model) _head);
  }
  
  /**
   * Limitations / Assumptions:
   * - @structure: (no nested packages, everything contained in Model)
   * - @properties: only bidirectional 1:* references, no multi-valued primitive attributes
   * - @size & position in pixel
   */
  public void doGenerate(final Resource input, final IFileSystemAccess fsa) {
    URI _uRI = input.getURI();
    String _plus = ("UmlToAppGenerator.doGenerate called with resource " + _uRI);
    System.out.print(_plus);
    boolean _isModel = UmlToAppGenerator.isModel(input);
    if (_isModel) {
      System.out.println(" - Generating ...");
      Model _umlModel = UmlToAppGenerator.getUmlModel(input);
      this.doGenerate(_umlModel, fsa);
      CrudModel _crudModel = UmlToAppGenerator.getCrudModel(input);
      this.doGenerate(_crudModel, fsa);
    } else {
      System.out.println(" - Skipped.");
    }
  }
  
  public void doGenerate(final Model model, final IFileSystemAccess fsa) {
    Iterable<org.eclipse.uml2.uml.Class> _allEntities = ModelAndPackageHelper.allEntities(model);
    final Procedure1<org.eclipse.uml2.uml.Class> _function = new Procedure1<org.eclipse.uml2.uml.Class>() {
      public void apply(final org.eclipse.uml2.uml.Class it) {
        UmlToAppGenerator.this.processEntity(it, fsa);
      }
    };
    IterableExtensions.<org.eclipse.uml2.uml.Class>forEach(_allEntities, _function);
    StringConcatenation _builder = new StringConcatenation();
    Iterable<org.eclipse.uml2.uml.Class> _allEntities_1 = ModelAndPackageHelper.allEntities(model);
    org.eclipse.uml2.uml.Class _head = IterableExtensions.<org.eclipse.uml2.uml.Class>head(_allEntities_1);
    String _logicPackageString = ModelAndPackageHelper.logicPackageString(_head);
    String _folderString = ModelAndPackageHelper.toFolderString(_logicPackageString);
    _builder.append(_folderString, "");
    _builder.append("/ServiceInitializer.java");
    ServiceInitializerGen _serviceInitializerGen = new ServiceInitializerGen();
    CharSequence _generateServiceInitializer = _serviceInitializerGen.generateServiceInitializer(model);
    fsa.generateFile(_builder.toString(), _generateServiceInitializer);
  }
  
  public void processEntity(final org.eclipse.uml2.uml.Class clazz, final IFileSystemAccess fsa) {
    StringConcatenation _builder = new StringConcatenation();
    String _entityPackageString = ModelAndPackageHelper.entityPackageString(clazz);
    String _folderString = ModelAndPackageHelper.toFolderString(_entityPackageString);
    _builder.append(_folderString, "");
    _builder.append("/");
    String _name = clazz.getName();
    _builder.append(_name, "");
    _builder.append(".java");
    DataClass _dataClass = new DataClass();
    CharSequence _generateDataClass = _dataClass.generateDataClass(clazz);
    fsa.generateFile(_builder.toString(), _generateDataClass);
    StringConcatenation _builder_1 = new StringConcatenation();
    String _logicPackageString = ModelAndPackageHelper.logicPackageString(clazz);
    String _folderString_1 = ModelAndPackageHelper.toFolderString(_logicPackageString);
    _builder_1.append(_folderString_1, "");
    _builder_1.append("/");
    String _serviceClassName = ClassHelper.serviceClassName(clazz);
    _builder_1.append(_serviceClassName, "");
    _builder_1.append(".java");
    ServiceProvider _serviceProvider = new ServiceProvider();
    String _generate = _serviceProvider.generate(clazz);
    fsa.generateFile(_builder_1.toString(), _generate);
  }
  
  public void doGenerate(final CrudModel model, final IFileSystemAccess fsa) {
    EList<Window> _windows = model.getWindows();
    final Function1<Window,String> _function = new Function1<Window,String>() {
      public String apply(final Window it) {
        String _name = it.getName();
        return _name;
      }
    };
    String _join = IterableExtensions.<Window>join(_windows, ", ", _function);
    String _plus = ("Window elements within the crud model: " + _join);
    InputOutput.<String>println(_plus);
    EList<Window> _windows_1 = model.getWindows();
    final Function1<Window,Boolean> _function_1 = new Function1<Window,Boolean>() {
      public Boolean apply(final Window e) {
        return Boolean.valueOf((e instanceof EntryWindow));
      }
    };
    Iterable<Window> _filter = IterableExtensions.<Window>filter(_windows_1, _function_1);
    final Function1<Window,EntryWindow> _function_2 = new Function1<Window,EntryWindow>() {
      public EntryWindow apply(final Window e) {
        return ((EntryWindow) e);
      }
    };
    Iterable<EntryWindow> _map = IterableExtensions.<Window, EntryWindow>map(_filter, _function_2);
    final Procedure1<EntryWindow> _function_3 = new Procedure1<EntryWindow>() {
      public void apply(final EntryWindow it) {
        UmlToAppGenerator.this.processEntryWindow(it, fsa);
      }
    };
    IterableExtensions.<EntryWindow>forEach(_map, _function_3);
    EList<Window> _windows_2 = model.getWindows();
    final Function1<Window,Boolean> _function_4 = new Function1<Window,Boolean>() {
      public Boolean apply(final Window e) {
        return Boolean.valueOf((e instanceof ListWindow));
      }
    };
    Iterable<Window> _filter_1 = IterableExtensions.<Window>filter(_windows_2, _function_4);
    final Function1<Window,ListWindow> _function_5 = new Function1<Window,ListWindow>() {
      public ListWindow apply(final Window e) {
        return ((ListWindow) e);
      }
    };
    Iterable<ListWindow> _map_1 = IterableExtensions.<Window, ListWindow>map(_filter_1, _function_5);
    final Procedure1<ListWindow> _function_6 = new Procedure1<ListWindow>() {
      public void apply(final ListWindow it) {
        UmlToAppGenerator.this.processListWindow(it, fsa);
      }
    };
    IterableExtensions.<ListWindow>forEach(_map_1, _function_6);
    this.processStartWindow(model, fsa);
  }
  
  public void processEntryWindow(final EntryWindow window, final IFileSystemAccess fsa) {
    StringConcatenation _builder = new StringConcatenation();
    String _guiPackageString = ModelAndPackageHelper.guiPackageString(window);
    String _folderString = ModelAndPackageHelper.toFolderString(_guiPackageString);
    _builder.append(_folderString, "");
    _builder.append("/");
    String _name = window.getName();
    _builder.append(_name, "");
    _builder.append(".java");
    EntryWindowGenerator _entryWindowGenerator = new EntryWindowGenerator();
    String _generate = _entryWindowGenerator.generate(window);
    fsa.generateFile(_builder.toString(), _generate);
  }
  
  public void processListWindow(final ListWindow window, final IFileSystemAccess fsa) {
    StringConcatenation _builder = new StringConcatenation();
    String _guiPackageString = ModelAndPackageHelper.guiPackageString(window);
    String _folderString = ModelAndPackageHelper.toFolderString(_guiPackageString);
    _builder.append(_folderString, "");
    _builder.append("/");
    String _name = window.getName();
    _builder.append(_name, "");
    _builder.append(".java");
    ListWindowGenerator _listWindowGenerator = new ListWindowGenerator();
    String _generate = _listWindowGenerator.generate(window);
    fsa.generateFile(_builder.toString(), _generate);
  }
  
  public void processStartWindow(final CrudModel model, final IFileSystemAccess fsa) {
    StringConcatenation _builder = new StringConcatenation();
    String _guiPackageString = ModelAndPackageHelper.guiPackageString(model);
    String _folderString = ModelAndPackageHelper.toFolderString(_guiPackageString);
    _builder.append(_folderString, "");
    _builder.append("/StartWindow.java");
    StartWindowGenerator _startWindowGenerator = new StartWindowGenerator();
    CharSequence _generateStartWindow = _startWindowGenerator.generateStartWindow(model);
    fsa.generateFile(_builder.toString(), _generateStartWindow);
  }
}
