package de.wwu.pi.mdsd.libraryImpl.logic;

import java.util.Collection;
import java.util.Date;
import java.util.LinkedList;

import de.wwu.pi.mdsd.libraryImpl.data.CD;
import de.wwu.pi.mdsd05.framework.logic.AbstractServiceProvider;
import de.wwu.pi.mdsd05.framework.logic.ValidationException;

public class CDService extends AbstractServiceProvider<CD> {
	
	//Constructor
	protected CDService() {
		super();
	}
	
	public boolean validateCD(String name, String interpreter, String asin) throws ValidationException {
		if(name == null)
			throw new ValidationException("name", "cannot be empty");
		if(interpreter == null)
			throw new ValidationException("interpreter", "cannot be empty");
		if(asin == null)
			throw new ValidationException("asin", "cannot be empty");
		return true;
	}
	
	public CD saveCD(int id, String name, String interpreter, String asin) {
		CD elem = getByOId(id);
		if(elem == null)
			elem = new CD();
		elem.setName(name);
		elem.setInterpreter(interpreter);
		elem.setAsin(asin);
		persist(elem);
		return elem;
	}
	
}
