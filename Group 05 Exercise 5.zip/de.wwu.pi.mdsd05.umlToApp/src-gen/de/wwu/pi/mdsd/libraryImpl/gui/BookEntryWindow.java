package de.wwu.pi.mdsd.libraryImpl.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.*;

import javax.swing.*;

import de.wwu.pi.mdsd.libraryImpl.data.Book;
import de.wwu.pi.mdsd.libraryImpl.data.Copy;
import de.wwu.pi.mdsd.libraryImpl.logic.BookService;
import de.wwu.pi.mdsd.libraryImpl.logic.ServiceInitializer;
import de.wwu.pi.mdsd05.framework.gui.*;
import de.wwu.pi.mdsd05.framework.logic.ValidationException;

public class BookEntryWindow extends AbstractEntryWindow<Book> implements CopyListingInterface {
	BookService service;

	private JTextField fd_name;
	private JTextField fd_author;
	private JTextField fd_isbn;
	private JList<Copy> fd_copies;
			
	public BookEntryWindow(AbstractWindow parent, Book currentEntity) {
		super(parent, currentEntity, 450, 400);
		service = ServiceInitializer.getProvider().getBookService();
	}

	@Override
	
	protected void createUIElements() {
		
		
		JLabel lbl_name = new JLabel("Name");
		lbl_name.setBounds(10, 10, 75, 20);
		getPanel().add(lbl_name);
		
		
		
		fd_name = new JTextField(currentEntity.getName() != null ? currentEntity.getName() : "");
		fd_name.setBounds(95, 10, 330, 20);
		getPanel().add(fd_name);
		fd_name.setColumns(10);
		
		
		JLabel lbl_author = new JLabel("Author");
		lbl_author.setBounds(10, 40, 75, 20);
		getPanel().add(lbl_author);
		
		
		
		fd_author = new JTextField(currentEntity.getAuthor() != null ? currentEntity.getAuthor() : "");
		fd_author.setBounds(95, 40, 330, 20);
		getPanel().add(fd_author);
		fd_author.setColumns(10);
		
		
		JLabel lbl_isbn = new JLabel("ISBN");
		lbl_isbn.setBounds(10, 70, 75, 20);
		getPanel().add(lbl_isbn);
		
		
		
		fd_isbn = new JTextField(currentEntity.getIsbn() != null ? currentEntity.getIsbn().toString() : "");
		fd_isbn.setBounds(95, 70, 330, 20);
		getPanel().add(fd_isbn);
		fd_isbn.setColumns(10);
		
		
		JLabel lbl_copies = new JLabel("Copies");
		lbl_copies.setBounds(10, 100, 75, 20);
		getPanel().add(lbl_copies);
		
		
		
		
		JButton btn_save = new JButton("Save");
		btn_save.setBounds(335, 325, 90, 25);
		getPanel().add(btn_save);
		btn_save.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
				try {
					saveAction();
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(getPanel(), "Could not be saved. " + e1.getMessage());
				}				
		}
		});
	}
	
	
	
	@Override
	protected String getTitle() {
		return "Book Entry Window";//Edit " + currentEntity.getClass().getSimpleName() + " Window";
	}
	
	@Override
	protected boolean saveAction() throws ParseException {
		//Read values from different fields 
		String
		  name = fd_name.getText().isEmpty() ? null : fd_name.getText();
		String
		  author = fd_author.getText().isEmpty() ? null : fd_author.getText();
		Integer
		  isbn = fd_isbn.getText().isEmpty() ? null : Integer.valueOf(fd_isbn.getText());
		
		//validation
		try {
			service.validateBook(name, author, isbn);
			BookEntryWindow.this.closeWindow();
		} catch (ValidationException e) {
			Util.showUserMessage("Validation error for " + e.getField(), "Validation error for " + e.getField() + ": " + e.getMessage());
			return false;
		}
		
		//persist
		currentEntity = service.saveBook(currentEntity.getOid(), name, author, isbn);
		
		//reload the listing in the parent window to make changes visible
		if(getParent() instanceof MediumListingInterface)
			((MediumListingInterface) getParent()).initializeMediumListings();
		if(getParent() instanceof BookListingInterface)
			((BookListingInterface) getParent()).initializeBookListings();
		return true;
	}
	
	@Override
	protected void createLists() {

		fd_copies = new JList<Copy>();
		initializeFd_copies();
		fd_copies.setBounds(95, 100, 330, 100-25);
		getPanel().add(fd_copies);
		//Button for List Element								
		JButton btn_fd_copies_Add = new JButton("Add");
									btn_fd_copies_Add.setEnabled(!currentEntity.isNew());
									btn_fd_copies_Add.setBounds(95,180,106,20);
									getPanel().add(btn_fd_copies_Add);
									btn_fd_copies_Add.addActionListener(new ActionListener() {
										@Override
										public void actionPerformed(ActionEvent e) {
											new CopyEntryWindow(BookEntryWindow.this, new Copy().initializeMedium(currentEntity)).open();
										}
									});
		JButton btn_fd_copies_Edit = new JButton("Edit");
									btn_fd_copies_Edit.setBounds(206,180,106,20);
									btn_fd_copies_Edit.setEnabled(!currentEntity.isNew());
									getPanel().add(btn_fd_copies_Edit);
									btn_fd_copies_Edit.addActionListener(new ActionListener() {
										@Override
										public void actionPerformed(ActionEvent e) {
											Copy entity = BookEntryWindow.this.fd_copies.getSelectedValue();
											if(entity == null)
												Util.showNothingSelected();
											else
												new CopyEntryWindow(BookEntryWindow.this, entity).open();
										}
									});
									JButton btn_fd_copies_Delete = new JButton("Delete");
									btn_fd_copies_Delete.setEnabled(false);
									btn_fd_copies_Delete.setBounds(317,180,106,20);
									getPanel().add(btn_fd_copies_Delete);
	}
	
	public void initializeFd_copies() {
		fd_copies.setListData(new Vector<Copy>(currentEntity.getCopies()));
	}
	
	@Override
	public void initializeCopyListings() {
		initializeFd_copies();
	}
}
