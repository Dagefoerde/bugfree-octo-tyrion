package de.wwu.pi.mdsd.libraryImpl.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.*;

import javax.swing.*;

import de.wwu.pi.mdsd05.framework.gui.*;
import de.wwu.pi.mdsd05.framework.logic.ValidationException;
import de.wwu.pi.mdsd.libraryImpl.data.Loan;
import de.wwu.pi.mdsd.libraryImpl.data.User;
import de.wwu.pi.mdsd.libraryImpl.logic.ServiceInitializer;
import de.wwu.pi.mdsd.libraryImpl.logic.UserService;

public class UserEntryWindow extends AbstractEntryWindow<User> implements LoanListingInterface {
	UserService service;

	private JTextField fd_name;
	private JTextField fd_address;
	private JList<Loan> fd_loans;
			
	public UserEntryWindow(AbstractWindow parent, User currentEntity) {
		super(parent, currentEntity, 450, 400);
		service = ServiceInitializer.getProvider().getUserService();
	}

	@Override
	
	protected void createUIElements() {
		
		
		JLabel lbl_name = new JLabel("Name");
		lbl_name.setBounds(10, 10, 75, 20);
		getPanel().add(lbl_name);
		
		
		
		fd_name = new JTextField(currentEntity.getName() != null ? currentEntity.getName() : "");
		fd_name.setBounds(95, 10, 330, 20);
		getPanel().add(fd_name);
		fd_name.setColumns(10);
		
		
		JLabel lbl_address = new JLabel("Address");
		lbl_address.setBounds(10, 40, 75, 20);
		getPanel().add(lbl_address);
		
		
		
		fd_address = new JTextField(currentEntity.getAddress() != null ? currentEntity.getAddress() : "");
		fd_address.setBounds(95, 40, 330, 20);
		getPanel().add(fd_address);
		fd_address.setColumns(10);
		
		
		JLabel lbl_loans = new JLabel("Loans");
		lbl_loans.setBounds(10, 70, 75, 20);
		getPanel().add(lbl_loans);
		
		
		
		
		JButton btn_save = new JButton("Save");
		btn_save.setBounds(335, 325, 90, 25);
		getPanel().add(btn_save);
		btn_save.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
				try {
					saveAction();
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(getPanel(), "Could not be saved. " + e1.getMessage());
				}				
		}
		});
	}
	
	
	
	@Override
	protected String getTitle() {
		return "User Listing";//Edit " + currentEntity.getClass().getSimpleName() + " Window";
	}
	
	@Override
	protected boolean saveAction() throws ParseException {
		//Read values from different fields 
		String
		  name = fd_name.getText().isEmpty() ? null : fd_name.getText();
		String
		  address = fd_address.getText().isEmpty() ? null : fd_address.getText();
		
		//validation
		try {
			service.validateUser(name, address);
			UserEntryWindow.this.closeWindow();
		} catch (ValidationException e) {
			Util.showUserMessage("Validation error for " + e.getField(), "Validation error for " + e.getField() + ": " + e.getMessage());
			return false;
		}
		
		//persist
		currentEntity = service.saveUser(currentEntity.getOid(), name, address);
		
		//reload the listing in the parent window to make changes visible
		if(getParent() instanceof UserListingInterface)
			((UserListingInterface) getParent()).initializeUserListings();
		return true;
	}
	
	@Override
	protected void createLists() {
		JScrollPane scroll_fd_loans = new JScrollPane();
		scroll_fd_loans.setBounds(95, 70, 150, 100-25);
		getPanel().add(scroll_fd_loans);
		
		fd_loans = new JList<Loan>();
		initializeFd_loans();
		scroll_fd_loans.setViewportView(fd_loans);
		
		//Button for List Element								
		JButton btn_fd_loans_Add = new JButton("Add");
									btn_fd_loans_Add.setEnabled(!currentEntity.isNew());
									btn_fd_loans_Add.setBounds(95,150,72,20);
									getPanel().add(btn_fd_loans_Add);
									btn_fd_loans_Add.addActionListener(new ActionListener() {
										@Override
										public void actionPerformed(ActionEvent e) {
											new LoanEntryWindow(UserEntryWindow.this, new Loan().initializeUser(currentEntity)).open();
										}
									});
		JButton btn_fd_loans_Edit = new JButton("Edit");
									btn_fd_loans_Edit.setBounds(172,150,72,20);
									btn_fd_loans_Edit.setEnabled(!currentEntity.isNew());
									getPanel().add(btn_fd_loans_Edit);
									btn_fd_loans_Edit.addActionListener(new ActionListener() {
										@Override
										public void actionPerformed(ActionEvent e) {
											Loan entity = UserEntryWindow.this.fd_loans.getSelectedValue();
											if(entity == null)
												Util.showNothingSelected();
											else
												new LoanEntryWindow(UserEntryWindow.this, entity).open();
										}
									});
	}
	
	public void initializeFd_loans() {
		fd_loans.setListData(new Vector<Loan>(currentEntity.getLoans()));
	}
	
	@Override
	public void initializeLoanListings() {
		initializeFd_loans();
	}
}
