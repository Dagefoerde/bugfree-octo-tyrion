package de.wwu.pi.mdsd.libraryImpl.gui;

import java.util.Vector;

import de.wwu.pi.mdsd05.framework.gui.AbstractListWindow;
import de.wwu.pi.mdsd05.framework.gui.AbstractWindow;
import de.wwu.pi.mdsd.libraryImpl.logic.ServiceInitializer;
import de.wwu.pi.mdsd.libraryImpl.data.Copy;
	
public class CopyListWindow extends AbstractListWindow<Copy> implements CopyListingInterface{

	public CopyListWindow(AbstractWindow parent) {
		super(parent,400,450);
	}
	
	public String getTitle() {
		return "Copy Listing";
	}
	
	@Override
	public Vector<Copy> getElements() {
		return new Vector<Copy>(ServiceInitializer.getProvider().getCopyService().getAll());
	}
	
	@Override
	public void initializeCopyListings() {
		initializeList();
	}
	
	@Override
	public void showEntryWindow(Copy entity) {
		//If entity is null -> initialize entity as new entity
		//show Entity Edit Window
		if(entity == null) {
			entity = new Copy();
		}
		new CopyEntryWindow(this,entity).open();
	}
}

//Interface that needs to be implemented, if the class references Copy objects in a list
interface CopyListingInterface {
	public void initializeCopyListings();
}