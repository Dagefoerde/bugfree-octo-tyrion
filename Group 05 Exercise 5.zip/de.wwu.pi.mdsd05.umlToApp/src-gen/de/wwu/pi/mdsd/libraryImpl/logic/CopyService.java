package de.wwu.pi.mdsd.libraryImpl.logic;

import java.util.Collection;
import java.util.Date;
import java.util.LinkedList;

import de.wwu.pi.mdsd05.framework.logic.AbstractServiceProvider;
import de.wwu.pi.mdsd05.framework.logic.ValidationException;

import de.wwu.pi.mdsd.libraryImpl.data.Copy;
import de.wwu.pi.mdsd.libraryImpl.data.Medium;

public class CopyService extends AbstractServiceProvider<Copy> {
	
	//Constructor
	protected CopyService() {
		super();
	}
	
	public boolean validateCopy(Integer inventoryNo, Medium medium) throws ValidationException {
		if(inventoryNo == null)
			throw new ValidationException("inventoryNo", "cannot be empty");
		if(medium == null)
			throw new ValidationException("medium", "cannot be empty");
		return true;
	}
	
	public Copy saveCopy(int id, Integer inventoryNo, Medium medium) {
		Copy elem = getByOId(id);
		if(elem == null)
			elem = new Copy();
		elem.setInventoryNo(inventoryNo);
		elem.setMedium(medium);
		persist(elem);
		return elem;
	}
	
}
