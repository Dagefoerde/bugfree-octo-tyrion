package de.wwu.pi.mdsd.libraryImpl.logic;

import java.util.Collection;
import java.util.Date;
import java.util.LinkedList;

import de.wwu.pi.mdsd05.framework.logic.AbstractServiceProvider;
import de.wwu.pi.mdsd05.framework.logic.ValidationException;

import de.wwu.pi.mdsd.libraryImpl.data.Medium;

public class MediumService extends AbstractServiceProvider<Medium> {
	
	//Constructor
	protected MediumService() {
		super();
	}
	
	public boolean validateMedium(String name) throws ValidationException {
		if(name == null)
			throw new ValidationException("name", "cannot be empty");
		return true;
	}
	
	
	@Override
	//Class has subclasses, thus getAll need to return subclasses
	public Collection<Medium> getAll() {
		Collection<Medium> result = new LinkedList<Medium>();
		result.addAll(super.getAll());
		result.addAll(ServiceInitializer.getProvider().getBookService().getAll());
		result.addAll(ServiceInitializer.getProvider().getCDService().getAll());
		return result;
	}
}
