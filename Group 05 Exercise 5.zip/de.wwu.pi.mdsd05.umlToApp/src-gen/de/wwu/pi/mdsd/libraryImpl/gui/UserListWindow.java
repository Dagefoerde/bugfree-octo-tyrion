package de.wwu.pi.mdsd.libraryImpl.gui;

import java.util.Vector;

import de.wwu.pi.mdsd05.framework.gui.AbstractListWindow;
import de.wwu.pi.mdsd05.framework.gui.AbstractWindow;
import de.wwu.pi.mdsd.libraryImpl.logic.ServiceInitializer;
import de.wwu.pi.mdsd.libraryImpl.data.User;
	
public class UserListWindow extends AbstractListWindow<User> implements UserListingInterface{

	public UserListWindow(AbstractWindow parent) {
		super(parent,400,450);
	}
	
	public String getTitle() {
		return "User Listing";
	}
	
	@Override
	public Vector<User> getElements() {
		return new Vector<User>(ServiceInitializer.getProvider().getUserService().getAll());
	}
	
	@Override
	public void initializeUserListings() {
		initializeList();
	}
	
	@Override
	public void showEntryWindow(User entity) {
		//If entity is null -> initialize entity as new entity
		//show Entity Edit Window
		if(entity == null) {
			entity = new User();
		}
		new UserEntryWindow(this,entity).open();
	}
}

//Interface that needs to be implemented, if the class references User objects in a list
interface UserListingInterface {
	public void initializeUserListings();
}