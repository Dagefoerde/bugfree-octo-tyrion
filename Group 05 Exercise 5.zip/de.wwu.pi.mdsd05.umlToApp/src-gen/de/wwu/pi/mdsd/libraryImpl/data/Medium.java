package de.wwu.pi.mdsd.libraryImpl.data;

import java.util.*;
import de.wwu.pi.mdsd05.framework.data.AbstractDataClass;

@SuppressWarnings("serial")
public abstract class Medium extends AbstractDataClass{
	
	public String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public List<Copy> copies = new ArrayList<Copy>();
	public List<Copy> getCopies() {
		return copies;
	}
	protected void addToCopies(Copy elem) {
		copies.add(elem);
	}
	
	//Constructors
	public Medium(String name) {
		this();
		setName(name);
	}
	
	//Default Constructor
	public Medium() {
		super();
	}
	
	@Override
	public String toString() {
		return (getName()) + "";
	}
}
