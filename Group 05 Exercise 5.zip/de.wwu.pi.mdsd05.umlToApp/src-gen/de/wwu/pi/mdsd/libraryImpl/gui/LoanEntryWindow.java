package de.wwu.pi.mdsd.libraryImpl.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.*;

import javax.swing.*;

import de.wwu.pi.mdsd05.framework.gui.*;
import de.wwu.pi.mdsd05.framework.logic.ValidationException;
import de.wwu.pi.mdsd.libraryImpl.data.Copy;
import de.wwu.pi.mdsd.libraryImpl.data.Loan;
import de.wwu.pi.mdsd.libraryImpl.data.User;
import de.wwu.pi.mdsd.libraryImpl.logic.LoanService;
import de.wwu.pi.mdsd.libraryImpl.logic.ServiceInitializer;

public class LoanEntryWindow extends AbstractEntryWindow<Loan> {
	LoanService service;

	private JTextField fd_loanDate;
	private JTextField fd_returnDate;
	private JComboBox<Copy> fd_copy;
	private JComboBox<User> fd_user;
			
	public LoanEntryWindow(AbstractWindow parent, Loan currentEntity) {
		super(parent, currentEntity, 450, 400);
		service = ServiceInitializer.getProvider().getLoanService();
	}

	@Override
	
	protected void createUIElements() {
		
		
		JLabel lbl_loanDate = new JLabel("Loan Date");
		lbl_loanDate.setBounds(10, 10, 75, 20);
		getPanel().add(lbl_loanDate);
		
		
		
		fd_loanDate = new JTextField(currentEntity.getLoanDate() != null ? Util.DATE_TIME_FORMATTER.format(currentEntity.getLoanDate()) : "");
		fd_loanDate.setBounds(95, 10, 330, 20);
		getPanel().add(fd_loanDate);
		fd_loanDate.setColumns(10);
		
		
		JLabel lbl_returnDate = new JLabel("Return Date");
		lbl_returnDate.setBounds(10, 40, 75, 20);
		getPanel().add(lbl_returnDate);
		
		
		
		fd_returnDate = new JTextField(currentEntity.getReturnDate() != null ? Util.DATE_TIME_FORMATTER.format(currentEntity.getReturnDate()) : "");
		fd_returnDate.setBounds(95, 40, 330, 20);
		getPanel().add(fd_returnDate);
		fd_returnDate.setColumns(10);
		
		
		JLabel lbl_copy = new JLabel("Copy");
		lbl_copy.setBounds(10, 70, 75, 20);
		getPanel().add(lbl_copy);
		
		
		
		fd_copy = new JComboBox<Copy>(new Vector<>(ServiceInitializer.getProvider().getCopyService().getAll()));
		fd_copy.setSelectedItem(currentEntity.getCopy());
		fd_copy.setBounds(95, 70, 330, 20);
		getPanel().add(fd_copy);
		
		
		JLabel lbl_user = new JLabel("User");
		lbl_user.setBounds(10, 100, 75, 20);
		getPanel().add(lbl_user);
		
		
		
		fd_user = new JComboBox<User>(new Vector<>(ServiceInitializer.getProvider().getUserService().getAll()));
		fd_user.setSelectedItem(currentEntity.getUser());
		fd_user.setBounds(95, 100, 330, 20);
		getPanel().add(fd_user);
		
		JButton btn_save = new JButton("Save");
		btn_save.setBounds(335, 325, 90, 25);
		getPanel().add(btn_save);
		btn_save.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
				try {
					saveAction();
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(getPanel(), "Could not be saved. " + e1.getMessage());
				}				
		}
		});
	}
	
	
	
	@Override
	protected String getTitle() {
		return "Loan Listing";//Edit " + currentEntity.getClass().getSimpleName() + " Window";
	}
	
	@Override
	protected boolean saveAction() throws ParseException {
		//Read values from different fields 
		Date
		  loanDate = fd_loanDate.getText().isEmpty() ? null : Util.DATE_TIME_FORMATTER.parse(fd_loanDate.getText());
		Date
		  returnDate = fd_returnDate.getText().isEmpty() ? null : Util.DATE_TIME_FORMATTER.parse(fd_returnDate.getText());
		Copy
		  copy = fd_copy.getItemAt(fd_copy.getSelectedIndex());
		User
		  user = fd_user.getItemAt(fd_user.getSelectedIndex());
		
		//validation
		try {
			service.validateLoan(loanDate, returnDate, user, copy);
			LoanEntryWindow.this.closeWindow();
		} catch (ValidationException e) {
			Util.showUserMessage("Validation error for " + e.getField(), "Validation error for " + e.getField() + ": " + e.getMessage());
			return false;
		}
		
		//persist
		currentEntity = service.saveLoan(currentEntity.getOid(), loanDate, returnDate, user, copy);
		
		//reload the listing in the parent window to make changes visible
		if(getParent() instanceof LoanListingInterface)
			((LoanListingInterface) getParent()).initializeLoanListings();
		return true;
	}
	
	@Override
	protected void createLists() {
	}
}
