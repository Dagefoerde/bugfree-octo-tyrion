package de.wwu.pi.mdsd.libraryImpl.gui;

import java.util.Vector;

//import de.wwu.pi.mdsd.framework.logic.*;
import de.wwu.pi.mdsd.libraryImpl.logic.ServiceInitializer;
import de.wwu.pi.mdsd.libraryImpl.data.Loan;
import de.wwu.pi.mdsd05.framework.gui.AbstractListWindow;
import de.wwu.pi.mdsd05.framework.gui.AbstractWindow;
	
public class LoanListWindow extends AbstractListWindow<Loan> implements LoanListingInterface{

	public LoanListWindow(AbstractWindow parent) {
		super(parent,400,450);
	}
	
	public String getTitle() {
		return "Loan Listing";
	}
	
	@Override
	public Vector<Loan> getElements() {
		return new Vector<Loan>(ServiceInitializer.getProvider().getLoanService().getAll());
	}
	
	@Override
	public void initializeLoanListings() {
		initializeList();
	}
	
	@Override
	public void showEntryWindow(Loan entity) {
		//If entity is null -> initialize entity as new entity
		//show Entity Edit Window
		if(entity == null) {
			entity = new Loan();
		}
		new LoanEntryWindow(this,entity).open();
	}
}

//Interface that needs to be implemented, if the class references Loan objects in a list
interface LoanListingInterface {
	public void initializeLoanListings();
}