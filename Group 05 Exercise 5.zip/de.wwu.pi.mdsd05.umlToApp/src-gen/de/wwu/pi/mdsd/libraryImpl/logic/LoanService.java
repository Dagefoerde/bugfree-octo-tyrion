package de.wwu.pi.mdsd.libraryImpl.logic;

import java.util.Collection;
import java.util.Date;
import java.util.LinkedList;

import de.wwu.pi.mdsd05.framework.logic.AbstractServiceProvider;
import de.wwu.pi.mdsd05.framework.logic.ValidationException;

import de.wwu.pi.mdsd.libraryImpl.data.Copy;
import de.wwu.pi.mdsd.libraryImpl.data.Loan;
import de.wwu.pi.mdsd.libraryImpl.data.User;

public class LoanService extends AbstractServiceProvider<Loan> {
	
	//Constructor
	protected LoanService() {
		super();
	}
	
	public boolean validateLoan(Date loanDate, Date returnDate, User user, Copy copy) throws ValidationException {
		if(loanDate == null)
			throw new ValidationException("loanDate", "cannot be empty");
		if(user == null)
			throw new ValidationException("user", "cannot be empty");
		if(copy == null)
			throw new ValidationException("copy", "cannot be empty");
		return true;
	}
	
	public Loan saveLoan(int id, Date loanDate, Date returnDate, User user, Copy copy) {
		Loan elem = getByOId(id);
		if(elem == null)
			elem = new Loan();
		elem.setLoanDate(loanDate);
		elem.setReturnDate(returnDate);
		elem.setUser(user);
		elem.setCopy(copy);
		persist(elem);
		return elem;
	}
	
}
