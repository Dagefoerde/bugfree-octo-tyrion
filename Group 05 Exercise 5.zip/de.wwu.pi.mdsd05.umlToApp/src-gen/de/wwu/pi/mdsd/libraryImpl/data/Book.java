package de.wwu.pi.mdsd.libraryImpl.data;

import java.util.*;
import de.wwu.pi.mdsd05.framework.data.AbstractDataClass;

@SuppressWarnings("serial")
public class Book extends Medium{
	
	public String author;
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public Integer isbn;
	public Integer getIsbn() {
		return isbn;
	}
	public void setIsbn(Integer isbn) {
		this.isbn = isbn;
	}
	
	//Constructors
	public Book(String name, String author, Integer isbn) {
		super(name);
		setAuthor(author);
		setIsbn(isbn);
	}
	
	//Default Constructor
	public Book() {
		super();
	}
	
	@Override
	public String toString() {
		return super.toString() + ", " + (getAuthor()) + ", " + (getIsbn()) + "";
	}
}
