package de.wwu.pi.mdsd.libraryImpl.data;

import java.util.*;
import de.wwu.pi.mdsd05.framework.data.AbstractDataClass;

@SuppressWarnings("serial")
public class User extends AbstractDataClass{
	
	public String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String address;
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public List<Loan> loans = new ArrayList<Loan>();
	public List<Loan> getLoans() {
		return loans;
	}
	protected void addToLoans(Loan elem) {
		loans.add(elem);
	}
	
	//Constructors
	public User(String name, String address) {
		this();
		setName(name);
		setAddress(address);
	}
	
	//Default Constructor
	public User() {
		super();
	}
	
	@Override
	public String toString() {
		return (getName()) + ", " + (getAddress()) + "";
	}
}
