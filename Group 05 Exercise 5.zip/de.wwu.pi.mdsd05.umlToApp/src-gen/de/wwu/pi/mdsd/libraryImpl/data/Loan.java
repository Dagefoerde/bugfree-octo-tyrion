package de.wwu.pi.mdsd.libraryImpl.data;

import java.util.*;
import de.wwu.pi.mdsd05.framework.data.AbstractDataClass;

@SuppressWarnings("serial")
public class Loan extends AbstractDataClass{
	
	public Date loanDate;
	public Date getLoanDate() {
		return loanDate;
	}
	public void setLoanDate(Date loanDate) {
		this.loanDate = loanDate;
	}
	
	public Date returnDate;
	public Date getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}
	
	public User user;
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		//do nothing, if user is the same
		if(this.user == user)
			return;
		//remove old user from opposite
		if(this.user != null)
			this.user.loans.remove(this.user);
		this.user = user;
		//unless new user is null add 
		if(user != null)
			user.addToLoans(this);
		this.user = user;
	}
	
	public Copy copy;
	public Copy getCopy() {
		return copy;
	}
	public void setCopy(Copy copy) {
		//do nothing, if copy is the same
		if(this.copy == copy)
			return;
		//remove old copy from opposite
		if(this.copy != null)
			this.copy.loans.remove(this.copy);
		this.copy = copy;
		//unless new copy is null add 
		if(copy != null)
			copy.addToLoans(this);
		this.copy = copy;
	}
	
	//Constructors
	public Loan(Date loanDate, User user, Copy copy) {
		this();
		setLoanDate(loanDate);
		setUser(user);
		setCopy(copy);
	}
	// Initializer for user; can be called when initializing a new Loan. Does not take care of friend methods
	public Loan initializeUser(User user) {
		this.user = user;
		return this;
	}
	// Initializer for copy; can be called when initializing a new Loan. Does not take care of friend methods
	public Loan initializeCopy(Copy copy) {
		this.copy = copy;
		return this;
	}
	
	//Default Constructor
	public Loan() {
		super();
	}
	
	@Override
	public String toString() {
		return (getLoanDate()) + ", " + ((getReturnDate()==null)?"-":getReturnDate()) + ", " + (getUser()) + ", " + (getCopy()) + "";
	}
}
