package de.wwu.pi.mdsd.libraryImpl.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.*;

import javax.swing.*;

import de.wwu.pi.mdsd.libraryImpl.data.CD;
import de.wwu.pi.mdsd.libraryImpl.data.Copy;
import de.wwu.pi.mdsd.libraryImpl.logic.CDService;
import de.wwu.pi.mdsd.libraryImpl.logic.ServiceInitializer;
import de.wwu.pi.mdsd05.framework.gui.*;
import de.wwu.pi.mdsd05.framework.logic.ValidationException;

public class CDEntryWindow extends AbstractEntryWindow<CD> implements CopyListingInterface {
	CDService service;

	private JTextField fd_name;
	private JTextField fd_interpreter;
	private JTextField fd_asin;
	private JList<Copy> fd_copies;
			
	public CDEntryWindow(AbstractWindow parent, CD currentEntity) {
		super(parent, currentEntity, 450, 400);
		service = ServiceInitializer.getProvider().getCDService();
	}

	@Override
	
	protected void createUIElements() {
		
		
		JLabel lbl_name = new JLabel("Name");
		lbl_name.setBounds(10, 10, 75, 20);
		getPanel().add(lbl_name);
		
		
		
		fd_name = new JTextField(currentEntity.getName() != null ? currentEntity.getName() : "");
		fd_name.setBounds(95, 10, 330, 20);
		getPanel().add(fd_name);
		fd_name.setColumns(10);
		
		
		JLabel lbl_interpreter = new JLabel("Interpreter");
		lbl_interpreter.setBounds(10, 40, 75, 20);
		getPanel().add(lbl_interpreter);
		
		
		
		fd_interpreter = new JTextField(currentEntity.getInterpreter() != null ? currentEntity.getInterpreter() : "");
		fd_interpreter.setBounds(95, 40, 330, 20);
		getPanel().add(fd_interpreter);
		fd_interpreter.setColumns(10);
		
		
		JLabel lbl_asin = new JLabel("ASIN");
		lbl_asin.setBounds(10, 70, 75, 20);
		getPanel().add(lbl_asin);
		
		
		
		fd_asin = new JTextField(currentEntity.getAsin() != null ? currentEntity.getAsin() : "");
		fd_asin.setBounds(95, 70, 330, 20);
		getPanel().add(fd_asin);
		fd_asin.setColumns(10);
		
		
		JLabel lbl_copies = new JLabel("Copies");
		lbl_copies.setBounds(10, 100, 75, 20);
		getPanel().add(lbl_copies);
		
		
		
		
		JButton btn_save = new JButton("Save");
		btn_save.setBounds(335, 325, 90, 25);
		getPanel().add(btn_save);
		btn_save.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
				try {
					saveAction();
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(getPanel(), "Could not be saved. " + e1.getMessage());
				}				
		}
		});
	}
	
	
	
	@Override
	protected String getTitle() {
		return "CD Entry Window";//Edit " + currentEntity.getClass().getSimpleName() + " Window";
	}
	
	@Override
	protected boolean saveAction() throws ParseException {
		//Read values from different fields 
		String
		  name = fd_name.getText().isEmpty() ? null : fd_name.getText();
		String
		  interpreter = fd_interpreter.getText().isEmpty() ? null : fd_interpreter.getText();
		String
		  asin = fd_asin.getText().isEmpty() ? null : fd_asin.getText();
		
		//validation
		try {
			service.validateCD(name, interpreter, asin);
			CDEntryWindow.this.closeWindow();
		} catch (ValidationException e) {
			Util.showUserMessage("Validation error for " + e.getField(), "Validation error for " + e.getField() + ": " + e.getMessage());
			return false;
		}
		
		//persist
		currentEntity = service.saveCD(currentEntity.getOid(), name, interpreter, asin);
		
		//reload the listing in the parent window to make changes visible
		if(getParent() instanceof MediumListingInterface)
			((MediumListingInterface) getParent()).initializeMediumListings();
		if(getParent() instanceof CDListingInterface)
			((CDListingInterface) getParent()).initializeCDListings();
		return true;
	}
	
	@Override
	protected void createLists() {

		fd_copies = new JList<Copy>();
		initializeFd_copies();
		fd_copies.setBounds(95, 100, 330, 100-25);
		getPanel().add(fd_copies);
		//Button for List Element								
		JButton btn_fd_copies_Add = new JButton("Add");
									btn_fd_copies_Add.setEnabled(!currentEntity.isNew());
									btn_fd_copies_Add.setBounds(95,180,106,20);
									getPanel().add(btn_fd_copies_Add);
									btn_fd_copies_Add.addActionListener(new ActionListener() {
										@Override
										public void actionPerformed(ActionEvent e) {
											new CopyEntryWindow(CDEntryWindow.this, new Copy().initializeMedium(currentEntity)).open();
										}
									});
		JButton btn_fd_copies_Edit = new JButton("Edit");
									btn_fd_copies_Edit.setBounds(206,180,106,20);
									btn_fd_copies_Edit.setEnabled(!currentEntity.isNew());
									getPanel().add(btn_fd_copies_Edit);
									btn_fd_copies_Edit.addActionListener(new ActionListener() {
										@Override
										public void actionPerformed(ActionEvent e) {
											Copy entity = CDEntryWindow.this.fd_copies.getSelectedValue();
											if(entity == null)
												Util.showNothingSelected();
											else
												new CopyEntryWindow(CDEntryWindow.this, entity).open();
										}
									});
									JButton btn_fd_copies_Delete = new JButton("Delete");
									btn_fd_copies_Delete.setEnabled(false);
									btn_fd_copies_Delete.setBounds(317,180,106,20);
									getPanel().add(btn_fd_copies_Delete);
	}
	
	public void initializeFd_copies() {
		fd_copies.setListData(new Vector<Copy>(currentEntity.getCopies()));
	}
	
	@Override
	public void initializeCopyListings() {
		initializeFd_copies();
	}
}
