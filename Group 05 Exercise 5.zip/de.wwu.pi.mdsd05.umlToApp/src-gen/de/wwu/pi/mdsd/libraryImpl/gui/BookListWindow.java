package de.wwu.pi.mdsd.libraryImpl.gui;

import java.util.Vector;

//import de.wwu.pi.mdsd.framework.logic.*;
import de.wwu.pi.mdsd.libraryImpl.logic.ServiceInitializer;
import de.wwu.pi.mdsd.libraryImpl.data.Book;
import de.wwu.pi.mdsd05.framework.gui.AbstractListWindow;
import de.wwu.pi.mdsd05.framework.gui.AbstractWindow;
	
public class BookListWindow extends AbstractListWindow<Book> implements BookListingInterface{

	public BookListWindow(AbstractWindow parent) {
		super(parent,400,450);
	}
	
	public String getTitle() {
		return "Book List Window";
	}
	
	@Override
	public Vector<Book> getElements() {
		return new Vector<Book>(ServiceInitializer.getProvider().getBookService().getAll());
	}
	
	@Override
	public void initializeBookListings() {
		initializeList();
	}
	
	@Override
	public void showEntryWindow(Book entity) {
		//If entity is null -> initialize entity as new entity
		//show Entity Edit Window
		if(entity == null) {
			entity = new Book();
		}
		new BookEntryWindow(this,entity).open();
	}
}

//Interface that needs to be implemented, if the class references Book objects in a list
interface BookListingInterface {
	public void initializeBookListings();
}