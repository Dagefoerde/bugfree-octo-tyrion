package de.wwu.pi.mdsd.libraryImpl.data;

import java.util.*;

import de.wwu.pi.mdsd05.framework.data.AbstractDataClass;

@SuppressWarnings("serial")
public class Copy extends AbstractDataClass{
	
	public Integer inventoryNo;
	public Integer getInventoryNo() {
		return inventoryNo;
	}
	public void setInventoryNo(Integer inventoryNo) {
		this.inventoryNo = inventoryNo;
	}
	
	public Medium medium;
	public Medium getMedium() {
		return medium;
	}
	public void setMedium(Medium medium) {
		//do nothing, if medium is the same
		if(this.medium == medium)
			return;
		//remove old medium from opposite
		if(this.medium != null)
			this.medium.copies.remove(this.medium);
		this.medium = medium;
		//unless new medium is null add 
		if(medium != null)
			medium.addToCopies(this);
		this.medium = medium;
	}
	
	public List<Loan> loans = new ArrayList<Loan>();
	public List<Loan> getLoans() {
		return loans;
	}
	protected void addToLoans(Loan elem) {
		loans.add(elem);
	}
	
	//Constructors
	public Copy(Integer inventoryNo, Medium medium) {
		this();
		setInventoryNo(inventoryNo);
		setMedium(medium);
	}
	// Initializer for medium; can be called when initializing a new Copy. Does not take care of friend methods
	public Copy initializeMedium(Medium medium) {
		this.medium = medium;
		return this;
	}
	
	//Default Constructor
	public Copy() {
		super();
	}
	
	@Override
	public String toString() {
		return (getInventoryNo()) + "";
	}
}
