package de.wwu.pi.mdsd.libraryImpl.data;

import java.util.*;
import de.wwu.pi.mdsd05.framework.data.AbstractDataClass;

@SuppressWarnings("serial")
public class CD extends Medium{
	
	public String interpreter;
	public String getInterpreter() {
		return interpreter;
	}
	public void setInterpreter(String interpreter) {
		this.interpreter = interpreter;
	}
	
	public String asin;
	public String getAsin() {
		return asin;
	}
	public void setAsin(String asin) {
		this.asin = asin;
	}
	
	//Constructors
	public CD(String name, String interpreter, String asin) {
		super(name);
		setInterpreter(interpreter);
		setAsin(asin);
	}
	
	//Default Constructor
	public CD() {
		super();
	}
	
	@Override
	public String toString() {
		return super.toString() + ", " + (getInterpreter()) + ", " + (getAsin()) + "";
	}
}
