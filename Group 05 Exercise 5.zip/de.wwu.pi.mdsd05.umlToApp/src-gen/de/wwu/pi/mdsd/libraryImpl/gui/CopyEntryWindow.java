package de.wwu.pi.mdsd.libraryImpl.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.*;

import javax.swing.*;

import de.wwu.pi.mdsd05.framework.gui.*;
import de.wwu.pi.mdsd05.framework.logic.ValidationException;
import de.wwu.pi.mdsd.libraryImpl.data.Copy;
import de.wwu.pi.mdsd.libraryImpl.data.Loan;
import de.wwu.pi.mdsd.libraryImpl.data.Medium;
import de.wwu.pi.mdsd.libraryImpl.logic.CopyService;
import de.wwu.pi.mdsd.libraryImpl.logic.ServiceInitializer;

public class CopyEntryWindow extends AbstractEntryWindow<Copy> implements LoanListingInterface {
	CopyService service;

	private JTextField fd_inventoryNo;
	private JComboBox<Medium> fd_medium;
	private JList<Loan> fd_loans;
			
	public CopyEntryWindow(AbstractWindow parent, Copy currentEntity) {
		super(parent, currentEntity, 450, 400);
		service = ServiceInitializer.getProvider().getCopyService();
	}

	@Override
	
	protected void createUIElements() {
		
		
		JLabel lbl_inventoryNo = new JLabel("Inventory No");
		lbl_inventoryNo.setBounds(10, 10, 75, 20);
		getPanel().add(lbl_inventoryNo);
		
		
		
		fd_inventoryNo = new JTextField(currentEntity.getInventoryNo() != null ? currentEntity.getInventoryNo().toString() : "");
		fd_inventoryNo.setBounds(95, 10, 330, 20);
		getPanel().add(fd_inventoryNo);
		fd_inventoryNo.setColumns(10);
		
		
		JLabel lbl_medium = new JLabel("Medium");
		lbl_medium.setBounds(10, 40, 75, 20);
		getPanel().add(lbl_medium);
		
		
		
		fd_medium = new JComboBox<Medium>(new Vector<>(ServiceInitializer.getProvider().getMediumService().getAll()));
		fd_medium.setSelectedItem(currentEntity.getMedium());
		fd_medium.setBounds(95, 40, 330, 20);
		getPanel().add(fd_medium);
		
		
		JLabel lbl_loans = new JLabel("Loans");
		lbl_loans.setBounds(10, 70, 75, 20);
		getPanel().add(lbl_loans);
		
		
		
		
		JButton btn_save = new JButton("Save");
		btn_save.setBounds(335, 325, 90, 25);
		getPanel().add(btn_save);
		btn_save.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
				try {
					saveAction();
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(getPanel(), "Could not be saved. " + e1.getMessage());
				}				
		}
		});
	}
	
	
	
	@Override
	protected String getTitle() {
		return "Copy Listing";//Edit " + currentEntity.getClass().getSimpleName() + " Window";
	}
	
	@Override
	protected boolean saveAction() throws ParseException {
		//Read values from different fields 
		Integer
		  inventoryNo = fd_inventoryNo.getText().isEmpty() ? null : Integer.valueOf(fd_inventoryNo.getText());
		Medium
		  medium = fd_medium.getItemAt(fd_medium.getSelectedIndex());
		
		//validation
		try {
			service.validateCopy(inventoryNo, medium);
			CopyEntryWindow.this.closeWindow();
		} catch (ValidationException e) {
			Util.showUserMessage("Validation error for " + e.getField(), "Validation error for " + e.getField() + ": " + e.getMessage());
			return false;
		}
		
		//persist
		currentEntity = service.saveCopy(currentEntity.getOid(), inventoryNo, medium);
		
		//reload the listing in the parent window to make changes visible
		if(getParent() instanceof CopyListingInterface)
			((CopyListingInterface) getParent()).initializeCopyListings();
		return true;
	}
	
	@Override
	protected void createLists() {
		JScrollPane scroll_fd_loans = new JScrollPane();
		scroll_fd_loans.setBounds(95, 70, 330, 100-25);
		getPanel().add(scroll_fd_loans);
		
		fd_loans = new JList<Loan>();
		initializeFd_loans();
		scroll_fd_loans.setViewportView(fd_loans);
		
		//Button for List Element								
		JButton btn_fd_loans_Add = new JButton("Add");
									btn_fd_loans_Add.setEnabled(!currentEntity.isNew());
									btn_fd_loans_Add.setBounds(95,150,106,20);
									getPanel().add(btn_fd_loans_Add);
									btn_fd_loans_Add.addActionListener(new ActionListener() {
										@Override
										public void actionPerformed(ActionEvent e) {
											new LoanEntryWindow(CopyEntryWindow.this, new Loan().initializeCopy(currentEntity)).open();
										}
									});
		JButton btn_fd_loans_Edit = new JButton("Edit");
									btn_fd_loans_Edit.setBounds(206,150,106,20);
									btn_fd_loans_Edit.setEnabled(!currentEntity.isNew());
									getPanel().add(btn_fd_loans_Edit);
									btn_fd_loans_Edit.addActionListener(new ActionListener() {
										@Override
										public void actionPerformed(ActionEvent e) {
											Loan entity = CopyEntryWindow.this.fd_loans.getSelectedValue();
											if(entity == null)
												Util.showNothingSelected();
											else
												new LoanEntryWindow(CopyEntryWindow.this, entity).open();
										}
									});
									JButton btn_fd_loans_Delete = new JButton("Delete");
									btn_fd_loans_Delete.setEnabled(false);
									btn_fd_loans_Delete.setBounds(317,150,106,20);
									getPanel().add(btn_fd_loans_Delete);
	}
	
	public void initializeFd_loans() {
		fd_loans.setListData(new Vector<Loan>(currentEntity.getLoans()));
	}
	
	@Override
	public void initializeLoanListings() {
		initializeFd_loans();
	}
}
