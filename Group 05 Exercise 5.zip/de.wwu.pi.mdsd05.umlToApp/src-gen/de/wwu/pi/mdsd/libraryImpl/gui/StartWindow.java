package de.wwu.pi.mdsd.libraryImpl.gui;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import de.wwu.pi.mdsd.libraryImpl.logic.ServiceInitializer;
import de.wwu.pi.mdsd05.framework.gui.AbstractStartWindow;

public class StartWindow extends AbstractStartWindow {

	@Override
	protected void ListChoices() {
		JButton userListWindow = new JButton("User Listing");
		GridBagConstraints gbc_userListWindow = new GridBagConstraints();
		gbc_userListWindow.insets = new Insets(0, 0, 5, 5);
		gbc_userListWindow.gridx = 1;
		gbc_userListWindow.gridy = getNextGridY();
		getPanel().add(userListWindow, gbc_userListWindow);
		userListWindow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new UserListWindow(StartWindow.this).open();
			}
		});
		JButton loanListWindow = new JButton("Loan Listing");
		GridBagConstraints gbc_loanListWindow = new GridBagConstraints();
		gbc_loanListWindow.insets = new Insets(0, 0, 5, 5);
		gbc_loanListWindow.gridx = 1;
		gbc_loanListWindow.gridy = getNextGridY();
		getPanel().add(loanListWindow, gbc_loanListWindow);
		loanListWindow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new LoanListWindow(StartWindow.this).open();
			}
		});
		JButton mediumListWindow = new JButton("Medium Listing");
		GridBagConstraints gbc_mediumListWindow = new GridBagConstraints();
		gbc_mediumListWindow.insets = new Insets(0, 0, 5, 5);
		gbc_mediumListWindow.gridx = 1;
		gbc_mediumListWindow.gridy = getNextGridY();
		getPanel().add(mediumListWindow, gbc_mediumListWindow);
		mediumListWindow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new MediumListWindow(StartWindow.this).open();
			}
		});
		JButton copyListWindow = new JButton("Copy Listing");
		GridBagConstraints gbc_copyListWindow = new GridBagConstraints();
		gbc_copyListWindow.insets = new Insets(0, 0, 5, 5);
		gbc_copyListWindow.gridx = 1;
		gbc_copyListWindow.gridy = getNextGridY();
		getPanel().add(copyListWindow, gbc_copyListWindow);
		copyListWindow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new CopyListWindow(StartWindow.this).open();
			}
		});
		JButton bookListWindow = new JButton("Book List Window");
		GridBagConstraints gbc_bookListWindow = new GridBagConstraints();
		gbc_bookListWindow.insets = new Insets(0, 0, 5, 5);
		gbc_bookListWindow.gridx = 1;
		gbc_bookListWindow.gridy = getNextGridY();
		getPanel().add(bookListWindow, gbc_bookListWindow);
		bookListWindow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new BookListWindow(StartWindow.this).open();
			}
		});
		JButton cDListWindow = new JButton("CD List Window");
		GridBagConstraints gbc_cDListWindow = new GridBagConstraints();
		gbc_cDListWindow.insets = new Insets(0, 0, 5, 5);
		gbc_cDListWindow.gridx = 1;
		gbc_cDListWindow.gridy = getNextGridY();
		getPanel().add(cDListWindow, gbc_cDListWindow);
		cDListWindow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new CDListWindow(StartWindow.this).open();
			}
		});
	}
	
	@Override
	protected void closeWindow()  {
		ServiceInitializer.serialize();
		super.closeWindow();
	}
	
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
		UIManager.setLookAndFeel(
			UIManager.getSystemLookAndFeelClassName());
			//"com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		new StartWindow().open();
	}
}
