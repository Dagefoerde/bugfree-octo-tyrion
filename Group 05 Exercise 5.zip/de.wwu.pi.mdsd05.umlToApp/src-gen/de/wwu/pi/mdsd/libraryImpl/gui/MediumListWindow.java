package de.wwu.pi.mdsd.libraryImpl.gui;

import java.util.Vector;

import de.wwu.pi.mdsd05.framework.gui.AbstractListWindow;
import de.wwu.pi.mdsd05.framework.gui.AbstractWindow;
import de.wwu.pi.mdsd.libraryImpl.logic.ServiceInitializer;
import de.wwu.pi.mdsd.libraryImpl.data.Book;
import de.wwu.pi.mdsd.libraryImpl.data.CD;
import de.wwu.pi.mdsd.libraryImpl.data.Medium;
	
public class MediumListWindow extends AbstractListWindow<Medium> implements MediumListingInterface{

	public MediumListWindow(AbstractWindow parent) {
		super(parent,400,450);
	}
	
	public String getTitle() {
		return "Medium Listing";
	}
	
	@Override
	public Vector<Medium> getElements() {
		return new Vector<Medium>(ServiceInitializer.getProvider().getMediumService().getAll());
	}
	
	@Override
	public void initializeMediumListings() {
		initializeList();
	}
	
	@Override
	public void showEntryWindow(Medium entity) {
		//If entity is null -> initialize entity as new entity
		//show Entity Edit Window
		if(entity == null) {
			if(cb_select_inh_type_Medium.getSelectedItem().equals("Book"))
				entity = new Book();
			if(cb_select_inh_type_Medium.getSelectedItem().equals("CD"))
				entity = new CD();
		}
		if(entity instanceof Book)
			new BookEntryWindow(this, (Book) entity).open();
		if(entity instanceof CD)
			new CDEntryWindow(this, (CD) entity).open();
	}
	
		javax.swing.JComboBox<String> cb_select_inh_type_Medium = new javax.swing.JComboBox<>();
		@Override //overrides superclass method to add a select box to the window
		public void createContents() {
			super.createContents();
			cb_select_inh_type_Medium.addItem("Book");
			cb_select_inh_type_Medium.addItem("CD");
			java.awt.GridBagConstraints gbc_cb_select_inh_type_Medium = new java.awt.GridBagConstraints();
			gbc_cb_select_inh_type_Medium.insets = new java.awt.Insets(0, 0, 5, 5);
			gbc_cb_select_inh_type_Medium.gridx = 1;
			gbc_cb_select_inh_type_Medium.gridy = 2;
			getPanel().add(cb_select_inh_type_Medium, gbc_cb_select_inh_type_Medium);
		}
}

//Interface that needs to be implemented, if the class references Medium objects in a list
interface MediumListingInterface {
	public void initializeMediumListings();
}