package de.wwu.pi.mdsd.libraryImpl.gui;

import java.util.Vector;

import de.wwu.pi.mdsd05.framework.gui.AbstractListWindow;
import de.wwu.pi.mdsd05.framework.gui.AbstractWindow;
import de.wwu.pi.mdsd.libraryImpl.logic.ServiceInitializer;
import de.wwu.pi.mdsd.libraryImpl.data.CD;
	
public class CDListWindow extends AbstractListWindow<CD> implements CDListingInterface{

	public CDListWindow(AbstractWindow parent) {
		super(parent,400,450);
	}
	
	public String getTitle() {
		return "CD List Window";
	}
	
	@Override
	public Vector<CD> getElements() {
		return new Vector<CD>(ServiceInitializer.getProvider().getCDService().getAll());
	}
	
	@Override
	public void initializeCDListings() {
		initializeList();
	}
	
	@Override
	public void showEntryWindow(CD entity) {
		//If entity is null -> initialize entity as new entity
		//show Entity Edit Window
		if(entity == null) {
			entity = new CD();
		}
		new CDEntryWindow(this,entity).open();
	}
}

//Interface that needs to be implemented, if the class references CD objects in a list
interface CDListingInterface {
	public void initializeCDListings();
}