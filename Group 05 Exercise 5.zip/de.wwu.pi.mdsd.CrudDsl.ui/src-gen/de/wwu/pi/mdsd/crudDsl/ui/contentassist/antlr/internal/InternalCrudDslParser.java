package de.wwu.pi.mdsd.crudDsl.ui.contentassist.antlr.internal; 

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ui.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ui.editor.contentassist.antlr.internal.DFA;
import de.wwu.pi.mdsd.crudDsl.services.CrudDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalCrudDslParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'String'", "'Integer'", "'Date'", "'[1]'", "'[*]'", "'createEdit'", "'delete'", "'cancel'", "'package'", "'entity'", "'{'", "'}'", "'extends'", "'att'", "':'", "'ref'", "'opposite='", "'ListWindow'", "'for'", "'title'", "'EntryWindow'", "'size='", "'('", "','", "')'", "'bounds='", "'Label'", "'Field'", "'Button'", "'.'", "'abstract'", "'optional'"
    };
    public static final int T__42=42;
    public static final int RULE_ID=4;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__29=29;
    public static final int T__28=28;
    public static final int T__27=27;
    public static final int T__26=26;
    public static final int T__25=25;
    public static final int T__24=24;
    public static final int T__23=23;
    public static final int T__22=22;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__21=21;
    public static final int T__20=20;
    public static final int RULE_SL_COMMENT=8;
    public static final int EOF=-1;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__30=30;
    public static final int T__19=19;
    public static final int T__31=31;
    public static final int RULE_STRING=5;
    public static final int T__32=32;
    public static final int T__33=33;
    public static final int T__16=16;
    public static final int T__34=34;
    public static final int T__15=15;
    public static final int T__35=35;
    public static final int T__18=18;
    public static final int T__36=36;
    public static final int T__17=17;
    public static final int T__37=37;
    public static final int T__12=12;
    public static final int T__38=38;
    public static final int T__11=11;
    public static final int T__39=39;
    public static final int T__14=14;
    public static final int T__13=13;
    public static final int RULE_INT=6;
    public static final int RULE_WS=9;

    // delegates
    // delegators


        public InternalCrudDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalCrudDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalCrudDslParser.tokenNames; }
    public String getGrammarFileName() { return "../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g"; }


     
     	private CrudDslGrammarAccess grammarAccess;
     	
        public void setGrammarAccess(CrudDslGrammarAccess grammarAccess) {
        	this.grammarAccess = grammarAccess;
        }
        
        @Override
        protected Grammar getGrammar() {
        	return grammarAccess.getGrammar();
        }
        
        @Override
        protected String getValueForTokenName(String tokenName) {
        	return tokenName;
        }




    // $ANTLR start "entryRuleCrudModel"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:60:1: entryRuleCrudModel : ruleCrudModel EOF ;
    public final void entryRuleCrudModel() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:61:1: ( ruleCrudModel EOF )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:62:1: ruleCrudModel EOF
            {
             before(grammarAccess.getCrudModelRule()); 
            pushFollow(FOLLOW_ruleCrudModel_in_entryRuleCrudModel61);
            ruleCrudModel();

            state._fsp--;

             after(grammarAccess.getCrudModelRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleCrudModel68); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCrudModel"


    // $ANTLR start "ruleCrudModel"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:69:1: ruleCrudModel : ( ( rule__CrudModel__Group__0 ) ) ;
    public final void ruleCrudModel() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:73:2: ( ( ( rule__CrudModel__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:74:1: ( ( rule__CrudModel__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:74:1: ( ( rule__CrudModel__Group__0 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:75:1: ( rule__CrudModel__Group__0 )
            {
             before(grammarAccess.getCrudModelAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:76:1: ( rule__CrudModel__Group__0 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:76:2: rule__CrudModel__Group__0
            {
            pushFollow(FOLLOW_rule__CrudModel__Group__0_in_ruleCrudModel94);
            rule__CrudModel__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getCrudModelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCrudModel"


    // $ANTLR start "entryRuleEntity"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:88:1: entryRuleEntity : ruleEntity EOF ;
    public final void entryRuleEntity() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:89:1: ( ruleEntity EOF )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:90:1: ruleEntity EOF
            {
             before(grammarAccess.getEntityRule()); 
            pushFollow(FOLLOW_ruleEntity_in_entryRuleEntity121);
            ruleEntity();

            state._fsp--;

             after(grammarAccess.getEntityRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleEntity128); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEntity"


    // $ANTLR start "ruleEntity"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:97:1: ruleEntity : ( ( rule__Entity__Group__0 ) ) ;
    public final void ruleEntity() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:101:2: ( ( ( rule__Entity__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:102:1: ( ( rule__Entity__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:102:1: ( ( rule__Entity__Group__0 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:103:1: ( rule__Entity__Group__0 )
            {
             before(grammarAccess.getEntityAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:104:1: ( rule__Entity__Group__0 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:104:2: rule__Entity__Group__0
            {
            pushFollow(FOLLOW_rule__Entity__Group__0_in_ruleEntity154);
            rule__Entity__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEntityAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEntity"


    // $ANTLR start "entryRuleProperty"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:116:1: entryRuleProperty : ruleProperty EOF ;
    public final void entryRuleProperty() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:117:1: ( ruleProperty EOF )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:118:1: ruleProperty EOF
            {
             before(grammarAccess.getPropertyRule()); 
            pushFollow(FOLLOW_ruleProperty_in_entryRuleProperty181);
            ruleProperty();

            state._fsp--;

             after(grammarAccess.getPropertyRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleProperty188); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:125:1: ruleProperty : ( ( rule__Property__Alternatives ) ) ;
    public final void ruleProperty() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:129:2: ( ( ( rule__Property__Alternatives ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:130:1: ( ( rule__Property__Alternatives ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:130:1: ( ( rule__Property__Alternatives ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:131:1: ( rule__Property__Alternatives )
            {
             before(grammarAccess.getPropertyAccess().getAlternatives()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:132:1: ( rule__Property__Alternatives )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:132:2: rule__Property__Alternatives
            {
            pushFollow(FOLLOW_rule__Property__Alternatives_in_ruleProperty214);
            rule__Property__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getPropertyAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRuleAttribute"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:144:1: entryRuleAttribute : ruleAttribute EOF ;
    public final void entryRuleAttribute() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:145:1: ( ruleAttribute EOF )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:146:1: ruleAttribute EOF
            {
             before(grammarAccess.getAttributeRule()); 
            pushFollow(FOLLOW_ruleAttribute_in_entryRuleAttribute241);
            ruleAttribute();

            state._fsp--;

             after(grammarAccess.getAttributeRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleAttribute248); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAttribute"


    // $ANTLR start "ruleAttribute"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:153:1: ruleAttribute : ( ( rule__Attribute__Group__0 ) ) ;
    public final void ruleAttribute() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:157:2: ( ( ( rule__Attribute__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:158:1: ( ( rule__Attribute__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:158:1: ( ( rule__Attribute__Group__0 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:159:1: ( rule__Attribute__Group__0 )
            {
             before(grammarAccess.getAttributeAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:160:1: ( rule__Attribute__Group__0 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:160:2: rule__Attribute__Group__0
            {
            pushFollow(FOLLOW_rule__Attribute__Group__0_in_ruleAttribute274);
            rule__Attribute__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getAttributeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAttribute"


    // $ANTLR start "entryRuleReference"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:172:1: entryRuleReference : ruleReference EOF ;
    public final void entryRuleReference() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:173:1: ( ruleReference EOF )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:174:1: ruleReference EOF
            {
             before(grammarAccess.getReferenceRule()); 
            pushFollow(FOLLOW_ruleReference_in_entryRuleReference301);
            ruleReference();

            state._fsp--;

             after(grammarAccess.getReferenceRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleReference308); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleReference"


    // $ANTLR start "ruleReference"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:181:1: ruleReference : ( ( rule__Reference__Group__0 ) ) ;
    public final void ruleReference() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:185:2: ( ( ( rule__Reference__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:186:1: ( ( rule__Reference__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:186:1: ( ( rule__Reference__Group__0 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:187:1: ( rule__Reference__Group__0 )
            {
             before(grammarAccess.getReferenceAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:188:1: ( rule__Reference__Group__0 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:188:2: rule__Reference__Group__0
            {
            pushFollow(FOLLOW_rule__Reference__Group__0_in_ruleReference334);
            rule__Reference__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getReferenceAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleReference"


    // $ANTLR start "entryRuleWindow"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:200:1: entryRuleWindow : ruleWindow EOF ;
    public final void entryRuleWindow() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:201:1: ( ruleWindow EOF )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:202:1: ruleWindow EOF
            {
             before(grammarAccess.getWindowRule()); 
            pushFollow(FOLLOW_ruleWindow_in_entryRuleWindow361);
            ruleWindow();

            state._fsp--;

             after(grammarAccess.getWindowRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleWindow368); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleWindow"


    // $ANTLR start "ruleWindow"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:209:1: ruleWindow : ( ( rule__Window__Alternatives ) ) ;
    public final void ruleWindow() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:213:2: ( ( ( rule__Window__Alternatives ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:214:1: ( ( rule__Window__Alternatives ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:214:1: ( ( rule__Window__Alternatives ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:215:1: ( rule__Window__Alternatives )
            {
             before(grammarAccess.getWindowAccess().getAlternatives()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:216:1: ( rule__Window__Alternatives )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:216:2: rule__Window__Alternatives
            {
            pushFollow(FOLLOW_rule__Window__Alternatives_in_ruleWindow394);
            rule__Window__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getWindowAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleWindow"


    // $ANTLR start "entryRuleListWindow"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:228:1: entryRuleListWindow : ruleListWindow EOF ;
    public final void entryRuleListWindow() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:229:1: ( ruleListWindow EOF )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:230:1: ruleListWindow EOF
            {
             before(grammarAccess.getListWindowRule()); 
            pushFollow(FOLLOW_ruleListWindow_in_entryRuleListWindow421);
            ruleListWindow();

            state._fsp--;

             after(grammarAccess.getListWindowRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleListWindow428); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleListWindow"


    // $ANTLR start "ruleListWindow"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:237:1: ruleListWindow : ( ( rule__ListWindow__Group__0 ) ) ;
    public final void ruleListWindow() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:241:2: ( ( ( rule__ListWindow__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:242:1: ( ( rule__ListWindow__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:242:1: ( ( rule__ListWindow__Group__0 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:243:1: ( rule__ListWindow__Group__0 )
            {
             before(grammarAccess.getListWindowAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:244:1: ( rule__ListWindow__Group__0 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:244:2: rule__ListWindow__Group__0
            {
            pushFollow(FOLLOW_rule__ListWindow__Group__0_in_ruleListWindow454);
            rule__ListWindow__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getListWindowAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleListWindow"


    // $ANTLR start "entryRuleEntryWindow"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:256:1: entryRuleEntryWindow : ruleEntryWindow EOF ;
    public final void entryRuleEntryWindow() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:257:1: ( ruleEntryWindow EOF )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:258:1: ruleEntryWindow EOF
            {
             before(grammarAccess.getEntryWindowRule()); 
            pushFollow(FOLLOW_ruleEntryWindow_in_entryRuleEntryWindow481);
            ruleEntryWindow();

            state._fsp--;

             after(grammarAccess.getEntryWindowRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleEntryWindow488); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEntryWindow"


    // $ANTLR start "ruleEntryWindow"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:265:1: ruleEntryWindow : ( ( rule__EntryWindow__Group__0 ) ) ;
    public final void ruleEntryWindow() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:269:2: ( ( ( rule__EntryWindow__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:270:1: ( ( rule__EntryWindow__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:270:1: ( ( rule__EntryWindow__Group__0 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:271:1: ( rule__EntryWindow__Group__0 )
            {
             before(grammarAccess.getEntryWindowAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:272:1: ( rule__EntryWindow__Group__0 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:272:2: rule__EntryWindow__Group__0
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group__0_in_ruleEntryWindow514);
            rule__EntryWindow__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEntryWindowAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEntryWindow"


    // $ANTLR start "entryRuleSize"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:284:1: entryRuleSize : ruleSize EOF ;
    public final void entryRuleSize() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:285:1: ( ruleSize EOF )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:286:1: ruleSize EOF
            {
             before(grammarAccess.getSizeRule()); 
            pushFollow(FOLLOW_ruleSize_in_entryRuleSize541);
            ruleSize();

            state._fsp--;

             after(grammarAccess.getSizeRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleSize548); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSize"


    // $ANTLR start "ruleSize"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:293:1: ruleSize : ( ( rule__Size__Group__0 ) ) ;
    public final void ruleSize() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:297:2: ( ( ( rule__Size__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:298:1: ( ( rule__Size__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:298:1: ( ( rule__Size__Group__0 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:299:1: ( rule__Size__Group__0 )
            {
             before(grammarAccess.getSizeAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:300:1: ( rule__Size__Group__0 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:300:2: rule__Size__Group__0
            {
            pushFollow(FOLLOW_rule__Size__Group__0_in_ruleSize574);
            rule__Size__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSizeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSize"


    // $ANTLR start "entryRuleBounds"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:312:1: entryRuleBounds : ruleBounds EOF ;
    public final void entryRuleBounds() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:313:1: ( ruleBounds EOF )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:314:1: ruleBounds EOF
            {
             before(grammarAccess.getBoundsRule()); 
            pushFollow(FOLLOW_ruleBounds_in_entryRuleBounds601);
            ruleBounds();

            state._fsp--;

             after(grammarAccess.getBoundsRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleBounds608); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleBounds"


    // $ANTLR start "ruleBounds"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:321:1: ruleBounds : ( ( rule__Bounds__Group__0 ) ) ;
    public final void ruleBounds() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:325:2: ( ( ( rule__Bounds__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:326:1: ( ( rule__Bounds__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:326:1: ( ( rule__Bounds__Group__0 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:327:1: ( rule__Bounds__Group__0 )
            {
             before(grammarAccess.getBoundsAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:328:1: ( rule__Bounds__Group__0 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:328:2: rule__Bounds__Group__0
            {
            pushFollow(FOLLOW_rule__Bounds__Group__0_in_ruleBounds634);
            rule__Bounds__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getBoundsAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleBounds"


    // $ANTLR start "entryRuleUIElement"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:340:1: entryRuleUIElement : ruleUIElement EOF ;
    public final void entryRuleUIElement() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:341:1: ( ruleUIElement EOF )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:342:1: ruleUIElement EOF
            {
             before(grammarAccess.getUIElementRule()); 
            pushFollow(FOLLOW_ruleUIElement_in_entryRuleUIElement661);
            ruleUIElement();

            state._fsp--;

             after(grammarAccess.getUIElementRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleUIElement668); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleUIElement"


    // $ANTLR start "ruleUIElement"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:349:1: ruleUIElement : ( ( rule__UIElement__Group__0 ) ) ;
    public final void ruleUIElement() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:353:2: ( ( ( rule__UIElement__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:354:1: ( ( rule__UIElement__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:354:1: ( ( rule__UIElement__Group__0 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:355:1: ( rule__UIElement__Group__0 )
            {
             before(grammarAccess.getUIElementAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:356:1: ( rule__UIElement__Group__0 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:356:2: rule__UIElement__Group__0
            {
            pushFollow(FOLLOW_rule__UIElement__Group__0_in_ruleUIElement694);
            rule__UIElement__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getUIElementAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleUIElement"


    // $ANTLR start "entryRuleLabel"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:368:1: entryRuleLabel : ruleLabel EOF ;
    public final void entryRuleLabel() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:369:1: ( ruleLabel EOF )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:370:1: ruleLabel EOF
            {
             before(grammarAccess.getLabelRule()); 
            pushFollow(FOLLOW_ruleLabel_in_entryRuleLabel721);
            ruleLabel();

            state._fsp--;

             after(grammarAccess.getLabelRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleLabel728); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLabel"


    // $ANTLR start "ruleLabel"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:377:1: ruleLabel : ( ( rule__Label__Group__0 ) ) ;
    public final void ruleLabel() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:381:2: ( ( ( rule__Label__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:382:1: ( ( rule__Label__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:382:1: ( ( rule__Label__Group__0 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:383:1: ( rule__Label__Group__0 )
            {
             before(grammarAccess.getLabelAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:384:1: ( rule__Label__Group__0 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:384:2: rule__Label__Group__0
            {
            pushFollow(FOLLOW_rule__Label__Group__0_in_ruleLabel754);
            rule__Label__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getLabelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLabel"


    // $ANTLR start "entryRuleField"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:396:1: entryRuleField : ruleField EOF ;
    public final void entryRuleField() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:397:1: ( ruleField EOF )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:398:1: ruleField EOF
            {
             before(grammarAccess.getFieldRule()); 
            pushFollow(FOLLOW_ruleField_in_entryRuleField781);
            ruleField();

            state._fsp--;

             after(grammarAccess.getFieldRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleField788); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleField"


    // $ANTLR start "ruleField"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:405:1: ruleField : ( ( rule__Field__Group__0 ) ) ;
    public final void ruleField() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:409:2: ( ( ( rule__Field__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:410:1: ( ( rule__Field__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:410:1: ( ( rule__Field__Group__0 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:411:1: ( rule__Field__Group__0 )
            {
             before(grammarAccess.getFieldAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:412:1: ( rule__Field__Group__0 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:412:2: rule__Field__Group__0
            {
            pushFollow(FOLLOW_rule__Field__Group__0_in_ruleField814);
            rule__Field__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleField"


    // $ANTLR start "entryRuleButton"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:424:1: entryRuleButton : ruleButton EOF ;
    public final void entryRuleButton() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:425:1: ( ruleButton EOF )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:426:1: ruleButton EOF
            {
             before(grammarAccess.getButtonRule()); 
            pushFollow(FOLLOW_ruleButton_in_entryRuleButton841);
            ruleButton();

            state._fsp--;

             after(grammarAccess.getButtonRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleButton848); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleButton"


    // $ANTLR start "ruleButton"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:433:1: ruleButton : ( ( rule__Button__Group__0 ) ) ;
    public final void ruleButton() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:437:2: ( ( ( rule__Button__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:438:1: ( ( rule__Button__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:438:1: ( ( rule__Button__Group__0 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:439:1: ( rule__Button__Group__0 )
            {
             before(grammarAccess.getButtonAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:440:1: ( rule__Button__Group__0 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:440:2: rule__Button__Group__0
            {
            pushFollow(FOLLOW_rule__Button__Group__0_in_ruleButton874);
            rule__Button__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getButtonAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleButton"


    // $ANTLR start "entryRuleQualifiedName"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:452:1: entryRuleQualifiedName : ruleQualifiedName EOF ;
    public final void entryRuleQualifiedName() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:453:1: ( ruleQualifiedName EOF )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:454:1: ruleQualifiedName EOF
            {
             before(grammarAccess.getQualifiedNameRule()); 
            pushFollow(FOLLOW_ruleQualifiedName_in_entryRuleQualifiedName901);
            ruleQualifiedName();

            state._fsp--;

             after(grammarAccess.getQualifiedNameRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleQualifiedName908); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleQualifiedName"


    // $ANTLR start "ruleQualifiedName"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:461:1: ruleQualifiedName : ( ( rule__QualifiedName__Group__0 ) ) ;
    public final void ruleQualifiedName() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:465:2: ( ( ( rule__QualifiedName__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:466:1: ( ( rule__QualifiedName__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:466:1: ( ( rule__QualifiedName__Group__0 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:467:1: ( rule__QualifiedName__Group__0 )
            {
             before(grammarAccess.getQualifiedNameAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:468:1: ( rule__QualifiedName__Group__0 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:468:2: rule__QualifiedName__Group__0
            {
            pushFollow(FOLLOW_rule__QualifiedName__Group__0_in_ruleQualifiedName934);
            rule__QualifiedName__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getQualifiedNameAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleQualifiedName"


    // $ANTLR start "ruleAttributeType"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:481:1: ruleAttributeType : ( ( rule__AttributeType__Alternatives ) ) ;
    public final void ruleAttributeType() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:485:1: ( ( ( rule__AttributeType__Alternatives ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:486:1: ( ( rule__AttributeType__Alternatives ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:486:1: ( ( rule__AttributeType__Alternatives ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:487:1: ( rule__AttributeType__Alternatives )
            {
             before(grammarAccess.getAttributeTypeAccess().getAlternatives()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:488:1: ( rule__AttributeType__Alternatives )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:488:2: rule__AttributeType__Alternatives
            {
            pushFollow(FOLLOW_rule__AttributeType__Alternatives_in_ruleAttributeType971);
            rule__AttributeType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getAttributeTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAttributeType"


    // $ANTLR start "ruleMultiplicityKind"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:500:1: ruleMultiplicityKind : ( ( rule__MultiplicityKind__Alternatives ) ) ;
    public final void ruleMultiplicityKind() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:504:1: ( ( ( rule__MultiplicityKind__Alternatives ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:505:1: ( ( rule__MultiplicityKind__Alternatives ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:505:1: ( ( rule__MultiplicityKind__Alternatives ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:506:1: ( rule__MultiplicityKind__Alternatives )
            {
             before(grammarAccess.getMultiplicityKindAccess().getAlternatives()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:507:1: ( rule__MultiplicityKind__Alternatives )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:507:2: rule__MultiplicityKind__Alternatives
            {
            pushFollow(FOLLOW_rule__MultiplicityKind__Alternatives_in_ruleMultiplicityKind1007);
            rule__MultiplicityKind__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getMultiplicityKindAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMultiplicityKind"


    // $ANTLR start "ruleButtonKind"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:519:1: ruleButtonKind : ( ( rule__ButtonKind__Alternatives ) ) ;
    public final void ruleButtonKind() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:523:1: ( ( ( rule__ButtonKind__Alternatives ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:524:1: ( ( rule__ButtonKind__Alternatives ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:524:1: ( ( rule__ButtonKind__Alternatives ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:525:1: ( rule__ButtonKind__Alternatives )
            {
             before(grammarAccess.getButtonKindAccess().getAlternatives()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:526:1: ( rule__ButtonKind__Alternatives )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:526:2: rule__ButtonKind__Alternatives
            {
            pushFollow(FOLLOW_rule__ButtonKind__Alternatives_in_ruleButtonKind1043);
            rule__ButtonKind__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getButtonKindAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleButtonKind"


    // $ANTLR start "rule__CrudModel__Alternatives_2"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:537:1: rule__CrudModel__Alternatives_2 : ( ( ( rule__CrudModel__EntitiesAssignment_2_0 ) ) | ( ( rule__CrudModel__WindowsAssignment_2_1 ) ) );
    public final void rule__CrudModel__Alternatives_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:541:1: ( ( ( rule__CrudModel__EntitiesAssignment_2_0 ) ) | ( ( rule__CrudModel__WindowsAssignment_2_1 ) ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==20||LA1_0==41) ) {
                alt1=1;
            }
            else if ( (LA1_0==28||LA1_0==31) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:542:1: ( ( rule__CrudModel__EntitiesAssignment_2_0 ) )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:542:1: ( ( rule__CrudModel__EntitiesAssignment_2_0 ) )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:543:1: ( rule__CrudModel__EntitiesAssignment_2_0 )
                    {
                     before(grammarAccess.getCrudModelAccess().getEntitiesAssignment_2_0()); 
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:544:1: ( rule__CrudModel__EntitiesAssignment_2_0 )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:544:2: rule__CrudModel__EntitiesAssignment_2_0
                    {
                    pushFollow(FOLLOW_rule__CrudModel__EntitiesAssignment_2_0_in_rule__CrudModel__Alternatives_21078);
                    rule__CrudModel__EntitiesAssignment_2_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getCrudModelAccess().getEntitiesAssignment_2_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:548:6: ( ( rule__CrudModel__WindowsAssignment_2_1 ) )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:548:6: ( ( rule__CrudModel__WindowsAssignment_2_1 ) )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:549:1: ( rule__CrudModel__WindowsAssignment_2_1 )
                    {
                     before(grammarAccess.getCrudModelAccess().getWindowsAssignment_2_1()); 
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:550:1: ( rule__CrudModel__WindowsAssignment_2_1 )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:550:2: rule__CrudModel__WindowsAssignment_2_1
                    {
                    pushFollow(FOLLOW_rule__CrudModel__WindowsAssignment_2_1_in_rule__CrudModel__Alternatives_21096);
                    rule__CrudModel__WindowsAssignment_2_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getCrudModelAccess().getWindowsAssignment_2_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CrudModel__Alternatives_2"


    // $ANTLR start "rule__Property__Alternatives"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:559:1: rule__Property__Alternatives : ( ( ruleAttribute ) | ( ruleReference ) );
    public final void rule__Property__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:563:1: ( ( ruleAttribute ) | ( ruleReference ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==24) ) {
                alt2=1;
            }
            else if ( (LA2_0==26) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:564:1: ( ruleAttribute )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:564:1: ( ruleAttribute )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:565:1: ruleAttribute
                    {
                     before(grammarAccess.getPropertyAccess().getAttributeParserRuleCall_0()); 
                    pushFollow(FOLLOW_ruleAttribute_in_rule__Property__Alternatives1129);
                    ruleAttribute();

                    state._fsp--;

                     after(grammarAccess.getPropertyAccess().getAttributeParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:570:6: ( ruleReference )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:570:6: ( ruleReference )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:571:1: ruleReference
                    {
                     before(grammarAccess.getPropertyAccess().getReferenceParserRuleCall_1()); 
                    pushFollow(FOLLOW_ruleReference_in_rule__Property__Alternatives1146);
                    ruleReference();

                    state._fsp--;

                     after(grammarAccess.getPropertyAccess().getReferenceParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Alternatives"


    // $ANTLR start "rule__Window__Alternatives"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:581:1: rule__Window__Alternatives : ( ( ruleEntryWindow ) | ( ruleListWindow ) );
    public final void rule__Window__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:585:1: ( ( ruleEntryWindow ) | ( ruleListWindow ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==31) ) {
                alt3=1;
            }
            else if ( (LA3_0==28) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:586:1: ( ruleEntryWindow )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:586:1: ( ruleEntryWindow )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:587:1: ruleEntryWindow
                    {
                     before(grammarAccess.getWindowAccess().getEntryWindowParserRuleCall_0()); 
                    pushFollow(FOLLOW_ruleEntryWindow_in_rule__Window__Alternatives1178);
                    ruleEntryWindow();

                    state._fsp--;

                     after(grammarAccess.getWindowAccess().getEntryWindowParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:592:6: ( ruleListWindow )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:592:6: ( ruleListWindow )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:593:1: ruleListWindow
                    {
                     before(grammarAccess.getWindowAccess().getListWindowParserRuleCall_1()); 
                    pushFollow(FOLLOW_ruleListWindow_in_rule__Window__Alternatives1195);
                    ruleListWindow();

                    state._fsp--;

                     after(grammarAccess.getWindowAccess().getListWindowParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Window__Alternatives"


    // $ANTLR start "rule__UIElement__Alternatives_0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:603:1: rule__UIElement__Alternatives_0 : ( ( ruleLabel ) | ( ruleField ) | ( ruleButton ) );
    public final void rule__UIElement__Alternatives_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:607:1: ( ( ruleLabel ) | ( ruleField ) | ( ruleButton ) )
            int alt4=3;
            switch ( input.LA(1) ) {
            case 37:
                {
                alt4=1;
                }
                break;
            case 38:
                {
                alt4=2;
                }
                break;
            case 39:
                {
                alt4=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:608:1: ( ruleLabel )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:608:1: ( ruleLabel )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:609:1: ruleLabel
                    {
                     before(grammarAccess.getUIElementAccess().getLabelParserRuleCall_0_0()); 
                    pushFollow(FOLLOW_ruleLabel_in_rule__UIElement__Alternatives_01227);
                    ruleLabel();

                    state._fsp--;

                     after(grammarAccess.getUIElementAccess().getLabelParserRuleCall_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:614:6: ( ruleField )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:614:6: ( ruleField )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:615:1: ruleField
                    {
                     before(grammarAccess.getUIElementAccess().getFieldParserRuleCall_0_1()); 
                    pushFollow(FOLLOW_ruleField_in_rule__UIElement__Alternatives_01244);
                    ruleField();

                    state._fsp--;

                     after(grammarAccess.getUIElementAccess().getFieldParserRuleCall_0_1()); 

                    }


                    }
                    break;
                case 3 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:620:6: ( ruleButton )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:620:6: ( ruleButton )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:621:1: ruleButton
                    {
                     before(grammarAccess.getUIElementAccess().getButtonParserRuleCall_0_2()); 
                    pushFollow(FOLLOW_ruleButton_in_rule__UIElement__Alternatives_01261);
                    ruleButton();

                    state._fsp--;

                     after(grammarAccess.getUIElementAccess().getButtonParserRuleCall_0_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UIElement__Alternatives_0"


    // $ANTLR start "rule__AttributeType__Alternatives"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:631:1: rule__AttributeType__Alternatives : ( ( ( 'String' ) ) | ( ( 'Integer' ) ) | ( ( 'Date' ) ) );
    public final void rule__AttributeType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:635:1: ( ( ( 'String' ) ) | ( ( 'Integer' ) ) | ( ( 'Date' ) ) )
            int alt5=3;
            switch ( input.LA(1) ) {
            case 11:
                {
                alt5=1;
                }
                break;
            case 12:
                {
                alt5=2;
                }
                break;
            case 13:
                {
                alt5=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:636:1: ( ( 'String' ) )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:636:1: ( ( 'String' ) )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:637:1: ( 'String' )
                    {
                     before(grammarAccess.getAttributeTypeAccess().getStringEnumLiteralDeclaration_0()); 
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:638:1: ( 'String' )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:638:3: 'String'
                    {
                    match(input,11,FOLLOW_11_in_rule__AttributeType__Alternatives1294); 

                    }

                     after(grammarAccess.getAttributeTypeAccess().getStringEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:643:6: ( ( 'Integer' ) )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:643:6: ( ( 'Integer' ) )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:644:1: ( 'Integer' )
                    {
                     before(grammarAccess.getAttributeTypeAccess().getIntegerEnumLiteralDeclaration_1()); 
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:645:1: ( 'Integer' )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:645:3: 'Integer'
                    {
                    match(input,12,FOLLOW_12_in_rule__AttributeType__Alternatives1315); 

                    }

                     after(grammarAccess.getAttributeTypeAccess().getIntegerEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:650:6: ( ( 'Date' ) )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:650:6: ( ( 'Date' ) )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:651:1: ( 'Date' )
                    {
                     before(grammarAccess.getAttributeTypeAccess().getDateEnumLiteralDeclaration_2()); 
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:652:1: ( 'Date' )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:652:3: 'Date'
                    {
                    match(input,13,FOLLOW_13_in_rule__AttributeType__Alternatives1336); 

                    }

                     after(grammarAccess.getAttributeTypeAccess().getDateEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AttributeType__Alternatives"


    // $ANTLR start "rule__MultiplicityKind__Alternatives"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:662:1: rule__MultiplicityKind__Alternatives : ( ( ( '[1]' ) ) | ( ( '[*]' ) ) );
    public final void rule__MultiplicityKind__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:666:1: ( ( ( '[1]' ) ) | ( ( '[*]' ) ) )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==14) ) {
                alt6=1;
            }
            else if ( (LA6_0==15) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:667:1: ( ( '[1]' ) )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:667:1: ( ( '[1]' ) )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:668:1: ( '[1]' )
                    {
                     before(grammarAccess.getMultiplicityKindAccess().getSingleEnumLiteralDeclaration_0()); 
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:669:1: ( '[1]' )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:669:3: '[1]'
                    {
                    match(input,14,FOLLOW_14_in_rule__MultiplicityKind__Alternatives1372); 

                    }

                     after(grammarAccess.getMultiplicityKindAccess().getSingleEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:674:6: ( ( '[*]' ) )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:674:6: ( ( '[*]' ) )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:675:1: ( '[*]' )
                    {
                     before(grammarAccess.getMultiplicityKindAccess().getMultipleEnumLiteralDeclaration_1()); 
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:676:1: ( '[*]' )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:676:3: '[*]'
                    {
                    match(input,15,FOLLOW_15_in_rule__MultiplicityKind__Alternatives1393); 

                    }

                     after(grammarAccess.getMultiplicityKindAccess().getMultipleEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplicityKind__Alternatives"


    // $ANTLR start "rule__ButtonKind__Alternatives"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:686:1: rule__ButtonKind__Alternatives : ( ( ( 'createEdit' ) ) | ( ( 'delete' ) ) | ( ( 'cancel' ) ) );
    public final void rule__ButtonKind__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:690:1: ( ( ( 'createEdit' ) ) | ( ( 'delete' ) ) | ( ( 'cancel' ) ) )
            int alt7=3;
            switch ( input.LA(1) ) {
            case 16:
                {
                alt7=1;
                }
                break;
            case 17:
                {
                alt7=2;
                }
                break;
            case 18:
                {
                alt7=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }

            switch (alt7) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:691:1: ( ( 'createEdit' ) )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:691:1: ( ( 'createEdit' ) )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:692:1: ( 'createEdit' )
                    {
                     before(grammarAccess.getButtonKindAccess().getCreateEditEnumLiteralDeclaration_0()); 
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:693:1: ( 'createEdit' )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:693:3: 'createEdit'
                    {
                    match(input,16,FOLLOW_16_in_rule__ButtonKind__Alternatives1429); 

                    }

                     after(grammarAccess.getButtonKindAccess().getCreateEditEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:698:6: ( ( 'delete' ) )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:698:6: ( ( 'delete' ) )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:699:1: ( 'delete' )
                    {
                     before(grammarAccess.getButtonKindAccess().getDeleteEnumLiteralDeclaration_1()); 
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:700:1: ( 'delete' )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:700:3: 'delete'
                    {
                    match(input,17,FOLLOW_17_in_rule__ButtonKind__Alternatives1450); 

                    }

                     after(grammarAccess.getButtonKindAccess().getDeleteEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:705:6: ( ( 'cancel' ) )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:705:6: ( ( 'cancel' ) )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:706:1: ( 'cancel' )
                    {
                     before(grammarAccess.getButtonKindAccess().getCancelEnumLiteralDeclaration_2()); 
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:707:1: ( 'cancel' )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:707:3: 'cancel'
                    {
                    match(input,18,FOLLOW_18_in_rule__ButtonKind__Alternatives1471); 

                    }

                     after(grammarAccess.getButtonKindAccess().getCancelEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ButtonKind__Alternatives"


    // $ANTLR start "rule__CrudModel__Group__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:719:1: rule__CrudModel__Group__0 : rule__CrudModel__Group__0__Impl rule__CrudModel__Group__1 ;
    public final void rule__CrudModel__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:723:1: ( rule__CrudModel__Group__0__Impl rule__CrudModel__Group__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:724:2: rule__CrudModel__Group__0__Impl rule__CrudModel__Group__1
            {
            pushFollow(FOLLOW_rule__CrudModel__Group__0__Impl_in_rule__CrudModel__Group__01504);
            rule__CrudModel__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__CrudModel__Group__1_in_rule__CrudModel__Group__01507);
            rule__CrudModel__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CrudModel__Group__0"


    // $ANTLR start "rule__CrudModel__Group__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:731:1: rule__CrudModel__Group__0__Impl : ( 'package' ) ;
    public final void rule__CrudModel__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:735:1: ( ( 'package' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:736:1: ( 'package' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:736:1: ( 'package' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:737:1: 'package'
            {
             before(grammarAccess.getCrudModelAccess().getPackageKeyword_0()); 
            match(input,19,FOLLOW_19_in_rule__CrudModel__Group__0__Impl1535); 
             after(grammarAccess.getCrudModelAccess().getPackageKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CrudModel__Group__0__Impl"


    // $ANTLR start "rule__CrudModel__Group__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:750:1: rule__CrudModel__Group__1 : rule__CrudModel__Group__1__Impl rule__CrudModel__Group__2 ;
    public final void rule__CrudModel__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:754:1: ( rule__CrudModel__Group__1__Impl rule__CrudModel__Group__2 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:755:2: rule__CrudModel__Group__1__Impl rule__CrudModel__Group__2
            {
            pushFollow(FOLLOW_rule__CrudModel__Group__1__Impl_in_rule__CrudModel__Group__11566);
            rule__CrudModel__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__CrudModel__Group__2_in_rule__CrudModel__Group__11569);
            rule__CrudModel__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CrudModel__Group__1"


    // $ANTLR start "rule__CrudModel__Group__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:762:1: rule__CrudModel__Group__1__Impl : ( ( rule__CrudModel__NameAssignment_1 ) ) ;
    public final void rule__CrudModel__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:766:1: ( ( ( rule__CrudModel__NameAssignment_1 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:767:1: ( ( rule__CrudModel__NameAssignment_1 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:767:1: ( ( rule__CrudModel__NameAssignment_1 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:768:1: ( rule__CrudModel__NameAssignment_1 )
            {
             before(grammarAccess.getCrudModelAccess().getNameAssignment_1()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:769:1: ( rule__CrudModel__NameAssignment_1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:769:2: rule__CrudModel__NameAssignment_1
            {
            pushFollow(FOLLOW_rule__CrudModel__NameAssignment_1_in_rule__CrudModel__Group__1__Impl1596);
            rule__CrudModel__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getCrudModelAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CrudModel__Group__1__Impl"


    // $ANTLR start "rule__CrudModel__Group__2"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:779:1: rule__CrudModel__Group__2 : rule__CrudModel__Group__2__Impl ;
    public final void rule__CrudModel__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:783:1: ( rule__CrudModel__Group__2__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:784:2: rule__CrudModel__Group__2__Impl
            {
            pushFollow(FOLLOW_rule__CrudModel__Group__2__Impl_in_rule__CrudModel__Group__21626);
            rule__CrudModel__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CrudModel__Group__2"


    // $ANTLR start "rule__CrudModel__Group__2__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:790:1: rule__CrudModel__Group__2__Impl : ( ( rule__CrudModel__Alternatives_2 )* ) ;
    public final void rule__CrudModel__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:794:1: ( ( ( rule__CrudModel__Alternatives_2 )* ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:795:1: ( ( rule__CrudModel__Alternatives_2 )* )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:795:1: ( ( rule__CrudModel__Alternatives_2 )* )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:796:1: ( rule__CrudModel__Alternatives_2 )*
            {
             before(grammarAccess.getCrudModelAccess().getAlternatives_2()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:797:1: ( rule__CrudModel__Alternatives_2 )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==20||LA8_0==28||LA8_0==31||LA8_0==41) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:797:2: rule__CrudModel__Alternatives_2
            	    {
            	    pushFollow(FOLLOW_rule__CrudModel__Alternatives_2_in_rule__CrudModel__Group__2__Impl1653);
            	    rule__CrudModel__Alternatives_2();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

             after(grammarAccess.getCrudModelAccess().getAlternatives_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CrudModel__Group__2__Impl"


    // $ANTLR start "rule__Entity__Group__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:813:1: rule__Entity__Group__0 : rule__Entity__Group__0__Impl rule__Entity__Group__1 ;
    public final void rule__Entity__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:817:1: ( rule__Entity__Group__0__Impl rule__Entity__Group__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:818:2: rule__Entity__Group__0__Impl rule__Entity__Group__1
            {
            pushFollow(FOLLOW_rule__Entity__Group__0__Impl_in_rule__Entity__Group__01690);
            rule__Entity__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entity__Group__1_in_rule__Entity__Group__01693);
            rule__Entity__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__0"


    // $ANTLR start "rule__Entity__Group__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:825:1: rule__Entity__Group__0__Impl : ( ( rule__Entity__AbstractAssignment_0 )? ) ;
    public final void rule__Entity__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:829:1: ( ( ( rule__Entity__AbstractAssignment_0 )? ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:830:1: ( ( rule__Entity__AbstractAssignment_0 )? )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:830:1: ( ( rule__Entity__AbstractAssignment_0 )? )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:831:1: ( rule__Entity__AbstractAssignment_0 )?
            {
             before(grammarAccess.getEntityAccess().getAbstractAssignment_0()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:832:1: ( rule__Entity__AbstractAssignment_0 )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==41) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:832:2: rule__Entity__AbstractAssignment_0
                    {
                    pushFollow(FOLLOW_rule__Entity__AbstractAssignment_0_in_rule__Entity__Group__0__Impl1720);
                    rule__Entity__AbstractAssignment_0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getEntityAccess().getAbstractAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__0__Impl"


    // $ANTLR start "rule__Entity__Group__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:842:1: rule__Entity__Group__1 : rule__Entity__Group__1__Impl rule__Entity__Group__2 ;
    public final void rule__Entity__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:846:1: ( rule__Entity__Group__1__Impl rule__Entity__Group__2 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:847:2: rule__Entity__Group__1__Impl rule__Entity__Group__2
            {
            pushFollow(FOLLOW_rule__Entity__Group__1__Impl_in_rule__Entity__Group__11751);
            rule__Entity__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entity__Group__2_in_rule__Entity__Group__11754);
            rule__Entity__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__1"


    // $ANTLR start "rule__Entity__Group__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:854:1: rule__Entity__Group__1__Impl : ( 'entity' ) ;
    public final void rule__Entity__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:858:1: ( ( 'entity' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:859:1: ( 'entity' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:859:1: ( 'entity' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:860:1: 'entity'
            {
             before(grammarAccess.getEntityAccess().getEntityKeyword_1()); 
            match(input,20,FOLLOW_20_in_rule__Entity__Group__1__Impl1782); 
             after(grammarAccess.getEntityAccess().getEntityKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__1__Impl"


    // $ANTLR start "rule__Entity__Group__2"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:873:1: rule__Entity__Group__2 : rule__Entity__Group__2__Impl rule__Entity__Group__3 ;
    public final void rule__Entity__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:877:1: ( rule__Entity__Group__2__Impl rule__Entity__Group__3 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:878:2: rule__Entity__Group__2__Impl rule__Entity__Group__3
            {
            pushFollow(FOLLOW_rule__Entity__Group__2__Impl_in_rule__Entity__Group__21813);
            rule__Entity__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entity__Group__3_in_rule__Entity__Group__21816);
            rule__Entity__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__2"


    // $ANTLR start "rule__Entity__Group__2__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:885:1: rule__Entity__Group__2__Impl : ( ( rule__Entity__NameAssignment_2 ) ) ;
    public final void rule__Entity__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:889:1: ( ( ( rule__Entity__NameAssignment_2 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:890:1: ( ( rule__Entity__NameAssignment_2 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:890:1: ( ( rule__Entity__NameAssignment_2 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:891:1: ( rule__Entity__NameAssignment_2 )
            {
             before(grammarAccess.getEntityAccess().getNameAssignment_2()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:892:1: ( rule__Entity__NameAssignment_2 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:892:2: rule__Entity__NameAssignment_2
            {
            pushFollow(FOLLOW_rule__Entity__NameAssignment_2_in_rule__Entity__Group__2__Impl1843);
            rule__Entity__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getEntityAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__2__Impl"


    // $ANTLR start "rule__Entity__Group__3"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:902:1: rule__Entity__Group__3 : rule__Entity__Group__3__Impl rule__Entity__Group__4 ;
    public final void rule__Entity__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:906:1: ( rule__Entity__Group__3__Impl rule__Entity__Group__4 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:907:2: rule__Entity__Group__3__Impl rule__Entity__Group__4
            {
            pushFollow(FOLLOW_rule__Entity__Group__3__Impl_in_rule__Entity__Group__31873);
            rule__Entity__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entity__Group__4_in_rule__Entity__Group__31876);
            rule__Entity__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__3"


    // $ANTLR start "rule__Entity__Group__3__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:914:1: rule__Entity__Group__3__Impl : ( ( rule__Entity__Group_3__0 )? ) ;
    public final void rule__Entity__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:918:1: ( ( ( rule__Entity__Group_3__0 )? ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:919:1: ( ( rule__Entity__Group_3__0 )? )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:919:1: ( ( rule__Entity__Group_3__0 )? )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:920:1: ( rule__Entity__Group_3__0 )?
            {
             before(grammarAccess.getEntityAccess().getGroup_3()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:921:1: ( rule__Entity__Group_3__0 )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==23) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:921:2: rule__Entity__Group_3__0
                    {
                    pushFollow(FOLLOW_rule__Entity__Group_3__0_in_rule__Entity__Group__3__Impl1903);
                    rule__Entity__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getEntityAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__3__Impl"


    // $ANTLR start "rule__Entity__Group__4"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:931:1: rule__Entity__Group__4 : rule__Entity__Group__4__Impl rule__Entity__Group__5 ;
    public final void rule__Entity__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:935:1: ( rule__Entity__Group__4__Impl rule__Entity__Group__5 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:936:2: rule__Entity__Group__4__Impl rule__Entity__Group__5
            {
            pushFollow(FOLLOW_rule__Entity__Group__4__Impl_in_rule__Entity__Group__41934);
            rule__Entity__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entity__Group__5_in_rule__Entity__Group__41937);
            rule__Entity__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__4"


    // $ANTLR start "rule__Entity__Group__4__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:943:1: rule__Entity__Group__4__Impl : ( '{' ) ;
    public final void rule__Entity__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:947:1: ( ( '{' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:948:1: ( '{' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:948:1: ( '{' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:949:1: '{'
            {
             before(grammarAccess.getEntityAccess().getLeftCurlyBracketKeyword_4()); 
            match(input,21,FOLLOW_21_in_rule__Entity__Group__4__Impl1965); 
             after(grammarAccess.getEntityAccess().getLeftCurlyBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__4__Impl"


    // $ANTLR start "rule__Entity__Group__5"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:962:1: rule__Entity__Group__5 : rule__Entity__Group__5__Impl rule__Entity__Group__6 ;
    public final void rule__Entity__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:966:1: ( rule__Entity__Group__5__Impl rule__Entity__Group__6 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:967:2: rule__Entity__Group__5__Impl rule__Entity__Group__6
            {
            pushFollow(FOLLOW_rule__Entity__Group__5__Impl_in_rule__Entity__Group__51996);
            rule__Entity__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entity__Group__6_in_rule__Entity__Group__51999);
            rule__Entity__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__5"


    // $ANTLR start "rule__Entity__Group__5__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:974:1: rule__Entity__Group__5__Impl : ( ( rule__Entity__PropertiesAssignment_5 )* ) ;
    public final void rule__Entity__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:978:1: ( ( ( rule__Entity__PropertiesAssignment_5 )* ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:979:1: ( ( rule__Entity__PropertiesAssignment_5 )* )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:979:1: ( ( rule__Entity__PropertiesAssignment_5 )* )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:980:1: ( rule__Entity__PropertiesAssignment_5 )*
            {
             before(grammarAccess.getEntityAccess().getPropertiesAssignment_5()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:981:1: ( rule__Entity__PropertiesAssignment_5 )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==24||LA11_0==26) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:981:2: rule__Entity__PropertiesAssignment_5
            	    {
            	    pushFollow(FOLLOW_rule__Entity__PropertiesAssignment_5_in_rule__Entity__Group__5__Impl2026);
            	    rule__Entity__PropertiesAssignment_5();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

             after(grammarAccess.getEntityAccess().getPropertiesAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__5__Impl"


    // $ANTLR start "rule__Entity__Group__6"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:991:1: rule__Entity__Group__6 : rule__Entity__Group__6__Impl ;
    public final void rule__Entity__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:995:1: ( rule__Entity__Group__6__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:996:2: rule__Entity__Group__6__Impl
            {
            pushFollow(FOLLOW_rule__Entity__Group__6__Impl_in_rule__Entity__Group__62057);
            rule__Entity__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__6"


    // $ANTLR start "rule__Entity__Group__6__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1002:1: rule__Entity__Group__6__Impl : ( '}' ) ;
    public final void rule__Entity__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1006:1: ( ( '}' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1007:1: ( '}' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1007:1: ( '}' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1008:1: '}'
            {
             before(grammarAccess.getEntityAccess().getRightCurlyBracketKeyword_6()); 
            match(input,22,FOLLOW_22_in_rule__Entity__Group__6__Impl2085); 
             after(grammarAccess.getEntityAccess().getRightCurlyBracketKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__6__Impl"


    // $ANTLR start "rule__Entity__Group_3__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1035:1: rule__Entity__Group_3__0 : rule__Entity__Group_3__0__Impl rule__Entity__Group_3__1 ;
    public final void rule__Entity__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1039:1: ( rule__Entity__Group_3__0__Impl rule__Entity__Group_3__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1040:2: rule__Entity__Group_3__0__Impl rule__Entity__Group_3__1
            {
            pushFollow(FOLLOW_rule__Entity__Group_3__0__Impl_in_rule__Entity__Group_3__02130);
            rule__Entity__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entity__Group_3__1_in_rule__Entity__Group_3__02133);
            rule__Entity__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group_3__0"


    // $ANTLR start "rule__Entity__Group_3__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1047:1: rule__Entity__Group_3__0__Impl : ( 'extends' ) ;
    public final void rule__Entity__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1051:1: ( ( 'extends' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1052:1: ( 'extends' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1052:1: ( 'extends' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1053:1: 'extends'
            {
             before(grammarAccess.getEntityAccess().getExtendsKeyword_3_0()); 
            match(input,23,FOLLOW_23_in_rule__Entity__Group_3__0__Impl2161); 
             after(grammarAccess.getEntityAccess().getExtendsKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group_3__0__Impl"


    // $ANTLR start "rule__Entity__Group_3__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1066:1: rule__Entity__Group_3__1 : rule__Entity__Group_3__1__Impl ;
    public final void rule__Entity__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1070:1: ( rule__Entity__Group_3__1__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1071:2: rule__Entity__Group_3__1__Impl
            {
            pushFollow(FOLLOW_rule__Entity__Group_3__1__Impl_in_rule__Entity__Group_3__12192);
            rule__Entity__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group_3__1"


    // $ANTLR start "rule__Entity__Group_3__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1077:1: rule__Entity__Group_3__1__Impl : ( ( rule__Entity__SuperTypeAssignment_3_1 ) ) ;
    public final void rule__Entity__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1081:1: ( ( ( rule__Entity__SuperTypeAssignment_3_1 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1082:1: ( ( rule__Entity__SuperTypeAssignment_3_1 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1082:1: ( ( rule__Entity__SuperTypeAssignment_3_1 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1083:1: ( rule__Entity__SuperTypeAssignment_3_1 )
            {
             before(grammarAccess.getEntityAccess().getSuperTypeAssignment_3_1()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1084:1: ( rule__Entity__SuperTypeAssignment_3_1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1084:2: rule__Entity__SuperTypeAssignment_3_1
            {
            pushFollow(FOLLOW_rule__Entity__SuperTypeAssignment_3_1_in_rule__Entity__Group_3__1__Impl2219);
            rule__Entity__SuperTypeAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getEntityAccess().getSuperTypeAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group_3__1__Impl"


    // $ANTLR start "rule__Attribute__Group__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1098:1: rule__Attribute__Group__0 : rule__Attribute__Group__0__Impl rule__Attribute__Group__1 ;
    public final void rule__Attribute__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1102:1: ( rule__Attribute__Group__0__Impl rule__Attribute__Group__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1103:2: rule__Attribute__Group__0__Impl rule__Attribute__Group__1
            {
            pushFollow(FOLLOW_rule__Attribute__Group__0__Impl_in_rule__Attribute__Group__02253);
            rule__Attribute__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Attribute__Group__1_in_rule__Attribute__Group__02256);
            rule__Attribute__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__0"


    // $ANTLR start "rule__Attribute__Group__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1110:1: rule__Attribute__Group__0__Impl : ( 'att' ) ;
    public final void rule__Attribute__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1114:1: ( ( 'att' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1115:1: ( 'att' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1115:1: ( 'att' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1116:1: 'att'
            {
             before(grammarAccess.getAttributeAccess().getAttKeyword_0()); 
            match(input,24,FOLLOW_24_in_rule__Attribute__Group__0__Impl2284); 
             after(grammarAccess.getAttributeAccess().getAttKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__0__Impl"


    // $ANTLR start "rule__Attribute__Group__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1129:1: rule__Attribute__Group__1 : rule__Attribute__Group__1__Impl rule__Attribute__Group__2 ;
    public final void rule__Attribute__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1133:1: ( rule__Attribute__Group__1__Impl rule__Attribute__Group__2 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1134:2: rule__Attribute__Group__1__Impl rule__Attribute__Group__2
            {
            pushFollow(FOLLOW_rule__Attribute__Group__1__Impl_in_rule__Attribute__Group__12315);
            rule__Attribute__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Attribute__Group__2_in_rule__Attribute__Group__12318);
            rule__Attribute__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__1"


    // $ANTLR start "rule__Attribute__Group__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1141:1: rule__Attribute__Group__1__Impl : ( ( rule__Attribute__NameAssignment_1 ) ) ;
    public final void rule__Attribute__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1145:1: ( ( ( rule__Attribute__NameAssignment_1 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1146:1: ( ( rule__Attribute__NameAssignment_1 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1146:1: ( ( rule__Attribute__NameAssignment_1 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1147:1: ( rule__Attribute__NameAssignment_1 )
            {
             before(grammarAccess.getAttributeAccess().getNameAssignment_1()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1148:1: ( rule__Attribute__NameAssignment_1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1148:2: rule__Attribute__NameAssignment_1
            {
            pushFollow(FOLLOW_rule__Attribute__NameAssignment_1_in_rule__Attribute__Group__1__Impl2345);
            rule__Attribute__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getAttributeAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__1__Impl"


    // $ANTLR start "rule__Attribute__Group__2"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1158:1: rule__Attribute__Group__2 : rule__Attribute__Group__2__Impl rule__Attribute__Group__3 ;
    public final void rule__Attribute__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1162:1: ( rule__Attribute__Group__2__Impl rule__Attribute__Group__3 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1163:2: rule__Attribute__Group__2__Impl rule__Attribute__Group__3
            {
            pushFollow(FOLLOW_rule__Attribute__Group__2__Impl_in_rule__Attribute__Group__22375);
            rule__Attribute__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Attribute__Group__3_in_rule__Attribute__Group__22378);
            rule__Attribute__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__2"


    // $ANTLR start "rule__Attribute__Group__2__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1170:1: rule__Attribute__Group__2__Impl : ( ':' ) ;
    public final void rule__Attribute__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1174:1: ( ( ':' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1175:1: ( ':' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1175:1: ( ':' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1176:1: ':'
            {
             before(grammarAccess.getAttributeAccess().getColonKeyword_2()); 
            match(input,25,FOLLOW_25_in_rule__Attribute__Group__2__Impl2406); 
             after(grammarAccess.getAttributeAccess().getColonKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__2__Impl"


    // $ANTLR start "rule__Attribute__Group__3"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1189:1: rule__Attribute__Group__3 : rule__Attribute__Group__3__Impl rule__Attribute__Group__4 ;
    public final void rule__Attribute__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1193:1: ( rule__Attribute__Group__3__Impl rule__Attribute__Group__4 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1194:2: rule__Attribute__Group__3__Impl rule__Attribute__Group__4
            {
            pushFollow(FOLLOW_rule__Attribute__Group__3__Impl_in_rule__Attribute__Group__32437);
            rule__Attribute__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Attribute__Group__4_in_rule__Attribute__Group__32440);
            rule__Attribute__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__3"


    // $ANTLR start "rule__Attribute__Group__3__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1201:1: rule__Attribute__Group__3__Impl : ( ( rule__Attribute__TypeAssignment_3 ) ) ;
    public final void rule__Attribute__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1205:1: ( ( ( rule__Attribute__TypeAssignment_3 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1206:1: ( ( rule__Attribute__TypeAssignment_3 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1206:1: ( ( rule__Attribute__TypeAssignment_3 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1207:1: ( rule__Attribute__TypeAssignment_3 )
            {
             before(grammarAccess.getAttributeAccess().getTypeAssignment_3()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1208:1: ( rule__Attribute__TypeAssignment_3 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1208:2: rule__Attribute__TypeAssignment_3
            {
            pushFollow(FOLLOW_rule__Attribute__TypeAssignment_3_in_rule__Attribute__Group__3__Impl2467);
            rule__Attribute__TypeAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getAttributeAccess().getTypeAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__3__Impl"


    // $ANTLR start "rule__Attribute__Group__4"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1218:1: rule__Attribute__Group__4 : rule__Attribute__Group__4__Impl ;
    public final void rule__Attribute__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1222:1: ( rule__Attribute__Group__4__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1223:2: rule__Attribute__Group__4__Impl
            {
            pushFollow(FOLLOW_rule__Attribute__Group__4__Impl_in_rule__Attribute__Group__42497);
            rule__Attribute__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__4"


    // $ANTLR start "rule__Attribute__Group__4__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1229:1: rule__Attribute__Group__4__Impl : ( ( rule__Attribute__OptionalAssignment_4 )? ) ;
    public final void rule__Attribute__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1233:1: ( ( ( rule__Attribute__OptionalAssignment_4 )? ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1234:1: ( ( rule__Attribute__OptionalAssignment_4 )? )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1234:1: ( ( rule__Attribute__OptionalAssignment_4 )? )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1235:1: ( rule__Attribute__OptionalAssignment_4 )?
            {
             before(grammarAccess.getAttributeAccess().getOptionalAssignment_4()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1236:1: ( rule__Attribute__OptionalAssignment_4 )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==42) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1236:2: rule__Attribute__OptionalAssignment_4
                    {
                    pushFollow(FOLLOW_rule__Attribute__OptionalAssignment_4_in_rule__Attribute__Group__4__Impl2524);
                    rule__Attribute__OptionalAssignment_4();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getAttributeAccess().getOptionalAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__4__Impl"


    // $ANTLR start "rule__Reference__Group__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1256:1: rule__Reference__Group__0 : rule__Reference__Group__0__Impl rule__Reference__Group__1 ;
    public final void rule__Reference__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1260:1: ( rule__Reference__Group__0__Impl rule__Reference__Group__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1261:2: rule__Reference__Group__0__Impl rule__Reference__Group__1
            {
            pushFollow(FOLLOW_rule__Reference__Group__0__Impl_in_rule__Reference__Group__02565);
            rule__Reference__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Reference__Group__1_in_rule__Reference__Group__02568);
            rule__Reference__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__0"


    // $ANTLR start "rule__Reference__Group__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1268:1: rule__Reference__Group__0__Impl : ( 'ref' ) ;
    public final void rule__Reference__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1272:1: ( ( 'ref' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1273:1: ( 'ref' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1273:1: ( 'ref' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1274:1: 'ref'
            {
             before(grammarAccess.getReferenceAccess().getRefKeyword_0()); 
            match(input,26,FOLLOW_26_in_rule__Reference__Group__0__Impl2596); 
             after(grammarAccess.getReferenceAccess().getRefKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__0__Impl"


    // $ANTLR start "rule__Reference__Group__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1287:1: rule__Reference__Group__1 : rule__Reference__Group__1__Impl rule__Reference__Group__2 ;
    public final void rule__Reference__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1291:1: ( rule__Reference__Group__1__Impl rule__Reference__Group__2 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1292:2: rule__Reference__Group__1__Impl rule__Reference__Group__2
            {
            pushFollow(FOLLOW_rule__Reference__Group__1__Impl_in_rule__Reference__Group__12627);
            rule__Reference__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Reference__Group__2_in_rule__Reference__Group__12630);
            rule__Reference__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__1"


    // $ANTLR start "rule__Reference__Group__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1299:1: rule__Reference__Group__1__Impl : ( ( rule__Reference__NameAssignment_1 ) ) ;
    public final void rule__Reference__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1303:1: ( ( ( rule__Reference__NameAssignment_1 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1304:1: ( ( rule__Reference__NameAssignment_1 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1304:1: ( ( rule__Reference__NameAssignment_1 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1305:1: ( rule__Reference__NameAssignment_1 )
            {
             before(grammarAccess.getReferenceAccess().getNameAssignment_1()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1306:1: ( rule__Reference__NameAssignment_1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1306:2: rule__Reference__NameAssignment_1
            {
            pushFollow(FOLLOW_rule__Reference__NameAssignment_1_in_rule__Reference__Group__1__Impl2657);
            rule__Reference__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getReferenceAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__1__Impl"


    // $ANTLR start "rule__Reference__Group__2"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1316:1: rule__Reference__Group__2 : rule__Reference__Group__2__Impl rule__Reference__Group__3 ;
    public final void rule__Reference__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1320:1: ( rule__Reference__Group__2__Impl rule__Reference__Group__3 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1321:2: rule__Reference__Group__2__Impl rule__Reference__Group__3
            {
            pushFollow(FOLLOW_rule__Reference__Group__2__Impl_in_rule__Reference__Group__22687);
            rule__Reference__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Reference__Group__3_in_rule__Reference__Group__22690);
            rule__Reference__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__2"


    // $ANTLR start "rule__Reference__Group__2__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1328:1: rule__Reference__Group__2__Impl : ( ':' ) ;
    public final void rule__Reference__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1332:1: ( ( ':' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1333:1: ( ':' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1333:1: ( ':' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1334:1: ':'
            {
             before(grammarAccess.getReferenceAccess().getColonKeyword_2()); 
            match(input,25,FOLLOW_25_in_rule__Reference__Group__2__Impl2718); 
             after(grammarAccess.getReferenceAccess().getColonKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__2__Impl"


    // $ANTLR start "rule__Reference__Group__3"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1347:1: rule__Reference__Group__3 : rule__Reference__Group__3__Impl rule__Reference__Group__4 ;
    public final void rule__Reference__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1351:1: ( rule__Reference__Group__3__Impl rule__Reference__Group__4 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1352:2: rule__Reference__Group__3__Impl rule__Reference__Group__4
            {
            pushFollow(FOLLOW_rule__Reference__Group__3__Impl_in_rule__Reference__Group__32749);
            rule__Reference__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Reference__Group__4_in_rule__Reference__Group__32752);
            rule__Reference__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__3"


    // $ANTLR start "rule__Reference__Group__3__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1359:1: rule__Reference__Group__3__Impl : ( ( rule__Reference__TypeAssignment_3 ) ) ;
    public final void rule__Reference__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1363:1: ( ( ( rule__Reference__TypeAssignment_3 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1364:1: ( ( rule__Reference__TypeAssignment_3 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1364:1: ( ( rule__Reference__TypeAssignment_3 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1365:1: ( rule__Reference__TypeAssignment_3 )
            {
             before(grammarAccess.getReferenceAccess().getTypeAssignment_3()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1366:1: ( rule__Reference__TypeAssignment_3 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1366:2: rule__Reference__TypeAssignment_3
            {
            pushFollow(FOLLOW_rule__Reference__TypeAssignment_3_in_rule__Reference__Group__3__Impl2779);
            rule__Reference__TypeAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getReferenceAccess().getTypeAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__3__Impl"


    // $ANTLR start "rule__Reference__Group__4"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1376:1: rule__Reference__Group__4 : rule__Reference__Group__4__Impl rule__Reference__Group__5 ;
    public final void rule__Reference__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1380:1: ( rule__Reference__Group__4__Impl rule__Reference__Group__5 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1381:2: rule__Reference__Group__4__Impl rule__Reference__Group__5
            {
            pushFollow(FOLLOW_rule__Reference__Group__4__Impl_in_rule__Reference__Group__42809);
            rule__Reference__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Reference__Group__5_in_rule__Reference__Group__42812);
            rule__Reference__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__4"


    // $ANTLR start "rule__Reference__Group__4__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1388:1: rule__Reference__Group__4__Impl : ( ( rule__Reference__MultiplicityAssignment_4 )? ) ;
    public final void rule__Reference__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1392:1: ( ( ( rule__Reference__MultiplicityAssignment_4 )? ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1393:1: ( ( rule__Reference__MultiplicityAssignment_4 )? )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1393:1: ( ( rule__Reference__MultiplicityAssignment_4 )? )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1394:1: ( rule__Reference__MultiplicityAssignment_4 )?
            {
             before(grammarAccess.getReferenceAccess().getMultiplicityAssignment_4()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1395:1: ( rule__Reference__MultiplicityAssignment_4 )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( ((LA13_0>=14 && LA13_0<=15)) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1395:2: rule__Reference__MultiplicityAssignment_4
                    {
                    pushFollow(FOLLOW_rule__Reference__MultiplicityAssignment_4_in_rule__Reference__Group__4__Impl2839);
                    rule__Reference__MultiplicityAssignment_4();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getReferenceAccess().getMultiplicityAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__4__Impl"


    // $ANTLR start "rule__Reference__Group__5"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1405:1: rule__Reference__Group__5 : rule__Reference__Group__5__Impl ;
    public final void rule__Reference__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1409:1: ( rule__Reference__Group__5__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1410:2: rule__Reference__Group__5__Impl
            {
            pushFollow(FOLLOW_rule__Reference__Group__5__Impl_in_rule__Reference__Group__52870);
            rule__Reference__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__5"


    // $ANTLR start "rule__Reference__Group__5__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1416:1: rule__Reference__Group__5__Impl : ( ( rule__Reference__Group_5__0 ) ) ;
    public final void rule__Reference__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1420:1: ( ( ( rule__Reference__Group_5__0 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1421:1: ( ( rule__Reference__Group_5__0 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1421:1: ( ( rule__Reference__Group_5__0 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1422:1: ( rule__Reference__Group_5__0 )
            {
             before(grammarAccess.getReferenceAccess().getGroup_5()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1423:1: ( rule__Reference__Group_5__0 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1423:2: rule__Reference__Group_5__0
            {
            pushFollow(FOLLOW_rule__Reference__Group_5__0_in_rule__Reference__Group__5__Impl2897);
            rule__Reference__Group_5__0();

            state._fsp--;


            }

             after(grammarAccess.getReferenceAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__5__Impl"


    // $ANTLR start "rule__Reference__Group_5__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1445:1: rule__Reference__Group_5__0 : rule__Reference__Group_5__0__Impl rule__Reference__Group_5__1 ;
    public final void rule__Reference__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1449:1: ( rule__Reference__Group_5__0__Impl rule__Reference__Group_5__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1450:2: rule__Reference__Group_5__0__Impl rule__Reference__Group_5__1
            {
            pushFollow(FOLLOW_rule__Reference__Group_5__0__Impl_in_rule__Reference__Group_5__02939);
            rule__Reference__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Reference__Group_5__1_in_rule__Reference__Group_5__02942);
            rule__Reference__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group_5__0"


    // $ANTLR start "rule__Reference__Group_5__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1457:1: rule__Reference__Group_5__0__Impl : ( 'opposite=' ) ;
    public final void rule__Reference__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1461:1: ( ( 'opposite=' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1462:1: ( 'opposite=' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1462:1: ( 'opposite=' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1463:1: 'opposite='
            {
             before(grammarAccess.getReferenceAccess().getOppositeKeyword_5_0()); 
            match(input,27,FOLLOW_27_in_rule__Reference__Group_5__0__Impl2970); 
             after(grammarAccess.getReferenceAccess().getOppositeKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group_5__0__Impl"


    // $ANTLR start "rule__Reference__Group_5__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1476:1: rule__Reference__Group_5__1 : rule__Reference__Group_5__1__Impl ;
    public final void rule__Reference__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1480:1: ( rule__Reference__Group_5__1__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1481:2: rule__Reference__Group_5__1__Impl
            {
            pushFollow(FOLLOW_rule__Reference__Group_5__1__Impl_in_rule__Reference__Group_5__13001);
            rule__Reference__Group_5__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group_5__1"


    // $ANTLR start "rule__Reference__Group_5__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1487:1: rule__Reference__Group_5__1__Impl : ( ( rule__Reference__OppositeAssignment_5_1 ) ) ;
    public final void rule__Reference__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1491:1: ( ( ( rule__Reference__OppositeAssignment_5_1 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1492:1: ( ( rule__Reference__OppositeAssignment_5_1 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1492:1: ( ( rule__Reference__OppositeAssignment_5_1 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1493:1: ( rule__Reference__OppositeAssignment_5_1 )
            {
             before(grammarAccess.getReferenceAccess().getOppositeAssignment_5_1()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1494:1: ( rule__Reference__OppositeAssignment_5_1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1494:2: rule__Reference__OppositeAssignment_5_1
            {
            pushFollow(FOLLOW_rule__Reference__OppositeAssignment_5_1_in_rule__Reference__Group_5__1__Impl3028);
            rule__Reference__OppositeAssignment_5_1();

            state._fsp--;


            }

             after(grammarAccess.getReferenceAccess().getOppositeAssignment_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group_5__1__Impl"


    // $ANTLR start "rule__ListWindow__Group__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1508:1: rule__ListWindow__Group__0 : rule__ListWindow__Group__0__Impl rule__ListWindow__Group__1 ;
    public final void rule__ListWindow__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1512:1: ( rule__ListWindow__Group__0__Impl rule__ListWindow__Group__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1513:2: rule__ListWindow__Group__0__Impl rule__ListWindow__Group__1
            {
            pushFollow(FOLLOW_rule__ListWindow__Group__0__Impl_in_rule__ListWindow__Group__03062);
            rule__ListWindow__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ListWindow__Group__1_in_rule__ListWindow__Group__03065);
            rule__ListWindow__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__0"


    // $ANTLR start "rule__ListWindow__Group__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1520:1: rule__ListWindow__Group__0__Impl : ( 'ListWindow' ) ;
    public final void rule__ListWindow__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1524:1: ( ( 'ListWindow' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1525:1: ( 'ListWindow' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1525:1: ( 'ListWindow' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1526:1: 'ListWindow'
            {
             before(grammarAccess.getListWindowAccess().getListWindowKeyword_0()); 
            match(input,28,FOLLOW_28_in_rule__ListWindow__Group__0__Impl3093); 
             after(grammarAccess.getListWindowAccess().getListWindowKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__0__Impl"


    // $ANTLR start "rule__ListWindow__Group__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1539:1: rule__ListWindow__Group__1 : rule__ListWindow__Group__1__Impl rule__ListWindow__Group__2 ;
    public final void rule__ListWindow__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1543:1: ( rule__ListWindow__Group__1__Impl rule__ListWindow__Group__2 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1544:2: rule__ListWindow__Group__1__Impl rule__ListWindow__Group__2
            {
            pushFollow(FOLLOW_rule__ListWindow__Group__1__Impl_in_rule__ListWindow__Group__13124);
            rule__ListWindow__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ListWindow__Group__2_in_rule__ListWindow__Group__13127);
            rule__ListWindow__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__1"


    // $ANTLR start "rule__ListWindow__Group__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1551:1: rule__ListWindow__Group__1__Impl : ( ( rule__ListWindow__NameAssignment_1 ) ) ;
    public final void rule__ListWindow__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1555:1: ( ( ( rule__ListWindow__NameAssignment_1 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1556:1: ( ( rule__ListWindow__NameAssignment_1 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1556:1: ( ( rule__ListWindow__NameAssignment_1 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1557:1: ( rule__ListWindow__NameAssignment_1 )
            {
             before(grammarAccess.getListWindowAccess().getNameAssignment_1()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1558:1: ( rule__ListWindow__NameAssignment_1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1558:2: rule__ListWindow__NameAssignment_1
            {
            pushFollow(FOLLOW_rule__ListWindow__NameAssignment_1_in_rule__ListWindow__Group__1__Impl3154);
            rule__ListWindow__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getListWindowAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__1__Impl"


    // $ANTLR start "rule__ListWindow__Group__2"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1568:1: rule__ListWindow__Group__2 : rule__ListWindow__Group__2__Impl rule__ListWindow__Group__3 ;
    public final void rule__ListWindow__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1572:1: ( rule__ListWindow__Group__2__Impl rule__ListWindow__Group__3 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1573:2: rule__ListWindow__Group__2__Impl rule__ListWindow__Group__3
            {
            pushFollow(FOLLOW_rule__ListWindow__Group__2__Impl_in_rule__ListWindow__Group__23184);
            rule__ListWindow__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ListWindow__Group__3_in_rule__ListWindow__Group__23187);
            rule__ListWindow__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__2"


    // $ANTLR start "rule__ListWindow__Group__2__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1580:1: rule__ListWindow__Group__2__Impl : ( 'for' ) ;
    public final void rule__ListWindow__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1584:1: ( ( 'for' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1585:1: ( 'for' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1585:1: ( 'for' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1586:1: 'for'
            {
             before(grammarAccess.getListWindowAccess().getForKeyword_2()); 
            match(input,29,FOLLOW_29_in_rule__ListWindow__Group__2__Impl3215); 
             after(grammarAccess.getListWindowAccess().getForKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__2__Impl"


    // $ANTLR start "rule__ListWindow__Group__3"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1599:1: rule__ListWindow__Group__3 : rule__ListWindow__Group__3__Impl rule__ListWindow__Group__4 ;
    public final void rule__ListWindow__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1603:1: ( rule__ListWindow__Group__3__Impl rule__ListWindow__Group__4 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1604:2: rule__ListWindow__Group__3__Impl rule__ListWindow__Group__4
            {
            pushFollow(FOLLOW_rule__ListWindow__Group__3__Impl_in_rule__ListWindow__Group__33246);
            rule__ListWindow__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ListWindow__Group__4_in_rule__ListWindow__Group__33249);
            rule__ListWindow__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__3"


    // $ANTLR start "rule__ListWindow__Group__3__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1611:1: rule__ListWindow__Group__3__Impl : ( ( rule__ListWindow__EntityAssignment_3 ) ) ;
    public final void rule__ListWindow__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1615:1: ( ( ( rule__ListWindow__EntityAssignment_3 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1616:1: ( ( rule__ListWindow__EntityAssignment_3 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1616:1: ( ( rule__ListWindow__EntityAssignment_3 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1617:1: ( rule__ListWindow__EntityAssignment_3 )
            {
             before(grammarAccess.getListWindowAccess().getEntityAssignment_3()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1618:1: ( rule__ListWindow__EntityAssignment_3 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1618:2: rule__ListWindow__EntityAssignment_3
            {
            pushFollow(FOLLOW_rule__ListWindow__EntityAssignment_3_in_rule__ListWindow__Group__3__Impl3276);
            rule__ListWindow__EntityAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getListWindowAccess().getEntityAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__3__Impl"


    // $ANTLR start "rule__ListWindow__Group__4"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1628:1: rule__ListWindow__Group__4 : rule__ListWindow__Group__4__Impl rule__ListWindow__Group__5 ;
    public final void rule__ListWindow__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1632:1: ( rule__ListWindow__Group__4__Impl rule__ListWindow__Group__5 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1633:2: rule__ListWindow__Group__4__Impl rule__ListWindow__Group__5
            {
            pushFollow(FOLLOW_rule__ListWindow__Group__4__Impl_in_rule__ListWindow__Group__43306);
            rule__ListWindow__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ListWindow__Group__5_in_rule__ListWindow__Group__43309);
            rule__ListWindow__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__4"


    // $ANTLR start "rule__ListWindow__Group__4__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1640:1: rule__ListWindow__Group__4__Impl : ( ( rule__ListWindow__Group_4__0 )? ) ;
    public final void rule__ListWindow__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1644:1: ( ( ( rule__ListWindow__Group_4__0 )? ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1645:1: ( ( rule__ListWindow__Group_4__0 )? )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1645:1: ( ( rule__ListWindow__Group_4__0 )? )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1646:1: ( rule__ListWindow__Group_4__0 )?
            {
             before(grammarAccess.getListWindowAccess().getGroup_4()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1647:1: ( rule__ListWindow__Group_4__0 )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==30) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1647:2: rule__ListWindow__Group_4__0
                    {
                    pushFollow(FOLLOW_rule__ListWindow__Group_4__0_in_rule__ListWindow__Group__4__Impl3336);
                    rule__ListWindow__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getListWindowAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__4__Impl"


    // $ANTLR start "rule__ListWindow__Group__5"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1657:1: rule__ListWindow__Group__5 : rule__ListWindow__Group__5__Impl ;
    public final void rule__ListWindow__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1661:1: ( rule__ListWindow__Group__5__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1662:2: rule__ListWindow__Group__5__Impl
            {
            pushFollow(FOLLOW_rule__ListWindow__Group__5__Impl_in_rule__ListWindow__Group__53367);
            rule__ListWindow__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__5"


    // $ANTLR start "rule__ListWindow__Group__5__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1668:1: rule__ListWindow__Group__5__Impl : ( ( rule__ListWindow__SizeAssignment_5 ) ) ;
    public final void rule__ListWindow__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1672:1: ( ( ( rule__ListWindow__SizeAssignment_5 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1673:1: ( ( rule__ListWindow__SizeAssignment_5 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1673:1: ( ( rule__ListWindow__SizeAssignment_5 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1674:1: ( rule__ListWindow__SizeAssignment_5 )
            {
             before(grammarAccess.getListWindowAccess().getSizeAssignment_5()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1675:1: ( rule__ListWindow__SizeAssignment_5 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1675:2: rule__ListWindow__SizeAssignment_5
            {
            pushFollow(FOLLOW_rule__ListWindow__SizeAssignment_5_in_rule__ListWindow__Group__5__Impl3394);
            rule__ListWindow__SizeAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getListWindowAccess().getSizeAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__5__Impl"


    // $ANTLR start "rule__ListWindow__Group_4__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1697:1: rule__ListWindow__Group_4__0 : rule__ListWindow__Group_4__0__Impl rule__ListWindow__Group_4__1 ;
    public final void rule__ListWindow__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1701:1: ( rule__ListWindow__Group_4__0__Impl rule__ListWindow__Group_4__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1702:2: rule__ListWindow__Group_4__0__Impl rule__ListWindow__Group_4__1
            {
            pushFollow(FOLLOW_rule__ListWindow__Group_4__0__Impl_in_rule__ListWindow__Group_4__03436);
            rule__ListWindow__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ListWindow__Group_4__1_in_rule__ListWindow__Group_4__03439);
            rule__ListWindow__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group_4__0"


    // $ANTLR start "rule__ListWindow__Group_4__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1709:1: rule__ListWindow__Group_4__0__Impl : ( 'title' ) ;
    public final void rule__ListWindow__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1713:1: ( ( 'title' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1714:1: ( 'title' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1714:1: ( 'title' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1715:1: 'title'
            {
             before(grammarAccess.getListWindowAccess().getTitleKeyword_4_0()); 
            match(input,30,FOLLOW_30_in_rule__ListWindow__Group_4__0__Impl3467); 
             after(grammarAccess.getListWindowAccess().getTitleKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group_4__0__Impl"


    // $ANTLR start "rule__ListWindow__Group_4__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1728:1: rule__ListWindow__Group_4__1 : rule__ListWindow__Group_4__1__Impl ;
    public final void rule__ListWindow__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1732:1: ( rule__ListWindow__Group_4__1__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1733:2: rule__ListWindow__Group_4__1__Impl
            {
            pushFollow(FOLLOW_rule__ListWindow__Group_4__1__Impl_in_rule__ListWindow__Group_4__13498);
            rule__ListWindow__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group_4__1"


    // $ANTLR start "rule__ListWindow__Group_4__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1739:1: rule__ListWindow__Group_4__1__Impl : ( ( rule__ListWindow__TitleAssignment_4_1 ) ) ;
    public final void rule__ListWindow__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1743:1: ( ( ( rule__ListWindow__TitleAssignment_4_1 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1744:1: ( ( rule__ListWindow__TitleAssignment_4_1 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1744:1: ( ( rule__ListWindow__TitleAssignment_4_1 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1745:1: ( rule__ListWindow__TitleAssignment_4_1 )
            {
             before(grammarAccess.getListWindowAccess().getTitleAssignment_4_1()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1746:1: ( rule__ListWindow__TitleAssignment_4_1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1746:2: rule__ListWindow__TitleAssignment_4_1
            {
            pushFollow(FOLLOW_rule__ListWindow__TitleAssignment_4_1_in_rule__ListWindow__Group_4__1__Impl3525);
            rule__ListWindow__TitleAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getListWindowAccess().getTitleAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group_4__1__Impl"


    // $ANTLR start "rule__EntryWindow__Group__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1760:1: rule__EntryWindow__Group__0 : rule__EntryWindow__Group__0__Impl rule__EntryWindow__Group__1 ;
    public final void rule__EntryWindow__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1764:1: ( rule__EntryWindow__Group__0__Impl rule__EntryWindow__Group__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1765:2: rule__EntryWindow__Group__0__Impl rule__EntryWindow__Group__1
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group__0__Impl_in_rule__EntryWindow__Group__03559);
            rule__EntryWindow__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__EntryWindow__Group__1_in_rule__EntryWindow__Group__03562);
            rule__EntryWindow__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__0"


    // $ANTLR start "rule__EntryWindow__Group__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1772:1: rule__EntryWindow__Group__0__Impl : ( 'EntryWindow' ) ;
    public final void rule__EntryWindow__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1776:1: ( ( 'EntryWindow' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1777:1: ( 'EntryWindow' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1777:1: ( 'EntryWindow' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1778:1: 'EntryWindow'
            {
             before(grammarAccess.getEntryWindowAccess().getEntryWindowKeyword_0()); 
            match(input,31,FOLLOW_31_in_rule__EntryWindow__Group__0__Impl3590); 
             after(grammarAccess.getEntryWindowAccess().getEntryWindowKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__0__Impl"


    // $ANTLR start "rule__EntryWindow__Group__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1791:1: rule__EntryWindow__Group__1 : rule__EntryWindow__Group__1__Impl rule__EntryWindow__Group__2 ;
    public final void rule__EntryWindow__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1795:1: ( rule__EntryWindow__Group__1__Impl rule__EntryWindow__Group__2 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1796:2: rule__EntryWindow__Group__1__Impl rule__EntryWindow__Group__2
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group__1__Impl_in_rule__EntryWindow__Group__13621);
            rule__EntryWindow__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__EntryWindow__Group__2_in_rule__EntryWindow__Group__13624);
            rule__EntryWindow__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__1"


    // $ANTLR start "rule__EntryWindow__Group__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1803:1: rule__EntryWindow__Group__1__Impl : ( ( rule__EntryWindow__NameAssignment_1 ) ) ;
    public final void rule__EntryWindow__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1807:1: ( ( ( rule__EntryWindow__NameAssignment_1 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1808:1: ( ( rule__EntryWindow__NameAssignment_1 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1808:1: ( ( rule__EntryWindow__NameAssignment_1 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1809:1: ( rule__EntryWindow__NameAssignment_1 )
            {
             before(grammarAccess.getEntryWindowAccess().getNameAssignment_1()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1810:1: ( rule__EntryWindow__NameAssignment_1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1810:2: rule__EntryWindow__NameAssignment_1
            {
            pushFollow(FOLLOW_rule__EntryWindow__NameAssignment_1_in_rule__EntryWindow__Group__1__Impl3651);
            rule__EntryWindow__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getEntryWindowAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__1__Impl"


    // $ANTLR start "rule__EntryWindow__Group__2"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1820:1: rule__EntryWindow__Group__2 : rule__EntryWindow__Group__2__Impl rule__EntryWindow__Group__3 ;
    public final void rule__EntryWindow__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1824:1: ( rule__EntryWindow__Group__2__Impl rule__EntryWindow__Group__3 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1825:2: rule__EntryWindow__Group__2__Impl rule__EntryWindow__Group__3
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group__2__Impl_in_rule__EntryWindow__Group__23681);
            rule__EntryWindow__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__EntryWindow__Group__3_in_rule__EntryWindow__Group__23684);
            rule__EntryWindow__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__2"


    // $ANTLR start "rule__EntryWindow__Group__2__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1832:1: rule__EntryWindow__Group__2__Impl : ( 'for' ) ;
    public final void rule__EntryWindow__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1836:1: ( ( 'for' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1837:1: ( 'for' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1837:1: ( 'for' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1838:1: 'for'
            {
             before(grammarAccess.getEntryWindowAccess().getForKeyword_2()); 
            match(input,29,FOLLOW_29_in_rule__EntryWindow__Group__2__Impl3712); 
             after(grammarAccess.getEntryWindowAccess().getForKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__2__Impl"


    // $ANTLR start "rule__EntryWindow__Group__3"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1851:1: rule__EntryWindow__Group__3 : rule__EntryWindow__Group__3__Impl rule__EntryWindow__Group__4 ;
    public final void rule__EntryWindow__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1855:1: ( rule__EntryWindow__Group__3__Impl rule__EntryWindow__Group__4 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1856:2: rule__EntryWindow__Group__3__Impl rule__EntryWindow__Group__4
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group__3__Impl_in_rule__EntryWindow__Group__33743);
            rule__EntryWindow__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__EntryWindow__Group__4_in_rule__EntryWindow__Group__33746);
            rule__EntryWindow__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__3"


    // $ANTLR start "rule__EntryWindow__Group__3__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1863:1: rule__EntryWindow__Group__3__Impl : ( ( rule__EntryWindow__EntityAssignment_3 ) ) ;
    public final void rule__EntryWindow__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1867:1: ( ( ( rule__EntryWindow__EntityAssignment_3 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1868:1: ( ( rule__EntryWindow__EntityAssignment_3 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1868:1: ( ( rule__EntryWindow__EntityAssignment_3 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1869:1: ( rule__EntryWindow__EntityAssignment_3 )
            {
             before(grammarAccess.getEntryWindowAccess().getEntityAssignment_3()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1870:1: ( rule__EntryWindow__EntityAssignment_3 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1870:2: rule__EntryWindow__EntityAssignment_3
            {
            pushFollow(FOLLOW_rule__EntryWindow__EntityAssignment_3_in_rule__EntryWindow__Group__3__Impl3773);
            rule__EntryWindow__EntityAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getEntryWindowAccess().getEntityAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__3__Impl"


    // $ANTLR start "rule__EntryWindow__Group__4"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1880:1: rule__EntryWindow__Group__4 : rule__EntryWindow__Group__4__Impl rule__EntryWindow__Group__5 ;
    public final void rule__EntryWindow__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1884:1: ( rule__EntryWindow__Group__4__Impl rule__EntryWindow__Group__5 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1885:2: rule__EntryWindow__Group__4__Impl rule__EntryWindow__Group__5
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group__4__Impl_in_rule__EntryWindow__Group__43803);
            rule__EntryWindow__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__EntryWindow__Group__5_in_rule__EntryWindow__Group__43806);
            rule__EntryWindow__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__4"


    // $ANTLR start "rule__EntryWindow__Group__4__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1892:1: rule__EntryWindow__Group__4__Impl : ( ( rule__EntryWindow__UnorderedGroup_4 ) ) ;
    public final void rule__EntryWindow__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1896:1: ( ( ( rule__EntryWindow__UnorderedGroup_4 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1897:1: ( ( rule__EntryWindow__UnorderedGroup_4 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1897:1: ( ( rule__EntryWindow__UnorderedGroup_4 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1898:1: ( rule__EntryWindow__UnorderedGroup_4 )
            {
             before(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1899:1: ( rule__EntryWindow__UnorderedGroup_4 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1899:2: rule__EntryWindow__UnorderedGroup_4
            {
            pushFollow(FOLLOW_rule__EntryWindow__UnorderedGroup_4_in_rule__EntryWindow__Group__4__Impl3833);
            rule__EntryWindow__UnorderedGroup_4();

            state._fsp--;


            }

             after(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__4__Impl"


    // $ANTLR start "rule__EntryWindow__Group__5"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1909:1: rule__EntryWindow__Group__5 : rule__EntryWindow__Group__5__Impl rule__EntryWindow__Group__6 ;
    public final void rule__EntryWindow__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1913:1: ( rule__EntryWindow__Group__5__Impl rule__EntryWindow__Group__6 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1914:2: rule__EntryWindow__Group__5__Impl rule__EntryWindow__Group__6
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group__5__Impl_in_rule__EntryWindow__Group__53863);
            rule__EntryWindow__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__EntryWindow__Group__6_in_rule__EntryWindow__Group__53866);
            rule__EntryWindow__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__5"


    // $ANTLR start "rule__EntryWindow__Group__5__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1921:1: rule__EntryWindow__Group__5__Impl : ( '{' ) ;
    public final void rule__EntryWindow__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1925:1: ( ( '{' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1926:1: ( '{' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1926:1: ( '{' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1927:1: '{'
            {
             before(grammarAccess.getEntryWindowAccess().getLeftCurlyBracketKeyword_5()); 
            match(input,21,FOLLOW_21_in_rule__EntryWindow__Group__5__Impl3894); 
             after(grammarAccess.getEntryWindowAccess().getLeftCurlyBracketKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__5__Impl"


    // $ANTLR start "rule__EntryWindow__Group__6"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1940:1: rule__EntryWindow__Group__6 : rule__EntryWindow__Group__6__Impl rule__EntryWindow__Group__7 ;
    public final void rule__EntryWindow__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1944:1: ( rule__EntryWindow__Group__6__Impl rule__EntryWindow__Group__7 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1945:2: rule__EntryWindow__Group__6__Impl rule__EntryWindow__Group__7
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group__6__Impl_in_rule__EntryWindow__Group__63925);
            rule__EntryWindow__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__EntryWindow__Group__7_in_rule__EntryWindow__Group__63928);
            rule__EntryWindow__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__6"


    // $ANTLR start "rule__EntryWindow__Group__6__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1952:1: rule__EntryWindow__Group__6__Impl : ( ( rule__EntryWindow__ElementsAssignment_6 )* ) ;
    public final void rule__EntryWindow__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1956:1: ( ( ( rule__EntryWindow__ElementsAssignment_6 )* ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1957:1: ( ( rule__EntryWindow__ElementsAssignment_6 )* )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1957:1: ( ( rule__EntryWindow__ElementsAssignment_6 )* )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1958:1: ( rule__EntryWindow__ElementsAssignment_6 )*
            {
             before(grammarAccess.getEntryWindowAccess().getElementsAssignment_6()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1959:1: ( rule__EntryWindow__ElementsAssignment_6 )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( ((LA15_0>=37 && LA15_0<=39)) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1959:2: rule__EntryWindow__ElementsAssignment_6
            	    {
            	    pushFollow(FOLLOW_rule__EntryWindow__ElementsAssignment_6_in_rule__EntryWindow__Group__6__Impl3955);
            	    rule__EntryWindow__ElementsAssignment_6();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);

             after(grammarAccess.getEntryWindowAccess().getElementsAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__6__Impl"


    // $ANTLR start "rule__EntryWindow__Group__7"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1969:1: rule__EntryWindow__Group__7 : rule__EntryWindow__Group__7__Impl ;
    public final void rule__EntryWindow__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1973:1: ( rule__EntryWindow__Group__7__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1974:2: rule__EntryWindow__Group__7__Impl
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group__7__Impl_in_rule__EntryWindow__Group__73986);
            rule__EntryWindow__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__7"


    // $ANTLR start "rule__EntryWindow__Group__7__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1980:1: rule__EntryWindow__Group__7__Impl : ( '}' ) ;
    public final void rule__EntryWindow__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1984:1: ( ( '}' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1985:1: ( '}' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1985:1: ( '}' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:1986:1: '}'
            {
             before(grammarAccess.getEntryWindowAccess().getRightCurlyBracketKeyword_7()); 
            match(input,22,FOLLOW_22_in_rule__EntryWindow__Group__7__Impl4014); 
             after(grammarAccess.getEntryWindowAccess().getRightCurlyBracketKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__7__Impl"


    // $ANTLR start "rule__EntryWindow__Group_4_0__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2015:1: rule__EntryWindow__Group_4_0__0 : rule__EntryWindow__Group_4_0__0__Impl rule__EntryWindow__Group_4_0__1 ;
    public final void rule__EntryWindow__Group_4_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2019:1: ( rule__EntryWindow__Group_4_0__0__Impl rule__EntryWindow__Group_4_0__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2020:2: rule__EntryWindow__Group_4_0__0__Impl rule__EntryWindow__Group_4_0__1
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group_4_0__0__Impl_in_rule__EntryWindow__Group_4_0__04061);
            rule__EntryWindow__Group_4_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__EntryWindow__Group_4_0__1_in_rule__EntryWindow__Group_4_0__04064);
            rule__EntryWindow__Group_4_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group_4_0__0"


    // $ANTLR start "rule__EntryWindow__Group_4_0__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2027:1: rule__EntryWindow__Group_4_0__0__Impl : ( 'title' ) ;
    public final void rule__EntryWindow__Group_4_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2031:1: ( ( 'title' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2032:1: ( 'title' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2032:1: ( 'title' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2033:1: 'title'
            {
             before(grammarAccess.getEntryWindowAccess().getTitleKeyword_4_0_0()); 
            match(input,30,FOLLOW_30_in_rule__EntryWindow__Group_4_0__0__Impl4092); 
             after(grammarAccess.getEntryWindowAccess().getTitleKeyword_4_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group_4_0__0__Impl"


    // $ANTLR start "rule__EntryWindow__Group_4_0__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2046:1: rule__EntryWindow__Group_4_0__1 : rule__EntryWindow__Group_4_0__1__Impl ;
    public final void rule__EntryWindow__Group_4_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2050:1: ( rule__EntryWindow__Group_4_0__1__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2051:2: rule__EntryWindow__Group_4_0__1__Impl
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group_4_0__1__Impl_in_rule__EntryWindow__Group_4_0__14123);
            rule__EntryWindow__Group_4_0__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group_4_0__1"


    // $ANTLR start "rule__EntryWindow__Group_4_0__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2057:1: rule__EntryWindow__Group_4_0__1__Impl : ( ( rule__EntryWindow__TitleAssignment_4_0_1 ) ) ;
    public final void rule__EntryWindow__Group_4_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2061:1: ( ( ( rule__EntryWindow__TitleAssignment_4_0_1 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2062:1: ( ( rule__EntryWindow__TitleAssignment_4_0_1 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2062:1: ( ( rule__EntryWindow__TitleAssignment_4_0_1 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2063:1: ( rule__EntryWindow__TitleAssignment_4_0_1 )
            {
             before(grammarAccess.getEntryWindowAccess().getTitleAssignment_4_0_1()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2064:1: ( rule__EntryWindow__TitleAssignment_4_0_1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2064:2: rule__EntryWindow__TitleAssignment_4_0_1
            {
            pushFollow(FOLLOW_rule__EntryWindow__TitleAssignment_4_0_1_in_rule__EntryWindow__Group_4_0__1__Impl4150);
            rule__EntryWindow__TitleAssignment_4_0_1();

            state._fsp--;


            }

             after(grammarAccess.getEntryWindowAccess().getTitleAssignment_4_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group_4_0__1__Impl"


    // $ANTLR start "rule__Size__Group__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2078:1: rule__Size__Group__0 : rule__Size__Group__0__Impl rule__Size__Group__1 ;
    public final void rule__Size__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2082:1: ( rule__Size__Group__0__Impl rule__Size__Group__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2083:2: rule__Size__Group__0__Impl rule__Size__Group__1
            {
            pushFollow(FOLLOW_rule__Size__Group__0__Impl_in_rule__Size__Group__04184);
            rule__Size__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Size__Group__1_in_rule__Size__Group__04187);
            rule__Size__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__0"


    // $ANTLR start "rule__Size__Group__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2090:1: rule__Size__Group__0__Impl : ( 'size=' ) ;
    public final void rule__Size__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2094:1: ( ( 'size=' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2095:1: ( 'size=' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2095:1: ( 'size=' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2096:1: 'size='
            {
             before(grammarAccess.getSizeAccess().getSizeKeyword_0()); 
            match(input,32,FOLLOW_32_in_rule__Size__Group__0__Impl4215); 
             after(grammarAccess.getSizeAccess().getSizeKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__0__Impl"


    // $ANTLR start "rule__Size__Group__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2109:1: rule__Size__Group__1 : rule__Size__Group__1__Impl rule__Size__Group__2 ;
    public final void rule__Size__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2113:1: ( rule__Size__Group__1__Impl rule__Size__Group__2 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2114:2: rule__Size__Group__1__Impl rule__Size__Group__2
            {
            pushFollow(FOLLOW_rule__Size__Group__1__Impl_in_rule__Size__Group__14246);
            rule__Size__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Size__Group__2_in_rule__Size__Group__14249);
            rule__Size__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__1"


    // $ANTLR start "rule__Size__Group__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2121:1: rule__Size__Group__1__Impl : ( '(' ) ;
    public final void rule__Size__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2125:1: ( ( '(' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2126:1: ( '(' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2126:1: ( '(' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2127:1: '('
            {
             before(grammarAccess.getSizeAccess().getLeftParenthesisKeyword_1()); 
            match(input,33,FOLLOW_33_in_rule__Size__Group__1__Impl4277); 
             after(grammarAccess.getSizeAccess().getLeftParenthesisKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__1__Impl"


    // $ANTLR start "rule__Size__Group__2"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2140:1: rule__Size__Group__2 : rule__Size__Group__2__Impl rule__Size__Group__3 ;
    public final void rule__Size__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2144:1: ( rule__Size__Group__2__Impl rule__Size__Group__3 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2145:2: rule__Size__Group__2__Impl rule__Size__Group__3
            {
            pushFollow(FOLLOW_rule__Size__Group__2__Impl_in_rule__Size__Group__24308);
            rule__Size__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Size__Group__3_in_rule__Size__Group__24311);
            rule__Size__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__2"


    // $ANTLR start "rule__Size__Group__2__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2152:1: rule__Size__Group__2__Impl : ( ( rule__Size__WidthAssignment_2 ) ) ;
    public final void rule__Size__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2156:1: ( ( ( rule__Size__WidthAssignment_2 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2157:1: ( ( rule__Size__WidthAssignment_2 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2157:1: ( ( rule__Size__WidthAssignment_2 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2158:1: ( rule__Size__WidthAssignment_2 )
            {
             before(grammarAccess.getSizeAccess().getWidthAssignment_2()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2159:1: ( rule__Size__WidthAssignment_2 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2159:2: rule__Size__WidthAssignment_2
            {
            pushFollow(FOLLOW_rule__Size__WidthAssignment_2_in_rule__Size__Group__2__Impl4338);
            rule__Size__WidthAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getSizeAccess().getWidthAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__2__Impl"


    // $ANTLR start "rule__Size__Group__3"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2169:1: rule__Size__Group__3 : rule__Size__Group__3__Impl rule__Size__Group__4 ;
    public final void rule__Size__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2173:1: ( rule__Size__Group__3__Impl rule__Size__Group__4 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2174:2: rule__Size__Group__3__Impl rule__Size__Group__4
            {
            pushFollow(FOLLOW_rule__Size__Group__3__Impl_in_rule__Size__Group__34368);
            rule__Size__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Size__Group__4_in_rule__Size__Group__34371);
            rule__Size__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__3"


    // $ANTLR start "rule__Size__Group__3__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2181:1: rule__Size__Group__3__Impl : ( ',' ) ;
    public final void rule__Size__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2185:1: ( ( ',' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2186:1: ( ',' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2186:1: ( ',' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2187:1: ','
            {
             before(grammarAccess.getSizeAccess().getCommaKeyword_3()); 
            match(input,34,FOLLOW_34_in_rule__Size__Group__3__Impl4399); 
             after(grammarAccess.getSizeAccess().getCommaKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__3__Impl"


    // $ANTLR start "rule__Size__Group__4"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2200:1: rule__Size__Group__4 : rule__Size__Group__4__Impl rule__Size__Group__5 ;
    public final void rule__Size__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2204:1: ( rule__Size__Group__4__Impl rule__Size__Group__5 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2205:2: rule__Size__Group__4__Impl rule__Size__Group__5
            {
            pushFollow(FOLLOW_rule__Size__Group__4__Impl_in_rule__Size__Group__44430);
            rule__Size__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Size__Group__5_in_rule__Size__Group__44433);
            rule__Size__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__4"


    // $ANTLR start "rule__Size__Group__4__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2212:1: rule__Size__Group__4__Impl : ( ( rule__Size__HeightAssignment_4 ) ) ;
    public final void rule__Size__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2216:1: ( ( ( rule__Size__HeightAssignment_4 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2217:1: ( ( rule__Size__HeightAssignment_4 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2217:1: ( ( rule__Size__HeightAssignment_4 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2218:1: ( rule__Size__HeightAssignment_4 )
            {
             before(grammarAccess.getSizeAccess().getHeightAssignment_4()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2219:1: ( rule__Size__HeightAssignment_4 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2219:2: rule__Size__HeightAssignment_4
            {
            pushFollow(FOLLOW_rule__Size__HeightAssignment_4_in_rule__Size__Group__4__Impl4460);
            rule__Size__HeightAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getSizeAccess().getHeightAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__4__Impl"


    // $ANTLR start "rule__Size__Group__5"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2229:1: rule__Size__Group__5 : rule__Size__Group__5__Impl ;
    public final void rule__Size__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2233:1: ( rule__Size__Group__5__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2234:2: rule__Size__Group__5__Impl
            {
            pushFollow(FOLLOW_rule__Size__Group__5__Impl_in_rule__Size__Group__54490);
            rule__Size__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__5"


    // $ANTLR start "rule__Size__Group__5__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2240:1: rule__Size__Group__5__Impl : ( ')' ) ;
    public final void rule__Size__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2244:1: ( ( ')' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2245:1: ( ')' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2245:1: ( ')' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2246:1: ')'
            {
             before(grammarAccess.getSizeAccess().getRightParenthesisKeyword_5()); 
            match(input,35,FOLLOW_35_in_rule__Size__Group__5__Impl4518); 
             after(grammarAccess.getSizeAccess().getRightParenthesisKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group__5__Impl"


    // $ANTLR start "rule__Bounds__Group__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2271:1: rule__Bounds__Group__0 : rule__Bounds__Group__0__Impl rule__Bounds__Group__1 ;
    public final void rule__Bounds__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2275:1: ( rule__Bounds__Group__0__Impl rule__Bounds__Group__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2276:2: rule__Bounds__Group__0__Impl rule__Bounds__Group__1
            {
            pushFollow(FOLLOW_rule__Bounds__Group__0__Impl_in_rule__Bounds__Group__04561);
            rule__Bounds__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Bounds__Group__1_in_rule__Bounds__Group__04564);
            rule__Bounds__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__0"


    // $ANTLR start "rule__Bounds__Group__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2283:1: rule__Bounds__Group__0__Impl : ( () ) ;
    public final void rule__Bounds__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2287:1: ( ( () ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2288:1: ( () )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2288:1: ( () )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2289:1: ()
            {
             before(grammarAccess.getBoundsAccess().getBoundsAction_0()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2290:1: ()
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2292:1: 
            {
            }

             after(grammarAccess.getBoundsAccess().getBoundsAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__0__Impl"


    // $ANTLR start "rule__Bounds__Group__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2302:1: rule__Bounds__Group__1 : rule__Bounds__Group__1__Impl rule__Bounds__Group__2 ;
    public final void rule__Bounds__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2306:1: ( rule__Bounds__Group__1__Impl rule__Bounds__Group__2 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2307:2: rule__Bounds__Group__1__Impl rule__Bounds__Group__2
            {
            pushFollow(FOLLOW_rule__Bounds__Group__1__Impl_in_rule__Bounds__Group__14622);
            rule__Bounds__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Bounds__Group__2_in_rule__Bounds__Group__14625);
            rule__Bounds__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__1"


    // $ANTLR start "rule__Bounds__Group__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2314:1: rule__Bounds__Group__1__Impl : ( 'bounds=' ) ;
    public final void rule__Bounds__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2318:1: ( ( 'bounds=' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2319:1: ( 'bounds=' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2319:1: ( 'bounds=' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2320:1: 'bounds='
            {
             before(grammarAccess.getBoundsAccess().getBoundsKeyword_1()); 
            match(input,36,FOLLOW_36_in_rule__Bounds__Group__1__Impl4653); 
             after(grammarAccess.getBoundsAccess().getBoundsKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__1__Impl"


    // $ANTLR start "rule__Bounds__Group__2"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2333:1: rule__Bounds__Group__2 : rule__Bounds__Group__2__Impl rule__Bounds__Group__3 ;
    public final void rule__Bounds__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2337:1: ( rule__Bounds__Group__2__Impl rule__Bounds__Group__3 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2338:2: rule__Bounds__Group__2__Impl rule__Bounds__Group__3
            {
            pushFollow(FOLLOW_rule__Bounds__Group__2__Impl_in_rule__Bounds__Group__24684);
            rule__Bounds__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Bounds__Group__3_in_rule__Bounds__Group__24687);
            rule__Bounds__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__2"


    // $ANTLR start "rule__Bounds__Group__2__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2345:1: rule__Bounds__Group__2__Impl : ( '(' ) ;
    public final void rule__Bounds__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2349:1: ( ( '(' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2350:1: ( '(' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2350:1: ( '(' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2351:1: '('
            {
             before(grammarAccess.getBoundsAccess().getLeftParenthesisKeyword_2()); 
            match(input,33,FOLLOW_33_in_rule__Bounds__Group__2__Impl4715); 
             after(grammarAccess.getBoundsAccess().getLeftParenthesisKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__2__Impl"


    // $ANTLR start "rule__Bounds__Group__3"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2364:1: rule__Bounds__Group__3 : rule__Bounds__Group__3__Impl rule__Bounds__Group__4 ;
    public final void rule__Bounds__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2368:1: ( rule__Bounds__Group__3__Impl rule__Bounds__Group__4 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2369:2: rule__Bounds__Group__3__Impl rule__Bounds__Group__4
            {
            pushFollow(FOLLOW_rule__Bounds__Group__3__Impl_in_rule__Bounds__Group__34746);
            rule__Bounds__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Bounds__Group__4_in_rule__Bounds__Group__34749);
            rule__Bounds__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__3"


    // $ANTLR start "rule__Bounds__Group__3__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2376:1: rule__Bounds__Group__3__Impl : ( ( rule__Bounds__XAssignment_3 ) ) ;
    public final void rule__Bounds__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2380:1: ( ( ( rule__Bounds__XAssignment_3 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2381:1: ( ( rule__Bounds__XAssignment_3 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2381:1: ( ( rule__Bounds__XAssignment_3 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2382:1: ( rule__Bounds__XAssignment_3 )
            {
             before(grammarAccess.getBoundsAccess().getXAssignment_3()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2383:1: ( rule__Bounds__XAssignment_3 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2383:2: rule__Bounds__XAssignment_3
            {
            pushFollow(FOLLOW_rule__Bounds__XAssignment_3_in_rule__Bounds__Group__3__Impl4776);
            rule__Bounds__XAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getBoundsAccess().getXAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__3__Impl"


    // $ANTLR start "rule__Bounds__Group__4"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2393:1: rule__Bounds__Group__4 : rule__Bounds__Group__4__Impl rule__Bounds__Group__5 ;
    public final void rule__Bounds__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2397:1: ( rule__Bounds__Group__4__Impl rule__Bounds__Group__5 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2398:2: rule__Bounds__Group__4__Impl rule__Bounds__Group__5
            {
            pushFollow(FOLLOW_rule__Bounds__Group__4__Impl_in_rule__Bounds__Group__44806);
            rule__Bounds__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Bounds__Group__5_in_rule__Bounds__Group__44809);
            rule__Bounds__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__4"


    // $ANTLR start "rule__Bounds__Group__4__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2405:1: rule__Bounds__Group__4__Impl : ( ',' ) ;
    public final void rule__Bounds__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2409:1: ( ( ',' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2410:1: ( ',' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2410:1: ( ',' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2411:1: ','
            {
             before(grammarAccess.getBoundsAccess().getCommaKeyword_4()); 
            match(input,34,FOLLOW_34_in_rule__Bounds__Group__4__Impl4837); 
             after(grammarAccess.getBoundsAccess().getCommaKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__4__Impl"


    // $ANTLR start "rule__Bounds__Group__5"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2424:1: rule__Bounds__Group__5 : rule__Bounds__Group__5__Impl rule__Bounds__Group__6 ;
    public final void rule__Bounds__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2428:1: ( rule__Bounds__Group__5__Impl rule__Bounds__Group__6 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2429:2: rule__Bounds__Group__5__Impl rule__Bounds__Group__6
            {
            pushFollow(FOLLOW_rule__Bounds__Group__5__Impl_in_rule__Bounds__Group__54868);
            rule__Bounds__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Bounds__Group__6_in_rule__Bounds__Group__54871);
            rule__Bounds__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__5"


    // $ANTLR start "rule__Bounds__Group__5__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2436:1: rule__Bounds__Group__5__Impl : ( ( rule__Bounds__YAssignment_5 ) ) ;
    public final void rule__Bounds__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2440:1: ( ( ( rule__Bounds__YAssignment_5 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2441:1: ( ( rule__Bounds__YAssignment_5 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2441:1: ( ( rule__Bounds__YAssignment_5 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2442:1: ( rule__Bounds__YAssignment_5 )
            {
             before(grammarAccess.getBoundsAccess().getYAssignment_5()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2443:1: ( rule__Bounds__YAssignment_5 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2443:2: rule__Bounds__YAssignment_5
            {
            pushFollow(FOLLOW_rule__Bounds__YAssignment_5_in_rule__Bounds__Group__5__Impl4898);
            rule__Bounds__YAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getBoundsAccess().getYAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__5__Impl"


    // $ANTLR start "rule__Bounds__Group__6"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2453:1: rule__Bounds__Group__6 : rule__Bounds__Group__6__Impl rule__Bounds__Group__7 ;
    public final void rule__Bounds__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2457:1: ( rule__Bounds__Group__6__Impl rule__Bounds__Group__7 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2458:2: rule__Bounds__Group__6__Impl rule__Bounds__Group__7
            {
            pushFollow(FOLLOW_rule__Bounds__Group__6__Impl_in_rule__Bounds__Group__64928);
            rule__Bounds__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Bounds__Group__7_in_rule__Bounds__Group__64931);
            rule__Bounds__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__6"


    // $ANTLR start "rule__Bounds__Group__6__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2465:1: rule__Bounds__Group__6__Impl : ( ',' ) ;
    public final void rule__Bounds__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2469:1: ( ( ',' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2470:1: ( ',' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2470:1: ( ',' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2471:1: ','
            {
             before(grammarAccess.getBoundsAccess().getCommaKeyword_6()); 
            match(input,34,FOLLOW_34_in_rule__Bounds__Group__6__Impl4959); 
             after(grammarAccess.getBoundsAccess().getCommaKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__6__Impl"


    // $ANTLR start "rule__Bounds__Group__7"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2484:1: rule__Bounds__Group__7 : rule__Bounds__Group__7__Impl rule__Bounds__Group__8 ;
    public final void rule__Bounds__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2488:1: ( rule__Bounds__Group__7__Impl rule__Bounds__Group__8 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2489:2: rule__Bounds__Group__7__Impl rule__Bounds__Group__8
            {
            pushFollow(FOLLOW_rule__Bounds__Group__7__Impl_in_rule__Bounds__Group__74990);
            rule__Bounds__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Bounds__Group__8_in_rule__Bounds__Group__74993);
            rule__Bounds__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__7"


    // $ANTLR start "rule__Bounds__Group__7__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2496:1: rule__Bounds__Group__7__Impl : ( ( rule__Bounds__WidthAssignment_7 ) ) ;
    public final void rule__Bounds__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2500:1: ( ( ( rule__Bounds__WidthAssignment_7 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2501:1: ( ( rule__Bounds__WidthAssignment_7 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2501:1: ( ( rule__Bounds__WidthAssignment_7 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2502:1: ( rule__Bounds__WidthAssignment_7 )
            {
             before(grammarAccess.getBoundsAccess().getWidthAssignment_7()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2503:1: ( rule__Bounds__WidthAssignment_7 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2503:2: rule__Bounds__WidthAssignment_7
            {
            pushFollow(FOLLOW_rule__Bounds__WidthAssignment_7_in_rule__Bounds__Group__7__Impl5020);
            rule__Bounds__WidthAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getBoundsAccess().getWidthAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__7__Impl"


    // $ANTLR start "rule__Bounds__Group__8"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2513:1: rule__Bounds__Group__8 : rule__Bounds__Group__8__Impl rule__Bounds__Group__9 ;
    public final void rule__Bounds__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2517:1: ( rule__Bounds__Group__8__Impl rule__Bounds__Group__9 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2518:2: rule__Bounds__Group__8__Impl rule__Bounds__Group__9
            {
            pushFollow(FOLLOW_rule__Bounds__Group__8__Impl_in_rule__Bounds__Group__85050);
            rule__Bounds__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Bounds__Group__9_in_rule__Bounds__Group__85053);
            rule__Bounds__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__8"


    // $ANTLR start "rule__Bounds__Group__8__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2525:1: rule__Bounds__Group__8__Impl : ( ',' ) ;
    public final void rule__Bounds__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2529:1: ( ( ',' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2530:1: ( ',' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2530:1: ( ',' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2531:1: ','
            {
             before(grammarAccess.getBoundsAccess().getCommaKeyword_8()); 
            match(input,34,FOLLOW_34_in_rule__Bounds__Group__8__Impl5081); 
             after(grammarAccess.getBoundsAccess().getCommaKeyword_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__8__Impl"


    // $ANTLR start "rule__Bounds__Group__9"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2544:1: rule__Bounds__Group__9 : rule__Bounds__Group__9__Impl rule__Bounds__Group__10 ;
    public final void rule__Bounds__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2548:1: ( rule__Bounds__Group__9__Impl rule__Bounds__Group__10 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2549:2: rule__Bounds__Group__9__Impl rule__Bounds__Group__10
            {
            pushFollow(FOLLOW_rule__Bounds__Group__9__Impl_in_rule__Bounds__Group__95112);
            rule__Bounds__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Bounds__Group__10_in_rule__Bounds__Group__95115);
            rule__Bounds__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__9"


    // $ANTLR start "rule__Bounds__Group__9__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2556:1: rule__Bounds__Group__9__Impl : ( ( rule__Bounds__HeightAssignment_9 ) ) ;
    public final void rule__Bounds__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2560:1: ( ( ( rule__Bounds__HeightAssignment_9 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2561:1: ( ( rule__Bounds__HeightAssignment_9 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2561:1: ( ( rule__Bounds__HeightAssignment_9 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2562:1: ( rule__Bounds__HeightAssignment_9 )
            {
             before(grammarAccess.getBoundsAccess().getHeightAssignment_9()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2563:1: ( rule__Bounds__HeightAssignment_9 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2563:2: rule__Bounds__HeightAssignment_9
            {
            pushFollow(FOLLOW_rule__Bounds__HeightAssignment_9_in_rule__Bounds__Group__9__Impl5142);
            rule__Bounds__HeightAssignment_9();

            state._fsp--;


            }

             after(grammarAccess.getBoundsAccess().getHeightAssignment_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__9__Impl"


    // $ANTLR start "rule__Bounds__Group__10"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2573:1: rule__Bounds__Group__10 : rule__Bounds__Group__10__Impl ;
    public final void rule__Bounds__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2577:1: ( rule__Bounds__Group__10__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2578:2: rule__Bounds__Group__10__Impl
            {
            pushFollow(FOLLOW_rule__Bounds__Group__10__Impl_in_rule__Bounds__Group__105172);
            rule__Bounds__Group__10__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__10"


    // $ANTLR start "rule__Bounds__Group__10__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2584:1: rule__Bounds__Group__10__Impl : ( ')' ) ;
    public final void rule__Bounds__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2588:1: ( ( ')' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2589:1: ( ')' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2589:1: ( ')' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2590:1: ')'
            {
             before(grammarAccess.getBoundsAccess().getRightParenthesisKeyword_10()); 
            match(input,35,FOLLOW_35_in_rule__Bounds__Group__10__Impl5200); 
             after(grammarAccess.getBoundsAccess().getRightParenthesisKeyword_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__Group__10__Impl"


    // $ANTLR start "rule__UIElement__Group__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2625:1: rule__UIElement__Group__0 : rule__UIElement__Group__0__Impl rule__UIElement__Group__1 ;
    public final void rule__UIElement__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2629:1: ( rule__UIElement__Group__0__Impl rule__UIElement__Group__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2630:2: rule__UIElement__Group__0__Impl rule__UIElement__Group__1
            {
            pushFollow(FOLLOW_rule__UIElement__Group__0__Impl_in_rule__UIElement__Group__05253);
            rule__UIElement__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__UIElement__Group__1_in_rule__UIElement__Group__05256);
            rule__UIElement__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UIElement__Group__0"


    // $ANTLR start "rule__UIElement__Group__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2637:1: rule__UIElement__Group__0__Impl : ( ( rule__UIElement__Alternatives_0 ) ) ;
    public final void rule__UIElement__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2641:1: ( ( ( rule__UIElement__Alternatives_0 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2642:1: ( ( rule__UIElement__Alternatives_0 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2642:1: ( ( rule__UIElement__Alternatives_0 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2643:1: ( rule__UIElement__Alternatives_0 )
            {
             before(grammarAccess.getUIElementAccess().getAlternatives_0()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2644:1: ( rule__UIElement__Alternatives_0 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2644:2: rule__UIElement__Alternatives_0
            {
            pushFollow(FOLLOW_rule__UIElement__Alternatives_0_in_rule__UIElement__Group__0__Impl5283);
            rule__UIElement__Alternatives_0();

            state._fsp--;


            }

             after(grammarAccess.getUIElementAccess().getAlternatives_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UIElement__Group__0__Impl"


    // $ANTLR start "rule__UIElement__Group__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2654:1: rule__UIElement__Group__1 : rule__UIElement__Group__1__Impl ;
    public final void rule__UIElement__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2658:1: ( rule__UIElement__Group__1__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2659:2: rule__UIElement__Group__1__Impl
            {
            pushFollow(FOLLOW_rule__UIElement__Group__1__Impl_in_rule__UIElement__Group__15313);
            rule__UIElement__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UIElement__Group__1"


    // $ANTLR start "rule__UIElement__Group__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2665:1: rule__UIElement__Group__1__Impl : ( ( rule__UIElement__BoundsAssignment_1 ) ) ;
    public final void rule__UIElement__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2669:1: ( ( ( rule__UIElement__BoundsAssignment_1 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2670:1: ( ( rule__UIElement__BoundsAssignment_1 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2670:1: ( ( rule__UIElement__BoundsAssignment_1 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2671:1: ( rule__UIElement__BoundsAssignment_1 )
            {
             before(grammarAccess.getUIElementAccess().getBoundsAssignment_1()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2672:1: ( rule__UIElement__BoundsAssignment_1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2672:2: rule__UIElement__BoundsAssignment_1
            {
            pushFollow(FOLLOW_rule__UIElement__BoundsAssignment_1_in_rule__UIElement__Group__1__Impl5340);
            rule__UIElement__BoundsAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getUIElementAccess().getBoundsAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UIElement__Group__1__Impl"


    // $ANTLR start "rule__Label__Group__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2686:1: rule__Label__Group__0 : rule__Label__Group__0__Impl rule__Label__Group__1 ;
    public final void rule__Label__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2690:1: ( rule__Label__Group__0__Impl rule__Label__Group__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2691:2: rule__Label__Group__0__Impl rule__Label__Group__1
            {
            pushFollow(FOLLOW_rule__Label__Group__0__Impl_in_rule__Label__Group__05374);
            rule__Label__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Label__Group__1_in_rule__Label__Group__05377);
            rule__Label__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__0"


    // $ANTLR start "rule__Label__Group__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2698:1: rule__Label__Group__0__Impl : ( 'Label' ) ;
    public final void rule__Label__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2702:1: ( ( 'Label' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2703:1: ( 'Label' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2703:1: ( 'Label' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2704:1: 'Label'
            {
             before(grammarAccess.getLabelAccess().getLabelKeyword_0()); 
            match(input,37,FOLLOW_37_in_rule__Label__Group__0__Impl5405); 
             after(grammarAccess.getLabelAccess().getLabelKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__0__Impl"


    // $ANTLR start "rule__Label__Group__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2717:1: rule__Label__Group__1 : rule__Label__Group__1__Impl rule__Label__Group__2 ;
    public final void rule__Label__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2721:1: ( rule__Label__Group__1__Impl rule__Label__Group__2 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2722:2: rule__Label__Group__1__Impl rule__Label__Group__2
            {
            pushFollow(FOLLOW_rule__Label__Group__1__Impl_in_rule__Label__Group__15436);
            rule__Label__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Label__Group__2_in_rule__Label__Group__15439);
            rule__Label__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__1"


    // $ANTLR start "rule__Label__Group__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2729:1: rule__Label__Group__1__Impl : ( ( rule__Label__NameAssignment_1 ) ) ;
    public final void rule__Label__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2733:1: ( ( ( rule__Label__NameAssignment_1 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2734:1: ( ( rule__Label__NameAssignment_1 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2734:1: ( ( rule__Label__NameAssignment_1 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2735:1: ( rule__Label__NameAssignment_1 )
            {
             before(grammarAccess.getLabelAccess().getNameAssignment_1()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2736:1: ( rule__Label__NameAssignment_1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2736:2: rule__Label__NameAssignment_1
            {
            pushFollow(FOLLOW_rule__Label__NameAssignment_1_in_rule__Label__Group__1__Impl5466);
            rule__Label__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getLabelAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__1__Impl"


    // $ANTLR start "rule__Label__Group__2"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2746:1: rule__Label__Group__2 : rule__Label__Group__2__Impl ;
    public final void rule__Label__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2750:1: ( rule__Label__Group__2__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2751:2: rule__Label__Group__2__Impl
            {
            pushFollow(FOLLOW_rule__Label__Group__2__Impl_in_rule__Label__Group__25496);
            rule__Label__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__2"


    // $ANTLR start "rule__Label__Group__2__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2757:1: rule__Label__Group__2__Impl : ( ( rule__Label__Group_2__0 )? ) ;
    public final void rule__Label__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2761:1: ( ( ( rule__Label__Group_2__0 )? ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2762:1: ( ( rule__Label__Group_2__0 )? )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2762:1: ( ( rule__Label__Group_2__0 )? )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2763:1: ( rule__Label__Group_2__0 )?
            {
             before(grammarAccess.getLabelAccess().getGroup_2()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2764:1: ( rule__Label__Group_2__0 )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==33) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2764:2: rule__Label__Group_2__0
                    {
                    pushFollow(FOLLOW_rule__Label__Group_2__0_in_rule__Label__Group__2__Impl5523);
                    rule__Label__Group_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getLabelAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__2__Impl"


    // $ANTLR start "rule__Label__Group_2__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2780:1: rule__Label__Group_2__0 : rule__Label__Group_2__0__Impl rule__Label__Group_2__1 ;
    public final void rule__Label__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2784:1: ( rule__Label__Group_2__0__Impl rule__Label__Group_2__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2785:2: rule__Label__Group_2__0__Impl rule__Label__Group_2__1
            {
            pushFollow(FOLLOW_rule__Label__Group_2__0__Impl_in_rule__Label__Group_2__05560);
            rule__Label__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Label__Group_2__1_in_rule__Label__Group_2__05563);
            rule__Label__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group_2__0"


    // $ANTLR start "rule__Label__Group_2__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2792:1: rule__Label__Group_2__0__Impl : ( '(' ) ;
    public final void rule__Label__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2796:1: ( ( '(' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2797:1: ( '(' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2797:1: ( '(' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2798:1: '('
            {
             before(grammarAccess.getLabelAccess().getLeftParenthesisKeyword_2_0()); 
            match(input,33,FOLLOW_33_in_rule__Label__Group_2__0__Impl5591); 
             after(grammarAccess.getLabelAccess().getLeftParenthesisKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group_2__0__Impl"


    // $ANTLR start "rule__Label__Group_2__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2811:1: rule__Label__Group_2__1 : rule__Label__Group_2__1__Impl rule__Label__Group_2__2 ;
    public final void rule__Label__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2815:1: ( rule__Label__Group_2__1__Impl rule__Label__Group_2__2 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2816:2: rule__Label__Group_2__1__Impl rule__Label__Group_2__2
            {
            pushFollow(FOLLOW_rule__Label__Group_2__1__Impl_in_rule__Label__Group_2__15622);
            rule__Label__Group_2__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Label__Group_2__2_in_rule__Label__Group_2__15625);
            rule__Label__Group_2__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group_2__1"


    // $ANTLR start "rule__Label__Group_2__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2823:1: rule__Label__Group_2__1__Impl : ( ( rule__Label__TextAssignment_2_1 )? ) ;
    public final void rule__Label__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2827:1: ( ( ( rule__Label__TextAssignment_2_1 )? ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2828:1: ( ( rule__Label__TextAssignment_2_1 )? )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2828:1: ( ( rule__Label__TextAssignment_2_1 )? )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2829:1: ( rule__Label__TextAssignment_2_1 )?
            {
             before(grammarAccess.getLabelAccess().getTextAssignment_2_1()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2830:1: ( rule__Label__TextAssignment_2_1 )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==RULE_STRING) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2830:2: rule__Label__TextAssignment_2_1
                    {
                    pushFollow(FOLLOW_rule__Label__TextAssignment_2_1_in_rule__Label__Group_2__1__Impl5652);
                    rule__Label__TextAssignment_2_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getLabelAccess().getTextAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group_2__1__Impl"


    // $ANTLR start "rule__Label__Group_2__2"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2840:1: rule__Label__Group_2__2 : rule__Label__Group_2__2__Impl ;
    public final void rule__Label__Group_2__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2844:1: ( rule__Label__Group_2__2__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2845:2: rule__Label__Group_2__2__Impl
            {
            pushFollow(FOLLOW_rule__Label__Group_2__2__Impl_in_rule__Label__Group_2__25683);
            rule__Label__Group_2__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group_2__2"


    // $ANTLR start "rule__Label__Group_2__2__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2851:1: rule__Label__Group_2__2__Impl : ( ')' ) ;
    public final void rule__Label__Group_2__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2855:1: ( ( ')' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2856:1: ( ')' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2856:1: ( ')' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2857:1: ')'
            {
             before(grammarAccess.getLabelAccess().getRightParenthesisKeyword_2_2()); 
            match(input,35,FOLLOW_35_in_rule__Label__Group_2__2__Impl5711); 
             after(grammarAccess.getLabelAccess().getRightParenthesisKeyword_2_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group_2__2__Impl"


    // $ANTLR start "rule__Field__Group__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2876:1: rule__Field__Group__0 : rule__Field__Group__0__Impl rule__Field__Group__1 ;
    public final void rule__Field__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2880:1: ( rule__Field__Group__0__Impl rule__Field__Group__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2881:2: rule__Field__Group__0__Impl rule__Field__Group__1
            {
            pushFollow(FOLLOW_rule__Field__Group__0__Impl_in_rule__Field__Group__05748);
            rule__Field__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Field__Group__1_in_rule__Field__Group__05751);
            rule__Field__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group__0"


    // $ANTLR start "rule__Field__Group__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2888:1: rule__Field__Group__0__Impl : ( 'Field' ) ;
    public final void rule__Field__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2892:1: ( ( 'Field' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2893:1: ( 'Field' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2893:1: ( 'Field' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2894:1: 'Field'
            {
             before(grammarAccess.getFieldAccess().getFieldKeyword_0()); 
            match(input,38,FOLLOW_38_in_rule__Field__Group__0__Impl5779); 
             after(grammarAccess.getFieldAccess().getFieldKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group__0__Impl"


    // $ANTLR start "rule__Field__Group__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2907:1: rule__Field__Group__1 : rule__Field__Group__1__Impl rule__Field__Group__2 ;
    public final void rule__Field__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2911:1: ( rule__Field__Group__1__Impl rule__Field__Group__2 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2912:2: rule__Field__Group__1__Impl rule__Field__Group__2
            {
            pushFollow(FOLLOW_rule__Field__Group__1__Impl_in_rule__Field__Group__15810);
            rule__Field__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Field__Group__2_in_rule__Field__Group__15813);
            rule__Field__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group__1"


    // $ANTLR start "rule__Field__Group__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2919:1: rule__Field__Group__1__Impl : ( ( rule__Field__NameAssignment_1 ) ) ;
    public final void rule__Field__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2923:1: ( ( ( rule__Field__NameAssignment_1 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2924:1: ( ( rule__Field__NameAssignment_1 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2924:1: ( ( rule__Field__NameAssignment_1 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2925:1: ( rule__Field__NameAssignment_1 )
            {
             before(grammarAccess.getFieldAccess().getNameAssignment_1()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2926:1: ( rule__Field__NameAssignment_1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2926:2: rule__Field__NameAssignment_1
            {
            pushFollow(FOLLOW_rule__Field__NameAssignment_1_in_rule__Field__Group__1__Impl5840);
            rule__Field__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group__1__Impl"


    // $ANTLR start "rule__Field__Group__2"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2936:1: rule__Field__Group__2 : rule__Field__Group__2__Impl rule__Field__Group__3 ;
    public final void rule__Field__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2940:1: ( rule__Field__Group__2__Impl rule__Field__Group__3 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2941:2: rule__Field__Group__2__Impl rule__Field__Group__3
            {
            pushFollow(FOLLOW_rule__Field__Group__2__Impl_in_rule__Field__Group__25870);
            rule__Field__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Field__Group__3_in_rule__Field__Group__25873);
            rule__Field__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group__2"


    // $ANTLR start "rule__Field__Group__2__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2948:1: rule__Field__Group__2__Impl : ( 'for' ) ;
    public final void rule__Field__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2952:1: ( ( 'for' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2953:1: ( 'for' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2953:1: ( 'for' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2954:1: 'for'
            {
             before(grammarAccess.getFieldAccess().getForKeyword_2()); 
            match(input,29,FOLLOW_29_in_rule__Field__Group__2__Impl5901); 
             after(grammarAccess.getFieldAccess().getForKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group__2__Impl"


    // $ANTLR start "rule__Field__Group__3"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2967:1: rule__Field__Group__3 : rule__Field__Group__3__Impl ;
    public final void rule__Field__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2971:1: ( rule__Field__Group__3__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2972:2: rule__Field__Group__3__Impl
            {
            pushFollow(FOLLOW_rule__Field__Group__3__Impl_in_rule__Field__Group__35932);
            rule__Field__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group__3"


    // $ANTLR start "rule__Field__Group__3__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2978:1: rule__Field__Group__3__Impl : ( ( rule__Field__PropertyAssignment_3 ) ) ;
    public final void rule__Field__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2982:1: ( ( ( rule__Field__PropertyAssignment_3 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2983:1: ( ( rule__Field__PropertyAssignment_3 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2983:1: ( ( rule__Field__PropertyAssignment_3 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2984:1: ( rule__Field__PropertyAssignment_3 )
            {
             before(grammarAccess.getFieldAccess().getPropertyAssignment_3()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2985:1: ( rule__Field__PropertyAssignment_3 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:2985:2: rule__Field__PropertyAssignment_3
            {
            pushFollow(FOLLOW_rule__Field__PropertyAssignment_3_in_rule__Field__Group__3__Impl5959);
            rule__Field__PropertyAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getPropertyAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group__3__Impl"


    // $ANTLR start "rule__Button__Group__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3003:1: rule__Button__Group__0 : rule__Button__Group__0__Impl rule__Button__Group__1 ;
    public final void rule__Button__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3007:1: ( rule__Button__Group__0__Impl rule__Button__Group__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3008:2: rule__Button__Group__0__Impl rule__Button__Group__1
            {
            pushFollow(FOLLOW_rule__Button__Group__0__Impl_in_rule__Button__Group__05997);
            rule__Button__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Button__Group__1_in_rule__Button__Group__06000);
            rule__Button__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__0"


    // $ANTLR start "rule__Button__Group__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3015:1: rule__Button__Group__0__Impl : ( 'Button' ) ;
    public final void rule__Button__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3019:1: ( ( 'Button' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3020:1: ( 'Button' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3020:1: ( 'Button' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3021:1: 'Button'
            {
             before(grammarAccess.getButtonAccess().getButtonKeyword_0()); 
            match(input,39,FOLLOW_39_in_rule__Button__Group__0__Impl6028); 
             after(grammarAccess.getButtonAccess().getButtonKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__0__Impl"


    // $ANTLR start "rule__Button__Group__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3034:1: rule__Button__Group__1 : rule__Button__Group__1__Impl rule__Button__Group__2 ;
    public final void rule__Button__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3038:1: ( rule__Button__Group__1__Impl rule__Button__Group__2 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3039:2: rule__Button__Group__1__Impl rule__Button__Group__2
            {
            pushFollow(FOLLOW_rule__Button__Group__1__Impl_in_rule__Button__Group__16059);
            rule__Button__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Button__Group__2_in_rule__Button__Group__16062);
            rule__Button__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__1"


    // $ANTLR start "rule__Button__Group__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3046:1: rule__Button__Group__1__Impl : ( ( rule__Button__NameAssignment_1 ) ) ;
    public final void rule__Button__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3050:1: ( ( ( rule__Button__NameAssignment_1 ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3051:1: ( ( rule__Button__NameAssignment_1 ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3051:1: ( ( rule__Button__NameAssignment_1 ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3052:1: ( rule__Button__NameAssignment_1 )
            {
             before(grammarAccess.getButtonAccess().getNameAssignment_1()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3053:1: ( rule__Button__NameAssignment_1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3053:2: rule__Button__NameAssignment_1
            {
            pushFollow(FOLLOW_rule__Button__NameAssignment_1_in_rule__Button__Group__1__Impl6089);
            rule__Button__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getButtonAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__1__Impl"


    // $ANTLR start "rule__Button__Group__2"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3063:1: rule__Button__Group__2 : rule__Button__Group__2__Impl rule__Button__Group__3 ;
    public final void rule__Button__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3067:1: ( rule__Button__Group__2__Impl rule__Button__Group__3 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3068:2: rule__Button__Group__2__Impl rule__Button__Group__3
            {
            pushFollow(FOLLOW_rule__Button__Group__2__Impl_in_rule__Button__Group__26119);
            rule__Button__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Button__Group__3_in_rule__Button__Group__26122);
            rule__Button__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__2"


    // $ANTLR start "rule__Button__Group__2__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3075:1: rule__Button__Group__2__Impl : ( ( rule__Button__KindAssignment_2 )? ) ;
    public final void rule__Button__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3079:1: ( ( ( rule__Button__KindAssignment_2 )? ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3080:1: ( ( rule__Button__KindAssignment_2 )? )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3080:1: ( ( rule__Button__KindAssignment_2 )? )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3081:1: ( rule__Button__KindAssignment_2 )?
            {
             before(grammarAccess.getButtonAccess().getKindAssignment_2()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3082:1: ( rule__Button__KindAssignment_2 )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( ((LA18_0>=16 && LA18_0<=18)) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3082:2: rule__Button__KindAssignment_2
                    {
                    pushFollow(FOLLOW_rule__Button__KindAssignment_2_in_rule__Button__Group__2__Impl6149);
                    rule__Button__KindAssignment_2();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getButtonAccess().getKindAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__2__Impl"


    // $ANTLR start "rule__Button__Group__3"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3092:1: rule__Button__Group__3 : rule__Button__Group__3__Impl ;
    public final void rule__Button__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3096:1: ( rule__Button__Group__3__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3097:2: rule__Button__Group__3__Impl
            {
            pushFollow(FOLLOW_rule__Button__Group__3__Impl_in_rule__Button__Group__36180);
            rule__Button__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__3"


    // $ANTLR start "rule__Button__Group__3__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3103:1: rule__Button__Group__3__Impl : ( ( rule__Button__Group_3__0 )? ) ;
    public final void rule__Button__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3107:1: ( ( ( rule__Button__Group_3__0 )? ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3108:1: ( ( rule__Button__Group_3__0 )? )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3108:1: ( ( rule__Button__Group_3__0 )? )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3109:1: ( rule__Button__Group_3__0 )?
            {
             before(grammarAccess.getButtonAccess().getGroup_3()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3110:1: ( rule__Button__Group_3__0 )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==33) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3110:2: rule__Button__Group_3__0
                    {
                    pushFollow(FOLLOW_rule__Button__Group_3__0_in_rule__Button__Group__3__Impl6207);
                    rule__Button__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getButtonAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__3__Impl"


    // $ANTLR start "rule__Button__Group_3__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3128:1: rule__Button__Group_3__0 : rule__Button__Group_3__0__Impl rule__Button__Group_3__1 ;
    public final void rule__Button__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3132:1: ( rule__Button__Group_3__0__Impl rule__Button__Group_3__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3133:2: rule__Button__Group_3__0__Impl rule__Button__Group_3__1
            {
            pushFollow(FOLLOW_rule__Button__Group_3__0__Impl_in_rule__Button__Group_3__06246);
            rule__Button__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Button__Group_3__1_in_rule__Button__Group_3__06249);
            rule__Button__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group_3__0"


    // $ANTLR start "rule__Button__Group_3__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3140:1: rule__Button__Group_3__0__Impl : ( '(' ) ;
    public final void rule__Button__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3144:1: ( ( '(' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3145:1: ( '(' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3145:1: ( '(' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3146:1: '('
            {
             before(grammarAccess.getButtonAccess().getLeftParenthesisKeyword_3_0()); 
            match(input,33,FOLLOW_33_in_rule__Button__Group_3__0__Impl6277); 
             after(grammarAccess.getButtonAccess().getLeftParenthesisKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group_3__0__Impl"


    // $ANTLR start "rule__Button__Group_3__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3159:1: rule__Button__Group_3__1 : rule__Button__Group_3__1__Impl rule__Button__Group_3__2 ;
    public final void rule__Button__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3163:1: ( rule__Button__Group_3__1__Impl rule__Button__Group_3__2 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3164:2: rule__Button__Group_3__1__Impl rule__Button__Group_3__2
            {
            pushFollow(FOLLOW_rule__Button__Group_3__1__Impl_in_rule__Button__Group_3__16308);
            rule__Button__Group_3__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Button__Group_3__2_in_rule__Button__Group_3__16311);
            rule__Button__Group_3__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group_3__1"


    // $ANTLR start "rule__Button__Group_3__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3171:1: rule__Button__Group_3__1__Impl : ( ( rule__Button__TextAssignment_3_1 )? ) ;
    public final void rule__Button__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3175:1: ( ( ( rule__Button__TextAssignment_3_1 )? ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3176:1: ( ( rule__Button__TextAssignment_3_1 )? )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3176:1: ( ( rule__Button__TextAssignment_3_1 )? )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3177:1: ( rule__Button__TextAssignment_3_1 )?
            {
             before(grammarAccess.getButtonAccess().getTextAssignment_3_1()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3178:1: ( rule__Button__TextAssignment_3_1 )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==RULE_STRING) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3178:2: rule__Button__TextAssignment_3_1
                    {
                    pushFollow(FOLLOW_rule__Button__TextAssignment_3_1_in_rule__Button__Group_3__1__Impl6338);
                    rule__Button__TextAssignment_3_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getButtonAccess().getTextAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group_3__1__Impl"


    // $ANTLR start "rule__Button__Group_3__2"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3188:1: rule__Button__Group_3__2 : rule__Button__Group_3__2__Impl ;
    public final void rule__Button__Group_3__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3192:1: ( rule__Button__Group_3__2__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3193:2: rule__Button__Group_3__2__Impl
            {
            pushFollow(FOLLOW_rule__Button__Group_3__2__Impl_in_rule__Button__Group_3__26369);
            rule__Button__Group_3__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group_3__2"


    // $ANTLR start "rule__Button__Group_3__2__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3199:1: rule__Button__Group_3__2__Impl : ( ')' ) ;
    public final void rule__Button__Group_3__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3203:1: ( ( ')' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3204:1: ( ')' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3204:1: ( ')' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3205:1: ')'
            {
             before(grammarAccess.getButtonAccess().getRightParenthesisKeyword_3_2()); 
            match(input,35,FOLLOW_35_in_rule__Button__Group_3__2__Impl6397); 
             after(grammarAccess.getButtonAccess().getRightParenthesisKeyword_3_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group_3__2__Impl"


    // $ANTLR start "rule__QualifiedName__Group__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3224:1: rule__QualifiedName__Group__0 : rule__QualifiedName__Group__0__Impl rule__QualifiedName__Group__1 ;
    public final void rule__QualifiedName__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3228:1: ( rule__QualifiedName__Group__0__Impl rule__QualifiedName__Group__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3229:2: rule__QualifiedName__Group__0__Impl rule__QualifiedName__Group__1
            {
            pushFollow(FOLLOW_rule__QualifiedName__Group__0__Impl_in_rule__QualifiedName__Group__06434);
            rule__QualifiedName__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__QualifiedName__Group__1_in_rule__QualifiedName__Group__06437);
            rule__QualifiedName__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group__0"


    // $ANTLR start "rule__QualifiedName__Group__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3236:1: rule__QualifiedName__Group__0__Impl : ( RULE_ID ) ;
    public final void rule__QualifiedName__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3240:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3241:1: ( RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3241:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3242:1: RULE_ID
            {
             before(grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__QualifiedName__Group__0__Impl6464); 
             after(grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group__0__Impl"


    // $ANTLR start "rule__QualifiedName__Group__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3253:1: rule__QualifiedName__Group__1 : rule__QualifiedName__Group__1__Impl ;
    public final void rule__QualifiedName__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3257:1: ( rule__QualifiedName__Group__1__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3258:2: rule__QualifiedName__Group__1__Impl
            {
            pushFollow(FOLLOW_rule__QualifiedName__Group__1__Impl_in_rule__QualifiedName__Group__16493);
            rule__QualifiedName__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group__1"


    // $ANTLR start "rule__QualifiedName__Group__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3264:1: rule__QualifiedName__Group__1__Impl : ( ( rule__QualifiedName__Group_1__0 )* ) ;
    public final void rule__QualifiedName__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3268:1: ( ( ( rule__QualifiedName__Group_1__0 )* ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3269:1: ( ( rule__QualifiedName__Group_1__0 )* )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3269:1: ( ( rule__QualifiedName__Group_1__0 )* )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3270:1: ( rule__QualifiedName__Group_1__0 )*
            {
             before(grammarAccess.getQualifiedNameAccess().getGroup_1()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3271:1: ( rule__QualifiedName__Group_1__0 )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( (LA21_0==40) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3271:2: rule__QualifiedName__Group_1__0
            	    {
            	    pushFollow(FOLLOW_rule__QualifiedName__Group_1__0_in_rule__QualifiedName__Group__1__Impl6520);
            	    rule__QualifiedName__Group_1__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);

             after(grammarAccess.getQualifiedNameAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group__1__Impl"


    // $ANTLR start "rule__QualifiedName__Group_1__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3285:1: rule__QualifiedName__Group_1__0 : rule__QualifiedName__Group_1__0__Impl rule__QualifiedName__Group_1__1 ;
    public final void rule__QualifiedName__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3289:1: ( rule__QualifiedName__Group_1__0__Impl rule__QualifiedName__Group_1__1 )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3290:2: rule__QualifiedName__Group_1__0__Impl rule__QualifiedName__Group_1__1
            {
            pushFollow(FOLLOW_rule__QualifiedName__Group_1__0__Impl_in_rule__QualifiedName__Group_1__06555);
            rule__QualifiedName__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__QualifiedName__Group_1__1_in_rule__QualifiedName__Group_1__06558);
            rule__QualifiedName__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group_1__0"


    // $ANTLR start "rule__QualifiedName__Group_1__0__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3297:1: rule__QualifiedName__Group_1__0__Impl : ( '.' ) ;
    public final void rule__QualifiedName__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3301:1: ( ( '.' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3302:1: ( '.' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3302:1: ( '.' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3303:1: '.'
            {
             before(grammarAccess.getQualifiedNameAccess().getFullStopKeyword_1_0()); 
            match(input,40,FOLLOW_40_in_rule__QualifiedName__Group_1__0__Impl6586); 
             after(grammarAccess.getQualifiedNameAccess().getFullStopKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group_1__0__Impl"


    // $ANTLR start "rule__QualifiedName__Group_1__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3316:1: rule__QualifiedName__Group_1__1 : rule__QualifiedName__Group_1__1__Impl ;
    public final void rule__QualifiedName__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3320:1: ( rule__QualifiedName__Group_1__1__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3321:2: rule__QualifiedName__Group_1__1__Impl
            {
            pushFollow(FOLLOW_rule__QualifiedName__Group_1__1__Impl_in_rule__QualifiedName__Group_1__16617);
            rule__QualifiedName__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group_1__1"


    // $ANTLR start "rule__QualifiedName__Group_1__1__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3327:1: rule__QualifiedName__Group_1__1__Impl : ( RULE_ID ) ;
    public final void rule__QualifiedName__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3331:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3332:1: ( RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3332:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3333:1: RULE_ID
            {
             before(grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_1_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__QualifiedName__Group_1__1__Impl6644); 
             after(grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group_1__1__Impl"


    // $ANTLR start "rule__EntryWindow__UnorderedGroup_4"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3349:1: rule__EntryWindow__UnorderedGroup_4 : rule__EntryWindow__UnorderedGroup_4__0 {...}?;
    public final void rule__EntryWindow__UnorderedGroup_4() throws RecognitionException {

            	int stackSize = keepStackSize();
        		getUnorderedGroupHelper().enter(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4());
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3354:1: ( rule__EntryWindow__UnorderedGroup_4__0 {...}?)
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3355:2: rule__EntryWindow__UnorderedGroup_4__0 {...}?
            {
            pushFollow(FOLLOW_rule__EntryWindow__UnorderedGroup_4__0_in_rule__EntryWindow__UnorderedGroup_46678);
            rule__EntryWindow__UnorderedGroup_4__0();

            state._fsp--;

            if ( ! getUnorderedGroupHelper().canLeave(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4()) ) {
                throw new FailedPredicateException(input, "rule__EntryWindow__UnorderedGroup_4", "getUnorderedGroupHelper().canLeave(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4())");
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	getUnorderedGroupHelper().leave(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4());
            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__UnorderedGroup_4"


    // $ANTLR start "rule__EntryWindow__UnorderedGroup_4__Impl"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3366:1: rule__EntryWindow__UnorderedGroup_4__Impl : ( ({...}? => ( ( ( rule__EntryWindow__Group_4_0__0 ) ) ) ) | ({...}? => ( ( ( rule__EntryWindow__SizeAssignment_4_1 ) ) ) ) ) ;
    public final void rule__EntryWindow__UnorderedGroup_4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        		boolean selected = false;
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3371:1: ( ( ({...}? => ( ( ( rule__EntryWindow__Group_4_0__0 ) ) ) ) | ({...}? => ( ( ( rule__EntryWindow__SizeAssignment_4_1 ) ) ) ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3372:3: ( ({...}? => ( ( ( rule__EntryWindow__Group_4_0__0 ) ) ) ) | ({...}? => ( ( ( rule__EntryWindow__SizeAssignment_4_1 ) ) ) ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3372:3: ( ({...}? => ( ( ( rule__EntryWindow__Group_4_0__0 ) ) ) ) | ({...}? => ( ( ( rule__EntryWindow__SizeAssignment_4_1 ) ) ) ) )
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( LA22_0 ==30 && getUnorderedGroupHelper().canSelect(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4(), 0) ) {
                alt22=1;
            }
            else if ( LA22_0 ==32 && getUnorderedGroupHelper().canSelect(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4(), 1) ) {
                alt22=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 22, 0, input);

                throw nvae;
            }
            switch (alt22) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3374:4: ({...}? => ( ( ( rule__EntryWindow__Group_4_0__0 ) ) ) )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3374:4: ({...}? => ( ( ( rule__EntryWindow__Group_4_0__0 ) ) ) )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3375:5: {...}? => ( ( ( rule__EntryWindow__Group_4_0__0 ) ) )
                    {
                    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4(), 0) ) {
                        throw new FailedPredicateException(input, "rule__EntryWindow__UnorderedGroup_4__Impl", "getUnorderedGroupHelper().canSelect(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4(), 0)");
                    }
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3375:108: ( ( ( rule__EntryWindow__Group_4_0__0 ) ) )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3376:6: ( ( rule__EntryWindow__Group_4_0__0 ) )
                    {
                     
                    	 				  getUnorderedGroupHelper().select(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4(), 0);
                    	 				

                    	 				  selected = true;
                    	 				
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3382:6: ( ( rule__EntryWindow__Group_4_0__0 ) )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3384:7: ( rule__EntryWindow__Group_4_0__0 )
                    {
                     before(grammarAccess.getEntryWindowAccess().getGroup_4_0()); 
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3385:7: ( rule__EntryWindow__Group_4_0__0 )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3385:8: rule__EntryWindow__Group_4_0__0
                    {
                    pushFollow(FOLLOW_rule__EntryWindow__Group_4_0__0_in_rule__EntryWindow__UnorderedGroup_4__Impl6767);
                    rule__EntryWindow__Group_4_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getEntryWindowAccess().getGroup_4_0()); 

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3391:4: ({...}? => ( ( ( rule__EntryWindow__SizeAssignment_4_1 ) ) ) )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3391:4: ({...}? => ( ( ( rule__EntryWindow__SizeAssignment_4_1 ) ) ) )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3392:5: {...}? => ( ( ( rule__EntryWindow__SizeAssignment_4_1 ) ) )
                    {
                    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4(), 1) ) {
                        throw new FailedPredicateException(input, "rule__EntryWindow__UnorderedGroup_4__Impl", "getUnorderedGroupHelper().canSelect(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4(), 1)");
                    }
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3392:108: ( ( ( rule__EntryWindow__SizeAssignment_4_1 ) ) )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3393:6: ( ( rule__EntryWindow__SizeAssignment_4_1 ) )
                    {
                     
                    	 				  getUnorderedGroupHelper().select(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4(), 1);
                    	 				

                    	 				  selected = true;
                    	 				
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3399:6: ( ( rule__EntryWindow__SizeAssignment_4_1 ) )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3401:7: ( rule__EntryWindow__SizeAssignment_4_1 )
                    {
                     before(grammarAccess.getEntryWindowAccess().getSizeAssignment_4_1()); 
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3402:7: ( rule__EntryWindow__SizeAssignment_4_1 )
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3402:8: rule__EntryWindow__SizeAssignment_4_1
                    {
                    pushFollow(FOLLOW_rule__EntryWindow__SizeAssignment_4_1_in_rule__EntryWindow__UnorderedGroup_4__Impl6858);
                    rule__EntryWindow__SizeAssignment_4_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getEntryWindowAccess().getSizeAssignment_4_1()); 

                    }


                    }


                    }


                    }
                    break;

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	if (selected)
            		getUnorderedGroupHelper().returnFromSelection(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4());
            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__UnorderedGroup_4__Impl"


    // $ANTLR start "rule__EntryWindow__UnorderedGroup_4__0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3417:1: rule__EntryWindow__UnorderedGroup_4__0 : rule__EntryWindow__UnorderedGroup_4__Impl ( rule__EntryWindow__UnorderedGroup_4__1 )? ;
    public final void rule__EntryWindow__UnorderedGroup_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3421:1: ( rule__EntryWindow__UnorderedGroup_4__Impl ( rule__EntryWindow__UnorderedGroup_4__1 )? )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3422:2: rule__EntryWindow__UnorderedGroup_4__Impl ( rule__EntryWindow__UnorderedGroup_4__1 )?
            {
            pushFollow(FOLLOW_rule__EntryWindow__UnorderedGroup_4__Impl_in_rule__EntryWindow__UnorderedGroup_4__06917);
            rule__EntryWindow__UnorderedGroup_4__Impl();

            state._fsp--;

            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3423:2: ( rule__EntryWindow__UnorderedGroup_4__1 )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( LA23_0 ==30 && getUnorderedGroupHelper().canSelect(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4(), 0) ) {
                alt23=1;
            }
            else if ( LA23_0 ==32 && getUnorderedGroupHelper().canSelect(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4(), 1) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3423:2: rule__EntryWindow__UnorderedGroup_4__1
                    {
                    pushFollow(FOLLOW_rule__EntryWindow__UnorderedGroup_4__1_in_rule__EntryWindow__UnorderedGroup_4__06920);
                    rule__EntryWindow__UnorderedGroup_4__1();

                    state._fsp--;


                    }
                    break;

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__UnorderedGroup_4__0"


    // $ANTLR start "rule__EntryWindow__UnorderedGroup_4__1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3430:1: rule__EntryWindow__UnorderedGroup_4__1 : rule__EntryWindow__UnorderedGroup_4__Impl ;
    public final void rule__EntryWindow__UnorderedGroup_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3434:1: ( rule__EntryWindow__UnorderedGroup_4__Impl )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3435:2: rule__EntryWindow__UnorderedGroup_4__Impl
            {
            pushFollow(FOLLOW_rule__EntryWindow__UnorderedGroup_4__Impl_in_rule__EntryWindow__UnorderedGroup_4__16945);
            rule__EntryWindow__UnorderedGroup_4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__UnorderedGroup_4__1"


    // $ANTLR start "rule__CrudModel__NameAssignment_1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3446:1: rule__CrudModel__NameAssignment_1 : ( ruleQualifiedName ) ;
    public final void rule__CrudModel__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3450:1: ( ( ruleQualifiedName ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3451:1: ( ruleQualifiedName )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3451:1: ( ruleQualifiedName )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3452:1: ruleQualifiedName
            {
             before(grammarAccess.getCrudModelAccess().getNameQualifiedNameParserRuleCall_1_0()); 
            pushFollow(FOLLOW_ruleQualifiedName_in_rule__CrudModel__NameAssignment_16977);
            ruleQualifiedName();

            state._fsp--;

             after(grammarAccess.getCrudModelAccess().getNameQualifiedNameParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CrudModel__NameAssignment_1"


    // $ANTLR start "rule__CrudModel__EntitiesAssignment_2_0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3461:1: rule__CrudModel__EntitiesAssignment_2_0 : ( ruleEntity ) ;
    public final void rule__CrudModel__EntitiesAssignment_2_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3465:1: ( ( ruleEntity ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3466:1: ( ruleEntity )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3466:1: ( ruleEntity )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3467:1: ruleEntity
            {
             before(grammarAccess.getCrudModelAccess().getEntitiesEntityParserRuleCall_2_0_0()); 
            pushFollow(FOLLOW_ruleEntity_in_rule__CrudModel__EntitiesAssignment_2_07008);
            ruleEntity();

            state._fsp--;

             after(grammarAccess.getCrudModelAccess().getEntitiesEntityParserRuleCall_2_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CrudModel__EntitiesAssignment_2_0"


    // $ANTLR start "rule__CrudModel__WindowsAssignment_2_1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3476:1: rule__CrudModel__WindowsAssignment_2_1 : ( ruleWindow ) ;
    public final void rule__CrudModel__WindowsAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3480:1: ( ( ruleWindow ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3481:1: ( ruleWindow )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3481:1: ( ruleWindow )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3482:1: ruleWindow
            {
             before(grammarAccess.getCrudModelAccess().getWindowsWindowParserRuleCall_2_1_0()); 
            pushFollow(FOLLOW_ruleWindow_in_rule__CrudModel__WindowsAssignment_2_17039);
            ruleWindow();

            state._fsp--;

             after(grammarAccess.getCrudModelAccess().getWindowsWindowParserRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CrudModel__WindowsAssignment_2_1"


    // $ANTLR start "rule__Entity__AbstractAssignment_0"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3491:1: rule__Entity__AbstractAssignment_0 : ( ( 'abstract' ) ) ;
    public final void rule__Entity__AbstractAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3495:1: ( ( ( 'abstract' ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3496:1: ( ( 'abstract' ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3496:1: ( ( 'abstract' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3497:1: ( 'abstract' )
            {
             before(grammarAccess.getEntityAccess().getAbstractAbstractKeyword_0_0()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3498:1: ( 'abstract' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3499:1: 'abstract'
            {
             before(grammarAccess.getEntityAccess().getAbstractAbstractKeyword_0_0()); 
            match(input,41,FOLLOW_41_in_rule__Entity__AbstractAssignment_07075); 
             after(grammarAccess.getEntityAccess().getAbstractAbstractKeyword_0_0()); 

            }

             after(grammarAccess.getEntityAccess().getAbstractAbstractKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__AbstractAssignment_0"


    // $ANTLR start "rule__Entity__NameAssignment_2"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3514:1: rule__Entity__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__Entity__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3518:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3519:1: ( RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3519:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3520:1: RULE_ID
            {
             before(grammarAccess.getEntityAccess().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Entity__NameAssignment_27114); 
             after(grammarAccess.getEntityAccess().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__NameAssignment_2"


    // $ANTLR start "rule__Entity__SuperTypeAssignment_3_1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3529:1: rule__Entity__SuperTypeAssignment_3_1 : ( ( RULE_ID ) ) ;
    public final void rule__Entity__SuperTypeAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3533:1: ( ( ( RULE_ID ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3534:1: ( ( RULE_ID ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3534:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3535:1: ( RULE_ID )
            {
             before(grammarAccess.getEntityAccess().getSuperTypeEntityCrossReference_3_1_0()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3536:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3537:1: RULE_ID
            {
             before(grammarAccess.getEntityAccess().getSuperTypeEntityIDTerminalRuleCall_3_1_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Entity__SuperTypeAssignment_3_17149); 
             after(grammarAccess.getEntityAccess().getSuperTypeEntityIDTerminalRuleCall_3_1_0_1()); 

            }

             after(grammarAccess.getEntityAccess().getSuperTypeEntityCrossReference_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__SuperTypeAssignment_3_1"


    // $ANTLR start "rule__Entity__PropertiesAssignment_5"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3548:1: rule__Entity__PropertiesAssignment_5 : ( ruleProperty ) ;
    public final void rule__Entity__PropertiesAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3552:1: ( ( ruleProperty ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3553:1: ( ruleProperty )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3553:1: ( ruleProperty )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3554:1: ruleProperty
            {
             before(grammarAccess.getEntityAccess().getPropertiesPropertyParserRuleCall_5_0()); 
            pushFollow(FOLLOW_ruleProperty_in_rule__Entity__PropertiesAssignment_57184);
            ruleProperty();

            state._fsp--;

             after(grammarAccess.getEntityAccess().getPropertiesPropertyParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__PropertiesAssignment_5"


    // $ANTLR start "rule__Attribute__NameAssignment_1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3563:1: rule__Attribute__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Attribute__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3567:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3568:1: ( RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3568:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3569:1: RULE_ID
            {
             before(grammarAccess.getAttributeAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Attribute__NameAssignment_17215); 
             after(grammarAccess.getAttributeAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__NameAssignment_1"


    // $ANTLR start "rule__Attribute__TypeAssignment_3"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3578:1: rule__Attribute__TypeAssignment_3 : ( ruleAttributeType ) ;
    public final void rule__Attribute__TypeAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3582:1: ( ( ruleAttributeType ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3583:1: ( ruleAttributeType )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3583:1: ( ruleAttributeType )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3584:1: ruleAttributeType
            {
             before(grammarAccess.getAttributeAccess().getTypeAttributeTypeEnumRuleCall_3_0()); 
            pushFollow(FOLLOW_ruleAttributeType_in_rule__Attribute__TypeAssignment_37246);
            ruleAttributeType();

            state._fsp--;

             after(grammarAccess.getAttributeAccess().getTypeAttributeTypeEnumRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__TypeAssignment_3"


    // $ANTLR start "rule__Attribute__OptionalAssignment_4"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3593:1: rule__Attribute__OptionalAssignment_4 : ( ( 'optional' ) ) ;
    public final void rule__Attribute__OptionalAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3597:1: ( ( ( 'optional' ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3598:1: ( ( 'optional' ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3598:1: ( ( 'optional' ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3599:1: ( 'optional' )
            {
             before(grammarAccess.getAttributeAccess().getOptionalOptionalKeyword_4_0()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3600:1: ( 'optional' )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3601:1: 'optional'
            {
             before(grammarAccess.getAttributeAccess().getOptionalOptionalKeyword_4_0()); 
            match(input,42,FOLLOW_42_in_rule__Attribute__OptionalAssignment_47282); 
             after(grammarAccess.getAttributeAccess().getOptionalOptionalKeyword_4_0()); 

            }

             after(grammarAccess.getAttributeAccess().getOptionalOptionalKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__OptionalAssignment_4"


    // $ANTLR start "rule__Reference__NameAssignment_1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3616:1: rule__Reference__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Reference__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3620:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3621:1: ( RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3621:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3622:1: RULE_ID
            {
             before(grammarAccess.getReferenceAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Reference__NameAssignment_17321); 
             after(grammarAccess.getReferenceAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__NameAssignment_1"


    // $ANTLR start "rule__Reference__TypeAssignment_3"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3631:1: rule__Reference__TypeAssignment_3 : ( ( RULE_ID ) ) ;
    public final void rule__Reference__TypeAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3635:1: ( ( ( RULE_ID ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3636:1: ( ( RULE_ID ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3636:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3637:1: ( RULE_ID )
            {
             before(grammarAccess.getReferenceAccess().getTypeEntityCrossReference_3_0()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3638:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3639:1: RULE_ID
            {
             before(grammarAccess.getReferenceAccess().getTypeEntityIDTerminalRuleCall_3_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Reference__TypeAssignment_37356); 
             after(grammarAccess.getReferenceAccess().getTypeEntityIDTerminalRuleCall_3_0_1()); 

            }

             after(grammarAccess.getReferenceAccess().getTypeEntityCrossReference_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__TypeAssignment_3"


    // $ANTLR start "rule__Reference__MultiplicityAssignment_4"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3650:1: rule__Reference__MultiplicityAssignment_4 : ( ruleMultiplicityKind ) ;
    public final void rule__Reference__MultiplicityAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3654:1: ( ( ruleMultiplicityKind ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3655:1: ( ruleMultiplicityKind )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3655:1: ( ruleMultiplicityKind )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3656:1: ruleMultiplicityKind
            {
             before(grammarAccess.getReferenceAccess().getMultiplicityMultiplicityKindEnumRuleCall_4_0()); 
            pushFollow(FOLLOW_ruleMultiplicityKind_in_rule__Reference__MultiplicityAssignment_47391);
            ruleMultiplicityKind();

            state._fsp--;

             after(grammarAccess.getReferenceAccess().getMultiplicityMultiplicityKindEnumRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__MultiplicityAssignment_4"


    // $ANTLR start "rule__Reference__OppositeAssignment_5_1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3665:1: rule__Reference__OppositeAssignment_5_1 : ( ( RULE_ID ) ) ;
    public final void rule__Reference__OppositeAssignment_5_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3669:1: ( ( ( RULE_ID ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3670:1: ( ( RULE_ID ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3670:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3671:1: ( RULE_ID )
            {
             before(grammarAccess.getReferenceAccess().getOppositeReferenceCrossReference_5_1_0()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3672:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3673:1: RULE_ID
            {
             before(grammarAccess.getReferenceAccess().getOppositeReferenceIDTerminalRuleCall_5_1_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Reference__OppositeAssignment_5_17426); 
             after(grammarAccess.getReferenceAccess().getOppositeReferenceIDTerminalRuleCall_5_1_0_1()); 

            }

             after(grammarAccess.getReferenceAccess().getOppositeReferenceCrossReference_5_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__OppositeAssignment_5_1"


    // $ANTLR start "rule__ListWindow__NameAssignment_1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3684:1: rule__ListWindow__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__ListWindow__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3688:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3689:1: ( RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3689:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3690:1: RULE_ID
            {
             before(grammarAccess.getListWindowAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__ListWindow__NameAssignment_17461); 
             after(grammarAccess.getListWindowAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__NameAssignment_1"


    // $ANTLR start "rule__ListWindow__EntityAssignment_3"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3699:1: rule__ListWindow__EntityAssignment_3 : ( ( RULE_ID ) ) ;
    public final void rule__ListWindow__EntityAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3703:1: ( ( ( RULE_ID ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3704:1: ( ( RULE_ID ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3704:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3705:1: ( RULE_ID )
            {
             before(grammarAccess.getListWindowAccess().getEntityEntityCrossReference_3_0()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3706:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3707:1: RULE_ID
            {
             before(grammarAccess.getListWindowAccess().getEntityEntityIDTerminalRuleCall_3_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__ListWindow__EntityAssignment_37496); 
             after(grammarAccess.getListWindowAccess().getEntityEntityIDTerminalRuleCall_3_0_1()); 

            }

             after(grammarAccess.getListWindowAccess().getEntityEntityCrossReference_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__EntityAssignment_3"


    // $ANTLR start "rule__ListWindow__TitleAssignment_4_1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3718:1: rule__ListWindow__TitleAssignment_4_1 : ( RULE_STRING ) ;
    public final void rule__ListWindow__TitleAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3722:1: ( ( RULE_STRING ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3723:1: ( RULE_STRING )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3723:1: ( RULE_STRING )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3724:1: RULE_STRING
            {
             before(grammarAccess.getListWindowAccess().getTitleSTRINGTerminalRuleCall_4_1_0()); 
            match(input,RULE_STRING,FOLLOW_RULE_STRING_in_rule__ListWindow__TitleAssignment_4_17531); 
             after(grammarAccess.getListWindowAccess().getTitleSTRINGTerminalRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__TitleAssignment_4_1"


    // $ANTLR start "rule__ListWindow__SizeAssignment_5"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3733:1: rule__ListWindow__SizeAssignment_5 : ( ruleSize ) ;
    public final void rule__ListWindow__SizeAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3737:1: ( ( ruleSize ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3738:1: ( ruleSize )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3738:1: ( ruleSize )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3739:1: ruleSize
            {
             before(grammarAccess.getListWindowAccess().getSizeSizeParserRuleCall_5_0()); 
            pushFollow(FOLLOW_ruleSize_in_rule__ListWindow__SizeAssignment_57562);
            ruleSize();

            state._fsp--;

             after(grammarAccess.getListWindowAccess().getSizeSizeParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__SizeAssignment_5"


    // $ANTLR start "rule__EntryWindow__NameAssignment_1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3748:1: rule__EntryWindow__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__EntryWindow__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3752:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3753:1: ( RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3753:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3754:1: RULE_ID
            {
             before(grammarAccess.getEntryWindowAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__EntryWindow__NameAssignment_17593); 
             after(grammarAccess.getEntryWindowAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__NameAssignment_1"


    // $ANTLR start "rule__EntryWindow__EntityAssignment_3"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3763:1: rule__EntryWindow__EntityAssignment_3 : ( ( RULE_ID ) ) ;
    public final void rule__EntryWindow__EntityAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3767:1: ( ( ( RULE_ID ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3768:1: ( ( RULE_ID ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3768:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3769:1: ( RULE_ID )
            {
             before(grammarAccess.getEntryWindowAccess().getEntityEntityCrossReference_3_0()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3770:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3771:1: RULE_ID
            {
             before(grammarAccess.getEntryWindowAccess().getEntityEntityIDTerminalRuleCall_3_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__EntryWindow__EntityAssignment_37628); 
             after(grammarAccess.getEntryWindowAccess().getEntityEntityIDTerminalRuleCall_3_0_1()); 

            }

             after(grammarAccess.getEntryWindowAccess().getEntityEntityCrossReference_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__EntityAssignment_3"


    // $ANTLR start "rule__EntryWindow__TitleAssignment_4_0_1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3782:1: rule__EntryWindow__TitleAssignment_4_0_1 : ( RULE_STRING ) ;
    public final void rule__EntryWindow__TitleAssignment_4_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3786:1: ( ( RULE_STRING ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3787:1: ( RULE_STRING )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3787:1: ( RULE_STRING )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3788:1: RULE_STRING
            {
             before(grammarAccess.getEntryWindowAccess().getTitleSTRINGTerminalRuleCall_4_0_1_0()); 
            match(input,RULE_STRING,FOLLOW_RULE_STRING_in_rule__EntryWindow__TitleAssignment_4_0_17663); 
             after(grammarAccess.getEntryWindowAccess().getTitleSTRINGTerminalRuleCall_4_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__TitleAssignment_4_0_1"


    // $ANTLR start "rule__EntryWindow__SizeAssignment_4_1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3797:1: rule__EntryWindow__SizeAssignment_4_1 : ( ruleSize ) ;
    public final void rule__EntryWindow__SizeAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3801:1: ( ( ruleSize ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3802:1: ( ruleSize )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3802:1: ( ruleSize )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3803:1: ruleSize
            {
             before(grammarAccess.getEntryWindowAccess().getSizeSizeParserRuleCall_4_1_0()); 
            pushFollow(FOLLOW_ruleSize_in_rule__EntryWindow__SizeAssignment_4_17694);
            ruleSize();

            state._fsp--;

             after(grammarAccess.getEntryWindowAccess().getSizeSizeParserRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__SizeAssignment_4_1"


    // $ANTLR start "rule__EntryWindow__ElementsAssignment_6"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3812:1: rule__EntryWindow__ElementsAssignment_6 : ( ruleUIElement ) ;
    public final void rule__EntryWindow__ElementsAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3816:1: ( ( ruleUIElement ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3817:1: ( ruleUIElement )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3817:1: ( ruleUIElement )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3818:1: ruleUIElement
            {
             before(grammarAccess.getEntryWindowAccess().getElementsUIElementParserRuleCall_6_0()); 
            pushFollow(FOLLOW_ruleUIElement_in_rule__EntryWindow__ElementsAssignment_67725);
            ruleUIElement();

            state._fsp--;

             after(grammarAccess.getEntryWindowAccess().getElementsUIElementParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__ElementsAssignment_6"


    // $ANTLR start "rule__Size__WidthAssignment_2"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3827:1: rule__Size__WidthAssignment_2 : ( RULE_INT ) ;
    public final void rule__Size__WidthAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3831:1: ( ( RULE_INT ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3832:1: ( RULE_INT )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3832:1: ( RULE_INT )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3833:1: RULE_INT
            {
             before(grammarAccess.getSizeAccess().getWidthINTTerminalRuleCall_2_0()); 
            match(input,RULE_INT,FOLLOW_RULE_INT_in_rule__Size__WidthAssignment_27756); 
             after(grammarAccess.getSizeAccess().getWidthINTTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__WidthAssignment_2"


    // $ANTLR start "rule__Size__HeightAssignment_4"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3842:1: rule__Size__HeightAssignment_4 : ( RULE_INT ) ;
    public final void rule__Size__HeightAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3846:1: ( ( RULE_INT ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3847:1: ( RULE_INT )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3847:1: ( RULE_INT )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3848:1: RULE_INT
            {
             before(grammarAccess.getSizeAccess().getHeightINTTerminalRuleCall_4_0()); 
            match(input,RULE_INT,FOLLOW_RULE_INT_in_rule__Size__HeightAssignment_47787); 
             after(grammarAccess.getSizeAccess().getHeightINTTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__HeightAssignment_4"


    // $ANTLR start "rule__Bounds__XAssignment_3"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3857:1: rule__Bounds__XAssignment_3 : ( RULE_INT ) ;
    public final void rule__Bounds__XAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3861:1: ( ( RULE_INT ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3862:1: ( RULE_INT )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3862:1: ( RULE_INT )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3863:1: RULE_INT
            {
             before(grammarAccess.getBoundsAccess().getXINTTerminalRuleCall_3_0()); 
            match(input,RULE_INT,FOLLOW_RULE_INT_in_rule__Bounds__XAssignment_37818); 
             after(grammarAccess.getBoundsAccess().getXINTTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__XAssignment_3"


    // $ANTLR start "rule__Bounds__YAssignment_5"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3872:1: rule__Bounds__YAssignment_5 : ( RULE_INT ) ;
    public final void rule__Bounds__YAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3876:1: ( ( RULE_INT ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3877:1: ( RULE_INT )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3877:1: ( RULE_INT )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3878:1: RULE_INT
            {
             before(grammarAccess.getBoundsAccess().getYINTTerminalRuleCall_5_0()); 
            match(input,RULE_INT,FOLLOW_RULE_INT_in_rule__Bounds__YAssignment_57849); 
             after(grammarAccess.getBoundsAccess().getYINTTerminalRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__YAssignment_5"


    // $ANTLR start "rule__Bounds__WidthAssignment_7"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3887:1: rule__Bounds__WidthAssignment_7 : ( RULE_INT ) ;
    public final void rule__Bounds__WidthAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3891:1: ( ( RULE_INT ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3892:1: ( RULE_INT )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3892:1: ( RULE_INT )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3893:1: RULE_INT
            {
             before(grammarAccess.getBoundsAccess().getWidthINTTerminalRuleCall_7_0()); 
            match(input,RULE_INT,FOLLOW_RULE_INT_in_rule__Bounds__WidthAssignment_77880); 
             after(grammarAccess.getBoundsAccess().getWidthINTTerminalRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__WidthAssignment_7"


    // $ANTLR start "rule__Bounds__HeightAssignment_9"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3902:1: rule__Bounds__HeightAssignment_9 : ( RULE_INT ) ;
    public final void rule__Bounds__HeightAssignment_9() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3906:1: ( ( RULE_INT ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3907:1: ( RULE_INT )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3907:1: ( RULE_INT )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3908:1: RULE_INT
            {
             before(grammarAccess.getBoundsAccess().getHeightINTTerminalRuleCall_9_0()); 
            match(input,RULE_INT,FOLLOW_RULE_INT_in_rule__Bounds__HeightAssignment_97911); 
             after(grammarAccess.getBoundsAccess().getHeightINTTerminalRuleCall_9_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Bounds__HeightAssignment_9"


    // $ANTLR start "rule__UIElement__BoundsAssignment_1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3917:1: rule__UIElement__BoundsAssignment_1 : ( ruleBounds ) ;
    public final void rule__UIElement__BoundsAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3921:1: ( ( ruleBounds ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3922:1: ( ruleBounds )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3922:1: ( ruleBounds )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3923:1: ruleBounds
            {
             before(grammarAccess.getUIElementAccess().getBoundsBoundsParserRuleCall_1_0()); 
            pushFollow(FOLLOW_ruleBounds_in_rule__UIElement__BoundsAssignment_17942);
            ruleBounds();

            state._fsp--;

             after(grammarAccess.getUIElementAccess().getBoundsBoundsParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UIElement__BoundsAssignment_1"


    // $ANTLR start "rule__Label__NameAssignment_1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3932:1: rule__Label__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Label__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3936:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3937:1: ( RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3937:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3938:1: RULE_ID
            {
             before(grammarAccess.getLabelAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Label__NameAssignment_17973); 
             after(grammarAccess.getLabelAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__NameAssignment_1"


    // $ANTLR start "rule__Label__TextAssignment_2_1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3947:1: rule__Label__TextAssignment_2_1 : ( RULE_STRING ) ;
    public final void rule__Label__TextAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3951:1: ( ( RULE_STRING ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3952:1: ( RULE_STRING )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3952:1: ( RULE_STRING )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3953:1: RULE_STRING
            {
             before(grammarAccess.getLabelAccess().getTextSTRINGTerminalRuleCall_2_1_0()); 
            match(input,RULE_STRING,FOLLOW_RULE_STRING_in_rule__Label__TextAssignment_2_18004); 
             after(grammarAccess.getLabelAccess().getTextSTRINGTerminalRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__TextAssignment_2_1"


    // $ANTLR start "rule__Field__NameAssignment_1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3962:1: rule__Field__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Field__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3966:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3967:1: ( RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3967:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3968:1: RULE_ID
            {
             before(grammarAccess.getFieldAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Field__NameAssignment_18035); 
             after(grammarAccess.getFieldAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__NameAssignment_1"


    // $ANTLR start "rule__Field__PropertyAssignment_3"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3977:1: rule__Field__PropertyAssignment_3 : ( ( RULE_ID ) ) ;
    public final void rule__Field__PropertyAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3981:1: ( ( ( RULE_ID ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3982:1: ( ( RULE_ID ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3982:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3983:1: ( RULE_ID )
            {
             before(grammarAccess.getFieldAccess().getPropertyPropertyCrossReference_3_0()); 
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3984:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3985:1: RULE_ID
            {
             before(grammarAccess.getFieldAccess().getPropertyPropertyIDTerminalRuleCall_3_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Field__PropertyAssignment_38070); 
             after(grammarAccess.getFieldAccess().getPropertyPropertyIDTerminalRuleCall_3_0_1()); 

            }

             after(grammarAccess.getFieldAccess().getPropertyPropertyCrossReference_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__PropertyAssignment_3"


    // $ANTLR start "rule__Button__NameAssignment_1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:3996:1: rule__Button__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Button__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:4000:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:4001:1: ( RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:4001:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:4002:1: RULE_ID
            {
             before(grammarAccess.getButtonAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Button__NameAssignment_18105); 
             after(grammarAccess.getButtonAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__NameAssignment_1"


    // $ANTLR start "rule__Button__KindAssignment_2"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:4011:1: rule__Button__KindAssignment_2 : ( ruleButtonKind ) ;
    public final void rule__Button__KindAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:4015:1: ( ( ruleButtonKind ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:4016:1: ( ruleButtonKind )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:4016:1: ( ruleButtonKind )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:4017:1: ruleButtonKind
            {
             before(grammarAccess.getButtonAccess().getKindButtonKindEnumRuleCall_2_0()); 
            pushFollow(FOLLOW_ruleButtonKind_in_rule__Button__KindAssignment_28136);
            ruleButtonKind();

            state._fsp--;

             after(grammarAccess.getButtonAccess().getKindButtonKindEnumRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__KindAssignment_2"


    // $ANTLR start "rule__Button__TextAssignment_3_1"
    // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:4026:1: rule__Button__TextAssignment_3_1 : ( RULE_STRING ) ;
    public final void rule__Button__TextAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:4030:1: ( ( RULE_STRING ) )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:4031:1: ( RULE_STRING )
            {
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:4031:1: ( RULE_STRING )
            // ../de.wwu.pi.mdsd.CrudDsl.ui/src-gen/de/wwu/pi/mdsd/crudDsl/ui/contentassist/antlr/internal/InternalCrudDsl.g:4032:1: RULE_STRING
            {
             before(grammarAccess.getButtonAccess().getTextSTRINGTerminalRuleCall_3_1_0()); 
            match(input,RULE_STRING,FOLLOW_RULE_STRING_in_rule__Button__TextAssignment_3_18167); 
             after(grammarAccess.getButtonAccess().getTextSTRINGTerminalRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__TextAssignment_3_1"

    // Delegated rules


 

    public static final BitSet FOLLOW_ruleCrudModel_in_entryRuleCrudModel61 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleCrudModel68 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__CrudModel__Group__0_in_ruleCrudModel94 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEntity_in_entryRuleEntity121 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleEntity128 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__Group__0_in_ruleEntity154 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleProperty_in_entryRuleProperty181 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleProperty188 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Property__Alternatives_in_ruleProperty214 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAttribute_in_entryRuleAttribute241 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleAttribute248 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__Group__0_in_ruleAttribute274 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleReference_in_entryRuleReference301 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleReference308 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__Group__0_in_ruleReference334 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleWindow_in_entryRuleWindow361 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleWindow368 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Window__Alternatives_in_ruleWindow394 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleListWindow_in_entryRuleListWindow421 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleListWindow428 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__0_in_ruleListWindow454 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEntryWindow_in_entryRuleEntryWindow481 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleEntryWindow488 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__0_in_ruleEntryWindow514 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleSize_in_entryRuleSize541 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleSize548 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__Group__0_in_ruleSize574 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleBounds_in_entryRuleBounds601 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleBounds608 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Bounds__Group__0_in_ruleBounds634 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleUIElement_in_entryRuleUIElement661 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleUIElement668 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__UIElement__Group__0_in_ruleUIElement694 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleLabel_in_entryRuleLabel721 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleLabel728 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Label__Group__0_in_ruleLabel754 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleField_in_entryRuleField781 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleField788 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Field__Group__0_in_ruleField814 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleButton_in_entryRuleButton841 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleButton848 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Button__Group__0_in_ruleButton874 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleQualifiedName_in_entryRuleQualifiedName901 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleQualifiedName908 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group__0_in_ruleQualifiedName934 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__AttributeType__Alternatives_in_ruleAttributeType971 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__MultiplicityKind__Alternatives_in_ruleMultiplicityKind1007 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ButtonKind__Alternatives_in_ruleButtonKind1043 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__CrudModel__EntitiesAssignment_2_0_in_rule__CrudModel__Alternatives_21078 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__CrudModel__WindowsAssignment_2_1_in_rule__CrudModel__Alternatives_21096 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAttribute_in_rule__Property__Alternatives1129 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleReference_in_rule__Property__Alternatives1146 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEntryWindow_in_rule__Window__Alternatives1178 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleListWindow_in_rule__Window__Alternatives1195 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleLabel_in_rule__UIElement__Alternatives_01227 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleField_in_rule__UIElement__Alternatives_01244 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleButton_in_rule__UIElement__Alternatives_01261 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_11_in_rule__AttributeType__Alternatives1294 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_12_in_rule__AttributeType__Alternatives1315 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_13_in_rule__AttributeType__Alternatives1336 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_14_in_rule__MultiplicityKind__Alternatives1372 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_15_in_rule__MultiplicityKind__Alternatives1393 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_16_in_rule__ButtonKind__Alternatives1429 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_17_in_rule__ButtonKind__Alternatives1450 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_18_in_rule__ButtonKind__Alternatives1471 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__CrudModel__Group__0__Impl_in_rule__CrudModel__Group__01504 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__CrudModel__Group__1_in_rule__CrudModel__Group__01507 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_19_in_rule__CrudModel__Group__0__Impl1535 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__CrudModel__Group__1__Impl_in_rule__CrudModel__Group__11566 = new BitSet(new long[]{0x0000020090100000L});
    public static final BitSet FOLLOW_rule__CrudModel__Group__2_in_rule__CrudModel__Group__11569 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__CrudModel__NameAssignment_1_in_rule__CrudModel__Group__1__Impl1596 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__CrudModel__Group__2__Impl_in_rule__CrudModel__Group__21626 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__CrudModel__Alternatives_2_in_rule__CrudModel__Group__2__Impl1653 = new BitSet(new long[]{0x0000020090100002L});
    public static final BitSet FOLLOW_rule__Entity__Group__0__Impl_in_rule__Entity__Group__01690 = new BitSet(new long[]{0x0000020000100000L});
    public static final BitSet FOLLOW_rule__Entity__Group__1_in_rule__Entity__Group__01693 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__AbstractAssignment_0_in_rule__Entity__Group__0__Impl1720 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__Group__1__Impl_in_rule__Entity__Group__11751 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Entity__Group__2_in_rule__Entity__Group__11754 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_20_in_rule__Entity__Group__1__Impl1782 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__Group__2__Impl_in_rule__Entity__Group__21813 = new BitSet(new long[]{0x0000000000A00000L});
    public static final BitSet FOLLOW_rule__Entity__Group__3_in_rule__Entity__Group__21816 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__NameAssignment_2_in_rule__Entity__Group__2__Impl1843 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__Group__3__Impl_in_rule__Entity__Group__31873 = new BitSet(new long[]{0x0000000000A00000L});
    public static final BitSet FOLLOW_rule__Entity__Group__4_in_rule__Entity__Group__31876 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__Group_3__0_in_rule__Entity__Group__3__Impl1903 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__Group__4__Impl_in_rule__Entity__Group__41934 = new BitSet(new long[]{0x0000000005400000L});
    public static final BitSet FOLLOW_rule__Entity__Group__5_in_rule__Entity__Group__41937 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_21_in_rule__Entity__Group__4__Impl1965 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__Group__5__Impl_in_rule__Entity__Group__51996 = new BitSet(new long[]{0x0000000005400000L});
    public static final BitSet FOLLOW_rule__Entity__Group__6_in_rule__Entity__Group__51999 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__PropertiesAssignment_5_in_rule__Entity__Group__5__Impl2026 = new BitSet(new long[]{0x0000000005000002L});
    public static final BitSet FOLLOW_rule__Entity__Group__6__Impl_in_rule__Entity__Group__62057 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_22_in_rule__Entity__Group__6__Impl2085 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__Group_3__0__Impl_in_rule__Entity__Group_3__02130 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Entity__Group_3__1_in_rule__Entity__Group_3__02133 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_23_in_rule__Entity__Group_3__0__Impl2161 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__Group_3__1__Impl_in_rule__Entity__Group_3__12192 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__SuperTypeAssignment_3_1_in_rule__Entity__Group_3__1__Impl2219 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__Group__0__Impl_in_rule__Attribute__Group__02253 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Attribute__Group__1_in_rule__Attribute__Group__02256 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_24_in_rule__Attribute__Group__0__Impl2284 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__Group__1__Impl_in_rule__Attribute__Group__12315 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_rule__Attribute__Group__2_in_rule__Attribute__Group__12318 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__NameAssignment_1_in_rule__Attribute__Group__1__Impl2345 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__Group__2__Impl_in_rule__Attribute__Group__22375 = new BitSet(new long[]{0x0000000000003800L});
    public static final BitSet FOLLOW_rule__Attribute__Group__3_in_rule__Attribute__Group__22378 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_25_in_rule__Attribute__Group__2__Impl2406 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__Group__3__Impl_in_rule__Attribute__Group__32437 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_rule__Attribute__Group__4_in_rule__Attribute__Group__32440 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__TypeAssignment_3_in_rule__Attribute__Group__3__Impl2467 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__Group__4__Impl_in_rule__Attribute__Group__42497 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__OptionalAssignment_4_in_rule__Attribute__Group__4__Impl2524 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__Group__0__Impl_in_rule__Reference__Group__02565 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Reference__Group__1_in_rule__Reference__Group__02568 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_26_in_rule__Reference__Group__0__Impl2596 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__Group__1__Impl_in_rule__Reference__Group__12627 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_rule__Reference__Group__2_in_rule__Reference__Group__12630 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__NameAssignment_1_in_rule__Reference__Group__1__Impl2657 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__Group__2__Impl_in_rule__Reference__Group__22687 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Reference__Group__3_in_rule__Reference__Group__22690 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_25_in_rule__Reference__Group__2__Impl2718 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__Group__3__Impl_in_rule__Reference__Group__32749 = new BitSet(new long[]{0x000000000800C000L});
    public static final BitSet FOLLOW_rule__Reference__Group__4_in_rule__Reference__Group__32752 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__TypeAssignment_3_in_rule__Reference__Group__3__Impl2779 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__Group__4__Impl_in_rule__Reference__Group__42809 = new BitSet(new long[]{0x000000000800C000L});
    public static final BitSet FOLLOW_rule__Reference__Group__5_in_rule__Reference__Group__42812 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__MultiplicityAssignment_4_in_rule__Reference__Group__4__Impl2839 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__Group__5__Impl_in_rule__Reference__Group__52870 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__Group_5__0_in_rule__Reference__Group__5__Impl2897 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__Group_5__0__Impl_in_rule__Reference__Group_5__02939 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Reference__Group_5__1_in_rule__Reference__Group_5__02942 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_27_in_rule__Reference__Group_5__0__Impl2970 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__Group_5__1__Impl_in_rule__Reference__Group_5__13001 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__OppositeAssignment_5_1_in_rule__Reference__Group_5__1__Impl3028 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__0__Impl_in_rule__ListWindow__Group__03062 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__1_in_rule__ListWindow__Group__03065 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_28_in_rule__ListWindow__Group__0__Impl3093 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__1__Impl_in_rule__ListWindow__Group__13124 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__2_in_rule__ListWindow__Group__13127 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__NameAssignment_1_in_rule__ListWindow__Group__1__Impl3154 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__2__Impl_in_rule__ListWindow__Group__23184 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__3_in_rule__ListWindow__Group__23187 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_29_in_rule__ListWindow__Group__2__Impl3215 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__3__Impl_in_rule__ListWindow__Group__33246 = new BitSet(new long[]{0x0000000140000000L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__4_in_rule__ListWindow__Group__33249 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__EntityAssignment_3_in_rule__ListWindow__Group__3__Impl3276 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__4__Impl_in_rule__ListWindow__Group__43306 = new BitSet(new long[]{0x0000000140000000L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__5_in_rule__ListWindow__Group__43309 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__Group_4__0_in_rule__ListWindow__Group__4__Impl3336 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__5__Impl_in_rule__ListWindow__Group__53367 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__SizeAssignment_5_in_rule__ListWindow__Group__5__Impl3394 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__Group_4__0__Impl_in_rule__ListWindow__Group_4__03436 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_rule__ListWindow__Group_4__1_in_rule__ListWindow__Group_4__03439 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_30_in_rule__ListWindow__Group_4__0__Impl3467 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__Group_4__1__Impl_in_rule__ListWindow__Group_4__13498 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__TitleAssignment_4_1_in_rule__ListWindow__Group_4__1__Impl3525 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__0__Impl_in_rule__EntryWindow__Group__03559 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__1_in_rule__EntryWindow__Group__03562 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_31_in_rule__EntryWindow__Group__0__Impl3590 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__1__Impl_in_rule__EntryWindow__Group__13621 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__2_in_rule__EntryWindow__Group__13624 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__NameAssignment_1_in_rule__EntryWindow__Group__1__Impl3651 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__2__Impl_in_rule__EntryWindow__Group__23681 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__3_in_rule__EntryWindow__Group__23684 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_29_in_rule__EntryWindow__Group__2__Impl3712 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__3__Impl_in_rule__EntryWindow__Group__33743 = new BitSet(new long[]{0x0000000140000000L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__4_in_rule__EntryWindow__Group__33746 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__EntityAssignment_3_in_rule__EntryWindow__Group__3__Impl3773 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__4__Impl_in_rule__EntryWindow__Group__43803 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__5_in_rule__EntryWindow__Group__43806 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__UnorderedGroup_4_in_rule__EntryWindow__Group__4__Impl3833 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__5__Impl_in_rule__EntryWindow__Group__53863 = new BitSet(new long[]{0x000000E000400000L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__6_in_rule__EntryWindow__Group__53866 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_21_in_rule__EntryWindow__Group__5__Impl3894 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__6__Impl_in_rule__EntryWindow__Group__63925 = new BitSet(new long[]{0x000000E000400000L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__7_in_rule__EntryWindow__Group__63928 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__ElementsAssignment_6_in_rule__EntryWindow__Group__6__Impl3955 = new BitSet(new long[]{0x000000E000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__7__Impl_in_rule__EntryWindow__Group__73986 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_22_in_rule__EntryWindow__Group__7__Impl4014 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group_4_0__0__Impl_in_rule__EntryWindow__Group_4_0__04061 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group_4_0__1_in_rule__EntryWindow__Group_4_0__04064 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_30_in_rule__EntryWindow__Group_4_0__0__Impl4092 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group_4_0__1__Impl_in_rule__EntryWindow__Group_4_0__14123 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__TitleAssignment_4_0_1_in_rule__EntryWindow__Group_4_0__1__Impl4150 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__Group__0__Impl_in_rule__Size__Group__04184 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_rule__Size__Group__1_in_rule__Size__Group__04187 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_32_in_rule__Size__Group__0__Impl4215 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__Group__1__Impl_in_rule__Size__Group__14246 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_rule__Size__Group__2_in_rule__Size__Group__14249 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_rule__Size__Group__1__Impl4277 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__Group__2__Impl_in_rule__Size__Group__24308 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_rule__Size__Group__3_in_rule__Size__Group__24311 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__WidthAssignment_2_in_rule__Size__Group__2__Impl4338 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__Group__3__Impl_in_rule__Size__Group__34368 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_rule__Size__Group__4_in_rule__Size__Group__34371 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_34_in_rule__Size__Group__3__Impl4399 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__Group__4__Impl_in_rule__Size__Group__44430 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_rule__Size__Group__5_in_rule__Size__Group__44433 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__HeightAssignment_4_in_rule__Size__Group__4__Impl4460 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__Group__5__Impl_in_rule__Size__Group__54490 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_35_in_rule__Size__Group__5__Impl4518 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Bounds__Group__0__Impl_in_rule__Bounds__Group__04561 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_rule__Bounds__Group__1_in_rule__Bounds__Group__04564 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Bounds__Group__1__Impl_in_rule__Bounds__Group__14622 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_rule__Bounds__Group__2_in_rule__Bounds__Group__14625 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_36_in_rule__Bounds__Group__1__Impl4653 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Bounds__Group__2__Impl_in_rule__Bounds__Group__24684 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_rule__Bounds__Group__3_in_rule__Bounds__Group__24687 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_rule__Bounds__Group__2__Impl4715 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Bounds__Group__3__Impl_in_rule__Bounds__Group__34746 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_rule__Bounds__Group__4_in_rule__Bounds__Group__34749 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Bounds__XAssignment_3_in_rule__Bounds__Group__3__Impl4776 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Bounds__Group__4__Impl_in_rule__Bounds__Group__44806 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_rule__Bounds__Group__5_in_rule__Bounds__Group__44809 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_34_in_rule__Bounds__Group__4__Impl4837 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Bounds__Group__5__Impl_in_rule__Bounds__Group__54868 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_rule__Bounds__Group__6_in_rule__Bounds__Group__54871 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Bounds__YAssignment_5_in_rule__Bounds__Group__5__Impl4898 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Bounds__Group__6__Impl_in_rule__Bounds__Group__64928 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_rule__Bounds__Group__7_in_rule__Bounds__Group__64931 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_34_in_rule__Bounds__Group__6__Impl4959 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Bounds__Group__7__Impl_in_rule__Bounds__Group__74990 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_rule__Bounds__Group__8_in_rule__Bounds__Group__74993 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Bounds__WidthAssignment_7_in_rule__Bounds__Group__7__Impl5020 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Bounds__Group__8__Impl_in_rule__Bounds__Group__85050 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_rule__Bounds__Group__9_in_rule__Bounds__Group__85053 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_34_in_rule__Bounds__Group__8__Impl5081 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Bounds__Group__9__Impl_in_rule__Bounds__Group__95112 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_rule__Bounds__Group__10_in_rule__Bounds__Group__95115 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Bounds__HeightAssignment_9_in_rule__Bounds__Group__9__Impl5142 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Bounds__Group__10__Impl_in_rule__Bounds__Group__105172 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_35_in_rule__Bounds__Group__10__Impl5200 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__UIElement__Group__0__Impl_in_rule__UIElement__Group__05253 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_rule__UIElement__Group__1_in_rule__UIElement__Group__05256 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__UIElement__Alternatives_0_in_rule__UIElement__Group__0__Impl5283 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__UIElement__Group__1__Impl_in_rule__UIElement__Group__15313 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__UIElement__BoundsAssignment_1_in_rule__UIElement__Group__1__Impl5340 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Label__Group__0__Impl_in_rule__Label__Group__05374 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Label__Group__1_in_rule__Label__Group__05377 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_37_in_rule__Label__Group__0__Impl5405 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Label__Group__1__Impl_in_rule__Label__Group__15436 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_rule__Label__Group__2_in_rule__Label__Group__15439 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Label__NameAssignment_1_in_rule__Label__Group__1__Impl5466 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Label__Group__2__Impl_in_rule__Label__Group__25496 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Label__Group_2__0_in_rule__Label__Group__2__Impl5523 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Label__Group_2__0__Impl_in_rule__Label__Group_2__05560 = new BitSet(new long[]{0x0000000800000020L});
    public static final BitSet FOLLOW_rule__Label__Group_2__1_in_rule__Label__Group_2__05563 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_rule__Label__Group_2__0__Impl5591 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Label__Group_2__1__Impl_in_rule__Label__Group_2__15622 = new BitSet(new long[]{0x0000000800000020L});
    public static final BitSet FOLLOW_rule__Label__Group_2__2_in_rule__Label__Group_2__15625 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Label__TextAssignment_2_1_in_rule__Label__Group_2__1__Impl5652 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Label__Group_2__2__Impl_in_rule__Label__Group_2__25683 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_35_in_rule__Label__Group_2__2__Impl5711 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Field__Group__0__Impl_in_rule__Field__Group__05748 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Field__Group__1_in_rule__Field__Group__05751 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_38_in_rule__Field__Group__0__Impl5779 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Field__Group__1__Impl_in_rule__Field__Group__15810 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_rule__Field__Group__2_in_rule__Field__Group__15813 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Field__NameAssignment_1_in_rule__Field__Group__1__Impl5840 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Field__Group__2__Impl_in_rule__Field__Group__25870 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Field__Group__3_in_rule__Field__Group__25873 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_29_in_rule__Field__Group__2__Impl5901 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Field__Group__3__Impl_in_rule__Field__Group__35932 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Field__PropertyAssignment_3_in_rule__Field__Group__3__Impl5959 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Button__Group__0__Impl_in_rule__Button__Group__05997 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Button__Group__1_in_rule__Button__Group__06000 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_39_in_rule__Button__Group__0__Impl6028 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Button__Group__1__Impl_in_rule__Button__Group__16059 = new BitSet(new long[]{0x0000000200070000L});
    public static final BitSet FOLLOW_rule__Button__Group__2_in_rule__Button__Group__16062 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Button__NameAssignment_1_in_rule__Button__Group__1__Impl6089 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Button__Group__2__Impl_in_rule__Button__Group__26119 = new BitSet(new long[]{0x0000000200070000L});
    public static final BitSet FOLLOW_rule__Button__Group__3_in_rule__Button__Group__26122 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Button__KindAssignment_2_in_rule__Button__Group__2__Impl6149 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Button__Group__3__Impl_in_rule__Button__Group__36180 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Button__Group_3__0_in_rule__Button__Group__3__Impl6207 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Button__Group_3__0__Impl_in_rule__Button__Group_3__06246 = new BitSet(new long[]{0x0000000800000020L});
    public static final BitSet FOLLOW_rule__Button__Group_3__1_in_rule__Button__Group_3__06249 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_rule__Button__Group_3__0__Impl6277 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Button__Group_3__1__Impl_in_rule__Button__Group_3__16308 = new BitSet(new long[]{0x0000000800000020L});
    public static final BitSet FOLLOW_rule__Button__Group_3__2_in_rule__Button__Group_3__16311 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Button__TextAssignment_3_1_in_rule__Button__Group_3__1__Impl6338 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Button__Group_3__2__Impl_in_rule__Button__Group_3__26369 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_35_in_rule__Button__Group_3__2__Impl6397 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group__0__Impl_in_rule__QualifiedName__Group__06434 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group__1_in_rule__QualifiedName__Group__06437 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__QualifiedName__Group__0__Impl6464 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group__1__Impl_in_rule__QualifiedName__Group__16493 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group_1__0_in_rule__QualifiedName__Group__1__Impl6520 = new BitSet(new long[]{0x0000010000000002L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group_1__0__Impl_in_rule__QualifiedName__Group_1__06555 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group_1__1_in_rule__QualifiedName__Group_1__06558 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_40_in_rule__QualifiedName__Group_1__0__Impl6586 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group_1__1__Impl_in_rule__QualifiedName__Group_1__16617 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__QualifiedName__Group_1__1__Impl6644 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__UnorderedGroup_4__0_in_rule__EntryWindow__UnorderedGroup_46678 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group_4_0__0_in_rule__EntryWindow__UnorderedGroup_4__Impl6767 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__SizeAssignment_4_1_in_rule__EntryWindow__UnorderedGroup_4__Impl6858 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__UnorderedGroup_4__Impl_in_rule__EntryWindow__UnorderedGroup_4__06917 = new BitSet(new long[]{0x0000000140000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__UnorderedGroup_4__1_in_rule__EntryWindow__UnorderedGroup_4__06920 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__UnorderedGroup_4__Impl_in_rule__EntryWindow__UnorderedGroup_4__16945 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleQualifiedName_in_rule__CrudModel__NameAssignment_16977 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEntity_in_rule__CrudModel__EntitiesAssignment_2_07008 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleWindow_in_rule__CrudModel__WindowsAssignment_2_17039 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_41_in_rule__Entity__AbstractAssignment_07075 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Entity__NameAssignment_27114 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Entity__SuperTypeAssignment_3_17149 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleProperty_in_rule__Entity__PropertiesAssignment_57184 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Attribute__NameAssignment_17215 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAttributeType_in_rule__Attribute__TypeAssignment_37246 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_42_in_rule__Attribute__OptionalAssignment_47282 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Reference__NameAssignment_17321 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Reference__TypeAssignment_37356 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleMultiplicityKind_in_rule__Reference__MultiplicityAssignment_47391 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Reference__OppositeAssignment_5_17426 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__ListWindow__NameAssignment_17461 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__ListWindow__EntityAssignment_37496 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_STRING_in_rule__ListWindow__TitleAssignment_4_17531 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleSize_in_rule__ListWindow__SizeAssignment_57562 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__EntryWindow__NameAssignment_17593 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__EntryWindow__EntityAssignment_37628 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_STRING_in_rule__EntryWindow__TitleAssignment_4_0_17663 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleSize_in_rule__EntryWindow__SizeAssignment_4_17694 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleUIElement_in_rule__EntryWindow__ElementsAssignment_67725 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_INT_in_rule__Size__WidthAssignment_27756 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_INT_in_rule__Size__HeightAssignment_47787 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_INT_in_rule__Bounds__XAssignment_37818 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_INT_in_rule__Bounds__YAssignment_57849 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_INT_in_rule__Bounds__WidthAssignment_77880 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_INT_in_rule__Bounds__HeightAssignment_97911 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleBounds_in_rule__UIElement__BoundsAssignment_17942 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Label__NameAssignment_17973 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_STRING_in_rule__Label__TextAssignment_2_18004 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Field__NameAssignment_18035 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Field__PropertyAssignment_38070 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Button__NameAssignment_18105 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleButtonKind_in_rule__Button__KindAssignment_28136 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_STRING_in_rule__Button__TextAssignment_3_18167 = new BitSet(new long[]{0x0000000000000002L});

}
