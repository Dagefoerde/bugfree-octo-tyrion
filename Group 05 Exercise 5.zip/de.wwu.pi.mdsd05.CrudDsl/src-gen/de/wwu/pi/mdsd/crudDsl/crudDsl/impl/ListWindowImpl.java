/**
 */
package de.wwu.pi.mdsd.crudDsl.crudDsl.impl;

import de.wwu.pi.mdsd.crudDsl.crudDsl.CrudDslPackage;
import de.wwu.pi.mdsd.crudDsl.crudDsl.ListWindow;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>List Window</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class ListWindowImpl extends WindowImpl implements ListWindow
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ListWindowImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return CrudDslPackage.Literals.LIST_WINDOW;
  }

} //ListWindowImpl
