/**
 */
package de.wwu.pi.mdsd.crudDsl.crudDsl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see de.wwu.pi.mdsd.crudDsl.crudDsl.CrudDslFactory
 * @model kind="package"
 * @generated
 */
public interface CrudDslPackage extends EPackage
{
  /**
   * The package name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNAME = "crudDsl";

  /**
   * The package namespace URI.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_URI = "http://www.wwu.de/pi/mdsd/crudDsl/CrudDsl";

  /**
   * The package namespace name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_PREFIX = "crudDsl";

  /**
   * The singleton instance of the package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  CrudDslPackage eINSTANCE = de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl.init();

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudModelImpl <em>Crud Model</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudModelImpl
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getCrudModel()
   * @generated
   */
  int CRUD_MODEL = 0;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CRUD_MODEL__NAME = 0;

  /**
   * The feature id for the '<em><b>Entities</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CRUD_MODEL__ENTITIES = 1;

  /**
   * The feature id for the '<em><b>Windows</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CRUD_MODEL__WINDOWS = 2;

  /**
   * The number of structural features of the '<em>Crud Model</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CRUD_MODEL_FEATURE_COUNT = 3;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.EntityImpl <em>Entity</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.EntityImpl
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getEntity()
   * @generated
   */
  int ENTITY = 1;

  /**
   * The feature id for the '<em><b>Abstract</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTITY__ABSTRACT = 0;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTITY__NAME = 1;

  /**
   * The feature id for the '<em><b>Super Type</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTITY__SUPER_TYPE = 2;

  /**
   * The feature id for the '<em><b>Properties</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTITY__PROPERTIES = 3;

  /**
   * The number of structural features of the '<em>Entity</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTITY_FEATURE_COUNT = 4;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.PropertyImpl <em>Property</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.PropertyImpl
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getProperty()
   * @generated
   */
  int PROPERTY = 2;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int PROPERTY__NAME = 0;

  /**
   * The number of structural features of the '<em>Property</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int PROPERTY_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.AttributeImpl <em>Attribute</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.AttributeImpl
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getAttribute()
   * @generated
   */
  int ATTRIBUTE = 3;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ATTRIBUTE__NAME = PROPERTY__NAME;

  /**
   * The feature id for the '<em><b>Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ATTRIBUTE__TYPE = PROPERTY_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Optional</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ATTRIBUTE__OPTIONAL = PROPERTY_FEATURE_COUNT + 1;

  /**
   * The number of structural features of the '<em>Attribute</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ATTRIBUTE_FEATURE_COUNT = PROPERTY_FEATURE_COUNT + 2;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.ReferenceImpl <em>Reference</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.ReferenceImpl
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getReference()
   * @generated
   */
  int REFERENCE = 4;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int REFERENCE__NAME = PROPERTY__NAME;

  /**
   * The feature id for the '<em><b>Type</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int REFERENCE__TYPE = PROPERTY_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Multiplicity</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int REFERENCE__MULTIPLICITY = PROPERTY_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Opposite</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int REFERENCE__OPPOSITE = PROPERTY_FEATURE_COUNT + 2;

  /**
   * The number of structural features of the '<em>Reference</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int REFERENCE_FEATURE_COUNT = PROPERTY_FEATURE_COUNT + 3;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.WindowImpl <em>Window</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.WindowImpl
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getWindow()
   * @generated
   */
  int WINDOW = 5;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int WINDOW__NAME = 0;

  /**
   * The feature id for the '<em><b>Entity</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int WINDOW__ENTITY = 1;

  /**
   * The feature id for the '<em><b>Title</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int WINDOW__TITLE = 2;

  /**
   * The feature id for the '<em><b>Size</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int WINDOW__SIZE = 3;

  /**
   * The number of structural features of the '<em>Window</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int WINDOW_FEATURE_COUNT = 4;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.ListWindowImpl <em>List Window</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.ListWindowImpl
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getListWindow()
   * @generated
   */
  int LIST_WINDOW = 6;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LIST_WINDOW__NAME = WINDOW__NAME;

  /**
   * The feature id for the '<em><b>Entity</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LIST_WINDOW__ENTITY = WINDOW__ENTITY;

  /**
   * The feature id for the '<em><b>Title</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LIST_WINDOW__TITLE = WINDOW__TITLE;

  /**
   * The feature id for the '<em><b>Size</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LIST_WINDOW__SIZE = WINDOW__SIZE;

  /**
   * The number of structural features of the '<em>List Window</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LIST_WINDOW_FEATURE_COUNT = WINDOW_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.EntryWindowImpl <em>Entry Window</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.EntryWindowImpl
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getEntryWindow()
   * @generated
   */
  int ENTRY_WINDOW = 7;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTRY_WINDOW__NAME = WINDOW__NAME;

  /**
   * The feature id for the '<em><b>Entity</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTRY_WINDOW__ENTITY = WINDOW__ENTITY;

  /**
   * The feature id for the '<em><b>Title</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTRY_WINDOW__TITLE = WINDOW__TITLE;

  /**
   * The feature id for the '<em><b>Size</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTRY_WINDOW__SIZE = WINDOW__SIZE;

  /**
   * The feature id for the '<em><b>Elements</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTRY_WINDOW__ELEMENTS = WINDOW_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Entry Window</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTRY_WINDOW_FEATURE_COUNT = WINDOW_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.SizeImpl <em>Size</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.SizeImpl
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getSize()
   * @generated
   */
  int SIZE = 8;

  /**
   * The feature id for the '<em><b>Width</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SIZE__WIDTH = 0;

  /**
   * The feature id for the '<em><b>Height</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SIZE__HEIGHT = 1;

  /**
   * The number of structural features of the '<em>Size</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SIZE_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.BoundsImpl <em>Bounds</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.BoundsImpl
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getBounds()
   * @generated
   */
  int BOUNDS = 9;

  /**
   * The feature id for the '<em><b>X</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BOUNDS__X = 0;

  /**
   * The feature id for the '<em><b>Y</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BOUNDS__Y = 1;

  /**
   * The feature id for the '<em><b>Width</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BOUNDS__WIDTH = 2;

  /**
   * The feature id for the '<em><b>Height</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BOUNDS__HEIGHT = 3;

  /**
   * The number of structural features of the '<em>Bounds</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BOUNDS_FEATURE_COUNT = 4;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.UIElementImpl <em>UI Element</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.UIElementImpl
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getUIElement()
   * @generated
   */
  int UI_ELEMENT = 10;

  /**
   * The feature id for the '<em><b>Bounds</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int UI_ELEMENT__BOUNDS = 0;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int UI_ELEMENT__NAME = 1;

  /**
   * The number of structural features of the '<em>UI Element</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int UI_ELEMENT_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.LabelImpl <em>Label</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.LabelImpl
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getLabel()
   * @generated
   */
  int LABEL = 11;

  /**
   * The feature id for the '<em><b>Bounds</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LABEL__BOUNDS = UI_ELEMENT__BOUNDS;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LABEL__NAME = UI_ELEMENT__NAME;

  /**
   * The feature id for the '<em><b>Text</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LABEL__TEXT = UI_ELEMENT_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Label</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LABEL_FEATURE_COUNT = UI_ELEMENT_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.FieldImpl <em>Field</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.FieldImpl
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getField()
   * @generated
   */
  int FIELD = 12;

  /**
   * The feature id for the '<em><b>Bounds</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FIELD__BOUNDS = UI_ELEMENT__BOUNDS;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FIELD__NAME = UI_ELEMENT__NAME;

  /**
   * The feature id for the '<em><b>Property</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FIELD__PROPERTY = UI_ELEMENT_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Field</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FIELD_FEATURE_COUNT = UI_ELEMENT_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.ButtonImpl <em>Button</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.ButtonImpl
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getButton()
   * @generated
   */
  int BUTTON = 13;

  /**
   * The feature id for the '<em><b>Bounds</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BUTTON__BOUNDS = UI_ELEMENT__BOUNDS;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BUTTON__NAME = UI_ELEMENT__NAME;

  /**
   * The feature id for the '<em><b>Kind</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BUTTON__KIND = UI_ELEMENT_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Text</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BUTTON__TEXT = UI_ELEMENT_FEATURE_COUNT + 1;

  /**
   * The number of structural features of the '<em>Button</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BUTTON_FEATURE_COUNT = UI_ELEMENT_FEATURE_COUNT + 2;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.AttributeType <em>Attribute Type</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.AttributeType
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getAttributeType()
   * @generated
   */
  int ATTRIBUTE_TYPE = 14;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.MultiplicityKind <em>Multiplicity Kind</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.MultiplicityKind
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getMultiplicityKind()
   * @generated
   */
  int MULTIPLICITY_KIND = 15;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.ButtonKind <em>Button Kind</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.ButtonKind
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getButtonKind()
   * @generated
   */
  int BUTTON_KIND = 16;


  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.CrudModel <em>Crud Model</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Crud Model</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.CrudModel
   * @generated
   */
  EClass getCrudModel();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.CrudModel#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.CrudModel#getName()
   * @see #getCrudModel()
   * @generated
   */
  EAttribute getCrudModel_Name();

  /**
   * Returns the meta object for the containment reference list '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.CrudModel#getEntities <em>Entities</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Entities</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.CrudModel#getEntities()
   * @see #getCrudModel()
   * @generated
   */
  EReference getCrudModel_Entities();

  /**
   * Returns the meta object for the containment reference list '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.CrudModel#getWindows <em>Windows</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Windows</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.CrudModel#getWindows()
   * @see #getCrudModel()
   * @generated
   */
  EReference getCrudModel_Windows();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Entity <em>Entity</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Entity</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Entity
   * @generated
   */
  EClass getEntity();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Entity#isAbstract <em>Abstract</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Abstract</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Entity#isAbstract()
   * @see #getEntity()
   * @generated
   */
  EAttribute getEntity_Abstract();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Entity#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Entity#getName()
   * @see #getEntity()
   * @generated
   */
  EAttribute getEntity_Name();

  /**
   * Returns the meta object for the reference '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Entity#getSuperType <em>Super Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Super Type</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Entity#getSuperType()
   * @see #getEntity()
   * @generated
   */
  EReference getEntity_SuperType();

  /**
   * Returns the meta object for the containment reference list '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Entity#getProperties <em>Properties</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Properties</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Entity#getProperties()
   * @see #getEntity()
   * @generated
   */
  EReference getEntity_Properties();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Property <em>Property</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Property</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Property
   * @generated
   */
  EClass getProperty();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Property#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Property#getName()
   * @see #getProperty()
   * @generated
   */
  EAttribute getProperty_Name();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Attribute <em>Attribute</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Attribute</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Attribute
   * @generated
   */
  EClass getAttribute();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Attribute#getType <em>Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Type</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Attribute#getType()
   * @see #getAttribute()
   * @generated
   */
  EAttribute getAttribute_Type();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Attribute#isOptional <em>Optional</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Optional</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Attribute#isOptional()
   * @see #getAttribute()
   * @generated
   */
  EAttribute getAttribute_Optional();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Reference <em>Reference</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Reference</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Reference
   * @generated
   */
  EClass getReference();

  /**
   * Returns the meta object for the reference '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Reference#getType <em>Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Type</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Reference#getType()
   * @see #getReference()
   * @generated
   */
  EReference getReference_Type();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Reference#getMultiplicity <em>Multiplicity</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Multiplicity</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Reference#getMultiplicity()
   * @see #getReference()
   * @generated
   */
  EAttribute getReference_Multiplicity();

  /**
   * Returns the meta object for the reference '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Reference#getOpposite <em>Opposite</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Opposite</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Reference#getOpposite()
   * @see #getReference()
   * @generated
   */
  EReference getReference_Opposite();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Window <em>Window</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Window</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Window
   * @generated
   */
  EClass getWindow();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Window#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Window#getName()
   * @see #getWindow()
   * @generated
   */
  EAttribute getWindow_Name();

  /**
   * Returns the meta object for the reference '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Window#getEntity <em>Entity</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Entity</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Window#getEntity()
   * @see #getWindow()
   * @generated
   */
  EReference getWindow_Entity();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Window#getTitle <em>Title</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Title</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Window#getTitle()
   * @see #getWindow()
   * @generated
   */
  EAttribute getWindow_Title();

  /**
   * Returns the meta object for the containment reference '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Window#getSize <em>Size</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Size</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Window#getSize()
   * @see #getWindow()
   * @generated
   */
  EReference getWindow_Size();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.ListWindow <em>List Window</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>List Window</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.ListWindow
   * @generated
   */
  EClass getListWindow();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.EntryWindow <em>Entry Window</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Entry Window</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.EntryWindow
   * @generated
   */
  EClass getEntryWindow();

  /**
   * Returns the meta object for the containment reference list '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.EntryWindow#getElements <em>Elements</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Elements</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.EntryWindow#getElements()
   * @see #getEntryWindow()
   * @generated
   */
  EReference getEntryWindow_Elements();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Size <em>Size</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Size</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Size
   * @generated
   */
  EClass getSize();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Size#getWidth <em>Width</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Width</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Size#getWidth()
   * @see #getSize()
   * @generated
   */
  EAttribute getSize_Width();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Size#getHeight <em>Height</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Height</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Size#getHeight()
   * @see #getSize()
   * @generated
   */
  EAttribute getSize_Height();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Bounds <em>Bounds</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Bounds</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Bounds
   * @generated
   */
  EClass getBounds();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Bounds#getX <em>X</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>X</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Bounds#getX()
   * @see #getBounds()
   * @generated
   */
  EAttribute getBounds_X();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Bounds#getY <em>Y</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Y</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Bounds#getY()
   * @see #getBounds()
   * @generated
   */
  EAttribute getBounds_Y();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Bounds#getWidth <em>Width</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Width</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Bounds#getWidth()
   * @see #getBounds()
   * @generated
   */
  EAttribute getBounds_Width();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Bounds#getHeight <em>Height</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Height</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Bounds#getHeight()
   * @see #getBounds()
   * @generated
   */
  EAttribute getBounds_Height();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.UIElement <em>UI Element</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>UI Element</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.UIElement
   * @generated
   */
  EClass getUIElement();

  /**
   * Returns the meta object for the containment reference '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.UIElement#getBounds <em>Bounds</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Bounds</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.UIElement#getBounds()
   * @see #getUIElement()
   * @generated
   */
  EReference getUIElement_Bounds();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.UIElement#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.UIElement#getName()
   * @see #getUIElement()
   * @generated
   */
  EAttribute getUIElement_Name();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Label <em>Label</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Label</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Label
   * @generated
   */
  EClass getLabel();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Label#getText <em>Text</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Text</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Label#getText()
   * @see #getLabel()
   * @generated
   */
  EAttribute getLabel_Text();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Field <em>Field</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Field</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Field
   * @generated
   */
  EClass getField();

  /**
   * Returns the meta object for the reference '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Field#getProperty <em>Property</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Property</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Field#getProperty()
   * @see #getField()
   * @generated
   */
  EReference getField_Property();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Button <em>Button</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Button</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Button
   * @generated
   */
  EClass getButton();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Button#getKind <em>Kind</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Kind</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Button#getKind()
   * @see #getButton()
   * @generated
   */
  EAttribute getButton_Kind();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.Button#getText <em>Text</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Text</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.Button#getText()
   * @see #getButton()
   * @generated
   */
  EAttribute getButton_Text();

  /**
   * Returns the meta object for enum '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.AttributeType <em>Attribute Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Attribute Type</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.AttributeType
   * @generated
   */
  EEnum getAttributeType();

  /**
   * Returns the meta object for enum '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.MultiplicityKind <em>Multiplicity Kind</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Multiplicity Kind</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.MultiplicityKind
   * @generated
   */
  EEnum getMultiplicityKind();

  /**
   * Returns the meta object for enum '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.ButtonKind <em>Button Kind</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Button Kind</em>'.
   * @see de.wwu.pi.mdsd.crudDsl.crudDsl.ButtonKind
   * @generated
   */
  EEnum getButtonKind();

  /**
   * Returns the factory that creates the instances of the model.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the factory that creates the instances of the model.
   * @generated
   */
  CrudDslFactory getCrudDslFactory();

  /**
   * <!-- begin-user-doc -->
   * Defines literals for the meta objects that represent
   * <ul>
   *   <li>each class,</li>
   *   <li>each feature of each class,</li>
   *   <li>each enum,</li>
   *   <li>and each data type</li>
   * </ul>
   * <!-- end-user-doc -->
   * @generated
   */
  interface Literals
  {
    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudModelImpl <em>Crud Model</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudModelImpl
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getCrudModel()
     * @generated
     */
    EClass CRUD_MODEL = eINSTANCE.getCrudModel();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute CRUD_MODEL__NAME = eINSTANCE.getCrudModel_Name();

    /**
     * The meta object literal for the '<em><b>Entities</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference CRUD_MODEL__ENTITIES = eINSTANCE.getCrudModel_Entities();

    /**
     * The meta object literal for the '<em><b>Windows</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference CRUD_MODEL__WINDOWS = eINSTANCE.getCrudModel_Windows();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.EntityImpl <em>Entity</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.EntityImpl
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getEntity()
     * @generated
     */
    EClass ENTITY = eINSTANCE.getEntity();

    /**
     * The meta object literal for the '<em><b>Abstract</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ENTITY__ABSTRACT = eINSTANCE.getEntity_Abstract();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ENTITY__NAME = eINSTANCE.getEntity_Name();

    /**
     * The meta object literal for the '<em><b>Super Type</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference ENTITY__SUPER_TYPE = eINSTANCE.getEntity_SuperType();

    /**
     * The meta object literal for the '<em><b>Properties</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference ENTITY__PROPERTIES = eINSTANCE.getEntity_Properties();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.PropertyImpl <em>Property</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.PropertyImpl
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getProperty()
     * @generated
     */
    EClass PROPERTY = eINSTANCE.getProperty();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute PROPERTY__NAME = eINSTANCE.getProperty_Name();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.AttributeImpl <em>Attribute</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.AttributeImpl
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getAttribute()
     * @generated
     */
    EClass ATTRIBUTE = eINSTANCE.getAttribute();

    /**
     * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ATTRIBUTE__TYPE = eINSTANCE.getAttribute_Type();

    /**
     * The meta object literal for the '<em><b>Optional</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ATTRIBUTE__OPTIONAL = eINSTANCE.getAttribute_Optional();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.ReferenceImpl <em>Reference</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.ReferenceImpl
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getReference()
     * @generated
     */
    EClass REFERENCE = eINSTANCE.getReference();

    /**
     * The meta object literal for the '<em><b>Type</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference REFERENCE__TYPE = eINSTANCE.getReference_Type();

    /**
     * The meta object literal for the '<em><b>Multiplicity</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute REFERENCE__MULTIPLICITY = eINSTANCE.getReference_Multiplicity();

    /**
     * The meta object literal for the '<em><b>Opposite</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference REFERENCE__OPPOSITE = eINSTANCE.getReference_Opposite();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.WindowImpl <em>Window</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.WindowImpl
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getWindow()
     * @generated
     */
    EClass WINDOW = eINSTANCE.getWindow();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute WINDOW__NAME = eINSTANCE.getWindow_Name();

    /**
     * The meta object literal for the '<em><b>Entity</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference WINDOW__ENTITY = eINSTANCE.getWindow_Entity();

    /**
     * The meta object literal for the '<em><b>Title</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute WINDOW__TITLE = eINSTANCE.getWindow_Title();

    /**
     * The meta object literal for the '<em><b>Size</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference WINDOW__SIZE = eINSTANCE.getWindow_Size();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.ListWindowImpl <em>List Window</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.ListWindowImpl
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getListWindow()
     * @generated
     */
    EClass LIST_WINDOW = eINSTANCE.getListWindow();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.EntryWindowImpl <em>Entry Window</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.EntryWindowImpl
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getEntryWindow()
     * @generated
     */
    EClass ENTRY_WINDOW = eINSTANCE.getEntryWindow();

    /**
     * The meta object literal for the '<em><b>Elements</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference ENTRY_WINDOW__ELEMENTS = eINSTANCE.getEntryWindow_Elements();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.SizeImpl <em>Size</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.SizeImpl
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getSize()
     * @generated
     */
    EClass SIZE = eINSTANCE.getSize();

    /**
     * The meta object literal for the '<em><b>Width</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SIZE__WIDTH = eINSTANCE.getSize_Width();

    /**
     * The meta object literal for the '<em><b>Height</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SIZE__HEIGHT = eINSTANCE.getSize_Height();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.BoundsImpl <em>Bounds</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.BoundsImpl
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getBounds()
     * @generated
     */
    EClass BOUNDS = eINSTANCE.getBounds();

    /**
     * The meta object literal for the '<em><b>X</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute BOUNDS__X = eINSTANCE.getBounds_X();

    /**
     * The meta object literal for the '<em><b>Y</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute BOUNDS__Y = eINSTANCE.getBounds_Y();

    /**
     * The meta object literal for the '<em><b>Width</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute BOUNDS__WIDTH = eINSTANCE.getBounds_Width();

    /**
     * The meta object literal for the '<em><b>Height</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute BOUNDS__HEIGHT = eINSTANCE.getBounds_Height();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.UIElementImpl <em>UI Element</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.UIElementImpl
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getUIElement()
     * @generated
     */
    EClass UI_ELEMENT = eINSTANCE.getUIElement();

    /**
     * The meta object literal for the '<em><b>Bounds</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference UI_ELEMENT__BOUNDS = eINSTANCE.getUIElement_Bounds();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute UI_ELEMENT__NAME = eINSTANCE.getUIElement_Name();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.LabelImpl <em>Label</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.LabelImpl
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getLabel()
     * @generated
     */
    EClass LABEL = eINSTANCE.getLabel();

    /**
     * The meta object literal for the '<em><b>Text</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute LABEL__TEXT = eINSTANCE.getLabel_Text();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.FieldImpl <em>Field</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.FieldImpl
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getField()
     * @generated
     */
    EClass FIELD = eINSTANCE.getField();

    /**
     * The meta object literal for the '<em><b>Property</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference FIELD__PROPERTY = eINSTANCE.getField_Property();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.impl.ButtonImpl <em>Button</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.ButtonImpl
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getButton()
     * @generated
     */
    EClass BUTTON = eINSTANCE.getButton();

    /**
     * The meta object literal for the '<em><b>Kind</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute BUTTON__KIND = eINSTANCE.getButton_Kind();

    /**
     * The meta object literal for the '<em><b>Text</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute BUTTON__TEXT = eINSTANCE.getButton_Text();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.AttributeType <em>Attribute Type</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.AttributeType
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getAttributeType()
     * @generated
     */
    EEnum ATTRIBUTE_TYPE = eINSTANCE.getAttributeType();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.MultiplicityKind <em>Multiplicity Kind</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.MultiplicityKind
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getMultiplicityKind()
     * @generated
     */
    EEnum MULTIPLICITY_KIND = eINSTANCE.getMultiplicityKind();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd.crudDsl.crudDsl.ButtonKind <em>Button Kind</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.ButtonKind
     * @see de.wwu.pi.mdsd.crudDsl.crudDsl.impl.CrudDslPackageImpl#getButtonKind()
     * @generated
     */
    EEnum BUTTON_KIND = eINSTANCE.getButtonKind();

  }

} //CrudDslPackage
