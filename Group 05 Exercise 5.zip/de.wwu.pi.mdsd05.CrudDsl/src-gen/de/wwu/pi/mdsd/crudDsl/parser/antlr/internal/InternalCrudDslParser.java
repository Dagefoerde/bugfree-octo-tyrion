package de.wwu.pi.mdsd.crudDsl.parser.antlr.internal; 

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import de.wwu.pi.mdsd.crudDsl.services.CrudDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalCrudDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'package'", "'abstract'", "'entity'", "'extends'", "'{'", "'}'", "'att'", "':'", "'optional'", "'ref'", "'opposite='", "'ListWindow'", "'for'", "'title'", "'EntryWindow'", "'size='", "'('", "','", "')'", "'bounds='", "'Label'", "'Field'", "'Button'", "'.'", "'String'", "'Integer'", "'Date'", "'[1]'", "'[*]'", "'createEdit'", "'delete'", "'cancel'"
    };
    public static final int T__42=42;
    public static final int RULE_ID=4;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__29=29;
    public static final int T__28=28;
    public static final int T__27=27;
    public static final int T__26=26;
    public static final int T__25=25;
    public static final int T__24=24;
    public static final int T__23=23;
    public static final int T__22=22;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__21=21;
    public static final int T__20=20;
    public static final int RULE_SL_COMMENT=8;
    public static final int EOF=-1;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__30=30;
    public static final int T__19=19;
    public static final int T__31=31;
    public static final int RULE_STRING=5;
    public static final int T__32=32;
    public static final int T__33=33;
    public static final int T__16=16;
    public static final int T__34=34;
    public static final int T__15=15;
    public static final int T__35=35;
    public static final int T__18=18;
    public static final int T__36=36;
    public static final int T__17=17;
    public static final int T__37=37;
    public static final int T__12=12;
    public static final int T__38=38;
    public static final int T__11=11;
    public static final int T__39=39;
    public static final int T__14=14;
    public static final int T__13=13;
    public static final int RULE_INT=6;
    public static final int RULE_WS=9;

    // delegates
    // delegators


        public InternalCrudDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalCrudDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalCrudDslParser.tokenNames; }
    public String getGrammarFileName() { return "../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g"; }



     	private CrudDslGrammarAccess grammarAccess;
     	
        public InternalCrudDslParser(TokenStream input, CrudDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }
        
        @Override
        protected String getFirstRuleName() {
        	return "CrudModel";	
       	}
       	
       	@Override
       	protected CrudDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}



    // $ANTLR start "entryRuleCrudModel"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:68:1: entryRuleCrudModel returns [EObject current=null] : iv_ruleCrudModel= ruleCrudModel EOF ;
    public final EObject entryRuleCrudModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCrudModel = null;


        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:69:2: (iv_ruleCrudModel= ruleCrudModel EOF )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:70:2: iv_ruleCrudModel= ruleCrudModel EOF
            {
             newCompositeNode(grammarAccess.getCrudModelRule()); 
            pushFollow(FOLLOW_ruleCrudModel_in_entryRuleCrudModel75);
            iv_ruleCrudModel=ruleCrudModel();

            state._fsp--;

             current =iv_ruleCrudModel; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleCrudModel85); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCrudModel"


    // $ANTLR start "ruleCrudModel"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:77:1: ruleCrudModel returns [EObject current=null] : (otherlv_0= 'package' ( (lv_name_1_0= ruleQualifiedName ) ) ( ( (lv_entities_2_0= ruleEntity ) ) | ( (lv_windows_3_0= ruleWindow ) ) )* ) ;
    public final EObject ruleCrudModel() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;

        EObject lv_entities_2_0 = null;

        EObject lv_windows_3_0 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:80:28: ( (otherlv_0= 'package' ( (lv_name_1_0= ruleQualifiedName ) ) ( ( (lv_entities_2_0= ruleEntity ) ) | ( (lv_windows_3_0= ruleWindow ) ) )* ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:81:1: (otherlv_0= 'package' ( (lv_name_1_0= ruleQualifiedName ) ) ( ( (lv_entities_2_0= ruleEntity ) ) | ( (lv_windows_3_0= ruleWindow ) ) )* )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:81:1: (otherlv_0= 'package' ( (lv_name_1_0= ruleQualifiedName ) ) ( ( (lv_entities_2_0= ruleEntity ) ) | ( (lv_windows_3_0= ruleWindow ) ) )* )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:81:3: otherlv_0= 'package' ( (lv_name_1_0= ruleQualifiedName ) ) ( ( (lv_entities_2_0= ruleEntity ) ) | ( (lv_windows_3_0= ruleWindow ) ) )*
            {
            otherlv_0=(Token)match(input,11,FOLLOW_11_in_ruleCrudModel122); 

                	newLeafNode(otherlv_0, grammarAccess.getCrudModelAccess().getPackageKeyword_0());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:85:1: ( (lv_name_1_0= ruleQualifiedName ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:86:1: (lv_name_1_0= ruleQualifiedName )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:86:1: (lv_name_1_0= ruleQualifiedName )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:87:3: lv_name_1_0= ruleQualifiedName
            {
             
            	        newCompositeNode(grammarAccess.getCrudModelAccess().getNameQualifiedNameParserRuleCall_1_0()); 
            	    
            pushFollow(FOLLOW_ruleQualifiedName_in_ruleCrudModel143);
            lv_name_1_0=ruleQualifiedName();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getCrudModelRule());
            	        }
                   		set(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"QualifiedName");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:103:2: ( ( (lv_entities_2_0= ruleEntity ) ) | ( (lv_windows_3_0= ruleWindow ) ) )*
            loop1:
            do {
                int alt1=3;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=12 && LA1_0<=13)) ) {
                    alt1=1;
                }
                else if ( (LA1_0==22||LA1_0==25) ) {
                    alt1=2;
                }


                switch (alt1) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:103:3: ( (lv_entities_2_0= ruleEntity ) )
            	    {
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:103:3: ( (lv_entities_2_0= ruleEntity ) )
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:104:1: (lv_entities_2_0= ruleEntity )
            	    {
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:104:1: (lv_entities_2_0= ruleEntity )
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:105:3: lv_entities_2_0= ruleEntity
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getCrudModelAccess().getEntitiesEntityParserRuleCall_2_0_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleEntity_in_ruleCrudModel165);
            	    lv_entities_2_0=ruleEntity();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getCrudModelRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"entities",
            	            		lv_entities_2_0, 
            	            		"Entity");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }
            	    break;
            	case 2 :
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:122:6: ( (lv_windows_3_0= ruleWindow ) )
            	    {
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:122:6: ( (lv_windows_3_0= ruleWindow ) )
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:123:1: (lv_windows_3_0= ruleWindow )
            	    {
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:123:1: (lv_windows_3_0= ruleWindow )
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:124:3: lv_windows_3_0= ruleWindow
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getCrudModelAccess().getWindowsWindowParserRuleCall_2_1_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleWindow_in_ruleCrudModel192);
            	    lv_windows_3_0=ruleWindow();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getCrudModelRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"windows",
            	            		lv_windows_3_0, 
            	            		"Window");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCrudModel"


    // $ANTLR start "entryRuleEntity"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:148:1: entryRuleEntity returns [EObject current=null] : iv_ruleEntity= ruleEntity EOF ;
    public final EObject entryRuleEntity() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEntity = null;


        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:149:2: (iv_ruleEntity= ruleEntity EOF )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:150:2: iv_ruleEntity= ruleEntity EOF
            {
             newCompositeNode(grammarAccess.getEntityRule()); 
            pushFollow(FOLLOW_ruleEntity_in_entryRuleEntity230);
            iv_ruleEntity=ruleEntity();

            state._fsp--;

             current =iv_ruleEntity; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleEntity240); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEntity"


    // $ANTLR start "ruleEntity"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:157:1: ruleEntity returns [EObject current=null] : ( ( (lv_abstract_0_0= 'abstract' ) )? otherlv_1= 'entity' ( (lv_name_2_0= RULE_ID ) ) (otherlv_3= 'extends' ( (otherlv_4= RULE_ID ) ) )? otherlv_5= '{' ( (lv_properties_6_0= ruleProperty ) )* otherlv_7= '}' ) ;
    public final EObject ruleEntity() throws RecognitionException {
        EObject current = null;

        Token lv_abstract_0_0=null;
        Token otherlv_1=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        EObject lv_properties_6_0 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:160:28: ( ( ( (lv_abstract_0_0= 'abstract' ) )? otherlv_1= 'entity' ( (lv_name_2_0= RULE_ID ) ) (otherlv_3= 'extends' ( (otherlv_4= RULE_ID ) ) )? otherlv_5= '{' ( (lv_properties_6_0= ruleProperty ) )* otherlv_7= '}' ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:161:1: ( ( (lv_abstract_0_0= 'abstract' ) )? otherlv_1= 'entity' ( (lv_name_2_0= RULE_ID ) ) (otherlv_3= 'extends' ( (otherlv_4= RULE_ID ) ) )? otherlv_5= '{' ( (lv_properties_6_0= ruleProperty ) )* otherlv_7= '}' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:161:1: ( ( (lv_abstract_0_0= 'abstract' ) )? otherlv_1= 'entity' ( (lv_name_2_0= RULE_ID ) ) (otherlv_3= 'extends' ( (otherlv_4= RULE_ID ) ) )? otherlv_5= '{' ( (lv_properties_6_0= ruleProperty ) )* otherlv_7= '}' )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:161:2: ( (lv_abstract_0_0= 'abstract' ) )? otherlv_1= 'entity' ( (lv_name_2_0= RULE_ID ) ) (otherlv_3= 'extends' ( (otherlv_4= RULE_ID ) ) )? otherlv_5= '{' ( (lv_properties_6_0= ruleProperty ) )* otherlv_7= '}'
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:161:2: ( (lv_abstract_0_0= 'abstract' ) )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==12) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:162:1: (lv_abstract_0_0= 'abstract' )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:162:1: (lv_abstract_0_0= 'abstract' )
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:163:3: lv_abstract_0_0= 'abstract'
                    {
                    lv_abstract_0_0=(Token)match(input,12,FOLLOW_12_in_ruleEntity283); 

                            newLeafNode(lv_abstract_0_0, grammarAccess.getEntityAccess().getAbstractAbstractKeyword_0_0());
                        

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getEntityRule());
                    	        }
                           		setWithLastConsumed(current, "abstract", true, "abstract");
                    	    

                    }


                    }
                    break;

            }

            otherlv_1=(Token)match(input,13,FOLLOW_13_in_ruleEntity309); 

                	newLeafNode(otherlv_1, grammarAccess.getEntityAccess().getEntityKeyword_1());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:180:1: ( (lv_name_2_0= RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:181:1: (lv_name_2_0= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:181:1: (lv_name_2_0= RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:182:3: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleEntity326); 

            			newLeafNode(lv_name_2_0, grammarAccess.getEntityAccess().getNameIDTerminalRuleCall_2_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getEntityRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_2_0, 
                    		"ID");
            	    

            }


            }

            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:198:2: (otherlv_3= 'extends' ( (otherlv_4= RULE_ID ) ) )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==14) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:198:4: otherlv_3= 'extends' ( (otherlv_4= RULE_ID ) )
                    {
                    otherlv_3=(Token)match(input,14,FOLLOW_14_in_ruleEntity344); 

                        	newLeafNode(otherlv_3, grammarAccess.getEntityAccess().getExtendsKeyword_3_0());
                        
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:202:1: ( (otherlv_4= RULE_ID ) )
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:203:1: (otherlv_4= RULE_ID )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:203:1: (otherlv_4= RULE_ID )
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:204:3: otherlv_4= RULE_ID
                    {

                    			if (current==null) {
                    	            current = createModelElement(grammarAccess.getEntityRule());
                    	        }
                            
                    otherlv_4=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleEntity364); 

                    		newLeafNode(otherlv_4, grammarAccess.getEntityAccess().getSuperTypeEntityCrossReference_3_1_0()); 
                    	

                    }


                    }


                    }
                    break;

            }

            otherlv_5=(Token)match(input,15,FOLLOW_15_in_ruleEntity378); 

                	newLeafNode(otherlv_5, grammarAccess.getEntityAccess().getLeftCurlyBracketKeyword_4());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:219:1: ( (lv_properties_6_0= ruleProperty ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==17||LA4_0==20) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:220:1: (lv_properties_6_0= ruleProperty )
            	    {
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:220:1: (lv_properties_6_0= ruleProperty )
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:221:3: lv_properties_6_0= ruleProperty
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getEntityAccess().getPropertiesPropertyParserRuleCall_5_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleProperty_in_ruleEntity399);
            	    lv_properties_6_0=ruleProperty();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getEntityRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"properties",
            	            		lv_properties_6_0, 
            	            		"Property");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            otherlv_7=(Token)match(input,16,FOLLOW_16_in_ruleEntity412); 

                	newLeafNode(otherlv_7, grammarAccess.getEntityAccess().getRightCurlyBracketKeyword_6());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEntity"


    // $ANTLR start "entryRuleProperty"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:249:1: entryRuleProperty returns [EObject current=null] : iv_ruleProperty= ruleProperty EOF ;
    public final EObject entryRuleProperty() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProperty = null;


        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:250:2: (iv_ruleProperty= ruleProperty EOF )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:251:2: iv_ruleProperty= ruleProperty EOF
            {
             newCompositeNode(grammarAccess.getPropertyRule()); 
            pushFollow(FOLLOW_ruleProperty_in_entryRuleProperty448);
            iv_ruleProperty=ruleProperty();

            state._fsp--;

             current =iv_ruleProperty; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleProperty458); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:258:1: ruleProperty returns [EObject current=null] : (this_Attribute_0= ruleAttribute | this_Reference_1= ruleReference ) ;
    public final EObject ruleProperty() throws RecognitionException {
        EObject current = null;

        EObject this_Attribute_0 = null;

        EObject this_Reference_1 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:261:28: ( (this_Attribute_0= ruleAttribute | this_Reference_1= ruleReference ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:262:1: (this_Attribute_0= ruleAttribute | this_Reference_1= ruleReference )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:262:1: (this_Attribute_0= ruleAttribute | this_Reference_1= ruleReference )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==17) ) {
                alt5=1;
            }
            else if ( (LA5_0==20) ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:263:5: this_Attribute_0= ruleAttribute
                    {
                     
                            newCompositeNode(grammarAccess.getPropertyAccess().getAttributeParserRuleCall_0()); 
                        
                    pushFollow(FOLLOW_ruleAttribute_in_ruleProperty505);
                    this_Attribute_0=ruleAttribute();

                    state._fsp--;

                     
                            current = this_Attribute_0; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:273:5: this_Reference_1= ruleReference
                    {
                     
                            newCompositeNode(grammarAccess.getPropertyAccess().getReferenceParserRuleCall_1()); 
                        
                    pushFollow(FOLLOW_ruleReference_in_ruleProperty532);
                    this_Reference_1=ruleReference();

                    state._fsp--;

                     
                            current = this_Reference_1; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRuleAttribute"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:289:1: entryRuleAttribute returns [EObject current=null] : iv_ruleAttribute= ruleAttribute EOF ;
    public final EObject entryRuleAttribute() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAttribute = null;


        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:290:2: (iv_ruleAttribute= ruleAttribute EOF )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:291:2: iv_ruleAttribute= ruleAttribute EOF
            {
             newCompositeNode(grammarAccess.getAttributeRule()); 
            pushFollow(FOLLOW_ruleAttribute_in_entryRuleAttribute567);
            iv_ruleAttribute=ruleAttribute();

            state._fsp--;

             current =iv_ruleAttribute; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleAttribute577); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAttribute"


    // $ANTLR start "ruleAttribute"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:298:1: ruleAttribute returns [EObject current=null] : (otherlv_0= 'att' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleAttributeType ) ) ( (lv_optional_4_0= 'optional' ) )? ) ;
    public final EObject ruleAttribute() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token lv_optional_4_0=null;
        Enumerator lv_type_3_0 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:301:28: ( (otherlv_0= 'att' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleAttributeType ) ) ( (lv_optional_4_0= 'optional' ) )? ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:302:1: (otherlv_0= 'att' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleAttributeType ) ) ( (lv_optional_4_0= 'optional' ) )? )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:302:1: (otherlv_0= 'att' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleAttributeType ) ) ( (lv_optional_4_0= 'optional' ) )? )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:302:3: otherlv_0= 'att' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleAttributeType ) ) ( (lv_optional_4_0= 'optional' ) )?
            {
            otherlv_0=(Token)match(input,17,FOLLOW_17_in_ruleAttribute614); 

                	newLeafNode(otherlv_0, grammarAccess.getAttributeAccess().getAttKeyword_0());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:306:1: ( (lv_name_1_0= RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:307:1: (lv_name_1_0= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:307:1: (lv_name_1_0= RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:308:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleAttribute631); 

            			newLeafNode(lv_name_1_0, grammarAccess.getAttributeAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getAttributeRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,18,FOLLOW_18_in_ruleAttribute648); 

                	newLeafNode(otherlv_2, grammarAccess.getAttributeAccess().getColonKeyword_2());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:328:1: ( (lv_type_3_0= ruleAttributeType ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:329:1: (lv_type_3_0= ruleAttributeType )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:329:1: (lv_type_3_0= ruleAttributeType )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:330:3: lv_type_3_0= ruleAttributeType
            {
             
            	        newCompositeNode(grammarAccess.getAttributeAccess().getTypeAttributeTypeEnumRuleCall_3_0()); 
            	    
            pushFollow(FOLLOW_ruleAttributeType_in_ruleAttribute669);
            lv_type_3_0=ruleAttributeType();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getAttributeRule());
            	        }
                   		set(
                   			current, 
                   			"type",
                    		lv_type_3_0, 
                    		"AttributeType");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:346:2: ( (lv_optional_4_0= 'optional' ) )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==19) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:347:1: (lv_optional_4_0= 'optional' )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:347:1: (lv_optional_4_0= 'optional' )
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:348:3: lv_optional_4_0= 'optional'
                    {
                    lv_optional_4_0=(Token)match(input,19,FOLLOW_19_in_ruleAttribute687); 

                            newLeafNode(lv_optional_4_0, grammarAccess.getAttributeAccess().getOptionalOptionalKeyword_4_0());
                        

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getAttributeRule());
                    	        }
                           		setWithLastConsumed(current, "optional", true, "optional");
                    	    

                    }


                    }
                    break;

            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAttribute"


    // $ANTLR start "entryRuleReference"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:369:1: entryRuleReference returns [EObject current=null] : iv_ruleReference= ruleReference EOF ;
    public final EObject entryRuleReference() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleReference = null;


        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:370:2: (iv_ruleReference= ruleReference EOF )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:371:2: iv_ruleReference= ruleReference EOF
            {
             newCompositeNode(grammarAccess.getReferenceRule()); 
            pushFollow(FOLLOW_ruleReference_in_entryRuleReference737);
            iv_ruleReference=ruleReference();

            state._fsp--;

             current =iv_ruleReference; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleReference747); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleReference"


    // $ANTLR start "ruleReference"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:378:1: ruleReference returns [EObject current=null] : (otherlv_0= 'ref' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (otherlv_3= RULE_ID ) ) ( (lv_multiplicity_4_0= ruleMultiplicityKind ) )? (otherlv_5= 'opposite=' ( (otherlv_6= RULE_ID ) ) ) ) ;
    public final EObject ruleReference() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Enumerator lv_multiplicity_4_0 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:381:28: ( (otherlv_0= 'ref' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (otherlv_3= RULE_ID ) ) ( (lv_multiplicity_4_0= ruleMultiplicityKind ) )? (otherlv_5= 'opposite=' ( (otherlv_6= RULE_ID ) ) ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:382:1: (otherlv_0= 'ref' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (otherlv_3= RULE_ID ) ) ( (lv_multiplicity_4_0= ruleMultiplicityKind ) )? (otherlv_5= 'opposite=' ( (otherlv_6= RULE_ID ) ) ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:382:1: (otherlv_0= 'ref' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (otherlv_3= RULE_ID ) ) ( (lv_multiplicity_4_0= ruleMultiplicityKind ) )? (otherlv_5= 'opposite=' ( (otherlv_6= RULE_ID ) ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:382:3: otherlv_0= 'ref' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (otherlv_3= RULE_ID ) ) ( (lv_multiplicity_4_0= ruleMultiplicityKind ) )? (otherlv_5= 'opposite=' ( (otherlv_6= RULE_ID ) ) )
            {
            otherlv_0=(Token)match(input,20,FOLLOW_20_in_ruleReference784); 

                	newLeafNode(otherlv_0, grammarAccess.getReferenceAccess().getRefKeyword_0());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:386:1: ( (lv_name_1_0= RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:387:1: (lv_name_1_0= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:387:1: (lv_name_1_0= RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:388:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleReference801); 

            			newLeafNode(lv_name_1_0, grammarAccess.getReferenceAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getReferenceRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,18,FOLLOW_18_in_ruleReference818); 

                	newLeafNode(otherlv_2, grammarAccess.getReferenceAccess().getColonKeyword_2());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:408:1: ( (otherlv_3= RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:409:1: (otherlv_3= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:409:1: (otherlv_3= RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:410:3: otherlv_3= RULE_ID
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getReferenceRule());
            	        }
                    
            otherlv_3=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleReference838); 

            		newLeafNode(otherlv_3, grammarAccess.getReferenceAccess().getTypeEntityCrossReference_3_0()); 
            	

            }


            }

            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:421:2: ( (lv_multiplicity_4_0= ruleMultiplicityKind ) )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( ((LA7_0>=38 && LA7_0<=39)) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:422:1: (lv_multiplicity_4_0= ruleMultiplicityKind )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:422:1: (lv_multiplicity_4_0= ruleMultiplicityKind )
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:423:3: lv_multiplicity_4_0= ruleMultiplicityKind
                    {
                     
                    	        newCompositeNode(grammarAccess.getReferenceAccess().getMultiplicityMultiplicityKindEnumRuleCall_4_0()); 
                    	    
                    pushFollow(FOLLOW_ruleMultiplicityKind_in_ruleReference859);
                    lv_multiplicity_4_0=ruleMultiplicityKind();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getReferenceRule());
                    	        }
                           		set(
                           			current, 
                           			"multiplicity",
                            		lv_multiplicity_4_0, 
                            		"MultiplicityKind");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }
                    break;

            }

            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:439:3: (otherlv_5= 'opposite=' ( (otherlv_6= RULE_ID ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:439:5: otherlv_5= 'opposite=' ( (otherlv_6= RULE_ID ) )
            {
            otherlv_5=(Token)match(input,21,FOLLOW_21_in_ruleReference873); 

                	newLeafNode(otherlv_5, grammarAccess.getReferenceAccess().getOppositeKeyword_5_0());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:443:1: ( (otherlv_6= RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:444:1: (otherlv_6= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:444:1: (otherlv_6= RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:445:3: otherlv_6= RULE_ID
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getReferenceRule());
            	        }
                    
            otherlv_6=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleReference893); 

            		newLeafNode(otherlv_6, grammarAccess.getReferenceAccess().getOppositeReferenceCrossReference_5_1_0()); 
            	

            }


            }


            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleReference"


    // $ANTLR start "entryRuleWindow"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:464:1: entryRuleWindow returns [EObject current=null] : iv_ruleWindow= ruleWindow EOF ;
    public final EObject entryRuleWindow() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleWindow = null;


        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:465:2: (iv_ruleWindow= ruleWindow EOF )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:466:2: iv_ruleWindow= ruleWindow EOF
            {
             newCompositeNode(grammarAccess.getWindowRule()); 
            pushFollow(FOLLOW_ruleWindow_in_entryRuleWindow930);
            iv_ruleWindow=ruleWindow();

            state._fsp--;

             current =iv_ruleWindow; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleWindow940); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleWindow"


    // $ANTLR start "ruleWindow"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:473:1: ruleWindow returns [EObject current=null] : (this_EntryWindow_0= ruleEntryWindow | this_ListWindow_1= ruleListWindow ) ;
    public final EObject ruleWindow() throws RecognitionException {
        EObject current = null;

        EObject this_EntryWindow_0 = null;

        EObject this_ListWindow_1 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:476:28: ( (this_EntryWindow_0= ruleEntryWindow | this_ListWindow_1= ruleListWindow ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:477:1: (this_EntryWindow_0= ruleEntryWindow | this_ListWindow_1= ruleListWindow )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:477:1: (this_EntryWindow_0= ruleEntryWindow | this_ListWindow_1= ruleListWindow )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==25) ) {
                alt8=1;
            }
            else if ( (LA8_0==22) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:478:5: this_EntryWindow_0= ruleEntryWindow
                    {
                     
                            newCompositeNode(grammarAccess.getWindowAccess().getEntryWindowParserRuleCall_0()); 
                        
                    pushFollow(FOLLOW_ruleEntryWindow_in_ruleWindow987);
                    this_EntryWindow_0=ruleEntryWindow();

                    state._fsp--;

                     
                            current = this_EntryWindow_0; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:488:5: this_ListWindow_1= ruleListWindow
                    {
                     
                            newCompositeNode(grammarAccess.getWindowAccess().getListWindowParserRuleCall_1()); 
                        
                    pushFollow(FOLLOW_ruleListWindow_in_ruleWindow1014);
                    this_ListWindow_1=ruleListWindow();

                    state._fsp--;

                     
                            current = this_ListWindow_1; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleWindow"


    // $ANTLR start "entryRuleListWindow"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:504:1: entryRuleListWindow returns [EObject current=null] : iv_ruleListWindow= ruleListWindow EOF ;
    public final EObject entryRuleListWindow() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleListWindow = null;


        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:505:2: (iv_ruleListWindow= ruleListWindow EOF )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:506:2: iv_ruleListWindow= ruleListWindow EOF
            {
             newCompositeNode(grammarAccess.getListWindowRule()); 
            pushFollow(FOLLOW_ruleListWindow_in_entryRuleListWindow1049);
            iv_ruleListWindow=ruleListWindow();

            state._fsp--;

             current =iv_ruleListWindow; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleListWindow1059); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleListWindow"


    // $ANTLR start "ruleListWindow"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:513:1: ruleListWindow returns [EObject current=null] : (otherlv_0= 'ListWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) (otherlv_4= 'title' ( (lv_title_5_0= RULE_STRING ) ) )? ( (lv_size_6_0= ruleSize ) ) ) ;
    public final EObject ruleListWindow() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token lv_title_5_0=null;
        EObject lv_size_6_0 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:516:28: ( (otherlv_0= 'ListWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) (otherlv_4= 'title' ( (lv_title_5_0= RULE_STRING ) ) )? ( (lv_size_6_0= ruleSize ) ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:517:1: (otherlv_0= 'ListWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) (otherlv_4= 'title' ( (lv_title_5_0= RULE_STRING ) ) )? ( (lv_size_6_0= ruleSize ) ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:517:1: (otherlv_0= 'ListWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) (otherlv_4= 'title' ( (lv_title_5_0= RULE_STRING ) ) )? ( (lv_size_6_0= ruleSize ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:517:3: otherlv_0= 'ListWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) (otherlv_4= 'title' ( (lv_title_5_0= RULE_STRING ) ) )? ( (lv_size_6_0= ruleSize ) )
            {
            otherlv_0=(Token)match(input,22,FOLLOW_22_in_ruleListWindow1096); 

                	newLeafNode(otherlv_0, grammarAccess.getListWindowAccess().getListWindowKeyword_0());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:521:1: ( (lv_name_1_0= RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:522:1: (lv_name_1_0= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:522:1: (lv_name_1_0= RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:523:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleListWindow1113); 

            			newLeafNode(lv_name_1_0, grammarAccess.getListWindowAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getListWindowRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,23,FOLLOW_23_in_ruleListWindow1130); 

                	newLeafNode(otherlv_2, grammarAccess.getListWindowAccess().getForKeyword_2());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:543:1: ( (otherlv_3= RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:544:1: (otherlv_3= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:544:1: (otherlv_3= RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:545:3: otherlv_3= RULE_ID
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getListWindowRule());
            	        }
                    
            otherlv_3=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleListWindow1150); 

            		newLeafNode(otherlv_3, grammarAccess.getListWindowAccess().getEntityEntityCrossReference_3_0()); 
            	

            }


            }

            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:556:2: (otherlv_4= 'title' ( (lv_title_5_0= RULE_STRING ) ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==24) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:556:4: otherlv_4= 'title' ( (lv_title_5_0= RULE_STRING ) )
                    {
                    otherlv_4=(Token)match(input,24,FOLLOW_24_in_ruleListWindow1163); 

                        	newLeafNode(otherlv_4, grammarAccess.getListWindowAccess().getTitleKeyword_4_0());
                        
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:560:1: ( (lv_title_5_0= RULE_STRING ) )
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:561:1: (lv_title_5_0= RULE_STRING )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:561:1: (lv_title_5_0= RULE_STRING )
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:562:3: lv_title_5_0= RULE_STRING
                    {
                    lv_title_5_0=(Token)match(input,RULE_STRING,FOLLOW_RULE_STRING_in_ruleListWindow1180); 

                    			newLeafNode(lv_title_5_0, grammarAccess.getListWindowAccess().getTitleSTRINGTerminalRuleCall_4_1_0()); 
                    		

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getListWindowRule());
                    	        }
                           		setWithLastConsumed(
                           			current, 
                           			"title",
                            		lv_title_5_0, 
                            		"STRING");
                    	    

                    }


                    }


                    }
                    break;

            }

            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:578:4: ( (lv_size_6_0= ruleSize ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:579:1: (lv_size_6_0= ruleSize )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:579:1: (lv_size_6_0= ruleSize )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:580:3: lv_size_6_0= ruleSize
            {
             
            	        newCompositeNode(grammarAccess.getListWindowAccess().getSizeSizeParserRuleCall_5_0()); 
            	    
            pushFollow(FOLLOW_ruleSize_in_ruleListWindow1208);
            lv_size_6_0=ruleSize();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getListWindowRule());
            	        }
                   		set(
                   			current, 
                   			"size",
                    		lv_size_6_0, 
                    		"Size");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleListWindow"


    // $ANTLR start "entryRuleEntryWindow"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:604:1: entryRuleEntryWindow returns [EObject current=null] : iv_ruleEntryWindow= ruleEntryWindow EOF ;
    public final EObject entryRuleEntryWindow() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEntryWindow = null;


        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:605:2: (iv_ruleEntryWindow= ruleEntryWindow EOF )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:606:2: iv_ruleEntryWindow= ruleEntryWindow EOF
            {
             newCompositeNode(grammarAccess.getEntryWindowRule()); 
            pushFollow(FOLLOW_ruleEntryWindow_in_entryRuleEntryWindow1244);
            iv_ruleEntryWindow=ruleEntryWindow();

            state._fsp--;

             current =iv_ruleEntryWindow; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleEntryWindow1254); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEntryWindow"


    // $ANTLR start "ruleEntryWindow"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:613:1: ruleEntryWindow returns [EObject current=null] : (otherlv_0= 'EntryWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) ( ( ( ( ({...}? => ( ({...}? => (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_7_0= ruleSize ) ) ) ) ) )+ {...}?) ) ) otherlv_8= '{' ( (lv_elements_9_0= ruleUIElement ) )* otherlv_10= '}' ) ;
    public final EObject ruleEntryWindow() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token lv_title_6_0=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        EObject lv_size_7_0 = null;

        EObject lv_elements_9_0 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:616:28: ( (otherlv_0= 'EntryWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) ( ( ( ( ({...}? => ( ({...}? => (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_7_0= ruleSize ) ) ) ) ) )+ {...}?) ) ) otherlv_8= '{' ( (lv_elements_9_0= ruleUIElement ) )* otherlv_10= '}' ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:617:1: (otherlv_0= 'EntryWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) ( ( ( ( ({...}? => ( ({...}? => (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_7_0= ruleSize ) ) ) ) ) )+ {...}?) ) ) otherlv_8= '{' ( (lv_elements_9_0= ruleUIElement ) )* otherlv_10= '}' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:617:1: (otherlv_0= 'EntryWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) ( ( ( ( ({...}? => ( ({...}? => (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_7_0= ruleSize ) ) ) ) ) )+ {...}?) ) ) otherlv_8= '{' ( (lv_elements_9_0= ruleUIElement ) )* otherlv_10= '}' )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:617:3: otherlv_0= 'EntryWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) ( ( ( ( ({...}? => ( ({...}? => (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_7_0= ruleSize ) ) ) ) ) )+ {...}?) ) ) otherlv_8= '{' ( (lv_elements_9_0= ruleUIElement ) )* otherlv_10= '}'
            {
            otherlv_0=(Token)match(input,25,FOLLOW_25_in_ruleEntryWindow1291); 

                	newLeafNode(otherlv_0, grammarAccess.getEntryWindowAccess().getEntryWindowKeyword_0());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:621:1: ( (lv_name_1_0= RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:622:1: (lv_name_1_0= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:622:1: (lv_name_1_0= RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:623:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleEntryWindow1308); 

            			newLeafNode(lv_name_1_0, grammarAccess.getEntryWindowAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getEntryWindowRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,23,FOLLOW_23_in_ruleEntryWindow1325); 

                	newLeafNode(otherlv_2, grammarAccess.getEntryWindowAccess().getForKeyword_2());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:643:1: ( (otherlv_3= RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:644:1: (otherlv_3= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:644:1: (otherlv_3= RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:645:3: otherlv_3= RULE_ID
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getEntryWindowRule());
            	        }
                    
            otherlv_3=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleEntryWindow1345); 

            		newLeafNode(otherlv_3, grammarAccess.getEntryWindowAccess().getEntityEntityCrossReference_3_0()); 
            	

            }


            }

            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:656:2: ( ( ( ( ({...}? => ( ({...}? => (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_7_0= ruleSize ) ) ) ) ) )+ {...}?) ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:658:1: ( ( ( ({...}? => ( ({...}? => (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_7_0= ruleSize ) ) ) ) ) )+ {...}?) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:658:1: ( ( ( ({...}? => ( ({...}? => (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_7_0= ruleSize ) ) ) ) ) )+ {...}?) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:659:2: ( ( ({...}? => ( ({...}? => (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_7_0= ruleSize ) ) ) ) ) )+ {...}?)
            {
             
            	  getUnorderedGroupHelper().enter(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4());
            	
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:662:2: ( ( ({...}? => ( ({...}? => (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_7_0= ruleSize ) ) ) ) ) )+ {...}?)
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:663:3: ( ({...}? => ( ({...}? => (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_7_0= ruleSize ) ) ) ) ) )+ {...}?
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:663:3: ( ({...}? => ( ({...}? => (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_7_0= ruleSize ) ) ) ) ) )+
            int cnt10=0;
            loop10:
            do {
                int alt10=3;
                int LA10_0 = input.LA(1);

                if ( LA10_0 ==24 && getUnorderedGroupHelper().canSelect(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4(), 0) ) {
                    alt10=1;
                }
                else if ( LA10_0 ==26 && getUnorderedGroupHelper().canSelect(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4(), 1) ) {
                    alt10=2;
                }


                switch (alt10) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:665:4: ({...}? => ( ({...}? => (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) ) ) ) )
            	    {
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:665:4: ({...}? => ( ({...}? => (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) ) ) ) )
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:666:5: {...}? => ( ({...}? => (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4(), 0) ) {
            	        throw new FailedPredicateException(input, "ruleEntryWindow", "getUnorderedGroupHelper().canSelect(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4(), 0)");
            	    }
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:666:108: ( ({...}? => (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) ) ) )
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:667:6: ({...}? => (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4(), 0);
            	    	 				
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:670:6: ({...}? => (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) ) )
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:670:7: {...}? => (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "ruleEntryWindow", "true");
            	    }
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:670:16: (otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) ) )
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:670:18: otherlv_5= 'title' ( (lv_title_6_0= RULE_STRING ) )
            	    {
            	    otherlv_5=(Token)match(input,24,FOLLOW_24_in_ruleEntryWindow1403); 

            	        	newLeafNode(otherlv_5, grammarAccess.getEntryWindowAccess().getTitleKeyword_4_0_0());
            	        
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:674:1: ( (lv_title_6_0= RULE_STRING ) )
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:675:1: (lv_title_6_0= RULE_STRING )
            	    {
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:675:1: (lv_title_6_0= RULE_STRING )
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:676:3: lv_title_6_0= RULE_STRING
            	    {
            	    lv_title_6_0=(Token)match(input,RULE_STRING,FOLLOW_RULE_STRING_in_ruleEntryWindow1420); 

            	    			newLeafNode(lv_title_6_0, grammarAccess.getEntryWindowAccess().getTitleSTRINGTerminalRuleCall_4_0_1_0()); 
            	    		

            	    	        if (current==null) {
            	    	            current = createModelElement(grammarAccess.getEntryWindowRule());
            	    	        }
            	           		setWithLastConsumed(
            	           			current, 
            	           			"title",
            	            		lv_title_6_0, 
            	            		"STRING");
            	    	    

            	    }


            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4());
            	    	 				

            	    }


            	    }


            	    }
            	    break;
            	case 2 :
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:699:4: ({...}? => ( ({...}? => ( (lv_size_7_0= ruleSize ) ) ) ) )
            	    {
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:699:4: ({...}? => ( ({...}? => ( (lv_size_7_0= ruleSize ) ) ) ) )
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:700:5: {...}? => ( ({...}? => ( (lv_size_7_0= ruleSize ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4(), 1) ) {
            	        throw new FailedPredicateException(input, "ruleEntryWindow", "getUnorderedGroupHelper().canSelect(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4(), 1)");
            	    }
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:700:108: ( ({...}? => ( (lv_size_7_0= ruleSize ) ) ) )
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:701:6: ({...}? => ( (lv_size_7_0= ruleSize ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4(), 1);
            	    	 				
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:704:6: ({...}? => ( (lv_size_7_0= ruleSize ) ) )
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:704:7: {...}? => ( (lv_size_7_0= ruleSize ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "ruleEntryWindow", "true");
            	    }
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:704:16: ( (lv_size_7_0= ruleSize ) )
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:705:1: (lv_size_7_0= ruleSize )
            	    {
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:705:1: (lv_size_7_0= ruleSize )
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:706:3: lv_size_7_0= ruleSize
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getEntryWindowAccess().getSizeSizeParserRuleCall_4_1_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleSize_in_ruleEntryWindow1501);
            	    lv_size_7_0=ruleSize();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getEntryWindowRule());
            	    	        }
            	           		set(
            	           			current, 
            	           			"size",
            	            		lv_size_7_0, 
            	            		"Size");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4());
            	    	 				

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt10 >= 1 ) break loop10;
                        EarlyExitException eee =
                            new EarlyExitException(10, input);
                        throw eee;
                }
                cnt10++;
            } while (true);

            if ( ! getUnorderedGroupHelper().canLeave(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4()) ) {
                throw new FailedPredicateException(input, "ruleEntryWindow", "getUnorderedGroupHelper().canLeave(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4())");
            }

            }


            }

             
            	  getUnorderedGroupHelper().leave(grammarAccess.getEntryWindowAccess().getUnorderedGroup_4());
            	

            }

            otherlv_8=(Token)match(input,15,FOLLOW_15_in_ruleEntryWindow1559); 

                	newLeafNode(otherlv_8, grammarAccess.getEntryWindowAccess().getLeftCurlyBracketKeyword_5());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:741:1: ( (lv_elements_9_0= ruleUIElement ) )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( ((LA11_0>=31 && LA11_0<=33)) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:742:1: (lv_elements_9_0= ruleUIElement )
            	    {
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:742:1: (lv_elements_9_0= ruleUIElement )
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:743:3: lv_elements_9_0= ruleUIElement
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getEntryWindowAccess().getElementsUIElementParserRuleCall_6_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleUIElement_in_ruleEntryWindow1580);
            	    lv_elements_9_0=ruleUIElement();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getEntryWindowRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"elements",
            	            		lv_elements_9_0, 
            	            		"UIElement");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

            otherlv_10=(Token)match(input,16,FOLLOW_16_in_ruleEntryWindow1593); 

                	newLeafNode(otherlv_10, grammarAccess.getEntryWindowAccess().getRightCurlyBracketKeyword_7());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEntryWindow"


    // $ANTLR start "entryRuleSize"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:771:1: entryRuleSize returns [EObject current=null] : iv_ruleSize= ruleSize EOF ;
    public final EObject entryRuleSize() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSize = null;


        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:772:2: (iv_ruleSize= ruleSize EOF )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:773:2: iv_ruleSize= ruleSize EOF
            {
             newCompositeNode(grammarAccess.getSizeRule()); 
            pushFollow(FOLLOW_ruleSize_in_entryRuleSize1629);
            iv_ruleSize=ruleSize();

            state._fsp--;

             current =iv_ruleSize; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleSize1639); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSize"


    // $ANTLR start "ruleSize"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:780:1: ruleSize returns [EObject current=null] : (otherlv_0= 'size=' otherlv_1= '(' ( (lv_width_2_0= RULE_INT ) ) otherlv_3= ',' ( (lv_height_4_0= RULE_INT ) ) otherlv_5= ')' ) ;
    public final EObject ruleSize() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_width_2_0=null;
        Token otherlv_3=null;
        Token lv_height_4_0=null;
        Token otherlv_5=null;

         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:783:28: ( (otherlv_0= 'size=' otherlv_1= '(' ( (lv_width_2_0= RULE_INT ) ) otherlv_3= ',' ( (lv_height_4_0= RULE_INT ) ) otherlv_5= ')' ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:784:1: (otherlv_0= 'size=' otherlv_1= '(' ( (lv_width_2_0= RULE_INT ) ) otherlv_3= ',' ( (lv_height_4_0= RULE_INT ) ) otherlv_5= ')' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:784:1: (otherlv_0= 'size=' otherlv_1= '(' ( (lv_width_2_0= RULE_INT ) ) otherlv_3= ',' ( (lv_height_4_0= RULE_INT ) ) otherlv_5= ')' )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:784:3: otherlv_0= 'size=' otherlv_1= '(' ( (lv_width_2_0= RULE_INT ) ) otherlv_3= ',' ( (lv_height_4_0= RULE_INT ) ) otherlv_5= ')'
            {
            otherlv_0=(Token)match(input,26,FOLLOW_26_in_ruleSize1676); 

                	newLeafNode(otherlv_0, grammarAccess.getSizeAccess().getSizeKeyword_0());
                
            otherlv_1=(Token)match(input,27,FOLLOW_27_in_ruleSize1688); 

                	newLeafNode(otherlv_1, grammarAccess.getSizeAccess().getLeftParenthesisKeyword_1());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:792:1: ( (lv_width_2_0= RULE_INT ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:793:1: (lv_width_2_0= RULE_INT )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:793:1: (lv_width_2_0= RULE_INT )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:794:3: lv_width_2_0= RULE_INT
            {
            lv_width_2_0=(Token)match(input,RULE_INT,FOLLOW_RULE_INT_in_ruleSize1705); 

            			newLeafNode(lv_width_2_0, grammarAccess.getSizeAccess().getWidthINTTerminalRuleCall_2_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getSizeRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"width",
                    		lv_width_2_0, 
                    		"INT");
            	    

            }


            }

            otherlv_3=(Token)match(input,28,FOLLOW_28_in_ruleSize1722); 

                	newLeafNode(otherlv_3, grammarAccess.getSizeAccess().getCommaKeyword_3());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:814:1: ( (lv_height_4_0= RULE_INT ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:815:1: (lv_height_4_0= RULE_INT )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:815:1: (lv_height_4_0= RULE_INT )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:816:3: lv_height_4_0= RULE_INT
            {
            lv_height_4_0=(Token)match(input,RULE_INT,FOLLOW_RULE_INT_in_ruleSize1739); 

            			newLeafNode(lv_height_4_0, grammarAccess.getSizeAccess().getHeightINTTerminalRuleCall_4_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getSizeRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"height",
                    		lv_height_4_0, 
                    		"INT");
            	    

            }


            }

            otherlv_5=(Token)match(input,29,FOLLOW_29_in_ruleSize1756); 

                	newLeafNode(otherlv_5, grammarAccess.getSizeAccess().getRightParenthesisKeyword_5());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSize"


    // $ANTLR start "entryRuleBounds"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:844:1: entryRuleBounds returns [EObject current=null] : iv_ruleBounds= ruleBounds EOF ;
    public final EObject entryRuleBounds() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBounds = null;


        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:845:2: (iv_ruleBounds= ruleBounds EOF )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:846:2: iv_ruleBounds= ruleBounds EOF
            {
             newCompositeNode(grammarAccess.getBoundsRule()); 
            pushFollow(FOLLOW_ruleBounds_in_entryRuleBounds1792);
            iv_ruleBounds=ruleBounds();

            state._fsp--;

             current =iv_ruleBounds; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleBounds1802); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBounds"


    // $ANTLR start "ruleBounds"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:853:1: ruleBounds returns [EObject current=null] : ( () otherlv_1= 'bounds=' otherlv_2= '(' ( (lv_x_3_0= RULE_INT ) ) otherlv_4= ',' ( (lv_y_5_0= RULE_INT ) ) otherlv_6= ',' ( (lv_width_7_0= RULE_INT ) ) otherlv_8= ',' ( (lv_height_9_0= RULE_INT ) ) otherlv_10= ')' ) ;
    public final EObject ruleBounds() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_x_3_0=null;
        Token otherlv_4=null;
        Token lv_y_5_0=null;
        Token otherlv_6=null;
        Token lv_width_7_0=null;
        Token otherlv_8=null;
        Token lv_height_9_0=null;
        Token otherlv_10=null;

         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:856:28: ( ( () otherlv_1= 'bounds=' otherlv_2= '(' ( (lv_x_3_0= RULE_INT ) ) otherlv_4= ',' ( (lv_y_5_0= RULE_INT ) ) otherlv_6= ',' ( (lv_width_7_0= RULE_INT ) ) otherlv_8= ',' ( (lv_height_9_0= RULE_INT ) ) otherlv_10= ')' ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:857:1: ( () otherlv_1= 'bounds=' otherlv_2= '(' ( (lv_x_3_0= RULE_INT ) ) otherlv_4= ',' ( (lv_y_5_0= RULE_INT ) ) otherlv_6= ',' ( (lv_width_7_0= RULE_INT ) ) otherlv_8= ',' ( (lv_height_9_0= RULE_INT ) ) otherlv_10= ')' )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:857:1: ( () otherlv_1= 'bounds=' otherlv_2= '(' ( (lv_x_3_0= RULE_INT ) ) otherlv_4= ',' ( (lv_y_5_0= RULE_INT ) ) otherlv_6= ',' ( (lv_width_7_0= RULE_INT ) ) otherlv_8= ',' ( (lv_height_9_0= RULE_INT ) ) otherlv_10= ')' )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:857:2: () otherlv_1= 'bounds=' otherlv_2= '(' ( (lv_x_3_0= RULE_INT ) ) otherlv_4= ',' ( (lv_y_5_0= RULE_INT ) ) otherlv_6= ',' ( (lv_width_7_0= RULE_INT ) ) otherlv_8= ',' ( (lv_height_9_0= RULE_INT ) ) otherlv_10= ')'
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:857:2: ()
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:858:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getBoundsAccess().getBoundsAction_0(),
                        current);
                

            }

            otherlv_1=(Token)match(input,30,FOLLOW_30_in_ruleBounds1848); 

                	newLeafNode(otherlv_1, grammarAccess.getBoundsAccess().getBoundsKeyword_1());
                
            otherlv_2=(Token)match(input,27,FOLLOW_27_in_ruleBounds1860); 

                	newLeafNode(otherlv_2, grammarAccess.getBoundsAccess().getLeftParenthesisKeyword_2());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:871:1: ( (lv_x_3_0= RULE_INT ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:872:1: (lv_x_3_0= RULE_INT )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:872:1: (lv_x_3_0= RULE_INT )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:873:3: lv_x_3_0= RULE_INT
            {
            lv_x_3_0=(Token)match(input,RULE_INT,FOLLOW_RULE_INT_in_ruleBounds1877); 

            			newLeafNode(lv_x_3_0, grammarAccess.getBoundsAccess().getXINTTerminalRuleCall_3_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getBoundsRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"x",
                    		lv_x_3_0, 
                    		"INT");
            	    

            }


            }

            otherlv_4=(Token)match(input,28,FOLLOW_28_in_ruleBounds1894); 

                	newLeafNode(otherlv_4, grammarAccess.getBoundsAccess().getCommaKeyword_4());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:893:1: ( (lv_y_5_0= RULE_INT ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:894:1: (lv_y_5_0= RULE_INT )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:894:1: (lv_y_5_0= RULE_INT )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:895:3: lv_y_5_0= RULE_INT
            {
            lv_y_5_0=(Token)match(input,RULE_INT,FOLLOW_RULE_INT_in_ruleBounds1911); 

            			newLeafNode(lv_y_5_0, grammarAccess.getBoundsAccess().getYINTTerminalRuleCall_5_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getBoundsRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"y",
                    		lv_y_5_0, 
                    		"INT");
            	    

            }


            }

            otherlv_6=(Token)match(input,28,FOLLOW_28_in_ruleBounds1928); 

                	newLeafNode(otherlv_6, grammarAccess.getBoundsAccess().getCommaKeyword_6());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:915:1: ( (lv_width_7_0= RULE_INT ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:916:1: (lv_width_7_0= RULE_INT )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:916:1: (lv_width_7_0= RULE_INT )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:917:3: lv_width_7_0= RULE_INT
            {
            lv_width_7_0=(Token)match(input,RULE_INT,FOLLOW_RULE_INT_in_ruleBounds1945); 

            			newLeafNode(lv_width_7_0, grammarAccess.getBoundsAccess().getWidthINTTerminalRuleCall_7_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getBoundsRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"width",
                    		lv_width_7_0, 
                    		"INT");
            	    

            }


            }

            otherlv_8=(Token)match(input,28,FOLLOW_28_in_ruleBounds1962); 

                	newLeafNode(otherlv_8, grammarAccess.getBoundsAccess().getCommaKeyword_8());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:937:1: ( (lv_height_9_0= RULE_INT ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:938:1: (lv_height_9_0= RULE_INT )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:938:1: (lv_height_9_0= RULE_INT )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:939:3: lv_height_9_0= RULE_INT
            {
            lv_height_9_0=(Token)match(input,RULE_INT,FOLLOW_RULE_INT_in_ruleBounds1979); 

            			newLeafNode(lv_height_9_0, grammarAccess.getBoundsAccess().getHeightINTTerminalRuleCall_9_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getBoundsRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"height",
                    		lv_height_9_0, 
                    		"INT");
            	    

            }


            }

            otherlv_10=(Token)match(input,29,FOLLOW_29_in_ruleBounds1996); 

                	newLeafNode(otherlv_10, grammarAccess.getBoundsAccess().getRightParenthesisKeyword_10());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBounds"


    // $ANTLR start "entryRuleUIElement"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:967:1: entryRuleUIElement returns [EObject current=null] : iv_ruleUIElement= ruleUIElement EOF ;
    public final EObject entryRuleUIElement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUIElement = null;


        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:968:2: (iv_ruleUIElement= ruleUIElement EOF )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:969:2: iv_ruleUIElement= ruleUIElement EOF
            {
             newCompositeNode(grammarAccess.getUIElementRule()); 
            pushFollow(FOLLOW_ruleUIElement_in_entryRuleUIElement2032);
            iv_ruleUIElement=ruleUIElement();

            state._fsp--;

             current =iv_ruleUIElement; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleUIElement2042); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUIElement"


    // $ANTLR start "ruleUIElement"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:976:1: ruleUIElement returns [EObject current=null] : ( (this_Label_0= ruleLabel | this_Field_1= ruleField | this_Button_2= ruleButton ) ( (lv_bounds_3_0= ruleBounds ) ) ) ;
    public final EObject ruleUIElement() throws RecognitionException {
        EObject current = null;

        EObject this_Label_0 = null;

        EObject this_Field_1 = null;

        EObject this_Button_2 = null;

        EObject lv_bounds_3_0 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:979:28: ( ( (this_Label_0= ruleLabel | this_Field_1= ruleField | this_Button_2= ruleButton ) ( (lv_bounds_3_0= ruleBounds ) ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:980:1: ( (this_Label_0= ruleLabel | this_Field_1= ruleField | this_Button_2= ruleButton ) ( (lv_bounds_3_0= ruleBounds ) ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:980:1: ( (this_Label_0= ruleLabel | this_Field_1= ruleField | this_Button_2= ruleButton ) ( (lv_bounds_3_0= ruleBounds ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:980:2: (this_Label_0= ruleLabel | this_Field_1= ruleField | this_Button_2= ruleButton ) ( (lv_bounds_3_0= ruleBounds ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:980:2: (this_Label_0= ruleLabel | this_Field_1= ruleField | this_Button_2= ruleButton )
            int alt12=3;
            switch ( input.LA(1) ) {
            case 31:
                {
                alt12=1;
                }
                break;
            case 32:
                {
                alt12=2;
                }
                break;
            case 33:
                {
                alt12=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }

            switch (alt12) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:981:5: this_Label_0= ruleLabel
                    {
                     
                            newCompositeNode(grammarAccess.getUIElementAccess().getLabelParserRuleCall_0_0()); 
                        
                    pushFollow(FOLLOW_ruleLabel_in_ruleUIElement2090);
                    this_Label_0=ruleLabel();

                    state._fsp--;

                     
                            current = this_Label_0; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:991:5: this_Field_1= ruleField
                    {
                     
                            newCompositeNode(grammarAccess.getUIElementAccess().getFieldParserRuleCall_0_1()); 
                        
                    pushFollow(FOLLOW_ruleField_in_ruleUIElement2117);
                    this_Field_1=ruleField();

                    state._fsp--;

                     
                            current = this_Field_1; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 3 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1001:5: this_Button_2= ruleButton
                    {
                     
                            newCompositeNode(grammarAccess.getUIElementAccess().getButtonParserRuleCall_0_2()); 
                        
                    pushFollow(FOLLOW_ruleButton_in_ruleUIElement2144);
                    this_Button_2=ruleButton();

                    state._fsp--;

                     
                            current = this_Button_2; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;

            }

            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1009:2: ( (lv_bounds_3_0= ruleBounds ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1010:1: (lv_bounds_3_0= ruleBounds )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1010:1: (lv_bounds_3_0= ruleBounds )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1011:3: lv_bounds_3_0= ruleBounds
            {
             
            	        newCompositeNode(grammarAccess.getUIElementAccess().getBoundsBoundsParserRuleCall_1_0()); 
            	    
            pushFollow(FOLLOW_ruleBounds_in_ruleUIElement2165);
            lv_bounds_3_0=ruleBounds();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getUIElementRule());
            	        }
                   		set(
                   			current, 
                   			"bounds",
                    		lv_bounds_3_0, 
                    		"Bounds");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUIElement"


    // $ANTLR start "entryRuleLabel"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1035:1: entryRuleLabel returns [EObject current=null] : iv_ruleLabel= ruleLabel EOF ;
    public final EObject entryRuleLabel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLabel = null;


        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1036:2: (iv_ruleLabel= ruleLabel EOF )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1037:2: iv_ruleLabel= ruleLabel EOF
            {
             newCompositeNode(grammarAccess.getLabelRule()); 
            pushFollow(FOLLOW_ruleLabel_in_entryRuleLabel2201);
            iv_ruleLabel=ruleLabel();

            state._fsp--;

             current =iv_ruleLabel; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleLabel2211); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLabel"


    // $ANTLR start "ruleLabel"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1044:1: ruleLabel returns [EObject current=null] : (otherlv_0= 'Label' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= '(' ( (lv_text_3_0= RULE_STRING ) )? otherlv_4= ')' )? ) ;
    public final EObject ruleLabel() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token lv_text_3_0=null;
        Token otherlv_4=null;

         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1047:28: ( (otherlv_0= 'Label' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= '(' ( (lv_text_3_0= RULE_STRING ) )? otherlv_4= ')' )? ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1048:1: (otherlv_0= 'Label' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= '(' ( (lv_text_3_0= RULE_STRING ) )? otherlv_4= ')' )? )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1048:1: (otherlv_0= 'Label' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= '(' ( (lv_text_3_0= RULE_STRING ) )? otherlv_4= ')' )? )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1048:3: otherlv_0= 'Label' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= '(' ( (lv_text_3_0= RULE_STRING ) )? otherlv_4= ')' )?
            {
            otherlv_0=(Token)match(input,31,FOLLOW_31_in_ruleLabel2248); 

                	newLeafNode(otherlv_0, grammarAccess.getLabelAccess().getLabelKeyword_0());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1052:1: ( (lv_name_1_0= RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1053:1: (lv_name_1_0= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1053:1: (lv_name_1_0= RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1054:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleLabel2265); 

            			newLeafNode(lv_name_1_0, grammarAccess.getLabelAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getLabelRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"ID");
            	    

            }


            }

            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1070:2: (otherlv_2= '(' ( (lv_text_3_0= RULE_STRING ) )? otherlv_4= ')' )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==27) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1070:4: otherlv_2= '(' ( (lv_text_3_0= RULE_STRING ) )? otherlv_4= ')'
                    {
                    otherlv_2=(Token)match(input,27,FOLLOW_27_in_ruleLabel2283); 

                        	newLeafNode(otherlv_2, grammarAccess.getLabelAccess().getLeftParenthesisKeyword_2_0());
                        
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1074:1: ( (lv_text_3_0= RULE_STRING ) )?
                    int alt13=2;
                    int LA13_0 = input.LA(1);

                    if ( (LA13_0==RULE_STRING) ) {
                        alt13=1;
                    }
                    switch (alt13) {
                        case 1 :
                            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1075:1: (lv_text_3_0= RULE_STRING )
                            {
                            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1075:1: (lv_text_3_0= RULE_STRING )
                            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1076:3: lv_text_3_0= RULE_STRING
                            {
                            lv_text_3_0=(Token)match(input,RULE_STRING,FOLLOW_RULE_STRING_in_ruleLabel2300); 

                            			newLeafNode(lv_text_3_0, grammarAccess.getLabelAccess().getTextSTRINGTerminalRuleCall_2_1_0()); 
                            		

                            	        if (current==null) {
                            	            current = createModelElement(grammarAccess.getLabelRule());
                            	        }
                                   		setWithLastConsumed(
                                   			current, 
                                   			"text",
                                    		lv_text_3_0, 
                                    		"STRING");
                            	    

                            }


                            }
                            break;

                    }

                    otherlv_4=(Token)match(input,29,FOLLOW_29_in_ruleLabel2318); 

                        	newLeafNode(otherlv_4, grammarAccess.getLabelAccess().getRightParenthesisKeyword_2_2());
                        

                    }
                    break;

            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLabel"


    // $ANTLR start "entryRuleField"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1104:1: entryRuleField returns [EObject current=null] : iv_ruleField= ruleField EOF ;
    public final EObject entryRuleField() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleField = null;


        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1105:2: (iv_ruleField= ruleField EOF )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1106:2: iv_ruleField= ruleField EOF
            {
             newCompositeNode(grammarAccess.getFieldRule()); 
            pushFollow(FOLLOW_ruleField_in_entryRuleField2356);
            iv_ruleField=ruleField();

            state._fsp--;

             current =iv_ruleField; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleField2366); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleField"


    // $ANTLR start "ruleField"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1113:1: ruleField returns [EObject current=null] : (otherlv_0= 'Field' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) ) ;
    public final EObject ruleField() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;

         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1116:28: ( (otherlv_0= 'Field' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1117:1: (otherlv_0= 'Field' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1117:1: (otherlv_0= 'Field' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1117:3: otherlv_0= 'Field' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,32,FOLLOW_32_in_ruleField2403); 

                	newLeafNode(otherlv_0, grammarAccess.getFieldAccess().getFieldKeyword_0());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1121:1: ( (lv_name_1_0= RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1122:1: (lv_name_1_0= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1122:1: (lv_name_1_0= RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1123:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleField2420); 

            			newLeafNode(lv_name_1_0, grammarAccess.getFieldAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getFieldRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,23,FOLLOW_23_in_ruleField2437); 

                	newLeafNode(otherlv_2, grammarAccess.getFieldAccess().getForKeyword_2());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1143:1: ( (otherlv_3= RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1144:1: (otherlv_3= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1144:1: (otherlv_3= RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1145:3: otherlv_3= RULE_ID
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getFieldRule());
            	        }
                    
            otherlv_3=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleField2457); 

            		newLeafNode(otherlv_3, grammarAccess.getFieldAccess().getPropertyPropertyCrossReference_3_0()); 
            	

            }


            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleField"


    // $ANTLR start "entryRuleButton"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1164:1: entryRuleButton returns [EObject current=null] : iv_ruleButton= ruleButton EOF ;
    public final EObject entryRuleButton() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleButton = null;


        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1165:2: (iv_ruleButton= ruleButton EOF )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1166:2: iv_ruleButton= ruleButton EOF
            {
             newCompositeNode(grammarAccess.getButtonRule()); 
            pushFollow(FOLLOW_ruleButton_in_entryRuleButton2493);
            iv_ruleButton=ruleButton();

            state._fsp--;

             current =iv_ruleButton; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleButton2503); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleButton"


    // $ANTLR start "ruleButton"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1173:1: ruleButton returns [EObject current=null] : (otherlv_0= 'Button' ( (lv_name_1_0= RULE_ID ) ) ( (lv_kind_2_0= ruleButtonKind ) )? (otherlv_3= '(' ( (lv_text_4_0= RULE_STRING ) )? otherlv_5= ')' )? ) ;
    public final EObject ruleButton() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_3=null;
        Token lv_text_4_0=null;
        Token otherlv_5=null;
        Enumerator lv_kind_2_0 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1176:28: ( (otherlv_0= 'Button' ( (lv_name_1_0= RULE_ID ) ) ( (lv_kind_2_0= ruleButtonKind ) )? (otherlv_3= '(' ( (lv_text_4_0= RULE_STRING ) )? otherlv_5= ')' )? ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1177:1: (otherlv_0= 'Button' ( (lv_name_1_0= RULE_ID ) ) ( (lv_kind_2_0= ruleButtonKind ) )? (otherlv_3= '(' ( (lv_text_4_0= RULE_STRING ) )? otherlv_5= ')' )? )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1177:1: (otherlv_0= 'Button' ( (lv_name_1_0= RULE_ID ) ) ( (lv_kind_2_0= ruleButtonKind ) )? (otherlv_3= '(' ( (lv_text_4_0= RULE_STRING ) )? otherlv_5= ')' )? )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1177:3: otherlv_0= 'Button' ( (lv_name_1_0= RULE_ID ) ) ( (lv_kind_2_0= ruleButtonKind ) )? (otherlv_3= '(' ( (lv_text_4_0= RULE_STRING ) )? otherlv_5= ')' )?
            {
            otherlv_0=(Token)match(input,33,FOLLOW_33_in_ruleButton2540); 

                	newLeafNode(otherlv_0, grammarAccess.getButtonAccess().getButtonKeyword_0());
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1181:1: ( (lv_name_1_0= RULE_ID ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1182:1: (lv_name_1_0= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1182:1: (lv_name_1_0= RULE_ID )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1183:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleButton2557); 

            			newLeafNode(lv_name_1_0, grammarAccess.getButtonAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getButtonRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"ID");
            	    

            }


            }

            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1199:2: ( (lv_kind_2_0= ruleButtonKind ) )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( ((LA15_0>=40 && LA15_0<=42)) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1200:1: (lv_kind_2_0= ruleButtonKind )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1200:1: (lv_kind_2_0= ruleButtonKind )
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1201:3: lv_kind_2_0= ruleButtonKind
                    {
                     
                    	        newCompositeNode(grammarAccess.getButtonAccess().getKindButtonKindEnumRuleCall_2_0()); 
                    	    
                    pushFollow(FOLLOW_ruleButtonKind_in_ruleButton2583);
                    lv_kind_2_0=ruleButtonKind();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getButtonRule());
                    	        }
                           		set(
                           			current, 
                           			"kind",
                            		lv_kind_2_0, 
                            		"ButtonKind");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }
                    break;

            }

            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1217:3: (otherlv_3= '(' ( (lv_text_4_0= RULE_STRING ) )? otherlv_5= ')' )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==27) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1217:5: otherlv_3= '(' ( (lv_text_4_0= RULE_STRING ) )? otherlv_5= ')'
                    {
                    otherlv_3=(Token)match(input,27,FOLLOW_27_in_ruleButton2597); 

                        	newLeafNode(otherlv_3, grammarAccess.getButtonAccess().getLeftParenthesisKeyword_3_0());
                        
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1221:1: ( (lv_text_4_0= RULE_STRING ) )?
                    int alt16=2;
                    int LA16_0 = input.LA(1);

                    if ( (LA16_0==RULE_STRING) ) {
                        alt16=1;
                    }
                    switch (alt16) {
                        case 1 :
                            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1222:1: (lv_text_4_0= RULE_STRING )
                            {
                            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1222:1: (lv_text_4_0= RULE_STRING )
                            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1223:3: lv_text_4_0= RULE_STRING
                            {
                            lv_text_4_0=(Token)match(input,RULE_STRING,FOLLOW_RULE_STRING_in_ruleButton2614); 

                            			newLeafNode(lv_text_4_0, grammarAccess.getButtonAccess().getTextSTRINGTerminalRuleCall_3_1_0()); 
                            		

                            	        if (current==null) {
                            	            current = createModelElement(grammarAccess.getButtonRule());
                            	        }
                                   		setWithLastConsumed(
                                   			current, 
                                   			"text",
                                    		lv_text_4_0, 
                                    		"STRING");
                            	    

                            }


                            }
                            break;

                    }

                    otherlv_5=(Token)match(input,29,FOLLOW_29_in_ruleButton2632); 

                        	newLeafNode(otherlv_5, grammarAccess.getButtonAccess().getRightParenthesisKeyword_3_2());
                        

                    }
                    break;

            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleButton"


    // $ANTLR start "entryRuleQualifiedName"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1251:1: entryRuleQualifiedName returns [String current=null] : iv_ruleQualifiedName= ruleQualifiedName EOF ;
    public final String entryRuleQualifiedName() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleQualifiedName = null;


        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1252:2: (iv_ruleQualifiedName= ruleQualifiedName EOF )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1253:2: iv_ruleQualifiedName= ruleQualifiedName EOF
            {
             newCompositeNode(grammarAccess.getQualifiedNameRule()); 
            pushFollow(FOLLOW_ruleQualifiedName_in_entryRuleQualifiedName2671);
            iv_ruleQualifiedName=ruleQualifiedName();

            state._fsp--;

             current =iv_ruleQualifiedName.getText(); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleQualifiedName2682); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleQualifiedName"


    // $ANTLR start "ruleQualifiedName"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1260:1: ruleQualifiedName returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* ) ;
    public final AntlrDatatypeRuleToken ruleQualifiedName() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_ID_0=null;
        Token kw=null;
        Token this_ID_2=null;

         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1263:28: ( (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1264:1: (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1264:1: (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1264:6: this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )*
            {
            this_ID_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleQualifiedName2722); 

            		current.merge(this_ID_0);
                
             
                newLeafNode(this_ID_0, grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_0()); 
                
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1271:1: (kw= '.' this_ID_2= RULE_ID )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( (LA18_0==34) ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1272:2: kw= '.' this_ID_2= RULE_ID
            	    {
            	    kw=(Token)match(input,34,FOLLOW_34_in_ruleQualifiedName2741); 

            	            current.merge(kw);
            	            newLeafNode(kw, grammarAccess.getQualifiedNameAccess().getFullStopKeyword_1_0()); 
            	        
            	    this_ID_2=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleQualifiedName2756); 

            	    		current.merge(this_ID_2);
            	        
            	     
            	        newLeafNode(this_ID_2, grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_1_1()); 
            	        

            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleQualifiedName"


    // $ANTLR start "ruleAttributeType"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1292:1: ruleAttributeType returns [Enumerator current=null] : ( (enumLiteral_0= 'String' ) | (enumLiteral_1= 'Integer' ) | (enumLiteral_2= 'Date' ) ) ;
    public final Enumerator ruleAttributeType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;

         enterRule(); 
        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1294:28: ( ( (enumLiteral_0= 'String' ) | (enumLiteral_1= 'Integer' ) | (enumLiteral_2= 'Date' ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1295:1: ( (enumLiteral_0= 'String' ) | (enumLiteral_1= 'Integer' ) | (enumLiteral_2= 'Date' ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1295:1: ( (enumLiteral_0= 'String' ) | (enumLiteral_1= 'Integer' ) | (enumLiteral_2= 'Date' ) )
            int alt19=3;
            switch ( input.LA(1) ) {
            case 35:
                {
                alt19=1;
                }
                break;
            case 36:
                {
                alt19=2;
                }
                break;
            case 37:
                {
                alt19=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }

            switch (alt19) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1295:2: (enumLiteral_0= 'String' )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1295:2: (enumLiteral_0= 'String' )
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1295:4: enumLiteral_0= 'String'
                    {
                    enumLiteral_0=(Token)match(input,35,FOLLOW_35_in_ruleAttributeType2817); 

                            current = grammarAccess.getAttributeTypeAccess().getStringEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_0, grammarAccess.getAttributeTypeAccess().getStringEnumLiteralDeclaration_0()); 
                        

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1301:6: (enumLiteral_1= 'Integer' )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1301:6: (enumLiteral_1= 'Integer' )
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1301:8: enumLiteral_1= 'Integer'
                    {
                    enumLiteral_1=(Token)match(input,36,FOLLOW_36_in_ruleAttributeType2834); 

                            current = grammarAccess.getAttributeTypeAccess().getIntegerEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_1, grammarAccess.getAttributeTypeAccess().getIntegerEnumLiteralDeclaration_1()); 
                        

                    }


                    }
                    break;
                case 3 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1307:6: (enumLiteral_2= 'Date' )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1307:6: (enumLiteral_2= 'Date' )
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1307:8: enumLiteral_2= 'Date'
                    {
                    enumLiteral_2=(Token)match(input,37,FOLLOW_37_in_ruleAttributeType2851); 

                            current = grammarAccess.getAttributeTypeAccess().getDateEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_2, grammarAccess.getAttributeTypeAccess().getDateEnumLiteralDeclaration_2()); 
                        

                    }


                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAttributeType"


    // $ANTLR start "ruleMultiplicityKind"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1317:1: ruleMultiplicityKind returns [Enumerator current=null] : ( (enumLiteral_0= '[1]' ) | (enumLiteral_1= '[*]' ) ) ;
    public final Enumerator ruleMultiplicityKind() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;

         enterRule(); 
        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1319:28: ( ( (enumLiteral_0= '[1]' ) | (enumLiteral_1= '[*]' ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1320:1: ( (enumLiteral_0= '[1]' ) | (enumLiteral_1= '[*]' ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1320:1: ( (enumLiteral_0= '[1]' ) | (enumLiteral_1= '[*]' ) )
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==38) ) {
                alt20=1;
            }
            else if ( (LA20_0==39) ) {
                alt20=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 20, 0, input);

                throw nvae;
            }
            switch (alt20) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1320:2: (enumLiteral_0= '[1]' )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1320:2: (enumLiteral_0= '[1]' )
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1320:4: enumLiteral_0= '[1]'
                    {
                    enumLiteral_0=(Token)match(input,38,FOLLOW_38_in_ruleMultiplicityKind2896); 

                            current = grammarAccess.getMultiplicityKindAccess().getSingleEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_0, grammarAccess.getMultiplicityKindAccess().getSingleEnumLiteralDeclaration_0()); 
                        

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1326:6: (enumLiteral_1= '[*]' )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1326:6: (enumLiteral_1= '[*]' )
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1326:8: enumLiteral_1= '[*]'
                    {
                    enumLiteral_1=(Token)match(input,39,FOLLOW_39_in_ruleMultiplicityKind2913); 

                            current = grammarAccess.getMultiplicityKindAccess().getMultipleEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_1, grammarAccess.getMultiplicityKindAccess().getMultipleEnumLiteralDeclaration_1()); 
                        

                    }


                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMultiplicityKind"


    // $ANTLR start "ruleButtonKind"
    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1336:1: ruleButtonKind returns [Enumerator current=null] : ( (enumLiteral_0= 'createEdit' ) | (enumLiteral_1= 'delete' ) | (enumLiteral_2= 'cancel' ) ) ;
    public final Enumerator ruleButtonKind() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;

         enterRule(); 
        try {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1338:28: ( ( (enumLiteral_0= 'createEdit' ) | (enumLiteral_1= 'delete' ) | (enumLiteral_2= 'cancel' ) ) )
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1339:1: ( (enumLiteral_0= 'createEdit' ) | (enumLiteral_1= 'delete' ) | (enumLiteral_2= 'cancel' ) )
            {
            // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1339:1: ( (enumLiteral_0= 'createEdit' ) | (enumLiteral_1= 'delete' ) | (enumLiteral_2= 'cancel' ) )
            int alt21=3;
            switch ( input.LA(1) ) {
            case 40:
                {
                alt21=1;
                }
                break;
            case 41:
                {
                alt21=2;
                }
                break;
            case 42:
                {
                alt21=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 21, 0, input);

                throw nvae;
            }

            switch (alt21) {
                case 1 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1339:2: (enumLiteral_0= 'createEdit' )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1339:2: (enumLiteral_0= 'createEdit' )
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1339:4: enumLiteral_0= 'createEdit'
                    {
                    enumLiteral_0=(Token)match(input,40,FOLLOW_40_in_ruleButtonKind2958); 

                            current = grammarAccess.getButtonKindAccess().getCreateEditEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_0, grammarAccess.getButtonKindAccess().getCreateEditEnumLiteralDeclaration_0()); 
                        

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1345:6: (enumLiteral_1= 'delete' )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1345:6: (enumLiteral_1= 'delete' )
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1345:8: enumLiteral_1= 'delete'
                    {
                    enumLiteral_1=(Token)match(input,41,FOLLOW_41_in_ruleButtonKind2975); 

                            current = grammarAccess.getButtonKindAccess().getDeleteEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_1, grammarAccess.getButtonKindAccess().getDeleteEnumLiteralDeclaration_1()); 
                        

                    }


                    }
                    break;
                case 3 :
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1351:6: (enumLiteral_2= 'cancel' )
                    {
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1351:6: (enumLiteral_2= 'cancel' )
                    // ../de.wwu.pi.mdsd.CrudDsl/src-gen/de/wwu/pi/mdsd/crudDsl/parser/antlr/internal/InternalCrudDsl.g:1351:8: enumLiteral_2= 'cancel'
                    {
                    enumLiteral_2=(Token)match(input,42,FOLLOW_42_in_ruleButtonKind2992); 

                            current = grammarAccess.getButtonKindAccess().getCancelEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_2, grammarAccess.getButtonKindAccess().getCancelEnumLiteralDeclaration_2()); 
                        

                    }


                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleButtonKind"

    // Delegated rules


 

    public static final BitSet FOLLOW_ruleCrudModel_in_entryRuleCrudModel75 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleCrudModel85 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_11_in_ruleCrudModel122 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ruleQualifiedName_in_ruleCrudModel143 = new BitSet(new long[]{0x0000000002403002L});
    public static final BitSet FOLLOW_ruleEntity_in_ruleCrudModel165 = new BitSet(new long[]{0x0000000002403002L});
    public static final BitSet FOLLOW_ruleWindow_in_ruleCrudModel192 = new BitSet(new long[]{0x0000000002403002L});
    public static final BitSet FOLLOW_ruleEntity_in_entryRuleEntity230 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleEntity240 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_12_in_ruleEntity283 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_13_in_ruleEntity309 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleEntity326 = new BitSet(new long[]{0x000000000000C000L});
    public static final BitSet FOLLOW_14_in_ruleEntity344 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleEntity364 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_15_in_ruleEntity378 = new BitSet(new long[]{0x0000000000130000L});
    public static final BitSet FOLLOW_ruleProperty_in_ruleEntity399 = new BitSet(new long[]{0x0000000000130000L});
    public static final BitSet FOLLOW_16_in_ruleEntity412 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleProperty_in_entryRuleProperty448 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleProperty458 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAttribute_in_ruleProperty505 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleReference_in_ruleProperty532 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAttribute_in_entryRuleAttribute567 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleAttribute577 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_17_in_ruleAttribute614 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleAttribute631 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_18_in_ruleAttribute648 = new BitSet(new long[]{0x0000003800000000L});
    public static final BitSet FOLLOW_ruleAttributeType_in_ruleAttribute669 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_19_in_ruleAttribute687 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleReference_in_entryRuleReference737 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleReference747 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_20_in_ruleReference784 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleReference801 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_18_in_ruleReference818 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleReference838 = new BitSet(new long[]{0x000000C000200000L});
    public static final BitSet FOLLOW_ruleMultiplicityKind_in_ruleReference859 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_21_in_ruleReference873 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleReference893 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleWindow_in_entryRuleWindow930 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleWindow940 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEntryWindow_in_ruleWindow987 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleListWindow_in_ruleWindow1014 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleListWindow_in_entryRuleListWindow1049 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleListWindow1059 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_22_in_ruleListWindow1096 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleListWindow1113 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_23_in_ruleListWindow1130 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleListWindow1150 = new BitSet(new long[]{0x0000000005000000L});
    public static final BitSet FOLLOW_24_in_ruleListWindow1163 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_RULE_STRING_in_ruleListWindow1180 = new BitSet(new long[]{0x0000000005000000L});
    public static final BitSet FOLLOW_ruleSize_in_ruleListWindow1208 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEntryWindow_in_entryRuleEntryWindow1244 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleEntryWindow1254 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_25_in_ruleEntryWindow1291 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleEntryWindow1308 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_23_in_ruleEntryWindow1325 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleEntryWindow1345 = new BitSet(new long[]{0x0000000005000000L});
    public static final BitSet FOLLOW_24_in_ruleEntryWindow1403 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_RULE_STRING_in_ruleEntryWindow1420 = new BitSet(new long[]{0x0000000005008000L});
    public static final BitSet FOLLOW_ruleSize_in_ruleEntryWindow1501 = new BitSet(new long[]{0x0000000005008000L});
    public static final BitSet FOLLOW_15_in_ruleEntryWindow1559 = new BitSet(new long[]{0x0000000380010000L});
    public static final BitSet FOLLOW_ruleUIElement_in_ruleEntryWindow1580 = new BitSet(new long[]{0x0000000380010000L});
    public static final BitSet FOLLOW_16_in_ruleEntryWindow1593 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleSize_in_entryRuleSize1629 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleSize1639 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_26_in_ruleSize1676 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_27_in_ruleSize1688 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_RULE_INT_in_ruleSize1705 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_28_in_ruleSize1722 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_RULE_INT_in_ruleSize1739 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_29_in_ruleSize1756 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleBounds_in_entryRuleBounds1792 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleBounds1802 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_30_in_ruleBounds1848 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_27_in_ruleBounds1860 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_RULE_INT_in_ruleBounds1877 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_28_in_ruleBounds1894 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_RULE_INT_in_ruleBounds1911 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_28_in_ruleBounds1928 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_RULE_INT_in_ruleBounds1945 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_28_in_ruleBounds1962 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_RULE_INT_in_ruleBounds1979 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_29_in_ruleBounds1996 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleUIElement_in_entryRuleUIElement2032 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleUIElement2042 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleLabel_in_ruleUIElement2090 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_ruleField_in_ruleUIElement2117 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_ruleButton_in_ruleUIElement2144 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_ruleBounds_in_ruleUIElement2165 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleLabel_in_entryRuleLabel2201 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleLabel2211 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_31_in_ruleLabel2248 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleLabel2265 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_27_in_ruleLabel2283 = new BitSet(new long[]{0x0000000020000020L});
    public static final BitSet FOLLOW_RULE_STRING_in_ruleLabel2300 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_29_in_ruleLabel2318 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleField_in_entryRuleField2356 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleField2366 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_32_in_ruleField2403 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleField2420 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_23_in_ruleField2437 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleField2457 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleButton_in_entryRuleButton2493 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleButton2503 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_ruleButton2540 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleButton2557 = new BitSet(new long[]{0x0000070008000002L});
    public static final BitSet FOLLOW_ruleButtonKind_in_ruleButton2583 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_27_in_ruleButton2597 = new BitSet(new long[]{0x0000000020000020L});
    public static final BitSet FOLLOW_RULE_STRING_in_ruleButton2614 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_29_in_ruleButton2632 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleQualifiedName_in_entryRuleQualifiedName2671 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleQualifiedName2682 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleQualifiedName2722 = new BitSet(new long[]{0x0000000400000002L});
    public static final BitSet FOLLOW_34_in_ruleQualifiedName2741 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleQualifiedName2756 = new BitSet(new long[]{0x0000000400000002L});
    public static final BitSet FOLLOW_35_in_ruleAttributeType2817 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_36_in_ruleAttributeType2834 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_37_in_ruleAttributeType2851 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_38_in_ruleMultiplicityKind2896 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_39_in_ruleMultiplicityKind2913 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_40_in_ruleButtonKind2958 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_41_in_ruleButtonKind2975 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_42_in_ruleButtonKind2992 = new BitSet(new long[]{0x0000000000000002L});

}
