package de.wwu.pi.mdsd.crudDsl.util;

import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Attribute;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Bounds;
import de.wwu.pi.mdsd.crudDsl.crudDsl.CrudModel;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Entity;
import de.wwu.pi.mdsd.crudDsl.crudDsl.EntryWindow;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Field;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Property;
import de.wwu.pi.mdsd.crudDsl.crudDsl.Reference;
import de.wwu.pi.mdsd.crudDsl.crudDsl.UIElement;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.Pair;

@SuppressWarnings("all")
public class ModelUtil {
  public static CrudModel getModelElement(final EObject obj) {
    CrudModel _xblockexpression = null;
    {
      if ((obj instanceof CrudModel)) {
        return ((CrudModel) obj);
      }
      EObject _eContainer = obj.eContainer();
      CrudModel _modelElement = ModelUtil.getModelElement(_eContainer);
      _xblockexpression = (_modelElement);
    }
    return _xblockexpression;
  }
  
  public static Iterable<Entity> getAllSupertypes(final Entity e) {
    Entity _superType = e.getSuperType();
    Set<Entity> _emptySet = CollectionLiterals.<Entity>emptySet();
    Iterable<Entity> _allSupertypes = ModelUtil.getAllSupertypes(_superType, _emptySet);
    return _allSupertypes;
  }
  
  private static Iterable<Entity> getAllSupertypes(final Entity e, final Iterable<Entity> resultSet) {
    Iterable<Entity> _xifexpression = null;
    boolean _or = false;
    boolean _equals = Objects.equal(e, null);
    if (_equals) {
      _or = true;
    } else {
      final Function1<Entity,Boolean> _function = new Function1<Entity,Boolean>() {
        public Boolean apply(final Entity it) {
          boolean _equals = Objects.equal(e, it);
          return Boolean.valueOf(_equals);
        }
      };
      boolean _exists = IterableExtensions.<Entity>exists(resultSet, _function);
      _or = (_equals || _exists);
    }
    if (_or) {
      _xifexpression = resultSet;
    } else {
      Entity _superType = e.getSuperType();
      Iterable<Entity> _plus = Iterables.<Entity>concat(Collections.<Entity>unmodifiableSet(Sets.<Entity>newHashSet(e)), resultSet);
      Iterable<Entity> _allSupertypes = ModelUtil.getAllSupertypes(_superType, _plus);
      _xifexpression = _allSupertypes;
    }
    return _xifexpression;
  }
  
  public static Iterable<Property> getProperties(final Entity e, final boolean withSupertypes) {
    Set<Property> _xifexpression = null;
    boolean _and = false;
    if (!withSupertypes) {
      _and = false;
    } else {
      Entity _superType = e.getSuperType();
      boolean _notEquals = (!Objects.equal(_superType, null));
      _and = (withSupertypes && _notEquals);
    }
    if (_and) {
      Set<Property> _xblockexpression = null;
      {
        Iterable<Entity> _allSupertypes = ModelUtil.getAllSupertypes(e);
        Set<Entity> _set = IterableExtensions.<Entity>toSet(_allSupertypes);
        Iterable<Entity> _plus = Iterables.<Entity>concat(_set, Collections.<Entity>unmodifiableSet(Sets.<Entity>newHashSet(e)));
        final Set<Entity> allentities = IterableExtensions.<Entity>toSet(_plus);
        final Function1<Entity,EList<Property>> _function = new Function1<Entity,EList<Property>>() {
          public EList<Property> apply(final Entity it) {
            EList<Property> _properties = it.getProperties();
            return _properties;
          }
        };
        Iterable<EList<Property>> _map = IterableExtensions.<Entity, EList<Property>>map(allentities, _function);
        Iterable<Property> _flatten = Iterables.<Property>concat(_map);
        Set<Property> _set_1 = IterableExtensions.<Property>toSet(_flatten);
        _xblockexpression = (_set_1);
      }
      _xifexpression = _xblockexpression;
    } else {
      EList<Property> _properties = e.getProperties();
      Set<Property> _set = IterableExtensions.<Property>toSet(_properties);
      _xifexpression = _set;
    }
    return _xifexpression;
  }
  
  public static Boolean required(final Property p) {
    Boolean _switchResult = null;
    boolean _matched = false;
    if (!_matched) {
      if (p instanceof Attribute) {
        final Attribute _attribute = (Attribute)p;
        _matched=true;
        boolean _isOptional = _attribute.isOptional();
        boolean _not = (!_isOptional);
        _switchResult = Boolean.valueOf(_not);
      }
    }
    if (!_matched) {
      if (p instanceof Reference) {
        final Reference _reference = (Reference)p;
        _matched=true;
        _switchResult = Boolean.valueOf(true);
      }
    }
    return _switchResult;
  }
  
  public static boolean optional(final Property p) {
    Boolean _required = ModelUtil.required(p);
    boolean _not = (!(_required).booleanValue());
    return _not;
  }
  
  public static Entity getEntity(final Property prop) {
    EObject _eContainer = prop.eContainer();
    return ((Entity) _eContainer);
  }
  
  public static Iterable<Field> allFields(final EntryWindow window) {
    EList<UIElement> _elements = window.getElements();
    Iterable<Field> _filter = Iterables.<Field>filter(_elements, Field.class);
    return _filter;
  }
  
  public static Iterable<Entity> findAll(final Entity e) {
    EList<Property> _properties = e.getProperties();
    Iterable<Entity> _filter = Iterables.<Entity>filter(_properties, Entity.class);
    Iterable<Entity> _plus = Iterables.<Entity>concat(_filter, Collections.<Entity>unmodifiableList(Lists.<Entity>newArrayList(e)));
    return _plus;
  }
  
  public static boolean uiOverlaps(final UIElement first, final UIElement second) {
    boolean _xblockexpression = false;
    {
      final Bounds boundsFirst = first.getBounds();
      final Bounds boundsSecond = second.getBounds();
      boolean _or = false;
      List<Pair<Integer,Integer>> _vertexes = ModelUtil.getVertexes(boundsFirst);
      final Function1<Pair<Integer,Integer>,Boolean> _function = new Function1<Pair<Integer,Integer>,Boolean>() {
        public Boolean apply(final Pair<Integer,Integer> it) {
          boolean _pointWithinBounds = ModelUtil.pointWithinBounds(boundsSecond, it);
          return Boolean.valueOf(_pointWithinBounds);
        }
      };
      boolean _exists = IterableExtensions.<Pair<Integer,Integer>>exists(_vertexes, _function);
      if (_exists) {
        _or = true;
      } else {
        List<Pair<Integer,Integer>> _vertexes_1 = ModelUtil.getVertexes(boundsSecond);
        final Function1<Pair<Integer,Integer>,Boolean> _function_1 = new Function1<Pair<Integer,Integer>,Boolean>() {
          public Boolean apply(final Pair<Integer,Integer> it) {
            boolean _pointWithinBounds = ModelUtil.pointWithinBounds(boundsFirst, it);
            return Boolean.valueOf(_pointWithinBounds);
          }
        };
        boolean _exists_1 = IterableExtensions.<Pair<Integer,Integer>>exists(_vertexes_1, _function_1);
        _or = (_exists || _exists_1);
      }
      _xblockexpression = (_or);
    }
    return _xblockexpression;
  }
  
  public static boolean pointWithinBounds(final Bounds bounds, final Pair<Integer,Integer> point) {
    boolean _and = false;
    boolean _and_1 = false;
    boolean _and_2 = false;
    int _x = bounds.getX();
    Integer _key = point.getKey();
    boolean _lessEqualsThan = (_x <= (_key).intValue());
    if (!_lessEqualsThan) {
      _and_2 = false;
    } else {
      Integer _key_1 = point.getKey();
      int _x_1 = bounds.getX();
      int _width = bounds.getWidth();
      int _plus = (_x_1 + _width);
      boolean _lessEqualsThan_1 = ((_key_1).intValue() <= _plus);
      _and_2 = (_lessEqualsThan && _lessEqualsThan_1);
    }
    if (!_and_2) {
      _and_1 = false;
    } else {
      int _y = bounds.getY();
      Integer _value = point.getValue();
      boolean _lessEqualsThan_2 = (_y <= (_value).intValue());
      _and_1 = (_and_2 && _lessEqualsThan_2);
    }
    if (!_and_1) {
      _and = false;
    } else {
      Integer _value_1 = point.getValue();
      int _y_1 = bounds.getY();
      int _height = bounds.getHeight();
      int _plus_1 = (_y_1 + _height);
      boolean _lessEqualsThan_3 = ((_value_1).intValue() <= _plus_1);
      _and = (_and_1 && _lessEqualsThan_3);
    }
    return _and;
  }
  
  public static List<Pair<Integer,Integer>> getVertexes(final Bounds bounds) {
    List<Pair<Integer,Integer>> _xblockexpression = null;
    {
      int _x = bounds.getX();
      int _y = bounds.getY();
      Pair<Integer,Integer> _pair = new Pair<Integer, Integer>(Integer.valueOf(_x), Integer.valueOf(_y));
      final Pair<Integer,Integer> lu = _pair;
      Integer _key = lu.getKey();
      Integer _value = lu.getValue();
      int _height = bounds.getHeight();
      int _plus = ((_value).intValue() + _height);
      Pair<Integer,Integer> _pair_1 = new Pair<Integer, Integer>(_key, Integer.valueOf(_plus));
      Integer _key_1 = lu.getKey();
      int _width = bounds.getWidth();
      int _plus_1 = ((_key_1).intValue() + _width);
      Integer _value_1 = lu.getValue();
      Pair<Integer,Integer> _pair_2 = new Pair<Integer, Integer>(Integer.valueOf(_plus_1), _value_1);
      Integer _key_2 = lu.getKey();
      int _width_1 = bounds.getWidth();
      int _plus_2 = ((_key_2).intValue() + _width_1);
      Integer _value_2 = lu.getValue();
      int _height_1 = bounds.getHeight();
      int _plus_3 = ((_value_2).intValue() + _height_1);
      Pair<Integer,Integer> _pair_3 = new Pair<Integer, Integer>(Integer.valueOf(_plus_2), Integer.valueOf(_plus_3));
      _xblockexpression = (Collections.<Pair<Integer, Integer>>unmodifiableList(Lists.<Pair<Integer, Integer>>newArrayList(lu, _pair_1, _pair_2, _pair_3)));
    }
    return _xblockexpression;
  }
}
