/**
 */
package de.wwu.pi.mdsd.crudDsl.crudDsl;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>List Window</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.wwu.pi.mdsd.crudDsl.crudDsl.CrudDslPackage#getListWindow()
 * @model
 * @generated
 */
public interface ListWindow extends Window
{
} // ListWindow
