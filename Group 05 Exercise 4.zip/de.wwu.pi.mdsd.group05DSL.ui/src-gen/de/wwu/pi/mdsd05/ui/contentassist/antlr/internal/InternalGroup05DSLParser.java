package de.wwu.pi.mdsd05.ui.contentassist.antlr.internal; 

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ui.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ui.editor.contentassist.antlr.internal.DFA;
import de.wwu.pi.mdsd05.services.Group05DSLGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalGroup05DSLParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'String'", "'Integer'", "'Date'", "'one'", "'multiple'", "'Create/Edit'", "'Delete'", "'Cancel'", "'Package'", "'.'", "'Entitytype'", "'{'", "'}'", "'extends'", "'Attribute'", "'Reference'", "'ListWindow'", "'for'", "'EntryWindow'", "'Label'", "'Field'", "'Button'", "'width'", "'height'", "'x_value'", "'y_value'", "'title'", "'abstract'", "'optional'"
    };
    public static final int RULE_ID=4;
    public static final int T__29=29;
    public static final int T__28=28;
    public static final int T__27=27;
    public static final int T__26=26;
    public static final int T__25=25;
    public static final int T__24=24;
    public static final int T__23=23;
    public static final int T__22=22;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__21=21;
    public static final int T__20=20;
    public static final int RULE_SL_COMMENT=8;
    public static final int EOF=-1;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__30=30;
    public static final int T__19=19;
    public static final int T__31=31;
    public static final int RULE_STRING=5;
    public static final int T__32=32;
    public static final int T__33=33;
    public static final int T__16=16;
    public static final int T__34=34;
    public static final int T__15=15;
    public static final int T__35=35;
    public static final int T__18=18;
    public static final int T__36=36;
    public static final int T__17=17;
    public static final int T__37=37;
    public static final int T__12=12;
    public static final int T__38=38;
    public static final int T__11=11;
    public static final int T__39=39;
    public static final int T__14=14;
    public static final int T__13=13;
    public static final int RULE_INT=6;
    public static final int RULE_WS=9;

    // delegates
    // delegators


        public InternalGroup05DSLParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalGroup05DSLParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalGroup05DSLParser.tokenNames; }
    public String getGrammarFileName() { return "../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g"; }


     
     	private Group05DSLGrammarAccess grammarAccess;
     	
        public void setGrammarAccess(Group05DSLGrammarAccess grammarAccess) {
        	this.grammarAccess = grammarAccess;
        }
        
        @Override
        protected Grammar getGrammar() {
        	return grammarAccess.getGrammar();
        }
        
        @Override
        protected String getValueForTokenName(String tokenName) {
        	return tokenName;
        }




    // $ANTLR start "entryRuleModel"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:60:1: entryRuleModel : ruleModel EOF ;
    public final void entryRuleModel() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:61:1: ( ruleModel EOF )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:62:1: ruleModel EOF
            {
             before(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_ruleModel_in_entryRuleModel61);
            ruleModel();

            state._fsp--;

             after(grammarAccess.getModelRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleModel68); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:69:1: ruleModel : ( ( rule__Model__Group__0 ) ) ;
    public final void ruleModel() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:73:2: ( ( ( rule__Model__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:74:1: ( ( rule__Model__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:74:1: ( ( rule__Model__Group__0 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:75:1: ( rule__Model__Group__0 )
            {
             before(grammarAccess.getModelAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:76:1: ( rule__Model__Group__0 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:76:2: rule__Model__Group__0
            {
            pushFollow(FOLLOW_rule__Model__Group__0_in_ruleModel94);
            rule__Model__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRulePackage"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:88:1: entryRulePackage : rulePackage EOF ;
    public final void entryRulePackage() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:89:1: ( rulePackage EOF )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:90:1: rulePackage EOF
            {
             before(grammarAccess.getPackageRule()); 
            pushFollow(FOLLOW_rulePackage_in_entryRulePackage121);
            rulePackage();

            state._fsp--;

             after(grammarAccess.getPackageRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRulePackage128); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePackage"


    // $ANTLR start "rulePackage"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:97:1: rulePackage : ( ( rule__Package__Group__0 ) ) ;
    public final void rulePackage() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:101:2: ( ( ( rule__Package__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:102:1: ( ( rule__Package__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:102:1: ( ( rule__Package__Group__0 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:103:1: ( rule__Package__Group__0 )
            {
             before(grammarAccess.getPackageAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:104:1: ( rule__Package__Group__0 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:104:2: rule__Package__Group__0
            {
            pushFollow(FOLLOW_rule__Package__Group__0_in_rulePackage154);
            rule__Package__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPackageAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePackage"


    // $ANTLR start "entryRuleQualifiedName"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:116:1: entryRuleQualifiedName : ruleQualifiedName EOF ;
    public final void entryRuleQualifiedName() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:117:1: ( ruleQualifiedName EOF )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:118:1: ruleQualifiedName EOF
            {
             before(grammarAccess.getQualifiedNameRule()); 
            pushFollow(FOLLOW_ruleQualifiedName_in_entryRuleQualifiedName181);
            ruleQualifiedName();

            state._fsp--;

             after(grammarAccess.getQualifiedNameRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleQualifiedName188); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleQualifiedName"


    // $ANTLR start "ruleQualifiedName"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:125:1: ruleQualifiedName : ( ( rule__QualifiedName__Group__0 ) ) ;
    public final void ruleQualifiedName() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:129:2: ( ( ( rule__QualifiedName__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:130:1: ( ( rule__QualifiedName__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:130:1: ( ( rule__QualifiedName__Group__0 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:131:1: ( rule__QualifiedName__Group__0 )
            {
             before(grammarAccess.getQualifiedNameAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:132:1: ( rule__QualifiedName__Group__0 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:132:2: rule__QualifiedName__Group__0
            {
            pushFollow(FOLLOW_rule__QualifiedName__Group__0_in_ruleQualifiedName214);
            rule__QualifiedName__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getQualifiedNameAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleQualifiedName"


    // $ANTLR start "entryRuleEntitytype"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:144:1: entryRuleEntitytype : ruleEntitytype EOF ;
    public final void entryRuleEntitytype() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:145:1: ( ruleEntitytype EOF )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:146:1: ruleEntitytype EOF
            {
             before(grammarAccess.getEntitytypeRule()); 
            pushFollow(FOLLOW_ruleEntitytype_in_entryRuleEntitytype241);
            ruleEntitytype();

            state._fsp--;

             after(grammarAccess.getEntitytypeRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleEntitytype248); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEntitytype"


    // $ANTLR start "ruleEntitytype"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:153:1: ruleEntitytype : ( ( rule__Entitytype__Group__0 ) ) ;
    public final void ruleEntitytype() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:157:2: ( ( ( rule__Entitytype__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:158:1: ( ( rule__Entitytype__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:158:1: ( ( rule__Entitytype__Group__0 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:159:1: ( rule__Entitytype__Group__0 )
            {
             before(grammarAccess.getEntitytypeAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:160:1: ( rule__Entitytype__Group__0 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:160:2: rule__Entitytype__Group__0
            {
            pushFollow(FOLLOW_rule__Entitytype__Group__0_in_ruleEntitytype274);
            rule__Entitytype__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEntitytypeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEntitytype"


    // $ANTLR start "entryRuleProperty"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:172:1: entryRuleProperty : ruleProperty EOF ;
    public final void entryRuleProperty() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:173:1: ( ruleProperty EOF )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:174:1: ruleProperty EOF
            {
             before(grammarAccess.getPropertyRule()); 
            pushFollow(FOLLOW_ruleProperty_in_entryRuleProperty301);
            ruleProperty();

            state._fsp--;

             after(grammarAccess.getPropertyRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleProperty308); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:181:1: ruleProperty : ( ( rule__Property__Alternatives ) ) ;
    public final void ruleProperty() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:185:2: ( ( ( rule__Property__Alternatives ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:186:1: ( ( rule__Property__Alternatives ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:186:1: ( ( rule__Property__Alternatives ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:187:1: ( rule__Property__Alternatives )
            {
             before(grammarAccess.getPropertyAccess().getAlternatives()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:188:1: ( rule__Property__Alternatives )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:188:2: rule__Property__Alternatives
            {
            pushFollow(FOLLOW_rule__Property__Alternatives_in_ruleProperty334);
            rule__Property__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getPropertyAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRuleAttribute"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:200:1: entryRuleAttribute : ruleAttribute EOF ;
    public final void entryRuleAttribute() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:201:1: ( ruleAttribute EOF )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:202:1: ruleAttribute EOF
            {
             before(grammarAccess.getAttributeRule()); 
            pushFollow(FOLLOW_ruleAttribute_in_entryRuleAttribute361);
            ruleAttribute();

            state._fsp--;

             after(grammarAccess.getAttributeRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleAttribute368); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAttribute"


    // $ANTLR start "ruleAttribute"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:209:1: ruleAttribute : ( ( rule__Attribute__Group__0 ) ) ;
    public final void ruleAttribute() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:213:2: ( ( ( rule__Attribute__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:214:1: ( ( rule__Attribute__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:214:1: ( ( rule__Attribute__Group__0 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:215:1: ( rule__Attribute__Group__0 )
            {
             before(grammarAccess.getAttributeAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:216:1: ( rule__Attribute__Group__0 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:216:2: rule__Attribute__Group__0
            {
            pushFollow(FOLLOW_rule__Attribute__Group__0_in_ruleAttribute394);
            rule__Attribute__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getAttributeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAttribute"


    // $ANTLR start "entryRuleReference"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:228:1: entryRuleReference : ruleReference EOF ;
    public final void entryRuleReference() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:229:1: ( ruleReference EOF )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:230:1: ruleReference EOF
            {
             before(grammarAccess.getReferenceRule()); 
            pushFollow(FOLLOW_ruleReference_in_entryRuleReference421);
            ruleReference();

            state._fsp--;

             after(grammarAccess.getReferenceRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleReference428); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleReference"


    // $ANTLR start "ruleReference"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:237:1: ruleReference : ( ( rule__Reference__Group__0 ) ) ;
    public final void ruleReference() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:241:2: ( ( ( rule__Reference__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:242:1: ( ( rule__Reference__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:242:1: ( ( rule__Reference__Group__0 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:243:1: ( rule__Reference__Group__0 )
            {
             before(grammarAccess.getReferenceAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:244:1: ( rule__Reference__Group__0 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:244:2: rule__Reference__Group__0
            {
            pushFollow(FOLLOW_rule__Reference__Group__0_in_ruleReference454);
            rule__Reference__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getReferenceAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleReference"


    // $ANTLR start "entryRuleUIWindow"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:256:1: entryRuleUIWindow : ruleUIWindow EOF ;
    public final void entryRuleUIWindow() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:257:1: ( ruleUIWindow EOF )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:258:1: ruleUIWindow EOF
            {
             before(grammarAccess.getUIWindowRule()); 
            pushFollow(FOLLOW_ruleUIWindow_in_entryRuleUIWindow481);
            ruleUIWindow();

            state._fsp--;

             after(grammarAccess.getUIWindowRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleUIWindow488); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleUIWindow"


    // $ANTLR start "ruleUIWindow"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:265:1: ruleUIWindow : ( ( rule__UIWindow__Alternatives ) ) ;
    public final void ruleUIWindow() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:269:2: ( ( ( rule__UIWindow__Alternatives ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:270:1: ( ( rule__UIWindow__Alternatives ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:270:1: ( ( rule__UIWindow__Alternatives ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:271:1: ( rule__UIWindow__Alternatives )
            {
             before(grammarAccess.getUIWindowAccess().getAlternatives()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:272:1: ( rule__UIWindow__Alternatives )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:272:2: rule__UIWindow__Alternatives
            {
            pushFollow(FOLLOW_rule__UIWindow__Alternatives_in_ruleUIWindow514);
            rule__UIWindow__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getUIWindowAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleUIWindow"


    // $ANTLR start "entryRuleListWindow"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:284:1: entryRuleListWindow : ruleListWindow EOF ;
    public final void entryRuleListWindow() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:285:1: ( ruleListWindow EOF )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:286:1: ruleListWindow EOF
            {
             before(grammarAccess.getListWindowRule()); 
            pushFollow(FOLLOW_ruleListWindow_in_entryRuleListWindow541);
            ruleListWindow();

            state._fsp--;

             after(grammarAccess.getListWindowRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleListWindow548); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleListWindow"


    // $ANTLR start "ruleListWindow"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:293:1: ruleListWindow : ( ( rule__ListWindow__Group__0 ) ) ;
    public final void ruleListWindow() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:297:2: ( ( ( rule__ListWindow__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:298:1: ( ( rule__ListWindow__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:298:1: ( ( rule__ListWindow__Group__0 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:299:1: ( rule__ListWindow__Group__0 )
            {
             before(grammarAccess.getListWindowAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:300:1: ( rule__ListWindow__Group__0 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:300:2: rule__ListWindow__Group__0
            {
            pushFollow(FOLLOW_rule__ListWindow__Group__0_in_ruleListWindow574);
            rule__ListWindow__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getListWindowAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleListWindow"


    // $ANTLR start "entryRuleEntryWindow"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:312:1: entryRuleEntryWindow : ruleEntryWindow EOF ;
    public final void entryRuleEntryWindow() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:313:1: ( ruleEntryWindow EOF )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:314:1: ruleEntryWindow EOF
            {
             before(grammarAccess.getEntryWindowRule()); 
            pushFollow(FOLLOW_ruleEntryWindow_in_entryRuleEntryWindow601);
            ruleEntryWindow();

            state._fsp--;

             after(grammarAccess.getEntryWindowRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleEntryWindow608); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEntryWindow"


    // $ANTLR start "ruleEntryWindow"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:321:1: ruleEntryWindow : ( ( rule__EntryWindow__Group__0 ) ) ;
    public final void ruleEntryWindow() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:325:2: ( ( ( rule__EntryWindow__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:326:1: ( ( rule__EntryWindow__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:326:1: ( ( rule__EntryWindow__Group__0 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:327:1: ( rule__EntryWindow__Group__0 )
            {
             before(grammarAccess.getEntryWindowAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:328:1: ( rule__EntryWindow__Group__0 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:328:2: rule__EntryWindow__Group__0
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group__0_in_ruleEntryWindow634);
            rule__EntryWindow__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEntryWindowAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEntryWindow"


    // $ANTLR start "entryRuleUIElement"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:340:1: entryRuleUIElement : ruleUIElement EOF ;
    public final void entryRuleUIElement() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:341:1: ( ruleUIElement EOF )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:342:1: ruleUIElement EOF
            {
             before(grammarAccess.getUIElementRule()); 
            pushFollow(FOLLOW_ruleUIElement_in_entryRuleUIElement661);
            ruleUIElement();

            state._fsp--;

             after(grammarAccess.getUIElementRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleUIElement668); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleUIElement"


    // $ANTLR start "ruleUIElement"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:349:1: ruleUIElement : ( ( rule__UIElement__Group__0 ) ) ;
    public final void ruleUIElement() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:353:2: ( ( ( rule__UIElement__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:354:1: ( ( rule__UIElement__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:354:1: ( ( rule__UIElement__Group__0 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:355:1: ( rule__UIElement__Group__0 )
            {
             before(grammarAccess.getUIElementAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:356:1: ( rule__UIElement__Group__0 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:356:2: rule__UIElement__Group__0
            {
            pushFollow(FOLLOW_rule__UIElement__Group__0_in_ruleUIElement694);
            rule__UIElement__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getUIElementAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleUIElement"


    // $ANTLR start "entryRuleUIOptions"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:368:1: entryRuleUIOptions : ruleUIOptions EOF ;
    public final void entryRuleUIOptions() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:369:1: ( ruleUIOptions EOF )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:370:1: ruleUIOptions EOF
            {
             before(grammarAccess.getUIOptionsRule()); 
            pushFollow(FOLLOW_ruleUIOptions_in_entryRuleUIOptions721);
            ruleUIOptions();

            state._fsp--;

             after(grammarAccess.getUIOptionsRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleUIOptions728); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleUIOptions"


    // $ANTLR start "ruleUIOptions"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:377:1: ruleUIOptions : ( ( rule__UIOptions__UnorderedGroup ) ) ;
    public final void ruleUIOptions() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:381:2: ( ( ( rule__UIOptions__UnorderedGroup ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:382:1: ( ( rule__UIOptions__UnorderedGroup ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:382:1: ( ( rule__UIOptions__UnorderedGroup ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:383:1: ( rule__UIOptions__UnorderedGroup )
            {
             before(grammarAccess.getUIOptionsAccess().getUnorderedGroup()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:384:1: ( rule__UIOptions__UnorderedGroup )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:384:2: rule__UIOptions__UnorderedGroup
            {
            pushFollow(FOLLOW_rule__UIOptions__UnorderedGroup_in_ruleUIOptions754);
            rule__UIOptions__UnorderedGroup();

            state._fsp--;


            }

             after(grammarAccess.getUIOptionsAccess().getUnorderedGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleUIOptions"


    // $ANTLR start "entryRuleLabel"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:396:1: entryRuleLabel : ruleLabel EOF ;
    public final void entryRuleLabel() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:397:1: ( ruleLabel EOF )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:398:1: ruleLabel EOF
            {
             before(grammarAccess.getLabelRule()); 
            pushFollow(FOLLOW_ruleLabel_in_entryRuleLabel781);
            ruleLabel();

            state._fsp--;

             after(grammarAccess.getLabelRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleLabel788); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLabel"


    // $ANTLR start "ruleLabel"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:405:1: ruleLabel : ( ( rule__Label__Group__0 ) ) ;
    public final void ruleLabel() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:409:2: ( ( ( rule__Label__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:410:1: ( ( rule__Label__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:410:1: ( ( rule__Label__Group__0 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:411:1: ( rule__Label__Group__0 )
            {
             before(grammarAccess.getLabelAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:412:1: ( rule__Label__Group__0 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:412:2: rule__Label__Group__0
            {
            pushFollow(FOLLOW_rule__Label__Group__0_in_ruleLabel814);
            rule__Label__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getLabelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLabel"


    // $ANTLR start "entryRuleField"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:424:1: entryRuleField : ruleField EOF ;
    public final void entryRuleField() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:425:1: ( ruleField EOF )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:426:1: ruleField EOF
            {
             before(grammarAccess.getFieldRule()); 
            pushFollow(FOLLOW_ruleField_in_entryRuleField841);
            ruleField();

            state._fsp--;

             after(grammarAccess.getFieldRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleField848); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleField"


    // $ANTLR start "ruleField"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:433:1: ruleField : ( ( rule__Field__Group__0 ) ) ;
    public final void ruleField() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:437:2: ( ( ( rule__Field__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:438:1: ( ( rule__Field__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:438:1: ( ( rule__Field__Group__0 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:439:1: ( rule__Field__Group__0 )
            {
             before(grammarAccess.getFieldAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:440:1: ( rule__Field__Group__0 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:440:2: rule__Field__Group__0
            {
            pushFollow(FOLLOW_rule__Field__Group__0_in_ruleField874);
            rule__Field__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleField"


    // $ANTLR start "entryRuleButton"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:452:1: entryRuleButton : ruleButton EOF ;
    public final void entryRuleButton() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:453:1: ( ruleButton EOF )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:454:1: ruleButton EOF
            {
             before(grammarAccess.getButtonRule()); 
            pushFollow(FOLLOW_ruleButton_in_entryRuleButton901);
            ruleButton();

            state._fsp--;

             after(grammarAccess.getButtonRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleButton908); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleButton"


    // $ANTLR start "ruleButton"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:461:1: ruleButton : ( ( rule__Button__Group__0 ) ) ;
    public final void ruleButton() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:465:2: ( ( ( rule__Button__Group__0 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:466:1: ( ( rule__Button__Group__0 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:466:1: ( ( rule__Button__Group__0 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:467:1: ( rule__Button__Group__0 )
            {
             before(grammarAccess.getButtonAccess().getGroup()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:468:1: ( rule__Button__Group__0 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:468:2: rule__Button__Group__0
            {
            pushFollow(FOLLOW_rule__Button__Group__0_in_ruleButton934);
            rule__Button__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getButtonAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleButton"


    // $ANTLR start "entryRuleSize"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:480:1: entryRuleSize : ruleSize EOF ;
    public final void entryRuleSize() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:481:1: ( ruleSize EOF )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:482:1: ruleSize EOF
            {
             before(grammarAccess.getSizeRule()); 
            pushFollow(FOLLOW_ruleSize_in_entryRuleSize961);
            ruleSize();

            state._fsp--;

             after(grammarAccess.getSizeRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleSize968); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSize"


    // $ANTLR start "ruleSize"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:489:1: ruleSize : ( ( rule__Size__UnorderedGroup ) ) ;
    public final void ruleSize() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:493:2: ( ( ( rule__Size__UnorderedGroup ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:494:1: ( ( rule__Size__UnorderedGroup ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:494:1: ( ( rule__Size__UnorderedGroup ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:495:1: ( rule__Size__UnorderedGroup )
            {
             before(grammarAccess.getSizeAccess().getUnorderedGroup()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:496:1: ( rule__Size__UnorderedGroup )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:496:2: rule__Size__UnorderedGroup
            {
            pushFollow(FOLLOW_rule__Size__UnorderedGroup_in_ruleSize994);
            rule__Size__UnorderedGroup();

            state._fsp--;


            }

             after(grammarAccess.getSizeAccess().getUnorderedGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSize"


    // $ANTLR start "entryRulePosition"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:508:1: entryRulePosition : rulePosition EOF ;
    public final void entryRulePosition() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:509:1: ( rulePosition EOF )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:510:1: rulePosition EOF
            {
             before(grammarAccess.getPositionRule()); 
            pushFollow(FOLLOW_rulePosition_in_entryRulePosition1021);
            rulePosition();

            state._fsp--;

             after(grammarAccess.getPositionRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRulePosition1028); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePosition"


    // $ANTLR start "rulePosition"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:517:1: rulePosition : ( ( rule__Position__UnorderedGroup ) ) ;
    public final void rulePosition() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:521:2: ( ( ( rule__Position__UnorderedGroup ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:522:1: ( ( rule__Position__UnorderedGroup ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:522:1: ( ( rule__Position__UnorderedGroup ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:523:1: ( rule__Position__UnorderedGroup )
            {
             before(grammarAccess.getPositionAccess().getUnorderedGroup()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:524:1: ( rule__Position__UnorderedGroup )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:524:2: rule__Position__UnorderedGroup
            {
            pushFollow(FOLLOW_rule__Position__UnorderedGroup_in_rulePosition1054);
            rule__Position__UnorderedGroup();

            state._fsp--;


            }

             after(grammarAccess.getPositionAccess().getUnorderedGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePosition"


    // $ANTLR start "entryRuleWindowOptions"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:536:1: entryRuleWindowOptions : ruleWindowOptions EOF ;
    public final void entryRuleWindowOptions() throws RecognitionException {
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:537:1: ( ruleWindowOptions EOF )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:538:1: ruleWindowOptions EOF
            {
             before(grammarAccess.getWindowOptionsRule()); 
            pushFollow(FOLLOW_ruleWindowOptions_in_entryRuleWindowOptions1081);
            ruleWindowOptions();

            state._fsp--;

             after(grammarAccess.getWindowOptionsRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleWindowOptions1088); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleWindowOptions"


    // $ANTLR start "ruleWindowOptions"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:545:1: ruleWindowOptions : ( ( rule__WindowOptions__UnorderedGroup ) ) ;
    public final void ruleWindowOptions() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:549:2: ( ( ( rule__WindowOptions__UnorderedGroup ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:550:1: ( ( rule__WindowOptions__UnorderedGroup ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:550:1: ( ( rule__WindowOptions__UnorderedGroup ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:551:1: ( rule__WindowOptions__UnorderedGroup )
            {
             before(grammarAccess.getWindowOptionsAccess().getUnorderedGroup()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:552:1: ( rule__WindowOptions__UnorderedGroup )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:552:2: rule__WindowOptions__UnorderedGroup
            {
            pushFollow(FOLLOW_rule__WindowOptions__UnorderedGroup_in_ruleWindowOptions1114);
            rule__WindowOptions__UnorderedGroup();

            state._fsp--;


            }

             after(grammarAccess.getWindowOptionsAccess().getUnorderedGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleWindowOptions"


    // $ANTLR start "ruleBasicType"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:565:1: ruleBasicType : ( ( rule__BasicType__Alternatives ) ) ;
    public final void ruleBasicType() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:569:1: ( ( ( rule__BasicType__Alternatives ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:570:1: ( ( rule__BasicType__Alternatives ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:570:1: ( ( rule__BasicType__Alternatives ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:571:1: ( rule__BasicType__Alternatives )
            {
             before(grammarAccess.getBasicTypeAccess().getAlternatives()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:572:1: ( rule__BasicType__Alternatives )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:572:2: rule__BasicType__Alternatives
            {
            pushFollow(FOLLOW_rule__BasicType__Alternatives_in_ruleBasicType1151);
            rule__BasicType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getBasicTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleBasicType"


    // $ANTLR start "ruleMultiplicity"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:584:1: ruleMultiplicity : ( ( rule__Multiplicity__Alternatives ) ) ;
    public final void ruleMultiplicity() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:588:1: ( ( ( rule__Multiplicity__Alternatives ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:589:1: ( ( rule__Multiplicity__Alternatives ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:589:1: ( ( rule__Multiplicity__Alternatives ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:590:1: ( rule__Multiplicity__Alternatives )
            {
             before(grammarAccess.getMultiplicityAccess().getAlternatives()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:591:1: ( rule__Multiplicity__Alternatives )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:591:2: rule__Multiplicity__Alternatives
            {
            pushFollow(FOLLOW_rule__Multiplicity__Alternatives_in_ruleMultiplicity1187);
            rule__Multiplicity__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getMultiplicityAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMultiplicity"


    // $ANTLR start "ruleInscription"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:603:1: ruleInscription : ( ( rule__Inscription__Alternatives ) ) ;
    public final void ruleInscription() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:607:1: ( ( ( rule__Inscription__Alternatives ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:608:1: ( ( rule__Inscription__Alternatives ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:608:1: ( ( rule__Inscription__Alternatives ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:609:1: ( rule__Inscription__Alternatives )
            {
             before(grammarAccess.getInscriptionAccess().getAlternatives()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:610:1: ( rule__Inscription__Alternatives )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:610:2: rule__Inscription__Alternatives
            {
            pushFollow(FOLLOW_rule__Inscription__Alternatives_in_ruleInscription1223);
            rule__Inscription__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getInscriptionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleInscription"


    // $ANTLR start "rule__Model__Alternatives_1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:621:1: rule__Model__Alternatives_1 : ( ( ( rule__Model__EntitytypesAssignment_1_0 ) ) | ( ( rule__Model__UiwindowsAssignment_1_1 ) ) );
    public final void rule__Model__Alternatives_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:625:1: ( ( ( rule__Model__EntitytypesAssignment_1_0 ) ) | ( ( rule__Model__UiwindowsAssignment_1_1 ) ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==21||LA1_0==38) ) {
                alt1=1;
            }
            else if ( (LA1_0==27||LA1_0==29) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:626:1: ( ( rule__Model__EntitytypesAssignment_1_0 ) )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:626:1: ( ( rule__Model__EntitytypesAssignment_1_0 ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:627:1: ( rule__Model__EntitytypesAssignment_1_0 )
                    {
                     before(grammarAccess.getModelAccess().getEntitytypesAssignment_1_0()); 
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:628:1: ( rule__Model__EntitytypesAssignment_1_0 )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:628:2: rule__Model__EntitytypesAssignment_1_0
                    {
                    pushFollow(FOLLOW_rule__Model__EntitytypesAssignment_1_0_in_rule__Model__Alternatives_11258);
                    rule__Model__EntitytypesAssignment_1_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getModelAccess().getEntitytypesAssignment_1_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:632:6: ( ( rule__Model__UiwindowsAssignment_1_1 ) )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:632:6: ( ( rule__Model__UiwindowsAssignment_1_1 ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:633:1: ( rule__Model__UiwindowsAssignment_1_1 )
                    {
                     before(grammarAccess.getModelAccess().getUiwindowsAssignment_1_1()); 
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:634:1: ( rule__Model__UiwindowsAssignment_1_1 )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:634:2: rule__Model__UiwindowsAssignment_1_1
                    {
                    pushFollow(FOLLOW_rule__Model__UiwindowsAssignment_1_1_in_rule__Model__Alternatives_11276);
                    rule__Model__UiwindowsAssignment_1_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getModelAccess().getUiwindowsAssignment_1_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Alternatives_1"


    // $ANTLR start "rule__Property__Alternatives"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:643:1: rule__Property__Alternatives : ( ( ruleAttribute ) | ( ruleReference ) );
    public final void rule__Property__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:647:1: ( ( ruleAttribute ) | ( ruleReference ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==25) ) {
                alt2=1;
            }
            else if ( (LA2_0==26) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:648:1: ( ruleAttribute )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:648:1: ( ruleAttribute )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:649:1: ruleAttribute
                    {
                     before(grammarAccess.getPropertyAccess().getAttributeParserRuleCall_0()); 
                    pushFollow(FOLLOW_ruleAttribute_in_rule__Property__Alternatives1309);
                    ruleAttribute();

                    state._fsp--;

                     after(grammarAccess.getPropertyAccess().getAttributeParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:654:6: ( ruleReference )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:654:6: ( ruleReference )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:655:1: ruleReference
                    {
                     before(grammarAccess.getPropertyAccess().getReferenceParserRuleCall_1()); 
                    pushFollow(FOLLOW_ruleReference_in_rule__Property__Alternatives1326);
                    ruleReference();

                    state._fsp--;

                     after(grammarAccess.getPropertyAccess().getReferenceParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Alternatives"


    // $ANTLR start "rule__UIWindow__Alternatives"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:665:1: rule__UIWindow__Alternatives : ( ( ruleListWindow ) | ( ruleEntryWindow ) );
    public final void rule__UIWindow__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:669:1: ( ( ruleListWindow ) | ( ruleEntryWindow ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==27) ) {
                alt3=1;
            }
            else if ( (LA3_0==29) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:670:1: ( ruleListWindow )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:670:1: ( ruleListWindow )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:671:1: ruleListWindow
                    {
                     before(grammarAccess.getUIWindowAccess().getListWindowParserRuleCall_0()); 
                    pushFollow(FOLLOW_ruleListWindow_in_rule__UIWindow__Alternatives1358);
                    ruleListWindow();

                    state._fsp--;

                     after(grammarAccess.getUIWindowAccess().getListWindowParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:676:6: ( ruleEntryWindow )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:676:6: ( ruleEntryWindow )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:677:1: ruleEntryWindow
                    {
                     before(grammarAccess.getUIWindowAccess().getEntryWindowParserRuleCall_1()); 
                    pushFollow(FOLLOW_ruleEntryWindow_in_rule__UIWindow__Alternatives1375);
                    ruleEntryWindow();

                    state._fsp--;

                     after(grammarAccess.getUIWindowAccess().getEntryWindowParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UIWindow__Alternatives"


    // $ANTLR start "rule__UIElement__Alternatives_0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:687:1: rule__UIElement__Alternatives_0 : ( ( ruleLabel ) | ( ruleField ) | ( ruleButton ) );
    public final void rule__UIElement__Alternatives_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:691:1: ( ( ruleLabel ) | ( ruleField ) | ( ruleButton ) )
            int alt4=3;
            switch ( input.LA(1) ) {
            case 30:
                {
                alt4=1;
                }
                break;
            case 31:
                {
                alt4=2;
                }
                break;
            case 32:
                {
                alt4=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:692:1: ( ruleLabel )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:692:1: ( ruleLabel )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:693:1: ruleLabel
                    {
                     before(grammarAccess.getUIElementAccess().getLabelParserRuleCall_0_0()); 
                    pushFollow(FOLLOW_ruleLabel_in_rule__UIElement__Alternatives_01407);
                    ruleLabel();

                    state._fsp--;

                     after(grammarAccess.getUIElementAccess().getLabelParserRuleCall_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:698:6: ( ruleField )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:698:6: ( ruleField )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:699:1: ruleField
                    {
                     before(grammarAccess.getUIElementAccess().getFieldParserRuleCall_0_1()); 
                    pushFollow(FOLLOW_ruleField_in_rule__UIElement__Alternatives_01424);
                    ruleField();

                    state._fsp--;

                     after(grammarAccess.getUIElementAccess().getFieldParserRuleCall_0_1()); 

                    }


                    }
                    break;
                case 3 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:704:6: ( ruleButton )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:704:6: ( ruleButton )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:705:1: ruleButton
                    {
                     before(grammarAccess.getUIElementAccess().getButtonParserRuleCall_0_2()); 
                    pushFollow(FOLLOW_ruleButton_in_rule__UIElement__Alternatives_01441);
                    ruleButton();

                    state._fsp--;

                     after(grammarAccess.getUIElementAccess().getButtonParserRuleCall_0_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UIElement__Alternatives_0"


    // $ANTLR start "rule__BasicType__Alternatives"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:715:1: rule__BasicType__Alternatives : ( ( ( 'String' ) ) | ( ( 'Integer' ) ) | ( ( 'Date' ) ) );
    public final void rule__BasicType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:719:1: ( ( ( 'String' ) ) | ( ( 'Integer' ) ) | ( ( 'Date' ) ) )
            int alt5=3;
            switch ( input.LA(1) ) {
            case 11:
                {
                alt5=1;
                }
                break;
            case 12:
                {
                alt5=2;
                }
                break;
            case 13:
                {
                alt5=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:720:1: ( ( 'String' ) )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:720:1: ( ( 'String' ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:721:1: ( 'String' )
                    {
                     before(grammarAccess.getBasicTypeAccess().getSTRINGEnumLiteralDeclaration_0()); 
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:722:1: ( 'String' )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:722:3: 'String'
                    {
                    match(input,11,FOLLOW_11_in_rule__BasicType__Alternatives1474); 

                    }

                     after(grammarAccess.getBasicTypeAccess().getSTRINGEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:727:6: ( ( 'Integer' ) )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:727:6: ( ( 'Integer' ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:728:1: ( 'Integer' )
                    {
                     before(grammarAccess.getBasicTypeAccess().getINTEGEREnumLiteralDeclaration_1()); 
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:729:1: ( 'Integer' )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:729:3: 'Integer'
                    {
                    match(input,12,FOLLOW_12_in_rule__BasicType__Alternatives1495); 

                    }

                     after(grammarAccess.getBasicTypeAccess().getINTEGEREnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:734:6: ( ( 'Date' ) )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:734:6: ( ( 'Date' ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:735:1: ( 'Date' )
                    {
                     before(grammarAccess.getBasicTypeAccess().getDATEEnumLiteralDeclaration_2()); 
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:736:1: ( 'Date' )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:736:3: 'Date'
                    {
                    match(input,13,FOLLOW_13_in_rule__BasicType__Alternatives1516); 

                    }

                     after(grammarAccess.getBasicTypeAccess().getDATEEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__BasicType__Alternatives"


    // $ANTLR start "rule__Multiplicity__Alternatives"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:746:1: rule__Multiplicity__Alternatives : ( ( ( 'one' ) ) | ( ( 'multiple' ) ) );
    public final void rule__Multiplicity__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:750:1: ( ( ( 'one' ) ) | ( ( 'multiple' ) ) )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==14) ) {
                alt6=1;
            }
            else if ( (LA6_0==15) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:751:1: ( ( 'one' ) )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:751:1: ( ( 'one' ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:752:1: ( 'one' )
                    {
                     before(grammarAccess.getMultiplicityAccess().getONEEnumLiteralDeclaration_0()); 
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:753:1: ( 'one' )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:753:3: 'one'
                    {
                    match(input,14,FOLLOW_14_in_rule__Multiplicity__Alternatives1552); 

                    }

                     after(grammarAccess.getMultiplicityAccess().getONEEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:758:6: ( ( 'multiple' ) )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:758:6: ( ( 'multiple' ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:759:1: ( 'multiple' )
                    {
                     before(grammarAccess.getMultiplicityAccess().getMULTIPLEEnumLiteralDeclaration_1()); 
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:760:1: ( 'multiple' )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:760:3: 'multiple'
                    {
                    match(input,15,FOLLOW_15_in_rule__Multiplicity__Alternatives1573); 

                    }

                     after(grammarAccess.getMultiplicityAccess().getMULTIPLEEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Multiplicity__Alternatives"


    // $ANTLR start "rule__Inscription__Alternatives"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:770:1: rule__Inscription__Alternatives : ( ( ( 'Create/Edit' ) ) | ( ( 'Delete' ) ) | ( ( 'Cancel' ) ) );
    public final void rule__Inscription__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:774:1: ( ( ( 'Create/Edit' ) ) | ( ( 'Delete' ) ) | ( ( 'Cancel' ) ) )
            int alt7=3;
            switch ( input.LA(1) ) {
            case 16:
                {
                alt7=1;
                }
                break;
            case 17:
                {
                alt7=2;
                }
                break;
            case 18:
                {
                alt7=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }

            switch (alt7) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:775:1: ( ( 'Create/Edit' ) )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:775:1: ( ( 'Create/Edit' ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:776:1: ( 'Create/Edit' )
                    {
                     before(grammarAccess.getInscriptionAccess().getCREATE_EDITEnumLiteralDeclaration_0()); 
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:777:1: ( 'Create/Edit' )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:777:3: 'Create/Edit'
                    {
                    match(input,16,FOLLOW_16_in_rule__Inscription__Alternatives1609); 

                    }

                     after(grammarAccess.getInscriptionAccess().getCREATE_EDITEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:782:6: ( ( 'Delete' ) )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:782:6: ( ( 'Delete' ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:783:1: ( 'Delete' )
                    {
                     before(grammarAccess.getInscriptionAccess().getDELETEEnumLiteralDeclaration_1()); 
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:784:1: ( 'Delete' )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:784:3: 'Delete'
                    {
                    match(input,17,FOLLOW_17_in_rule__Inscription__Alternatives1630); 

                    }

                     after(grammarAccess.getInscriptionAccess().getDELETEEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:789:6: ( ( 'Cancel' ) )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:789:6: ( ( 'Cancel' ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:790:1: ( 'Cancel' )
                    {
                     before(grammarAccess.getInscriptionAccess().getCANCELEnumLiteralDeclaration_2()); 
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:791:1: ( 'Cancel' )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:791:3: 'Cancel'
                    {
                    match(input,18,FOLLOW_18_in_rule__Inscription__Alternatives1651); 

                    }

                     after(grammarAccess.getInscriptionAccess().getCANCELEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Inscription__Alternatives"


    // $ANTLR start "rule__Model__Group__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:803:1: rule__Model__Group__0 : rule__Model__Group__0__Impl rule__Model__Group__1 ;
    public final void rule__Model__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:807:1: ( rule__Model__Group__0__Impl rule__Model__Group__1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:808:2: rule__Model__Group__0__Impl rule__Model__Group__1
            {
            pushFollow(FOLLOW_rule__Model__Group__0__Impl_in_rule__Model__Group__01684);
            rule__Model__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Model__Group__1_in_rule__Model__Group__01687);
            rule__Model__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__0"


    // $ANTLR start "rule__Model__Group__0__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:815:1: rule__Model__Group__0__Impl : ( ( rule__Model__PackageAssignment_0 ) ) ;
    public final void rule__Model__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:819:1: ( ( ( rule__Model__PackageAssignment_0 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:820:1: ( ( rule__Model__PackageAssignment_0 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:820:1: ( ( rule__Model__PackageAssignment_0 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:821:1: ( rule__Model__PackageAssignment_0 )
            {
             before(grammarAccess.getModelAccess().getPackageAssignment_0()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:822:1: ( rule__Model__PackageAssignment_0 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:822:2: rule__Model__PackageAssignment_0
            {
            pushFollow(FOLLOW_rule__Model__PackageAssignment_0_in_rule__Model__Group__0__Impl1714);
            rule__Model__PackageAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getPackageAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__0__Impl"


    // $ANTLR start "rule__Model__Group__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:832:1: rule__Model__Group__1 : rule__Model__Group__1__Impl ;
    public final void rule__Model__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:836:1: ( rule__Model__Group__1__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:837:2: rule__Model__Group__1__Impl
            {
            pushFollow(FOLLOW_rule__Model__Group__1__Impl_in_rule__Model__Group__11744);
            rule__Model__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__1"


    // $ANTLR start "rule__Model__Group__1__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:843:1: rule__Model__Group__1__Impl : ( ( rule__Model__Alternatives_1 )* ) ;
    public final void rule__Model__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:847:1: ( ( ( rule__Model__Alternatives_1 )* ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:848:1: ( ( rule__Model__Alternatives_1 )* )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:848:1: ( ( rule__Model__Alternatives_1 )* )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:849:1: ( rule__Model__Alternatives_1 )*
            {
             before(grammarAccess.getModelAccess().getAlternatives_1()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:850:1: ( rule__Model__Alternatives_1 )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==21||LA8_0==27||LA8_0==29||LA8_0==38) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:850:2: rule__Model__Alternatives_1
            	    {
            	    pushFollow(FOLLOW_rule__Model__Alternatives_1_in_rule__Model__Group__1__Impl1771);
            	    rule__Model__Alternatives_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getAlternatives_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__1__Impl"


    // $ANTLR start "rule__Package__Group__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:864:1: rule__Package__Group__0 : rule__Package__Group__0__Impl rule__Package__Group__1 ;
    public final void rule__Package__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:868:1: ( rule__Package__Group__0__Impl rule__Package__Group__1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:869:2: rule__Package__Group__0__Impl rule__Package__Group__1
            {
            pushFollow(FOLLOW_rule__Package__Group__0__Impl_in_rule__Package__Group__01806);
            rule__Package__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Package__Group__1_in_rule__Package__Group__01809);
            rule__Package__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__Group__0"


    // $ANTLR start "rule__Package__Group__0__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:876:1: rule__Package__Group__0__Impl : ( 'Package' ) ;
    public final void rule__Package__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:880:1: ( ( 'Package' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:881:1: ( 'Package' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:881:1: ( 'Package' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:882:1: 'Package'
            {
             before(grammarAccess.getPackageAccess().getPackageKeyword_0()); 
            match(input,19,FOLLOW_19_in_rule__Package__Group__0__Impl1837); 
             after(grammarAccess.getPackageAccess().getPackageKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__Group__0__Impl"


    // $ANTLR start "rule__Package__Group__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:895:1: rule__Package__Group__1 : rule__Package__Group__1__Impl ;
    public final void rule__Package__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:899:1: ( rule__Package__Group__1__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:900:2: rule__Package__Group__1__Impl
            {
            pushFollow(FOLLOW_rule__Package__Group__1__Impl_in_rule__Package__Group__11868);
            rule__Package__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__Group__1"


    // $ANTLR start "rule__Package__Group__1__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:906:1: rule__Package__Group__1__Impl : ( ( rule__Package__NameAssignment_1 ) ) ;
    public final void rule__Package__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:910:1: ( ( ( rule__Package__NameAssignment_1 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:911:1: ( ( rule__Package__NameAssignment_1 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:911:1: ( ( rule__Package__NameAssignment_1 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:912:1: ( rule__Package__NameAssignment_1 )
            {
             before(grammarAccess.getPackageAccess().getNameAssignment_1()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:913:1: ( rule__Package__NameAssignment_1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:913:2: rule__Package__NameAssignment_1
            {
            pushFollow(FOLLOW_rule__Package__NameAssignment_1_in_rule__Package__Group__1__Impl1895);
            rule__Package__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getPackageAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__Group__1__Impl"


    // $ANTLR start "rule__QualifiedName__Group__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:927:1: rule__QualifiedName__Group__0 : rule__QualifiedName__Group__0__Impl rule__QualifiedName__Group__1 ;
    public final void rule__QualifiedName__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:931:1: ( rule__QualifiedName__Group__0__Impl rule__QualifiedName__Group__1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:932:2: rule__QualifiedName__Group__0__Impl rule__QualifiedName__Group__1
            {
            pushFollow(FOLLOW_rule__QualifiedName__Group__0__Impl_in_rule__QualifiedName__Group__01929);
            rule__QualifiedName__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__QualifiedName__Group__1_in_rule__QualifiedName__Group__01932);
            rule__QualifiedName__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group__0"


    // $ANTLR start "rule__QualifiedName__Group__0__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:939:1: rule__QualifiedName__Group__0__Impl : ( RULE_ID ) ;
    public final void rule__QualifiedName__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:943:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:944:1: ( RULE_ID )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:944:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:945:1: RULE_ID
            {
             before(grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__QualifiedName__Group__0__Impl1959); 
             after(grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group__0__Impl"


    // $ANTLR start "rule__QualifiedName__Group__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:956:1: rule__QualifiedName__Group__1 : rule__QualifiedName__Group__1__Impl ;
    public final void rule__QualifiedName__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:960:1: ( rule__QualifiedName__Group__1__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:961:2: rule__QualifiedName__Group__1__Impl
            {
            pushFollow(FOLLOW_rule__QualifiedName__Group__1__Impl_in_rule__QualifiedName__Group__11988);
            rule__QualifiedName__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group__1"


    // $ANTLR start "rule__QualifiedName__Group__1__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:967:1: rule__QualifiedName__Group__1__Impl : ( ( rule__QualifiedName__Group_1__0 )* ) ;
    public final void rule__QualifiedName__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:971:1: ( ( ( rule__QualifiedName__Group_1__0 )* ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:972:1: ( ( rule__QualifiedName__Group_1__0 )* )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:972:1: ( ( rule__QualifiedName__Group_1__0 )* )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:973:1: ( rule__QualifiedName__Group_1__0 )*
            {
             before(grammarAccess.getQualifiedNameAccess().getGroup_1()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:974:1: ( rule__QualifiedName__Group_1__0 )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==20) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:974:2: rule__QualifiedName__Group_1__0
            	    {
            	    pushFollow(FOLLOW_rule__QualifiedName__Group_1__0_in_rule__QualifiedName__Group__1__Impl2015);
            	    rule__QualifiedName__Group_1__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

             after(grammarAccess.getQualifiedNameAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group__1__Impl"


    // $ANTLR start "rule__QualifiedName__Group_1__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:988:1: rule__QualifiedName__Group_1__0 : rule__QualifiedName__Group_1__0__Impl rule__QualifiedName__Group_1__1 ;
    public final void rule__QualifiedName__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:992:1: ( rule__QualifiedName__Group_1__0__Impl rule__QualifiedName__Group_1__1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:993:2: rule__QualifiedName__Group_1__0__Impl rule__QualifiedName__Group_1__1
            {
            pushFollow(FOLLOW_rule__QualifiedName__Group_1__0__Impl_in_rule__QualifiedName__Group_1__02050);
            rule__QualifiedName__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__QualifiedName__Group_1__1_in_rule__QualifiedName__Group_1__02053);
            rule__QualifiedName__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group_1__0"


    // $ANTLR start "rule__QualifiedName__Group_1__0__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1000:1: rule__QualifiedName__Group_1__0__Impl : ( '.' ) ;
    public final void rule__QualifiedName__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1004:1: ( ( '.' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1005:1: ( '.' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1005:1: ( '.' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1006:1: '.'
            {
             before(grammarAccess.getQualifiedNameAccess().getFullStopKeyword_1_0()); 
            match(input,20,FOLLOW_20_in_rule__QualifiedName__Group_1__0__Impl2081); 
             after(grammarAccess.getQualifiedNameAccess().getFullStopKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group_1__0__Impl"


    // $ANTLR start "rule__QualifiedName__Group_1__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1019:1: rule__QualifiedName__Group_1__1 : rule__QualifiedName__Group_1__1__Impl ;
    public final void rule__QualifiedName__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1023:1: ( rule__QualifiedName__Group_1__1__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1024:2: rule__QualifiedName__Group_1__1__Impl
            {
            pushFollow(FOLLOW_rule__QualifiedName__Group_1__1__Impl_in_rule__QualifiedName__Group_1__12112);
            rule__QualifiedName__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group_1__1"


    // $ANTLR start "rule__QualifiedName__Group_1__1__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1030:1: rule__QualifiedName__Group_1__1__Impl : ( RULE_ID ) ;
    public final void rule__QualifiedName__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1034:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1035:1: ( RULE_ID )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1035:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1036:1: RULE_ID
            {
             before(grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_1_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__QualifiedName__Group_1__1__Impl2139); 
             after(grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group_1__1__Impl"


    // $ANTLR start "rule__Entitytype__Group__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1051:1: rule__Entitytype__Group__0 : rule__Entitytype__Group__0__Impl rule__Entitytype__Group__1 ;
    public final void rule__Entitytype__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1055:1: ( rule__Entitytype__Group__0__Impl rule__Entitytype__Group__1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1056:2: rule__Entitytype__Group__0__Impl rule__Entitytype__Group__1
            {
            pushFollow(FOLLOW_rule__Entitytype__Group__0__Impl_in_rule__Entitytype__Group__02172);
            rule__Entitytype__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entitytype__Group__1_in_rule__Entitytype__Group__02175);
            rule__Entitytype__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__Group__0"


    // $ANTLR start "rule__Entitytype__Group__0__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1063:1: rule__Entitytype__Group__0__Impl : ( ( rule__Entitytype__AbstractAssignment_0 )? ) ;
    public final void rule__Entitytype__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1067:1: ( ( ( rule__Entitytype__AbstractAssignment_0 )? ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1068:1: ( ( rule__Entitytype__AbstractAssignment_0 )? )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1068:1: ( ( rule__Entitytype__AbstractAssignment_0 )? )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1069:1: ( rule__Entitytype__AbstractAssignment_0 )?
            {
             before(grammarAccess.getEntitytypeAccess().getAbstractAssignment_0()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1070:1: ( rule__Entitytype__AbstractAssignment_0 )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==38) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1070:2: rule__Entitytype__AbstractAssignment_0
                    {
                    pushFollow(FOLLOW_rule__Entitytype__AbstractAssignment_0_in_rule__Entitytype__Group__0__Impl2202);
                    rule__Entitytype__AbstractAssignment_0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getEntitytypeAccess().getAbstractAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__Group__0__Impl"


    // $ANTLR start "rule__Entitytype__Group__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1080:1: rule__Entitytype__Group__1 : rule__Entitytype__Group__1__Impl rule__Entitytype__Group__2 ;
    public final void rule__Entitytype__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1084:1: ( rule__Entitytype__Group__1__Impl rule__Entitytype__Group__2 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1085:2: rule__Entitytype__Group__1__Impl rule__Entitytype__Group__2
            {
            pushFollow(FOLLOW_rule__Entitytype__Group__1__Impl_in_rule__Entitytype__Group__12233);
            rule__Entitytype__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entitytype__Group__2_in_rule__Entitytype__Group__12236);
            rule__Entitytype__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__Group__1"


    // $ANTLR start "rule__Entitytype__Group__1__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1092:1: rule__Entitytype__Group__1__Impl : ( 'Entitytype' ) ;
    public final void rule__Entitytype__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1096:1: ( ( 'Entitytype' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1097:1: ( 'Entitytype' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1097:1: ( 'Entitytype' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1098:1: 'Entitytype'
            {
             before(grammarAccess.getEntitytypeAccess().getEntitytypeKeyword_1()); 
            match(input,21,FOLLOW_21_in_rule__Entitytype__Group__1__Impl2264); 
             after(grammarAccess.getEntitytypeAccess().getEntitytypeKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__Group__1__Impl"


    // $ANTLR start "rule__Entitytype__Group__2"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1111:1: rule__Entitytype__Group__2 : rule__Entitytype__Group__2__Impl rule__Entitytype__Group__3 ;
    public final void rule__Entitytype__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1115:1: ( rule__Entitytype__Group__2__Impl rule__Entitytype__Group__3 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1116:2: rule__Entitytype__Group__2__Impl rule__Entitytype__Group__3
            {
            pushFollow(FOLLOW_rule__Entitytype__Group__2__Impl_in_rule__Entitytype__Group__22295);
            rule__Entitytype__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entitytype__Group__3_in_rule__Entitytype__Group__22298);
            rule__Entitytype__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__Group__2"


    // $ANTLR start "rule__Entitytype__Group__2__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1123:1: rule__Entitytype__Group__2__Impl : ( ( rule__Entitytype__NameAssignment_2 ) ) ;
    public final void rule__Entitytype__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1127:1: ( ( ( rule__Entitytype__NameAssignment_2 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1128:1: ( ( rule__Entitytype__NameAssignment_2 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1128:1: ( ( rule__Entitytype__NameAssignment_2 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1129:1: ( rule__Entitytype__NameAssignment_2 )
            {
             before(grammarAccess.getEntitytypeAccess().getNameAssignment_2()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1130:1: ( rule__Entitytype__NameAssignment_2 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1130:2: rule__Entitytype__NameAssignment_2
            {
            pushFollow(FOLLOW_rule__Entitytype__NameAssignment_2_in_rule__Entitytype__Group__2__Impl2325);
            rule__Entitytype__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getEntitytypeAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__Group__2__Impl"


    // $ANTLR start "rule__Entitytype__Group__3"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1140:1: rule__Entitytype__Group__3 : rule__Entitytype__Group__3__Impl rule__Entitytype__Group__4 ;
    public final void rule__Entitytype__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1144:1: ( rule__Entitytype__Group__3__Impl rule__Entitytype__Group__4 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1145:2: rule__Entitytype__Group__3__Impl rule__Entitytype__Group__4
            {
            pushFollow(FOLLOW_rule__Entitytype__Group__3__Impl_in_rule__Entitytype__Group__32355);
            rule__Entitytype__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entitytype__Group__4_in_rule__Entitytype__Group__32358);
            rule__Entitytype__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__Group__3"


    // $ANTLR start "rule__Entitytype__Group__3__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1152:1: rule__Entitytype__Group__3__Impl : ( ( rule__Entitytype__Group_3__0 )? ) ;
    public final void rule__Entitytype__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1156:1: ( ( ( rule__Entitytype__Group_3__0 )? ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1157:1: ( ( rule__Entitytype__Group_3__0 )? )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1157:1: ( ( rule__Entitytype__Group_3__0 )? )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1158:1: ( rule__Entitytype__Group_3__0 )?
            {
             before(grammarAccess.getEntitytypeAccess().getGroup_3()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1159:1: ( rule__Entitytype__Group_3__0 )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==24) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1159:2: rule__Entitytype__Group_3__0
                    {
                    pushFollow(FOLLOW_rule__Entitytype__Group_3__0_in_rule__Entitytype__Group__3__Impl2385);
                    rule__Entitytype__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getEntitytypeAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__Group__3__Impl"


    // $ANTLR start "rule__Entitytype__Group__4"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1169:1: rule__Entitytype__Group__4 : rule__Entitytype__Group__4__Impl rule__Entitytype__Group__5 ;
    public final void rule__Entitytype__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1173:1: ( rule__Entitytype__Group__4__Impl rule__Entitytype__Group__5 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1174:2: rule__Entitytype__Group__4__Impl rule__Entitytype__Group__5
            {
            pushFollow(FOLLOW_rule__Entitytype__Group__4__Impl_in_rule__Entitytype__Group__42416);
            rule__Entitytype__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entitytype__Group__5_in_rule__Entitytype__Group__42419);
            rule__Entitytype__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__Group__4"


    // $ANTLR start "rule__Entitytype__Group__4__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1181:1: rule__Entitytype__Group__4__Impl : ( '{' ) ;
    public final void rule__Entitytype__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1185:1: ( ( '{' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1186:1: ( '{' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1186:1: ( '{' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1187:1: '{'
            {
             before(grammarAccess.getEntitytypeAccess().getLeftCurlyBracketKeyword_4()); 
            match(input,22,FOLLOW_22_in_rule__Entitytype__Group__4__Impl2447); 
             after(grammarAccess.getEntitytypeAccess().getLeftCurlyBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__Group__4__Impl"


    // $ANTLR start "rule__Entitytype__Group__5"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1200:1: rule__Entitytype__Group__5 : rule__Entitytype__Group__5__Impl rule__Entitytype__Group__6 ;
    public final void rule__Entitytype__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1204:1: ( rule__Entitytype__Group__5__Impl rule__Entitytype__Group__6 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1205:2: rule__Entitytype__Group__5__Impl rule__Entitytype__Group__6
            {
            pushFollow(FOLLOW_rule__Entitytype__Group__5__Impl_in_rule__Entitytype__Group__52478);
            rule__Entitytype__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entitytype__Group__6_in_rule__Entitytype__Group__52481);
            rule__Entitytype__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__Group__5"


    // $ANTLR start "rule__Entitytype__Group__5__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1212:1: rule__Entitytype__Group__5__Impl : ( ( ( rule__Entitytype__PropertiesAssignment_5 ) ) ( ( rule__Entitytype__PropertiesAssignment_5 )* ) ) ;
    public final void rule__Entitytype__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1216:1: ( ( ( ( rule__Entitytype__PropertiesAssignment_5 ) ) ( ( rule__Entitytype__PropertiesAssignment_5 )* ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1217:1: ( ( ( rule__Entitytype__PropertiesAssignment_5 ) ) ( ( rule__Entitytype__PropertiesAssignment_5 )* ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1217:1: ( ( ( rule__Entitytype__PropertiesAssignment_5 ) ) ( ( rule__Entitytype__PropertiesAssignment_5 )* ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1218:1: ( ( rule__Entitytype__PropertiesAssignment_5 ) ) ( ( rule__Entitytype__PropertiesAssignment_5 )* )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1218:1: ( ( rule__Entitytype__PropertiesAssignment_5 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1219:1: ( rule__Entitytype__PropertiesAssignment_5 )
            {
             before(grammarAccess.getEntitytypeAccess().getPropertiesAssignment_5()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1220:1: ( rule__Entitytype__PropertiesAssignment_5 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1220:2: rule__Entitytype__PropertiesAssignment_5
            {
            pushFollow(FOLLOW_rule__Entitytype__PropertiesAssignment_5_in_rule__Entitytype__Group__5__Impl2510);
            rule__Entitytype__PropertiesAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getEntitytypeAccess().getPropertiesAssignment_5()); 

            }

            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1223:1: ( ( rule__Entitytype__PropertiesAssignment_5 )* )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1224:1: ( rule__Entitytype__PropertiesAssignment_5 )*
            {
             before(grammarAccess.getEntitytypeAccess().getPropertiesAssignment_5()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1225:1: ( rule__Entitytype__PropertiesAssignment_5 )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( ((LA12_0>=25 && LA12_0<=26)) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1225:2: rule__Entitytype__PropertiesAssignment_5
            	    {
            	    pushFollow(FOLLOW_rule__Entitytype__PropertiesAssignment_5_in_rule__Entitytype__Group__5__Impl2522);
            	    rule__Entitytype__PropertiesAssignment_5();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

             after(grammarAccess.getEntitytypeAccess().getPropertiesAssignment_5()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__Group__5__Impl"


    // $ANTLR start "rule__Entitytype__Group__6"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1236:1: rule__Entitytype__Group__6 : rule__Entitytype__Group__6__Impl ;
    public final void rule__Entitytype__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1240:1: ( rule__Entitytype__Group__6__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1241:2: rule__Entitytype__Group__6__Impl
            {
            pushFollow(FOLLOW_rule__Entitytype__Group__6__Impl_in_rule__Entitytype__Group__62555);
            rule__Entitytype__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__Group__6"


    // $ANTLR start "rule__Entitytype__Group__6__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1247:1: rule__Entitytype__Group__6__Impl : ( '}' ) ;
    public final void rule__Entitytype__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1251:1: ( ( '}' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1252:1: ( '}' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1252:1: ( '}' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1253:1: '}'
            {
             before(grammarAccess.getEntitytypeAccess().getRightCurlyBracketKeyword_6()); 
            match(input,23,FOLLOW_23_in_rule__Entitytype__Group__6__Impl2583); 
             after(grammarAccess.getEntitytypeAccess().getRightCurlyBracketKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__Group__6__Impl"


    // $ANTLR start "rule__Entitytype__Group_3__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1280:1: rule__Entitytype__Group_3__0 : rule__Entitytype__Group_3__0__Impl rule__Entitytype__Group_3__1 ;
    public final void rule__Entitytype__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1284:1: ( rule__Entitytype__Group_3__0__Impl rule__Entitytype__Group_3__1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1285:2: rule__Entitytype__Group_3__0__Impl rule__Entitytype__Group_3__1
            {
            pushFollow(FOLLOW_rule__Entitytype__Group_3__0__Impl_in_rule__Entitytype__Group_3__02628);
            rule__Entitytype__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entitytype__Group_3__1_in_rule__Entitytype__Group_3__02631);
            rule__Entitytype__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__Group_3__0"


    // $ANTLR start "rule__Entitytype__Group_3__0__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1292:1: rule__Entitytype__Group_3__0__Impl : ( 'extends' ) ;
    public final void rule__Entitytype__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1296:1: ( ( 'extends' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1297:1: ( 'extends' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1297:1: ( 'extends' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1298:1: 'extends'
            {
             before(grammarAccess.getEntitytypeAccess().getExtendsKeyword_3_0()); 
            match(input,24,FOLLOW_24_in_rule__Entitytype__Group_3__0__Impl2659); 
             after(grammarAccess.getEntitytypeAccess().getExtendsKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__Group_3__0__Impl"


    // $ANTLR start "rule__Entitytype__Group_3__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1311:1: rule__Entitytype__Group_3__1 : rule__Entitytype__Group_3__1__Impl ;
    public final void rule__Entitytype__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1315:1: ( rule__Entitytype__Group_3__1__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1316:2: rule__Entitytype__Group_3__1__Impl
            {
            pushFollow(FOLLOW_rule__Entitytype__Group_3__1__Impl_in_rule__Entitytype__Group_3__12690);
            rule__Entitytype__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__Group_3__1"


    // $ANTLR start "rule__Entitytype__Group_3__1__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1322:1: rule__Entitytype__Group_3__1__Impl : ( ( rule__Entitytype__SupertypeAssignment_3_1 ) ) ;
    public final void rule__Entitytype__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1326:1: ( ( ( rule__Entitytype__SupertypeAssignment_3_1 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1327:1: ( ( rule__Entitytype__SupertypeAssignment_3_1 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1327:1: ( ( rule__Entitytype__SupertypeAssignment_3_1 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1328:1: ( rule__Entitytype__SupertypeAssignment_3_1 )
            {
             before(grammarAccess.getEntitytypeAccess().getSupertypeAssignment_3_1()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1329:1: ( rule__Entitytype__SupertypeAssignment_3_1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1329:2: rule__Entitytype__SupertypeAssignment_3_1
            {
            pushFollow(FOLLOW_rule__Entitytype__SupertypeAssignment_3_1_in_rule__Entitytype__Group_3__1__Impl2717);
            rule__Entitytype__SupertypeAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getEntitytypeAccess().getSupertypeAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__Group_3__1__Impl"


    // $ANTLR start "rule__Attribute__Group__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1343:1: rule__Attribute__Group__0 : rule__Attribute__Group__0__Impl rule__Attribute__Group__1 ;
    public final void rule__Attribute__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1347:1: ( rule__Attribute__Group__0__Impl rule__Attribute__Group__1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1348:2: rule__Attribute__Group__0__Impl rule__Attribute__Group__1
            {
            pushFollow(FOLLOW_rule__Attribute__Group__0__Impl_in_rule__Attribute__Group__02751);
            rule__Attribute__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Attribute__Group__1_in_rule__Attribute__Group__02754);
            rule__Attribute__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__0"


    // $ANTLR start "rule__Attribute__Group__0__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1355:1: rule__Attribute__Group__0__Impl : ( 'Attribute' ) ;
    public final void rule__Attribute__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1359:1: ( ( 'Attribute' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1360:1: ( 'Attribute' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1360:1: ( 'Attribute' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1361:1: 'Attribute'
            {
             before(grammarAccess.getAttributeAccess().getAttributeKeyword_0()); 
            match(input,25,FOLLOW_25_in_rule__Attribute__Group__0__Impl2782); 
             after(grammarAccess.getAttributeAccess().getAttributeKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__0__Impl"


    // $ANTLR start "rule__Attribute__Group__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1374:1: rule__Attribute__Group__1 : rule__Attribute__Group__1__Impl rule__Attribute__Group__2 ;
    public final void rule__Attribute__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1378:1: ( rule__Attribute__Group__1__Impl rule__Attribute__Group__2 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1379:2: rule__Attribute__Group__1__Impl rule__Attribute__Group__2
            {
            pushFollow(FOLLOW_rule__Attribute__Group__1__Impl_in_rule__Attribute__Group__12813);
            rule__Attribute__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Attribute__Group__2_in_rule__Attribute__Group__12816);
            rule__Attribute__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__1"


    // $ANTLR start "rule__Attribute__Group__1__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1386:1: rule__Attribute__Group__1__Impl : ( ( rule__Attribute__TypeAssignment_1 ) ) ;
    public final void rule__Attribute__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1390:1: ( ( ( rule__Attribute__TypeAssignment_1 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1391:1: ( ( rule__Attribute__TypeAssignment_1 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1391:1: ( ( rule__Attribute__TypeAssignment_1 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1392:1: ( rule__Attribute__TypeAssignment_1 )
            {
             before(grammarAccess.getAttributeAccess().getTypeAssignment_1()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1393:1: ( rule__Attribute__TypeAssignment_1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1393:2: rule__Attribute__TypeAssignment_1
            {
            pushFollow(FOLLOW_rule__Attribute__TypeAssignment_1_in_rule__Attribute__Group__1__Impl2843);
            rule__Attribute__TypeAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getAttributeAccess().getTypeAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__1__Impl"


    // $ANTLR start "rule__Attribute__Group__2"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1403:1: rule__Attribute__Group__2 : rule__Attribute__Group__2__Impl rule__Attribute__Group__3 ;
    public final void rule__Attribute__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1407:1: ( rule__Attribute__Group__2__Impl rule__Attribute__Group__3 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1408:2: rule__Attribute__Group__2__Impl rule__Attribute__Group__3
            {
            pushFollow(FOLLOW_rule__Attribute__Group__2__Impl_in_rule__Attribute__Group__22873);
            rule__Attribute__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Attribute__Group__3_in_rule__Attribute__Group__22876);
            rule__Attribute__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__2"


    // $ANTLR start "rule__Attribute__Group__2__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1415:1: rule__Attribute__Group__2__Impl : ( ( rule__Attribute__NameAssignment_2 ) ) ;
    public final void rule__Attribute__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1419:1: ( ( ( rule__Attribute__NameAssignment_2 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1420:1: ( ( rule__Attribute__NameAssignment_2 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1420:1: ( ( rule__Attribute__NameAssignment_2 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1421:1: ( rule__Attribute__NameAssignment_2 )
            {
             before(grammarAccess.getAttributeAccess().getNameAssignment_2()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1422:1: ( rule__Attribute__NameAssignment_2 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1422:2: rule__Attribute__NameAssignment_2
            {
            pushFollow(FOLLOW_rule__Attribute__NameAssignment_2_in_rule__Attribute__Group__2__Impl2903);
            rule__Attribute__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getAttributeAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__2__Impl"


    // $ANTLR start "rule__Attribute__Group__3"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1432:1: rule__Attribute__Group__3 : rule__Attribute__Group__3__Impl ;
    public final void rule__Attribute__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1436:1: ( rule__Attribute__Group__3__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1437:2: rule__Attribute__Group__3__Impl
            {
            pushFollow(FOLLOW_rule__Attribute__Group__3__Impl_in_rule__Attribute__Group__32933);
            rule__Attribute__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__3"


    // $ANTLR start "rule__Attribute__Group__3__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1443:1: rule__Attribute__Group__3__Impl : ( ( rule__Attribute__OptionalAssignment_3 )? ) ;
    public final void rule__Attribute__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1447:1: ( ( ( rule__Attribute__OptionalAssignment_3 )? ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1448:1: ( ( rule__Attribute__OptionalAssignment_3 )? )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1448:1: ( ( rule__Attribute__OptionalAssignment_3 )? )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1449:1: ( rule__Attribute__OptionalAssignment_3 )?
            {
             before(grammarAccess.getAttributeAccess().getOptionalAssignment_3()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1450:1: ( rule__Attribute__OptionalAssignment_3 )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==39) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1450:2: rule__Attribute__OptionalAssignment_3
                    {
                    pushFollow(FOLLOW_rule__Attribute__OptionalAssignment_3_in_rule__Attribute__Group__3__Impl2960);
                    rule__Attribute__OptionalAssignment_3();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getAttributeAccess().getOptionalAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__3__Impl"


    // $ANTLR start "rule__Reference__Group__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1468:1: rule__Reference__Group__0 : rule__Reference__Group__0__Impl rule__Reference__Group__1 ;
    public final void rule__Reference__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1472:1: ( rule__Reference__Group__0__Impl rule__Reference__Group__1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1473:2: rule__Reference__Group__0__Impl rule__Reference__Group__1
            {
            pushFollow(FOLLOW_rule__Reference__Group__0__Impl_in_rule__Reference__Group__02999);
            rule__Reference__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Reference__Group__1_in_rule__Reference__Group__03002);
            rule__Reference__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__0"


    // $ANTLR start "rule__Reference__Group__0__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1480:1: rule__Reference__Group__0__Impl : ( 'Reference' ) ;
    public final void rule__Reference__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1484:1: ( ( 'Reference' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1485:1: ( 'Reference' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1485:1: ( 'Reference' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1486:1: 'Reference'
            {
             before(grammarAccess.getReferenceAccess().getReferenceKeyword_0()); 
            match(input,26,FOLLOW_26_in_rule__Reference__Group__0__Impl3030); 
             after(grammarAccess.getReferenceAccess().getReferenceKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__0__Impl"


    // $ANTLR start "rule__Reference__Group__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1499:1: rule__Reference__Group__1 : rule__Reference__Group__1__Impl rule__Reference__Group__2 ;
    public final void rule__Reference__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1503:1: ( rule__Reference__Group__1__Impl rule__Reference__Group__2 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1504:2: rule__Reference__Group__1__Impl rule__Reference__Group__2
            {
            pushFollow(FOLLOW_rule__Reference__Group__1__Impl_in_rule__Reference__Group__13061);
            rule__Reference__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Reference__Group__2_in_rule__Reference__Group__13064);
            rule__Reference__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__1"


    // $ANTLR start "rule__Reference__Group__1__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1511:1: rule__Reference__Group__1__Impl : ( ( rule__Reference__ReferencesAssignment_1 ) ) ;
    public final void rule__Reference__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1515:1: ( ( ( rule__Reference__ReferencesAssignment_1 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1516:1: ( ( rule__Reference__ReferencesAssignment_1 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1516:1: ( ( rule__Reference__ReferencesAssignment_1 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1517:1: ( rule__Reference__ReferencesAssignment_1 )
            {
             before(grammarAccess.getReferenceAccess().getReferencesAssignment_1()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1518:1: ( rule__Reference__ReferencesAssignment_1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1518:2: rule__Reference__ReferencesAssignment_1
            {
            pushFollow(FOLLOW_rule__Reference__ReferencesAssignment_1_in_rule__Reference__Group__1__Impl3091);
            rule__Reference__ReferencesAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getReferenceAccess().getReferencesAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__1__Impl"


    // $ANTLR start "rule__Reference__Group__2"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1528:1: rule__Reference__Group__2 : rule__Reference__Group__2__Impl rule__Reference__Group__3 ;
    public final void rule__Reference__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1532:1: ( rule__Reference__Group__2__Impl rule__Reference__Group__3 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1533:2: rule__Reference__Group__2__Impl rule__Reference__Group__3
            {
            pushFollow(FOLLOW_rule__Reference__Group__2__Impl_in_rule__Reference__Group__23121);
            rule__Reference__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Reference__Group__3_in_rule__Reference__Group__23124);
            rule__Reference__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__2"


    // $ANTLR start "rule__Reference__Group__2__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1540:1: rule__Reference__Group__2__Impl : ( ( rule__Reference__NameAssignment_2 ) ) ;
    public final void rule__Reference__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1544:1: ( ( ( rule__Reference__NameAssignment_2 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1545:1: ( ( rule__Reference__NameAssignment_2 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1545:1: ( ( rule__Reference__NameAssignment_2 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1546:1: ( rule__Reference__NameAssignment_2 )
            {
             before(grammarAccess.getReferenceAccess().getNameAssignment_2()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1547:1: ( rule__Reference__NameAssignment_2 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1547:2: rule__Reference__NameAssignment_2
            {
            pushFollow(FOLLOW_rule__Reference__NameAssignment_2_in_rule__Reference__Group__2__Impl3151);
            rule__Reference__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getReferenceAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__2__Impl"


    // $ANTLR start "rule__Reference__Group__3"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1557:1: rule__Reference__Group__3 : rule__Reference__Group__3__Impl ;
    public final void rule__Reference__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1561:1: ( rule__Reference__Group__3__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1562:2: rule__Reference__Group__3__Impl
            {
            pushFollow(FOLLOW_rule__Reference__Group__3__Impl_in_rule__Reference__Group__33181);
            rule__Reference__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__3"


    // $ANTLR start "rule__Reference__Group__3__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1568:1: rule__Reference__Group__3__Impl : ( ( rule__Reference__MultiplicityAssignment_3 )? ) ;
    public final void rule__Reference__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1572:1: ( ( ( rule__Reference__MultiplicityAssignment_3 )? ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1573:1: ( ( rule__Reference__MultiplicityAssignment_3 )? )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1573:1: ( ( rule__Reference__MultiplicityAssignment_3 )? )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1574:1: ( rule__Reference__MultiplicityAssignment_3 )?
            {
             before(grammarAccess.getReferenceAccess().getMultiplicityAssignment_3()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1575:1: ( rule__Reference__MultiplicityAssignment_3 )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( ((LA14_0>=14 && LA14_0<=15)) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1575:2: rule__Reference__MultiplicityAssignment_3
                    {
                    pushFollow(FOLLOW_rule__Reference__MultiplicityAssignment_3_in_rule__Reference__Group__3__Impl3208);
                    rule__Reference__MultiplicityAssignment_3();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getReferenceAccess().getMultiplicityAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__3__Impl"


    // $ANTLR start "rule__ListWindow__Group__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1593:1: rule__ListWindow__Group__0 : rule__ListWindow__Group__0__Impl rule__ListWindow__Group__1 ;
    public final void rule__ListWindow__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1597:1: ( rule__ListWindow__Group__0__Impl rule__ListWindow__Group__1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1598:2: rule__ListWindow__Group__0__Impl rule__ListWindow__Group__1
            {
            pushFollow(FOLLOW_rule__ListWindow__Group__0__Impl_in_rule__ListWindow__Group__03247);
            rule__ListWindow__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ListWindow__Group__1_in_rule__ListWindow__Group__03250);
            rule__ListWindow__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__0"


    // $ANTLR start "rule__ListWindow__Group__0__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1605:1: rule__ListWindow__Group__0__Impl : ( 'ListWindow' ) ;
    public final void rule__ListWindow__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1609:1: ( ( 'ListWindow' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1610:1: ( 'ListWindow' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1610:1: ( 'ListWindow' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1611:1: 'ListWindow'
            {
             before(grammarAccess.getListWindowAccess().getListWindowKeyword_0()); 
            match(input,27,FOLLOW_27_in_rule__ListWindow__Group__0__Impl3278); 
             after(grammarAccess.getListWindowAccess().getListWindowKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__0__Impl"


    // $ANTLR start "rule__ListWindow__Group__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1624:1: rule__ListWindow__Group__1 : rule__ListWindow__Group__1__Impl rule__ListWindow__Group__2 ;
    public final void rule__ListWindow__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1628:1: ( rule__ListWindow__Group__1__Impl rule__ListWindow__Group__2 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1629:2: rule__ListWindow__Group__1__Impl rule__ListWindow__Group__2
            {
            pushFollow(FOLLOW_rule__ListWindow__Group__1__Impl_in_rule__ListWindow__Group__13309);
            rule__ListWindow__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ListWindow__Group__2_in_rule__ListWindow__Group__13312);
            rule__ListWindow__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__1"


    // $ANTLR start "rule__ListWindow__Group__1__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1636:1: rule__ListWindow__Group__1__Impl : ( ( rule__ListWindow__NameAssignment_1 ) ) ;
    public final void rule__ListWindow__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1640:1: ( ( ( rule__ListWindow__NameAssignment_1 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1641:1: ( ( rule__ListWindow__NameAssignment_1 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1641:1: ( ( rule__ListWindow__NameAssignment_1 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1642:1: ( rule__ListWindow__NameAssignment_1 )
            {
             before(grammarAccess.getListWindowAccess().getNameAssignment_1()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1643:1: ( rule__ListWindow__NameAssignment_1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1643:2: rule__ListWindow__NameAssignment_1
            {
            pushFollow(FOLLOW_rule__ListWindow__NameAssignment_1_in_rule__ListWindow__Group__1__Impl3339);
            rule__ListWindow__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getListWindowAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__1__Impl"


    // $ANTLR start "rule__ListWindow__Group__2"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1653:1: rule__ListWindow__Group__2 : rule__ListWindow__Group__2__Impl rule__ListWindow__Group__3 ;
    public final void rule__ListWindow__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1657:1: ( rule__ListWindow__Group__2__Impl rule__ListWindow__Group__3 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1658:2: rule__ListWindow__Group__2__Impl rule__ListWindow__Group__3
            {
            pushFollow(FOLLOW_rule__ListWindow__Group__2__Impl_in_rule__ListWindow__Group__23369);
            rule__ListWindow__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ListWindow__Group__3_in_rule__ListWindow__Group__23372);
            rule__ListWindow__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__2"


    // $ANTLR start "rule__ListWindow__Group__2__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1665:1: rule__ListWindow__Group__2__Impl : ( 'for' ) ;
    public final void rule__ListWindow__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1669:1: ( ( 'for' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1670:1: ( 'for' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1670:1: ( 'for' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1671:1: 'for'
            {
             before(grammarAccess.getListWindowAccess().getForKeyword_2()); 
            match(input,28,FOLLOW_28_in_rule__ListWindow__Group__2__Impl3400); 
             after(grammarAccess.getListWindowAccess().getForKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__2__Impl"


    // $ANTLR start "rule__ListWindow__Group__3"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1684:1: rule__ListWindow__Group__3 : rule__ListWindow__Group__3__Impl rule__ListWindow__Group__4 ;
    public final void rule__ListWindow__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1688:1: ( rule__ListWindow__Group__3__Impl rule__ListWindow__Group__4 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1689:2: rule__ListWindow__Group__3__Impl rule__ListWindow__Group__4
            {
            pushFollow(FOLLOW_rule__ListWindow__Group__3__Impl_in_rule__ListWindow__Group__33431);
            rule__ListWindow__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ListWindow__Group__4_in_rule__ListWindow__Group__33434);
            rule__ListWindow__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__3"


    // $ANTLR start "rule__ListWindow__Group__3__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1696:1: rule__ListWindow__Group__3__Impl : ( ( rule__ListWindow__EntitytypeAssignment_3 ) ) ;
    public final void rule__ListWindow__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1700:1: ( ( ( rule__ListWindow__EntitytypeAssignment_3 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1701:1: ( ( rule__ListWindow__EntitytypeAssignment_3 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1701:1: ( ( rule__ListWindow__EntitytypeAssignment_3 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1702:1: ( rule__ListWindow__EntitytypeAssignment_3 )
            {
             before(grammarAccess.getListWindowAccess().getEntitytypeAssignment_3()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1703:1: ( rule__ListWindow__EntitytypeAssignment_3 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1703:2: rule__ListWindow__EntitytypeAssignment_3
            {
            pushFollow(FOLLOW_rule__ListWindow__EntitytypeAssignment_3_in_rule__ListWindow__Group__3__Impl3461);
            rule__ListWindow__EntitytypeAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getListWindowAccess().getEntitytypeAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__3__Impl"


    // $ANTLR start "rule__ListWindow__Group__4"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1713:1: rule__ListWindow__Group__4 : rule__ListWindow__Group__4__Impl rule__ListWindow__Group__5 ;
    public final void rule__ListWindow__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1717:1: ( rule__ListWindow__Group__4__Impl rule__ListWindow__Group__5 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1718:2: rule__ListWindow__Group__4__Impl rule__ListWindow__Group__5
            {
            pushFollow(FOLLOW_rule__ListWindow__Group__4__Impl_in_rule__ListWindow__Group__43491);
            rule__ListWindow__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ListWindow__Group__5_in_rule__ListWindow__Group__43494);
            rule__ListWindow__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__4"


    // $ANTLR start "rule__ListWindow__Group__4__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1725:1: rule__ListWindow__Group__4__Impl : ( '{' ) ;
    public final void rule__ListWindow__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1729:1: ( ( '{' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1730:1: ( '{' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1730:1: ( '{' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1731:1: '{'
            {
             before(grammarAccess.getListWindowAccess().getLeftCurlyBracketKeyword_4()); 
            match(input,22,FOLLOW_22_in_rule__ListWindow__Group__4__Impl3522); 
             after(grammarAccess.getListWindowAccess().getLeftCurlyBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__4__Impl"


    // $ANTLR start "rule__ListWindow__Group__5"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1744:1: rule__ListWindow__Group__5 : rule__ListWindow__Group__5__Impl rule__ListWindow__Group__6 ;
    public final void rule__ListWindow__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1748:1: ( rule__ListWindow__Group__5__Impl rule__ListWindow__Group__6 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1749:2: rule__ListWindow__Group__5__Impl rule__ListWindow__Group__6
            {
            pushFollow(FOLLOW_rule__ListWindow__Group__5__Impl_in_rule__ListWindow__Group__53553);
            rule__ListWindow__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ListWindow__Group__6_in_rule__ListWindow__Group__53556);
            rule__ListWindow__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__5"


    // $ANTLR start "rule__ListWindow__Group__5__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1756:1: rule__ListWindow__Group__5__Impl : ( ( rule__ListWindow__OptionsAssignment_5 ) ) ;
    public final void rule__ListWindow__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1760:1: ( ( ( rule__ListWindow__OptionsAssignment_5 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1761:1: ( ( rule__ListWindow__OptionsAssignment_5 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1761:1: ( ( rule__ListWindow__OptionsAssignment_5 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1762:1: ( rule__ListWindow__OptionsAssignment_5 )
            {
             before(grammarAccess.getListWindowAccess().getOptionsAssignment_5()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1763:1: ( rule__ListWindow__OptionsAssignment_5 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1763:2: rule__ListWindow__OptionsAssignment_5
            {
            pushFollow(FOLLOW_rule__ListWindow__OptionsAssignment_5_in_rule__ListWindow__Group__5__Impl3583);
            rule__ListWindow__OptionsAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getListWindowAccess().getOptionsAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__5__Impl"


    // $ANTLR start "rule__ListWindow__Group__6"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1773:1: rule__ListWindow__Group__6 : rule__ListWindow__Group__6__Impl ;
    public final void rule__ListWindow__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1777:1: ( rule__ListWindow__Group__6__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1778:2: rule__ListWindow__Group__6__Impl
            {
            pushFollow(FOLLOW_rule__ListWindow__Group__6__Impl_in_rule__ListWindow__Group__63613);
            rule__ListWindow__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__6"


    // $ANTLR start "rule__ListWindow__Group__6__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1784:1: rule__ListWindow__Group__6__Impl : ( '}' ) ;
    public final void rule__ListWindow__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1788:1: ( ( '}' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1789:1: ( '}' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1789:1: ( '}' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1790:1: '}'
            {
             before(grammarAccess.getListWindowAccess().getRightCurlyBracketKeyword_6()); 
            match(input,23,FOLLOW_23_in_rule__ListWindow__Group__6__Impl3641); 
             after(grammarAccess.getListWindowAccess().getRightCurlyBracketKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__Group__6__Impl"


    // $ANTLR start "rule__EntryWindow__Group__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1817:1: rule__EntryWindow__Group__0 : rule__EntryWindow__Group__0__Impl rule__EntryWindow__Group__1 ;
    public final void rule__EntryWindow__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1821:1: ( rule__EntryWindow__Group__0__Impl rule__EntryWindow__Group__1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1822:2: rule__EntryWindow__Group__0__Impl rule__EntryWindow__Group__1
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group__0__Impl_in_rule__EntryWindow__Group__03686);
            rule__EntryWindow__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__EntryWindow__Group__1_in_rule__EntryWindow__Group__03689);
            rule__EntryWindow__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__0"


    // $ANTLR start "rule__EntryWindow__Group__0__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1829:1: rule__EntryWindow__Group__0__Impl : ( 'EntryWindow' ) ;
    public final void rule__EntryWindow__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1833:1: ( ( 'EntryWindow' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1834:1: ( 'EntryWindow' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1834:1: ( 'EntryWindow' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1835:1: 'EntryWindow'
            {
             before(grammarAccess.getEntryWindowAccess().getEntryWindowKeyword_0()); 
            match(input,29,FOLLOW_29_in_rule__EntryWindow__Group__0__Impl3717); 
             after(grammarAccess.getEntryWindowAccess().getEntryWindowKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__0__Impl"


    // $ANTLR start "rule__EntryWindow__Group__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1848:1: rule__EntryWindow__Group__1 : rule__EntryWindow__Group__1__Impl rule__EntryWindow__Group__2 ;
    public final void rule__EntryWindow__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1852:1: ( rule__EntryWindow__Group__1__Impl rule__EntryWindow__Group__2 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1853:2: rule__EntryWindow__Group__1__Impl rule__EntryWindow__Group__2
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group__1__Impl_in_rule__EntryWindow__Group__13748);
            rule__EntryWindow__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__EntryWindow__Group__2_in_rule__EntryWindow__Group__13751);
            rule__EntryWindow__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__1"


    // $ANTLR start "rule__EntryWindow__Group__1__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1860:1: rule__EntryWindow__Group__1__Impl : ( ( rule__EntryWindow__NameAssignment_1 ) ) ;
    public final void rule__EntryWindow__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1864:1: ( ( ( rule__EntryWindow__NameAssignment_1 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1865:1: ( ( rule__EntryWindow__NameAssignment_1 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1865:1: ( ( rule__EntryWindow__NameAssignment_1 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1866:1: ( rule__EntryWindow__NameAssignment_1 )
            {
             before(grammarAccess.getEntryWindowAccess().getNameAssignment_1()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1867:1: ( rule__EntryWindow__NameAssignment_1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1867:2: rule__EntryWindow__NameAssignment_1
            {
            pushFollow(FOLLOW_rule__EntryWindow__NameAssignment_1_in_rule__EntryWindow__Group__1__Impl3778);
            rule__EntryWindow__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getEntryWindowAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__1__Impl"


    // $ANTLR start "rule__EntryWindow__Group__2"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1877:1: rule__EntryWindow__Group__2 : rule__EntryWindow__Group__2__Impl rule__EntryWindow__Group__3 ;
    public final void rule__EntryWindow__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1881:1: ( rule__EntryWindow__Group__2__Impl rule__EntryWindow__Group__3 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1882:2: rule__EntryWindow__Group__2__Impl rule__EntryWindow__Group__3
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group__2__Impl_in_rule__EntryWindow__Group__23808);
            rule__EntryWindow__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__EntryWindow__Group__3_in_rule__EntryWindow__Group__23811);
            rule__EntryWindow__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__2"


    // $ANTLR start "rule__EntryWindow__Group__2__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1889:1: rule__EntryWindow__Group__2__Impl : ( 'for' ) ;
    public final void rule__EntryWindow__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1893:1: ( ( 'for' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1894:1: ( 'for' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1894:1: ( 'for' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1895:1: 'for'
            {
             before(grammarAccess.getEntryWindowAccess().getForKeyword_2()); 
            match(input,28,FOLLOW_28_in_rule__EntryWindow__Group__2__Impl3839); 
             after(grammarAccess.getEntryWindowAccess().getForKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__2__Impl"


    // $ANTLR start "rule__EntryWindow__Group__3"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1908:1: rule__EntryWindow__Group__3 : rule__EntryWindow__Group__3__Impl rule__EntryWindow__Group__4 ;
    public final void rule__EntryWindow__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1912:1: ( rule__EntryWindow__Group__3__Impl rule__EntryWindow__Group__4 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1913:2: rule__EntryWindow__Group__3__Impl rule__EntryWindow__Group__4
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group__3__Impl_in_rule__EntryWindow__Group__33870);
            rule__EntryWindow__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__EntryWindow__Group__4_in_rule__EntryWindow__Group__33873);
            rule__EntryWindow__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__3"


    // $ANTLR start "rule__EntryWindow__Group__3__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1920:1: rule__EntryWindow__Group__3__Impl : ( ( rule__EntryWindow__EntitytypeAssignment_3 ) ) ;
    public final void rule__EntryWindow__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1924:1: ( ( ( rule__EntryWindow__EntitytypeAssignment_3 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1925:1: ( ( rule__EntryWindow__EntitytypeAssignment_3 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1925:1: ( ( rule__EntryWindow__EntitytypeAssignment_3 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1926:1: ( rule__EntryWindow__EntitytypeAssignment_3 )
            {
             before(grammarAccess.getEntryWindowAccess().getEntitytypeAssignment_3()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1927:1: ( rule__EntryWindow__EntitytypeAssignment_3 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1927:2: rule__EntryWindow__EntitytypeAssignment_3
            {
            pushFollow(FOLLOW_rule__EntryWindow__EntitytypeAssignment_3_in_rule__EntryWindow__Group__3__Impl3900);
            rule__EntryWindow__EntitytypeAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getEntryWindowAccess().getEntitytypeAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__3__Impl"


    // $ANTLR start "rule__EntryWindow__Group__4"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1937:1: rule__EntryWindow__Group__4 : rule__EntryWindow__Group__4__Impl rule__EntryWindow__Group__5 ;
    public final void rule__EntryWindow__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1941:1: ( rule__EntryWindow__Group__4__Impl rule__EntryWindow__Group__5 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1942:2: rule__EntryWindow__Group__4__Impl rule__EntryWindow__Group__5
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group__4__Impl_in_rule__EntryWindow__Group__43930);
            rule__EntryWindow__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__EntryWindow__Group__5_in_rule__EntryWindow__Group__43933);
            rule__EntryWindow__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__4"


    // $ANTLR start "rule__EntryWindow__Group__4__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1949:1: rule__EntryWindow__Group__4__Impl : ( '{' ) ;
    public final void rule__EntryWindow__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1953:1: ( ( '{' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1954:1: ( '{' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1954:1: ( '{' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1955:1: '{'
            {
             before(grammarAccess.getEntryWindowAccess().getLeftCurlyBracketKeyword_4()); 
            match(input,22,FOLLOW_22_in_rule__EntryWindow__Group__4__Impl3961); 
             after(grammarAccess.getEntryWindowAccess().getLeftCurlyBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__4__Impl"


    // $ANTLR start "rule__EntryWindow__Group__5"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1968:1: rule__EntryWindow__Group__5 : rule__EntryWindow__Group__5__Impl rule__EntryWindow__Group__6 ;
    public final void rule__EntryWindow__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1972:1: ( rule__EntryWindow__Group__5__Impl rule__EntryWindow__Group__6 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1973:2: rule__EntryWindow__Group__5__Impl rule__EntryWindow__Group__6
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group__5__Impl_in_rule__EntryWindow__Group__53992);
            rule__EntryWindow__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__EntryWindow__Group__6_in_rule__EntryWindow__Group__53995);
            rule__EntryWindow__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__5"


    // $ANTLR start "rule__EntryWindow__Group__5__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1980:1: rule__EntryWindow__Group__5__Impl : ( ( rule__EntryWindow__OptionsAssignment_5 ) ) ;
    public final void rule__EntryWindow__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1984:1: ( ( ( rule__EntryWindow__OptionsAssignment_5 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1985:1: ( ( rule__EntryWindow__OptionsAssignment_5 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1985:1: ( ( rule__EntryWindow__OptionsAssignment_5 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1986:1: ( rule__EntryWindow__OptionsAssignment_5 )
            {
             before(grammarAccess.getEntryWindowAccess().getOptionsAssignment_5()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1987:1: ( rule__EntryWindow__OptionsAssignment_5 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1987:2: rule__EntryWindow__OptionsAssignment_5
            {
            pushFollow(FOLLOW_rule__EntryWindow__OptionsAssignment_5_in_rule__EntryWindow__Group__5__Impl4022);
            rule__EntryWindow__OptionsAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getEntryWindowAccess().getOptionsAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__5__Impl"


    // $ANTLR start "rule__EntryWindow__Group__6"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:1997:1: rule__EntryWindow__Group__6 : rule__EntryWindow__Group__6__Impl rule__EntryWindow__Group__7 ;
    public final void rule__EntryWindow__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2001:1: ( rule__EntryWindow__Group__6__Impl rule__EntryWindow__Group__7 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2002:2: rule__EntryWindow__Group__6__Impl rule__EntryWindow__Group__7
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group__6__Impl_in_rule__EntryWindow__Group__64052);
            rule__EntryWindow__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__EntryWindow__Group__7_in_rule__EntryWindow__Group__64055);
            rule__EntryWindow__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__6"


    // $ANTLR start "rule__EntryWindow__Group__6__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2009:1: rule__EntryWindow__Group__6__Impl : ( ( ( rule__EntryWindow__ElementsAssignment_6 ) ) ( ( rule__EntryWindow__ElementsAssignment_6 )* ) ) ;
    public final void rule__EntryWindow__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2013:1: ( ( ( ( rule__EntryWindow__ElementsAssignment_6 ) ) ( ( rule__EntryWindow__ElementsAssignment_6 )* ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2014:1: ( ( ( rule__EntryWindow__ElementsAssignment_6 ) ) ( ( rule__EntryWindow__ElementsAssignment_6 )* ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2014:1: ( ( ( rule__EntryWindow__ElementsAssignment_6 ) ) ( ( rule__EntryWindow__ElementsAssignment_6 )* ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2015:1: ( ( rule__EntryWindow__ElementsAssignment_6 ) ) ( ( rule__EntryWindow__ElementsAssignment_6 )* )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2015:1: ( ( rule__EntryWindow__ElementsAssignment_6 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2016:1: ( rule__EntryWindow__ElementsAssignment_6 )
            {
             before(grammarAccess.getEntryWindowAccess().getElementsAssignment_6()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2017:1: ( rule__EntryWindow__ElementsAssignment_6 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2017:2: rule__EntryWindow__ElementsAssignment_6
            {
            pushFollow(FOLLOW_rule__EntryWindow__ElementsAssignment_6_in_rule__EntryWindow__Group__6__Impl4084);
            rule__EntryWindow__ElementsAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getEntryWindowAccess().getElementsAssignment_6()); 

            }

            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2020:1: ( ( rule__EntryWindow__ElementsAssignment_6 )* )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2021:1: ( rule__EntryWindow__ElementsAssignment_6 )*
            {
             before(grammarAccess.getEntryWindowAccess().getElementsAssignment_6()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2022:1: ( rule__EntryWindow__ElementsAssignment_6 )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( ((LA15_0>=30 && LA15_0<=32)) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2022:2: rule__EntryWindow__ElementsAssignment_6
            	    {
            	    pushFollow(FOLLOW_rule__EntryWindow__ElementsAssignment_6_in_rule__EntryWindow__Group__6__Impl4096);
            	    rule__EntryWindow__ElementsAssignment_6();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);

             after(grammarAccess.getEntryWindowAccess().getElementsAssignment_6()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__6__Impl"


    // $ANTLR start "rule__EntryWindow__Group__7"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2033:1: rule__EntryWindow__Group__7 : rule__EntryWindow__Group__7__Impl ;
    public final void rule__EntryWindow__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2037:1: ( rule__EntryWindow__Group__7__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2038:2: rule__EntryWindow__Group__7__Impl
            {
            pushFollow(FOLLOW_rule__EntryWindow__Group__7__Impl_in_rule__EntryWindow__Group__74129);
            rule__EntryWindow__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__7"


    // $ANTLR start "rule__EntryWindow__Group__7__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2044:1: rule__EntryWindow__Group__7__Impl : ( '}' ) ;
    public final void rule__EntryWindow__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2048:1: ( ( '}' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2049:1: ( '}' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2049:1: ( '}' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2050:1: '}'
            {
             before(grammarAccess.getEntryWindowAccess().getRightCurlyBracketKeyword_7()); 
            match(input,23,FOLLOW_23_in_rule__EntryWindow__Group__7__Impl4157); 
             after(grammarAccess.getEntryWindowAccess().getRightCurlyBracketKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__Group__7__Impl"


    // $ANTLR start "rule__UIElement__Group__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2079:1: rule__UIElement__Group__0 : rule__UIElement__Group__0__Impl rule__UIElement__Group__1 ;
    public final void rule__UIElement__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2083:1: ( rule__UIElement__Group__0__Impl rule__UIElement__Group__1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2084:2: rule__UIElement__Group__0__Impl rule__UIElement__Group__1
            {
            pushFollow(FOLLOW_rule__UIElement__Group__0__Impl_in_rule__UIElement__Group__04204);
            rule__UIElement__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__UIElement__Group__1_in_rule__UIElement__Group__04207);
            rule__UIElement__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UIElement__Group__0"


    // $ANTLR start "rule__UIElement__Group__0__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2091:1: rule__UIElement__Group__0__Impl : ( ( rule__UIElement__Alternatives_0 ) ) ;
    public final void rule__UIElement__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2095:1: ( ( ( rule__UIElement__Alternatives_0 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2096:1: ( ( rule__UIElement__Alternatives_0 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2096:1: ( ( rule__UIElement__Alternatives_0 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2097:1: ( rule__UIElement__Alternatives_0 )
            {
             before(grammarAccess.getUIElementAccess().getAlternatives_0()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2098:1: ( rule__UIElement__Alternatives_0 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2098:2: rule__UIElement__Alternatives_0
            {
            pushFollow(FOLLOW_rule__UIElement__Alternatives_0_in_rule__UIElement__Group__0__Impl4234);
            rule__UIElement__Alternatives_0();

            state._fsp--;


            }

             after(grammarAccess.getUIElementAccess().getAlternatives_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UIElement__Group__0__Impl"


    // $ANTLR start "rule__UIElement__Group__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2108:1: rule__UIElement__Group__1 : rule__UIElement__Group__1__Impl ;
    public final void rule__UIElement__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2112:1: ( rule__UIElement__Group__1__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2113:2: rule__UIElement__Group__1__Impl
            {
            pushFollow(FOLLOW_rule__UIElement__Group__1__Impl_in_rule__UIElement__Group__14264);
            rule__UIElement__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UIElement__Group__1"


    // $ANTLR start "rule__UIElement__Group__1__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2119:1: rule__UIElement__Group__1__Impl : ( ( rule__UIElement__UiOptionsAssignment_1 ) ) ;
    public final void rule__UIElement__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2123:1: ( ( ( rule__UIElement__UiOptionsAssignment_1 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2124:1: ( ( rule__UIElement__UiOptionsAssignment_1 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2124:1: ( ( rule__UIElement__UiOptionsAssignment_1 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2125:1: ( rule__UIElement__UiOptionsAssignment_1 )
            {
             before(grammarAccess.getUIElementAccess().getUiOptionsAssignment_1()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2126:1: ( rule__UIElement__UiOptionsAssignment_1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2126:2: rule__UIElement__UiOptionsAssignment_1
            {
            pushFollow(FOLLOW_rule__UIElement__UiOptionsAssignment_1_in_rule__UIElement__Group__1__Impl4291);
            rule__UIElement__UiOptionsAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getUIElementAccess().getUiOptionsAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UIElement__Group__1__Impl"


    // $ANTLR start "rule__Label__Group__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2140:1: rule__Label__Group__0 : rule__Label__Group__0__Impl rule__Label__Group__1 ;
    public final void rule__Label__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2144:1: ( rule__Label__Group__0__Impl rule__Label__Group__1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2145:2: rule__Label__Group__0__Impl rule__Label__Group__1
            {
            pushFollow(FOLLOW_rule__Label__Group__0__Impl_in_rule__Label__Group__04325);
            rule__Label__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Label__Group__1_in_rule__Label__Group__04328);
            rule__Label__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__0"


    // $ANTLR start "rule__Label__Group__0__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2152:1: rule__Label__Group__0__Impl : ( 'Label' ) ;
    public final void rule__Label__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2156:1: ( ( 'Label' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2157:1: ( 'Label' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2157:1: ( 'Label' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2158:1: 'Label'
            {
             before(grammarAccess.getLabelAccess().getLabelKeyword_0()); 
            match(input,30,FOLLOW_30_in_rule__Label__Group__0__Impl4356); 
             after(grammarAccess.getLabelAccess().getLabelKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__0__Impl"


    // $ANTLR start "rule__Label__Group__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2171:1: rule__Label__Group__1 : rule__Label__Group__1__Impl rule__Label__Group__2 ;
    public final void rule__Label__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2175:1: ( rule__Label__Group__1__Impl rule__Label__Group__2 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2176:2: rule__Label__Group__1__Impl rule__Label__Group__2
            {
            pushFollow(FOLLOW_rule__Label__Group__1__Impl_in_rule__Label__Group__14387);
            rule__Label__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Label__Group__2_in_rule__Label__Group__14390);
            rule__Label__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__1"


    // $ANTLR start "rule__Label__Group__1__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2183:1: rule__Label__Group__1__Impl : ( ( rule__Label__NameAssignment_1 ) ) ;
    public final void rule__Label__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2187:1: ( ( ( rule__Label__NameAssignment_1 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2188:1: ( ( rule__Label__NameAssignment_1 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2188:1: ( ( rule__Label__NameAssignment_1 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2189:1: ( rule__Label__NameAssignment_1 )
            {
             before(grammarAccess.getLabelAccess().getNameAssignment_1()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2190:1: ( rule__Label__NameAssignment_1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2190:2: rule__Label__NameAssignment_1
            {
            pushFollow(FOLLOW_rule__Label__NameAssignment_1_in_rule__Label__Group__1__Impl4417);
            rule__Label__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getLabelAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__1__Impl"


    // $ANTLR start "rule__Label__Group__2"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2200:1: rule__Label__Group__2 : rule__Label__Group__2__Impl ;
    public final void rule__Label__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2204:1: ( rule__Label__Group__2__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2205:2: rule__Label__Group__2__Impl
            {
            pushFollow(FOLLOW_rule__Label__Group__2__Impl_in_rule__Label__Group__24447);
            rule__Label__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__2"


    // $ANTLR start "rule__Label__Group__2__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2211:1: rule__Label__Group__2__Impl : ( ( rule__Label__TextAssignment_2 )? ) ;
    public final void rule__Label__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2215:1: ( ( ( rule__Label__TextAssignment_2 )? ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2216:1: ( ( rule__Label__TextAssignment_2 )? )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2216:1: ( ( rule__Label__TextAssignment_2 )? )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2217:1: ( rule__Label__TextAssignment_2 )?
            {
             before(grammarAccess.getLabelAccess().getTextAssignment_2()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2218:1: ( rule__Label__TextAssignment_2 )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==RULE_STRING) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2218:2: rule__Label__TextAssignment_2
                    {
                    pushFollow(FOLLOW_rule__Label__TextAssignment_2_in_rule__Label__Group__2__Impl4474);
                    rule__Label__TextAssignment_2();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getLabelAccess().getTextAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Group__2__Impl"


    // $ANTLR start "rule__Field__Group__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2234:1: rule__Field__Group__0 : rule__Field__Group__0__Impl rule__Field__Group__1 ;
    public final void rule__Field__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2238:1: ( rule__Field__Group__0__Impl rule__Field__Group__1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2239:2: rule__Field__Group__0__Impl rule__Field__Group__1
            {
            pushFollow(FOLLOW_rule__Field__Group__0__Impl_in_rule__Field__Group__04511);
            rule__Field__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Field__Group__1_in_rule__Field__Group__04514);
            rule__Field__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group__0"


    // $ANTLR start "rule__Field__Group__0__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2246:1: rule__Field__Group__0__Impl : ( 'Field' ) ;
    public final void rule__Field__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2250:1: ( ( 'Field' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2251:1: ( 'Field' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2251:1: ( 'Field' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2252:1: 'Field'
            {
             before(grammarAccess.getFieldAccess().getFieldKeyword_0()); 
            match(input,31,FOLLOW_31_in_rule__Field__Group__0__Impl4542); 
             after(grammarAccess.getFieldAccess().getFieldKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group__0__Impl"


    // $ANTLR start "rule__Field__Group__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2265:1: rule__Field__Group__1 : rule__Field__Group__1__Impl ;
    public final void rule__Field__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2269:1: ( rule__Field__Group__1__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2270:2: rule__Field__Group__1__Impl
            {
            pushFollow(FOLLOW_rule__Field__Group__1__Impl_in_rule__Field__Group__14573);
            rule__Field__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group__1"


    // $ANTLR start "rule__Field__Group__1__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2276:1: rule__Field__Group__1__Impl : ( ( rule__Field__PropertyAssignment_1 ) ) ;
    public final void rule__Field__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2280:1: ( ( ( rule__Field__PropertyAssignment_1 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2281:1: ( ( rule__Field__PropertyAssignment_1 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2281:1: ( ( rule__Field__PropertyAssignment_1 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2282:1: ( rule__Field__PropertyAssignment_1 )
            {
             before(grammarAccess.getFieldAccess().getPropertyAssignment_1()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2283:1: ( rule__Field__PropertyAssignment_1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2283:2: rule__Field__PropertyAssignment_1
            {
            pushFollow(FOLLOW_rule__Field__PropertyAssignment_1_in_rule__Field__Group__1__Impl4600);
            rule__Field__PropertyAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getPropertyAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group__1__Impl"


    // $ANTLR start "rule__Button__Group__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2297:1: rule__Button__Group__0 : rule__Button__Group__0__Impl rule__Button__Group__1 ;
    public final void rule__Button__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2301:1: ( rule__Button__Group__0__Impl rule__Button__Group__1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2302:2: rule__Button__Group__0__Impl rule__Button__Group__1
            {
            pushFollow(FOLLOW_rule__Button__Group__0__Impl_in_rule__Button__Group__04634);
            rule__Button__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Button__Group__1_in_rule__Button__Group__04637);
            rule__Button__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__0"


    // $ANTLR start "rule__Button__Group__0__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2309:1: rule__Button__Group__0__Impl : ( 'Button' ) ;
    public final void rule__Button__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2313:1: ( ( 'Button' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2314:1: ( 'Button' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2314:1: ( 'Button' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2315:1: 'Button'
            {
             before(grammarAccess.getButtonAccess().getButtonKeyword_0()); 
            match(input,32,FOLLOW_32_in_rule__Button__Group__0__Impl4665); 
             after(grammarAccess.getButtonAccess().getButtonKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__0__Impl"


    // $ANTLR start "rule__Button__Group__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2328:1: rule__Button__Group__1 : rule__Button__Group__1__Impl ;
    public final void rule__Button__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2332:1: ( rule__Button__Group__1__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2333:2: rule__Button__Group__1__Impl
            {
            pushFollow(FOLLOW_rule__Button__Group__1__Impl_in_rule__Button__Group__14696);
            rule__Button__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__1"


    // $ANTLR start "rule__Button__Group__1__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2339:1: rule__Button__Group__1__Impl : ( ( rule__Button__InscriptionAssignment_1 ) ) ;
    public final void rule__Button__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2343:1: ( ( ( rule__Button__InscriptionAssignment_1 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2344:1: ( ( rule__Button__InscriptionAssignment_1 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2344:1: ( ( rule__Button__InscriptionAssignment_1 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2345:1: ( rule__Button__InscriptionAssignment_1 )
            {
             before(grammarAccess.getButtonAccess().getInscriptionAssignment_1()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2346:1: ( rule__Button__InscriptionAssignment_1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2346:2: rule__Button__InscriptionAssignment_1
            {
            pushFollow(FOLLOW_rule__Button__InscriptionAssignment_1_in_rule__Button__Group__1__Impl4723);
            rule__Button__InscriptionAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getButtonAccess().getInscriptionAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__Group__1__Impl"


    // $ANTLR start "rule__Size__Group_0__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2360:1: rule__Size__Group_0__0 : rule__Size__Group_0__0__Impl rule__Size__Group_0__1 ;
    public final void rule__Size__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2364:1: ( rule__Size__Group_0__0__Impl rule__Size__Group_0__1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2365:2: rule__Size__Group_0__0__Impl rule__Size__Group_0__1
            {
            pushFollow(FOLLOW_rule__Size__Group_0__0__Impl_in_rule__Size__Group_0__04757);
            rule__Size__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Size__Group_0__1_in_rule__Size__Group_0__04760);
            rule__Size__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group_0__0"


    // $ANTLR start "rule__Size__Group_0__0__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2372:1: rule__Size__Group_0__0__Impl : ( 'width' ) ;
    public final void rule__Size__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2376:1: ( ( 'width' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2377:1: ( 'width' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2377:1: ( 'width' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2378:1: 'width'
            {
             before(grammarAccess.getSizeAccess().getWidthKeyword_0_0()); 
            match(input,33,FOLLOW_33_in_rule__Size__Group_0__0__Impl4788); 
             after(grammarAccess.getSizeAccess().getWidthKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group_0__0__Impl"


    // $ANTLR start "rule__Size__Group_0__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2391:1: rule__Size__Group_0__1 : rule__Size__Group_0__1__Impl ;
    public final void rule__Size__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2395:1: ( rule__Size__Group_0__1__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2396:2: rule__Size__Group_0__1__Impl
            {
            pushFollow(FOLLOW_rule__Size__Group_0__1__Impl_in_rule__Size__Group_0__14819);
            rule__Size__Group_0__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group_0__1"


    // $ANTLR start "rule__Size__Group_0__1__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2402:1: rule__Size__Group_0__1__Impl : ( ( rule__Size__WidthAssignment_0_1 ) ) ;
    public final void rule__Size__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2406:1: ( ( ( rule__Size__WidthAssignment_0_1 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2407:1: ( ( rule__Size__WidthAssignment_0_1 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2407:1: ( ( rule__Size__WidthAssignment_0_1 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2408:1: ( rule__Size__WidthAssignment_0_1 )
            {
             before(grammarAccess.getSizeAccess().getWidthAssignment_0_1()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2409:1: ( rule__Size__WidthAssignment_0_1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2409:2: rule__Size__WidthAssignment_0_1
            {
            pushFollow(FOLLOW_rule__Size__WidthAssignment_0_1_in_rule__Size__Group_0__1__Impl4846);
            rule__Size__WidthAssignment_0_1();

            state._fsp--;


            }

             after(grammarAccess.getSizeAccess().getWidthAssignment_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group_0__1__Impl"


    // $ANTLR start "rule__Size__Group_1__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2423:1: rule__Size__Group_1__0 : rule__Size__Group_1__0__Impl rule__Size__Group_1__1 ;
    public final void rule__Size__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2427:1: ( rule__Size__Group_1__0__Impl rule__Size__Group_1__1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2428:2: rule__Size__Group_1__0__Impl rule__Size__Group_1__1
            {
            pushFollow(FOLLOW_rule__Size__Group_1__0__Impl_in_rule__Size__Group_1__04880);
            rule__Size__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Size__Group_1__1_in_rule__Size__Group_1__04883);
            rule__Size__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group_1__0"


    // $ANTLR start "rule__Size__Group_1__0__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2435:1: rule__Size__Group_1__0__Impl : ( 'height' ) ;
    public final void rule__Size__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2439:1: ( ( 'height' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2440:1: ( 'height' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2440:1: ( 'height' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2441:1: 'height'
            {
             before(grammarAccess.getSizeAccess().getHeightKeyword_1_0()); 
            match(input,34,FOLLOW_34_in_rule__Size__Group_1__0__Impl4911); 
             after(grammarAccess.getSizeAccess().getHeightKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group_1__0__Impl"


    // $ANTLR start "rule__Size__Group_1__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2454:1: rule__Size__Group_1__1 : rule__Size__Group_1__1__Impl ;
    public final void rule__Size__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2458:1: ( rule__Size__Group_1__1__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2459:2: rule__Size__Group_1__1__Impl
            {
            pushFollow(FOLLOW_rule__Size__Group_1__1__Impl_in_rule__Size__Group_1__14942);
            rule__Size__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group_1__1"


    // $ANTLR start "rule__Size__Group_1__1__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2465:1: rule__Size__Group_1__1__Impl : ( ( rule__Size__HeightAssignment_1_1 ) ) ;
    public final void rule__Size__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2469:1: ( ( ( rule__Size__HeightAssignment_1_1 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2470:1: ( ( rule__Size__HeightAssignment_1_1 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2470:1: ( ( rule__Size__HeightAssignment_1_1 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2471:1: ( rule__Size__HeightAssignment_1_1 )
            {
             before(grammarAccess.getSizeAccess().getHeightAssignment_1_1()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2472:1: ( rule__Size__HeightAssignment_1_1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2472:2: rule__Size__HeightAssignment_1_1
            {
            pushFollow(FOLLOW_rule__Size__HeightAssignment_1_1_in_rule__Size__Group_1__1__Impl4969);
            rule__Size__HeightAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getSizeAccess().getHeightAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__Group_1__1__Impl"


    // $ANTLR start "rule__Position__Group_0__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2486:1: rule__Position__Group_0__0 : rule__Position__Group_0__0__Impl rule__Position__Group_0__1 ;
    public final void rule__Position__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2490:1: ( rule__Position__Group_0__0__Impl rule__Position__Group_0__1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2491:2: rule__Position__Group_0__0__Impl rule__Position__Group_0__1
            {
            pushFollow(FOLLOW_rule__Position__Group_0__0__Impl_in_rule__Position__Group_0__05003);
            rule__Position__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Position__Group_0__1_in_rule__Position__Group_0__05006);
            rule__Position__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_0__0"


    // $ANTLR start "rule__Position__Group_0__0__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2498:1: rule__Position__Group_0__0__Impl : ( 'x_value' ) ;
    public final void rule__Position__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2502:1: ( ( 'x_value' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2503:1: ( 'x_value' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2503:1: ( 'x_value' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2504:1: 'x_value'
            {
             before(grammarAccess.getPositionAccess().getX_valueKeyword_0_0()); 
            match(input,35,FOLLOW_35_in_rule__Position__Group_0__0__Impl5034); 
             after(grammarAccess.getPositionAccess().getX_valueKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_0__0__Impl"


    // $ANTLR start "rule__Position__Group_0__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2517:1: rule__Position__Group_0__1 : rule__Position__Group_0__1__Impl ;
    public final void rule__Position__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2521:1: ( rule__Position__Group_0__1__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2522:2: rule__Position__Group_0__1__Impl
            {
            pushFollow(FOLLOW_rule__Position__Group_0__1__Impl_in_rule__Position__Group_0__15065);
            rule__Position__Group_0__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_0__1"


    // $ANTLR start "rule__Position__Group_0__1__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2528:1: rule__Position__Group_0__1__Impl : ( ( rule__Position__XAssignment_0_1 ) ) ;
    public final void rule__Position__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2532:1: ( ( ( rule__Position__XAssignment_0_1 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2533:1: ( ( rule__Position__XAssignment_0_1 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2533:1: ( ( rule__Position__XAssignment_0_1 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2534:1: ( rule__Position__XAssignment_0_1 )
            {
             before(grammarAccess.getPositionAccess().getXAssignment_0_1()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2535:1: ( rule__Position__XAssignment_0_1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2535:2: rule__Position__XAssignment_0_1
            {
            pushFollow(FOLLOW_rule__Position__XAssignment_0_1_in_rule__Position__Group_0__1__Impl5092);
            rule__Position__XAssignment_0_1();

            state._fsp--;


            }

             after(grammarAccess.getPositionAccess().getXAssignment_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_0__1__Impl"


    // $ANTLR start "rule__Position__Group_1__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2549:1: rule__Position__Group_1__0 : rule__Position__Group_1__0__Impl rule__Position__Group_1__1 ;
    public final void rule__Position__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2553:1: ( rule__Position__Group_1__0__Impl rule__Position__Group_1__1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2554:2: rule__Position__Group_1__0__Impl rule__Position__Group_1__1
            {
            pushFollow(FOLLOW_rule__Position__Group_1__0__Impl_in_rule__Position__Group_1__05126);
            rule__Position__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Position__Group_1__1_in_rule__Position__Group_1__05129);
            rule__Position__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_1__0"


    // $ANTLR start "rule__Position__Group_1__0__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2561:1: rule__Position__Group_1__0__Impl : ( 'y_value' ) ;
    public final void rule__Position__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2565:1: ( ( 'y_value' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2566:1: ( 'y_value' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2566:1: ( 'y_value' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2567:1: 'y_value'
            {
             before(grammarAccess.getPositionAccess().getY_valueKeyword_1_0()); 
            match(input,36,FOLLOW_36_in_rule__Position__Group_1__0__Impl5157); 
             after(grammarAccess.getPositionAccess().getY_valueKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_1__0__Impl"


    // $ANTLR start "rule__Position__Group_1__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2580:1: rule__Position__Group_1__1 : rule__Position__Group_1__1__Impl ;
    public final void rule__Position__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2584:1: ( rule__Position__Group_1__1__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2585:2: rule__Position__Group_1__1__Impl
            {
            pushFollow(FOLLOW_rule__Position__Group_1__1__Impl_in_rule__Position__Group_1__15188);
            rule__Position__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_1__1"


    // $ANTLR start "rule__Position__Group_1__1__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2591:1: rule__Position__Group_1__1__Impl : ( ( rule__Position__YAssignment_1_1 ) ) ;
    public final void rule__Position__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2595:1: ( ( ( rule__Position__YAssignment_1_1 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2596:1: ( ( rule__Position__YAssignment_1_1 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2596:1: ( ( rule__Position__YAssignment_1_1 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2597:1: ( rule__Position__YAssignment_1_1 )
            {
             before(grammarAccess.getPositionAccess().getYAssignment_1_1()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2598:1: ( rule__Position__YAssignment_1_1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2598:2: rule__Position__YAssignment_1_1
            {
            pushFollow(FOLLOW_rule__Position__YAssignment_1_1_in_rule__Position__Group_1__1__Impl5215);
            rule__Position__YAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getPositionAccess().getYAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__Group_1__1__Impl"


    // $ANTLR start "rule__WindowOptions__Group_1__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2612:1: rule__WindowOptions__Group_1__0 : rule__WindowOptions__Group_1__0__Impl rule__WindowOptions__Group_1__1 ;
    public final void rule__WindowOptions__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2616:1: ( rule__WindowOptions__Group_1__0__Impl rule__WindowOptions__Group_1__1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2617:2: rule__WindowOptions__Group_1__0__Impl rule__WindowOptions__Group_1__1
            {
            pushFollow(FOLLOW_rule__WindowOptions__Group_1__0__Impl_in_rule__WindowOptions__Group_1__05249);
            rule__WindowOptions__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__WindowOptions__Group_1__1_in_rule__WindowOptions__Group_1__05252);
            rule__WindowOptions__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__WindowOptions__Group_1__0"


    // $ANTLR start "rule__WindowOptions__Group_1__0__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2624:1: rule__WindowOptions__Group_1__0__Impl : ( 'title' ) ;
    public final void rule__WindowOptions__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2628:1: ( ( 'title' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2629:1: ( 'title' )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2629:1: ( 'title' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2630:1: 'title'
            {
             before(grammarAccess.getWindowOptionsAccess().getTitleKeyword_1_0()); 
            match(input,37,FOLLOW_37_in_rule__WindowOptions__Group_1__0__Impl5280); 
             after(grammarAccess.getWindowOptionsAccess().getTitleKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__WindowOptions__Group_1__0__Impl"


    // $ANTLR start "rule__WindowOptions__Group_1__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2643:1: rule__WindowOptions__Group_1__1 : rule__WindowOptions__Group_1__1__Impl ;
    public final void rule__WindowOptions__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2647:1: ( rule__WindowOptions__Group_1__1__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2648:2: rule__WindowOptions__Group_1__1__Impl
            {
            pushFollow(FOLLOW_rule__WindowOptions__Group_1__1__Impl_in_rule__WindowOptions__Group_1__15311);
            rule__WindowOptions__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__WindowOptions__Group_1__1"


    // $ANTLR start "rule__WindowOptions__Group_1__1__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2654:1: rule__WindowOptions__Group_1__1__Impl : ( ( rule__WindowOptions__TitleAssignment_1_1 ) ) ;
    public final void rule__WindowOptions__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2658:1: ( ( ( rule__WindowOptions__TitleAssignment_1_1 ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2659:1: ( ( rule__WindowOptions__TitleAssignment_1_1 ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2659:1: ( ( rule__WindowOptions__TitleAssignment_1_1 ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2660:1: ( rule__WindowOptions__TitleAssignment_1_1 )
            {
             before(grammarAccess.getWindowOptionsAccess().getTitleAssignment_1_1()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2661:1: ( rule__WindowOptions__TitleAssignment_1_1 )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2661:2: rule__WindowOptions__TitleAssignment_1_1
            {
            pushFollow(FOLLOW_rule__WindowOptions__TitleAssignment_1_1_in_rule__WindowOptions__Group_1__1__Impl5338);
            rule__WindowOptions__TitleAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getWindowOptionsAccess().getTitleAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__WindowOptions__Group_1__1__Impl"


    // $ANTLR start "rule__UIOptions__UnorderedGroup"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2676:1: rule__UIOptions__UnorderedGroup : rule__UIOptions__UnorderedGroup__0 {...}?;
    public final void rule__UIOptions__UnorderedGroup() throws RecognitionException {

            	int stackSize = keepStackSize();
        		getUnorderedGroupHelper().enter(grammarAccess.getUIOptionsAccess().getUnorderedGroup());
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2681:1: ( rule__UIOptions__UnorderedGroup__0 {...}?)
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2682:2: rule__UIOptions__UnorderedGroup__0 {...}?
            {
            pushFollow(FOLLOW_rule__UIOptions__UnorderedGroup__0_in_rule__UIOptions__UnorderedGroup5373);
            rule__UIOptions__UnorderedGroup__0();

            state._fsp--;

            if ( ! getUnorderedGroupHelper().canLeave(grammarAccess.getUIOptionsAccess().getUnorderedGroup()) ) {
                throw new FailedPredicateException(input, "rule__UIOptions__UnorderedGroup", "getUnorderedGroupHelper().canLeave(grammarAccess.getUIOptionsAccess().getUnorderedGroup())");
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	getUnorderedGroupHelper().leave(grammarAccess.getUIOptionsAccess().getUnorderedGroup());
            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UIOptions__UnorderedGroup"


    // $ANTLR start "rule__UIOptions__UnorderedGroup__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2693:1: rule__UIOptions__UnorderedGroup__Impl : ( ({...}? => ( ( ( rule__UIOptions__PositionAssignment_0 ) ) ) ) | ({...}? => ( ( ( rule__UIOptions__SizeAssignment_1 ) ) ) ) ) ;
    public final void rule__UIOptions__UnorderedGroup__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        		boolean selected = false;
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2698:1: ( ( ({...}? => ( ( ( rule__UIOptions__PositionAssignment_0 ) ) ) ) | ({...}? => ( ( ( rule__UIOptions__SizeAssignment_1 ) ) ) ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2699:3: ( ({...}? => ( ( ( rule__UIOptions__PositionAssignment_0 ) ) ) ) | ({...}? => ( ( ( rule__UIOptions__SizeAssignment_1 ) ) ) ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2699:3: ( ({...}? => ( ( ( rule__UIOptions__PositionAssignment_0 ) ) ) ) | ({...}? => ( ( ( rule__UIOptions__SizeAssignment_1 ) ) ) ) )
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( LA17_0 >=35 && LA17_0<=36 && getUnorderedGroupHelper().canSelect(grammarAccess.getUIOptionsAccess().getUnorderedGroup(), 0) ) {
                alt17=1;
            }
            else if ( LA17_0 >=33 && LA17_0<=34 && getUnorderedGroupHelper().canSelect(grammarAccess.getUIOptionsAccess().getUnorderedGroup(), 1) ) {
                alt17=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }
            switch (alt17) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2701:4: ({...}? => ( ( ( rule__UIOptions__PositionAssignment_0 ) ) ) )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2701:4: ({...}? => ( ( ( rule__UIOptions__PositionAssignment_0 ) ) ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2702:5: {...}? => ( ( ( rule__UIOptions__PositionAssignment_0 ) ) )
                    {
                    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getUIOptionsAccess().getUnorderedGroup(), 0) ) {
                        throw new FailedPredicateException(input, "rule__UIOptions__UnorderedGroup__Impl", "getUnorderedGroupHelper().canSelect(grammarAccess.getUIOptionsAccess().getUnorderedGroup(), 0)");
                    }
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2702:104: ( ( ( rule__UIOptions__PositionAssignment_0 ) ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2703:6: ( ( rule__UIOptions__PositionAssignment_0 ) )
                    {
                     
                    	 				  getUnorderedGroupHelper().select(grammarAccess.getUIOptionsAccess().getUnorderedGroup(), 0);
                    	 				

                    	 				  selected = true;
                    	 				
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2709:6: ( ( rule__UIOptions__PositionAssignment_0 ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2711:7: ( rule__UIOptions__PositionAssignment_0 )
                    {
                     before(grammarAccess.getUIOptionsAccess().getPositionAssignment_0()); 
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2712:7: ( rule__UIOptions__PositionAssignment_0 )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2712:8: rule__UIOptions__PositionAssignment_0
                    {
                    pushFollow(FOLLOW_rule__UIOptions__PositionAssignment_0_in_rule__UIOptions__UnorderedGroup__Impl5462);
                    rule__UIOptions__PositionAssignment_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getUIOptionsAccess().getPositionAssignment_0()); 

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2718:4: ({...}? => ( ( ( rule__UIOptions__SizeAssignment_1 ) ) ) )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2718:4: ({...}? => ( ( ( rule__UIOptions__SizeAssignment_1 ) ) ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2719:5: {...}? => ( ( ( rule__UIOptions__SizeAssignment_1 ) ) )
                    {
                    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getUIOptionsAccess().getUnorderedGroup(), 1) ) {
                        throw new FailedPredicateException(input, "rule__UIOptions__UnorderedGroup__Impl", "getUnorderedGroupHelper().canSelect(grammarAccess.getUIOptionsAccess().getUnorderedGroup(), 1)");
                    }
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2719:104: ( ( ( rule__UIOptions__SizeAssignment_1 ) ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2720:6: ( ( rule__UIOptions__SizeAssignment_1 ) )
                    {
                     
                    	 				  getUnorderedGroupHelper().select(grammarAccess.getUIOptionsAccess().getUnorderedGroup(), 1);
                    	 				

                    	 				  selected = true;
                    	 				
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2726:6: ( ( rule__UIOptions__SizeAssignment_1 ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2728:7: ( rule__UIOptions__SizeAssignment_1 )
                    {
                     before(grammarAccess.getUIOptionsAccess().getSizeAssignment_1()); 
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2729:7: ( rule__UIOptions__SizeAssignment_1 )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2729:8: rule__UIOptions__SizeAssignment_1
                    {
                    pushFollow(FOLLOW_rule__UIOptions__SizeAssignment_1_in_rule__UIOptions__UnorderedGroup__Impl5553);
                    rule__UIOptions__SizeAssignment_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getUIOptionsAccess().getSizeAssignment_1()); 

                    }


                    }


                    }


                    }
                    break;

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	if (selected)
            		getUnorderedGroupHelper().returnFromSelection(grammarAccess.getUIOptionsAccess().getUnorderedGroup());
            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UIOptions__UnorderedGroup__Impl"


    // $ANTLR start "rule__UIOptions__UnorderedGroup__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2744:1: rule__UIOptions__UnorderedGroup__0 : rule__UIOptions__UnorderedGroup__Impl ( rule__UIOptions__UnorderedGroup__1 )? ;
    public final void rule__UIOptions__UnorderedGroup__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2748:1: ( rule__UIOptions__UnorderedGroup__Impl ( rule__UIOptions__UnorderedGroup__1 )? )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2749:2: rule__UIOptions__UnorderedGroup__Impl ( rule__UIOptions__UnorderedGroup__1 )?
            {
            pushFollow(FOLLOW_rule__UIOptions__UnorderedGroup__Impl_in_rule__UIOptions__UnorderedGroup__05612);
            rule__UIOptions__UnorderedGroup__Impl();

            state._fsp--;

            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2750:2: ( rule__UIOptions__UnorderedGroup__1 )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( LA18_0 >=35 && LA18_0<=36 && getUnorderedGroupHelper().canSelect(grammarAccess.getUIOptionsAccess().getUnorderedGroup(), 0) ) {
                alt18=1;
            }
            else if ( LA18_0 >=33 && LA18_0<=34 && getUnorderedGroupHelper().canSelect(grammarAccess.getUIOptionsAccess().getUnorderedGroup(), 1) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2750:2: rule__UIOptions__UnorderedGroup__1
                    {
                    pushFollow(FOLLOW_rule__UIOptions__UnorderedGroup__1_in_rule__UIOptions__UnorderedGroup__05615);
                    rule__UIOptions__UnorderedGroup__1();

                    state._fsp--;


                    }
                    break;

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UIOptions__UnorderedGroup__0"


    // $ANTLR start "rule__UIOptions__UnorderedGroup__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2757:1: rule__UIOptions__UnorderedGroup__1 : rule__UIOptions__UnorderedGroup__Impl ;
    public final void rule__UIOptions__UnorderedGroup__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2761:1: ( rule__UIOptions__UnorderedGroup__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2762:2: rule__UIOptions__UnorderedGroup__Impl
            {
            pushFollow(FOLLOW_rule__UIOptions__UnorderedGroup__Impl_in_rule__UIOptions__UnorderedGroup__15640);
            rule__UIOptions__UnorderedGroup__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UIOptions__UnorderedGroup__1"


    // $ANTLR start "rule__Size__UnorderedGroup"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2773:1: rule__Size__UnorderedGroup : rule__Size__UnorderedGroup__0 {...}?;
    public final void rule__Size__UnorderedGroup() throws RecognitionException {

            	int stackSize = keepStackSize();
        		getUnorderedGroupHelper().enter(grammarAccess.getSizeAccess().getUnorderedGroup());
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2778:1: ( rule__Size__UnorderedGroup__0 {...}?)
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2779:2: rule__Size__UnorderedGroup__0 {...}?
            {
            pushFollow(FOLLOW_rule__Size__UnorderedGroup__0_in_rule__Size__UnorderedGroup5668);
            rule__Size__UnorderedGroup__0();

            state._fsp--;

            if ( ! getUnorderedGroupHelper().canLeave(grammarAccess.getSizeAccess().getUnorderedGroup()) ) {
                throw new FailedPredicateException(input, "rule__Size__UnorderedGroup", "getUnorderedGroupHelper().canLeave(grammarAccess.getSizeAccess().getUnorderedGroup())");
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	getUnorderedGroupHelper().leave(grammarAccess.getSizeAccess().getUnorderedGroup());
            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__UnorderedGroup"


    // $ANTLR start "rule__Size__UnorderedGroup__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2790:1: rule__Size__UnorderedGroup__Impl : ( ({...}? => ( ( ( rule__Size__Group_0__0 ) ) ) ) | ({...}? => ( ( ( rule__Size__Group_1__0 ) ) ) ) ) ;
    public final void rule__Size__UnorderedGroup__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        		boolean selected = false;
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2795:1: ( ( ({...}? => ( ( ( rule__Size__Group_0__0 ) ) ) ) | ({...}? => ( ( ( rule__Size__Group_1__0 ) ) ) ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2796:3: ( ({...}? => ( ( ( rule__Size__Group_0__0 ) ) ) ) | ({...}? => ( ( ( rule__Size__Group_1__0 ) ) ) ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2796:3: ( ({...}? => ( ( ( rule__Size__Group_0__0 ) ) ) ) | ({...}? => ( ( ( rule__Size__Group_1__0 ) ) ) ) )
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( LA19_0 ==33 && getUnorderedGroupHelper().canSelect(grammarAccess.getSizeAccess().getUnorderedGroup(), 0) ) {
                alt19=1;
            }
            else if ( LA19_0 ==34 && getUnorderedGroupHelper().canSelect(grammarAccess.getSizeAccess().getUnorderedGroup(), 1) ) {
                alt19=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }
            switch (alt19) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2798:4: ({...}? => ( ( ( rule__Size__Group_0__0 ) ) ) )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2798:4: ({...}? => ( ( ( rule__Size__Group_0__0 ) ) ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2799:5: {...}? => ( ( ( rule__Size__Group_0__0 ) ) )
                    {
                    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getSizeAccess().getUnorderedGroup(), 0) ) {
                        throw new FailedPredicateException(input, "rule__Size__UnorderedGroup__Impl", "getUnorderedGroupHelper().canSelect(grammarAccess.getSizeAccess().getUnorderedGroup(), 0)");
                    }
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2799:99: ( ( ( rule__Size__Group_0__0 ) ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2800:6: ( ( rule__Size__Group_0__0 ) )
                    {
                     
                    	 				  getUnorderedGroupHelper().select(grammarAccess.getSizeAccess().getUnorderedGroup(), 0);
                    	 				

                    	 				  selected = true;
                    	 				
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2806:6: ( ( rule__Size__Group_0__0 ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2808:7: ( rule__Size__Group_0__0 )
                    {
                     before(grammarAccess.getSizeAccess().getGroup_0()); 
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2809:7: ( rule__Size__Group_0__0 )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2809:8: rule__Size__Group_0__0
                    {
                    pushFollow(FOLLOW_rule__Size__Group_0__0_in_rule__Size__UnorderedGroup__Impl5757);
                    rule__Size__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getSizeAccess().getGroup_0()); 

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2815:4: ({...}? => ( ( ( rule__Size__Group_1__0 ) ) ) )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2815:4: ({...}? => ( ( ( rule__Size__Group_1__0 ) ) ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2816:5: {...}? => ( ( ( rule__Size__Group_1__0 ) ) )
                    {
                    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getSizeAccess().getUnorderedGroup(), 1) ) {
                        throw new FailedPredicateException(input, "rule__Size__UnorderedGroup__Impl", "getUnorderedGroupHelper().canSelect(grammarAccess.getSizeAccess().getUnorderedGroup(), 1)");
                    }
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2816:99: ( ( ( rule__Size__Group_1__0 ) ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2817:6: ( ( rule__Size__Group_1__0 ) )
                    {
                     
                    	 				  getUnorderedGroupHelper().select(grammarAccess.getSizeAccess().getUnorderedGroup(), 1);
                    	 				

                    	 				  selected = true;
                    	 				
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2823:6: ( ( rule__Size__Group_1__0 ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2825:7: ( rule__Size__Group_1__0 )
                    {
                     before(grammarAccess.getSizeAccess().getGroup_1()); 
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2826:7: ( rule__Size__Group_1__0 )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2826:8: rule__Size__Group_1__0
                    {
                    pushFollow(FOLLOW_rule__Size__Group_1__0_in_rule__Size__UnorderedGroup__Impl5848);
                    rule__Size__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getSizeAccess().getGroup_1()); 

                    }


                    }


                    }


                    }
                    break;

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	if (selected)
            		getUnorderedGroupHelper().returnFromSelection(grammarAccess.getSizeAccess().getUnorderedGroup());
            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__UnorderedGroup__Impl"


    // $ANTLR start "rule__Size__UnorderedGroup__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2841:1: rule__Size__UnorderedGroup__0 : rule__Size__UnorderedGroup__Impl ( rule__Size__UnorderedGroup__1 )? ;
    public final void rule__Size__UnorderedGroup__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2845:1: ( rule__Size__UnorderedGroup__Impl ( rule__Size__UnorderedGroup__1 )? )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2846:2: rule__Size__UnorderedGroup__Impl ( rule__Size__UnorderedGroup__1 )?
            {
            pushFollow(FOLLOW_rule__Size__UnorderedGroup__Impl_in_rule__Size__UnorderedGroup__05907);
            rule__Size__UnorderedGroup__Impl();

            state._fsp--;

            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2847:2: ( rule__Size__UnorderedGroup__1 )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==33) ) {
                int LA20_1 = input.LA(2);

                if ( (LA20_1==RULE_INT) ) {
                    int LA20_4 = input.LA(3);

                    if ( getUnorderedGroupHelper().canSelect(grammarAccess.getSizeAccess().getUnorderedGroup(), 0) ) {
                        alt20=1;
                    }
                }
            }
            else if ( (LA20_0==34) ) {
                int LA20_2 = input.LA(2);

                if ( (LA20_2==RULE_INT) ) {
                    int LA20_5 = input.LA(3);

                    if ( getUnorderedGroupHelper().canSelect(grammarAccess.getSizeAccess().getUnorderedGroup(), 1) ) {
                        alt20=1;
                    }
                }
            }
            switch (alt20) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2847:2: rule__Size__UnorderedGroup__1
                    {
                    pushFollow(FOLLOW_rule__Size__UnorderedGroup__1_in_rule__Size__UnorderedGroup__05910);
                    rule__Size__UnorderedGroup__1();

                    state._fsp--;


                    }
                    break;

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__UnorderedGroup__0"


    // $ANTLR start "rule__Size__UnorderedGroup__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2854:1: rule__Size__UnorderedGroup__1 : rule__Size__UnorderedGroup__Impl ;
    public final void rule__Size__UnorderedGroup__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2858:1: ( rule__Size__UnorderedGroup__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2859:2: rule__Size__UnorderedGroup__Impl
            {
            pushFollow(FOLLOW_rule__Size__UnorderedGroup__Impl_in_rule__Size__UnorderedGroup__15935);
            rule__Size__UnorderedGroup__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__UnorderedGroup__1"


    // $ANTLR start "rule__Position__UnorderedGroup"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2870:1: rule__Position__UnorderedGroup : rule__Position__UnorderedGroup__0 {...}?;
    public final void rule__Position__UnorderedGroup() throws RecognitionException {

            	int stackSize = keepStackSize();
        		getUnorderedGroupHelper().enter(grammarAccess.getPositionAccess().getUnorderedGroup());
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2875:1: ( rule__Position__UnorderedGroup__0 {...}?)
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2876:2: rule__Position__UnorderedGroup__0 {...}?
            {
            pushFollow(FOLLOW_rule__Position__UnorderedGroup__0_in_rule__Position__UnorderedGroup5963);
            rule__Position__UnorderedGroup__0();

            state._fsp--;

            if ( ! getUnorderedGroupHelper().canLeave(grammarAccess.getPositionAccess().getUnorderedGroup()) ) {
                throw new FailedPredicateException(input, "rule__Position__UnorderedGroup", "getUnorderedGroupHelper().canLeave(grammarAccess.getPositionAccess().getUnorderedGroup())");
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	getUnorderedGroupHelper().leave(grammarAccess.getPositionAccess().getUnorderedGroup());
            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__UnorderedGroup"


    // $ANTLR start "rule__Position__UnorderedGroup__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2887:1: rule__Position__UnorderedGroup__Impl : ( ({...}? => ( ( ( rule__Position__Group_0__0 ) ) ) ) | ({...}? => ( ( ( rule__Position__Group_1__0 ) ) ) ) ) ;
    public final void rule__Position__UnorderedGroup__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        		boolean selected = false;
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2892:1: ( ( ({...}? => ( ( ( rule__Position__Group_0__0 ) ) ) ) | ({...}? => ( ( ( rule__Position__Group_1__0 ) ) ) ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2893:3: ( ({...}? => ( ( ( rule__Position__Group_0__0 ) ) ) ) | ({...}? => ( ( ( rule__Position__Group_1__0 ) ) ) ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2893:3: ( ({...}? => ( ( ( rule__Position__Group_0__0 ) ) ) ) | ({...}? => ( ( ( rule__Position__Group_1__0 ) ) ) ) )
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( LA21_0 ==35 && getUnorderedGroupHelper().canSelect(grammarAccess.getPositionAccess().getUnorderedGroup(), 0) ) {
                alt21=1;
            }
            else if ( LA21_0 ==36 && getUnorderedGroupHelper().canSelect(grammarAccess.getPositionAccess().getUnorderedGroup(), 1) ) {
                alt21=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 21, 0, input);

                throw nvae;
            }
            switch (alt21) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2895:4: ({...}? => ( ( ( rule__Position__Group_0__0 ) ) ) )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2895:4: ({...}? => ( ( ( rule__Position__Group_0__0 ) ) ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2896:5: {...}? => ( ( ( rule__Position__Group_0__0 ) ) )
                    {
                    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getPositionAccess().getUnorderedGroup(), 0) ) {
                        throw new FailedPredicateException(input, "rule__Position__UnorderedGroup__Impl", "getUnorderedGroupHelper().canSelect(grammarAccess.getPositionAccess().getUnorderedGroup(), 0)");
                    }
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2896:103: ( ( ( rule__Position__Group_0__0 ) ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2897:6: ( ( rule__Position__Group_0__0 ) )
                    {
                     
                    	 				  getUnorderedGroupHelper().select(grammarAccess.getPositionAccess().getUnorderedGroup(), 0);
                    	 				

                    	 				  selected = true;
                    	 				
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2903:6: ( ( rule__Position__Group_0__0 ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2905:7: ( rule__Position__Group_0__0 )
                    {
                     before(grammarAccess.getPositionAccess().getGroup_0()); 
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2906:7: ( rule__Position__Group_0__0 )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2906:8: rule__Position__Group_0__0
                    {
                    pushFollow(FOLLOW_rule__Position__Group_0__0_in_rule__Position__UnorderedGroup__Impl6052);
                    rule__Position__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPositionAccess().getGroup_0()); 

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2912:4: ({...}? => ( ( ( rule__Position__Group_1__0 ) ) ) )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2912:4: ({...}? => ( ( ( rule__Position__Group_1__0 ) ) ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2913:5: {...}? => ( ( ( rule__Position__Group_1__0 ) ) )
                    {
                    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getPositionAccess().getUnorderedGroup(), 1) ) {
                        throw new FailedPredicateException(input, "rule__Position__UnorderedGroup__Impl", "getUnorderedGroupHelper().canSelect(grammarAccess.getPositionAccess().getUnorderedGroup(), 1)");
                    }
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2913:103: ( ( ( rule__Position__Group_1__0 ) ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2914:6: ( ( rule__Position__Group_1__0 ) )
                    {
                     
                    	 				  getUnorderedGroupHelper().select(grammarAccess.getPositionAccess().getUnorderedGroup(), 1);
                    	 				

                    	 				  selected = true;
                    	 				
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2920:6: ( ( rule__Position__Group_1__0 ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2922:7: ( rule__Position__Group_1__0 )
                    {
                     before(grammarAccess.getPositionAccess().getGroup_1()); 
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2923:7: ( rule__Position__Group_1__0 )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2923:8: rule__Position__Group_1__0
                    {
                    pushFollow(FOLLOW_rule__Position__Group_1__0_in_rule__Position__UnorderedGroup__Impl6143);
                    rule__Position__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPositionAccess().getGroup_1()); 

                    }


                    }


                    }


                    }
                    break;

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	if (selected)
            		getUnorderedGroupHelper().returnFromSelection(grammarAccess.getPositionAccess().getUnorderedGroup());
            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__UnorderedGroup__Impl"


    // $ANTLR start "rule__Position__UnorderedGroup__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2938:1: rule__Position__UnorderedGroup__0 : rule__Position__UnorderedGroup__Impl ( rule__Position__UnorderedGroup__1 )? ;
    public final void rule__Position__UnorderedGroup__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2942:1: ( rule__Position__UnorderedGroup__Impl ( rule__Position__UnorderedGroup__1 )? )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2943:2: rule__Position__UnorderedGroup__Impl ( rule__Position__UnorderedGroup__1 )?
            {
            pushFollow(FOLLOW_rule__Position__UnorderedGroup__Impl_in_rule__Position__UnorderedGroup__06202);
            rule__Position__UnorderedGroup__Impl();

            state._fsp--;

            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2944:2: ( rule__Position__UnorderedGroup__1 )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==35) ) {
                int LA22_1 = input.LA(2);

                if ( (LA22_1==RULE_INT) ) {
                    int LA22_4 = input.LA(3);

                    if ( getUnorderedGroupHelper().canSelect(grammarAccess.getPositionAccess().getUnorderedGroup(), 0) ) {
                        alt22=1;
                    }
                }
            }
            else if ( (LA22_0==36) ) {
                int LA22_2 = input.LA(2);

                if ( (LA22_2==RULE_INT) ) {
                    int LA22_5 = input.LA(3);

                    if ( getUnorderedGroupHelper().canSelect(grammarAccess.getPositionAccess().getUnorderedGroup(), 1) ) {
                        alt22=1;
                    }
                }
            }
            switch (alt22) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2944:2: rule__Position__UnorderedGroup__1
                    {
                    pushFollow(FOLLOW_rule__Position__UnorderedGroup__1_in_rule__Position__UnorderedGroup__06205);
                    rule__Position__UnorderedGroup__1();

                    state._fsp--;


                    }
                    break;

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__UnorderedGroup__0"


    // $ANTLR start "rule__Position__UnorderedGroup__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2951:1: rule__Position__UnorderedGroup__1 : rule__Position__UnorderedGroup__Impl ;
    public final void rule__Position__UnorderedGroup__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2955:1: ( rule__Position__UnorderedGroup__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2956:2: rule__Position__UnorderedGroup__Impl
            {
            pushFollow(FOLLOW_rule__Position__UnorderedGroup__Impl_in_rule__Position__UnorderedGroup__16230);
            rule__Position__UnorderedGroup__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__UnorderedGroup__1"


    // $ANTLR start "rule__WindowOptions__UnorderedGroup"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2967:1: rule__WindowOptions__UnorderedGroup : rule__WindowOptions__UnorderedGroup__0 {...}?;
    public final void rule__WindowOptions__UnorderedGroup() throws RecognitionException {

            	int stackSize = keepStackSize();
        		getUnorderedGroupHelper().enter(grammarAccess.getWindowOptionsAccess().getUnorderedGroup());
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2972:1: ( rule__WindowOptions__UnorderedGroup__0 {...}?)
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2973:2: rule__WindowOptions__UnorderedGroup__0 {...}?
            {
            pushFollow(FOLLOW_rule__WindowOptions__UnorderedGroup__0_in_rule__WindowOptions__UnorderedGroup6258);
            rule__WindowOptions__UnorderedGroup__0();

            state._fsp--;

            if ( ! getUnorderedGroupHelper().canLeave(grammarAccess.getWindowOptionsAccess().getUnorderedGroup()) ) {
                throw new FailedPredicateException(input, "rule__WindowOptions__UnorderedGroup", "getUnorderedGroupHelper().canLeave(grammarAccess.getWindowOptionsAccess().getUnorderedGroup())");
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	getUnorderedGroupHelper().leave(grammarAccess.getWindowOptionsAccess().getUnorderedGroup());
            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__WindowOptions__UnorderedGroup"


    // $ANTLR start "rule__WindowOptions__UnorderedGroup__Impl"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2984:1: rule__WindowOptions__UnorderedGroup__Impl : ( ({...}? => ( ( ( rule__WindowOptions__SizeAssignment_0 ) ) ) ) | ({...}? => ( ( ( rule__WindowOptions__Group_1__0 ) ) ) ) ) ;
    public final void rule__WindowOptions__UnorderedGroup__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        		boolean selected = false;
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2989:1: ( ( ({...}? => ( ( ( rule__WindowOptions__SizeAssignment_0 ) ) ) ) | ({...}? => ( ( ( rule__WindowOptions__Group_1__0 ) ) ) ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2990:3: ( ({...}? => ( ( ( rule__WindowOptions__SizeAssignment_0 ) ) ) ) | ({...}? => ( ( ( rule__WindowOptions__Group_1__0 ) ) ) ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2990:3: ( ({...}? => ( ( ( rule__WindowOptions__SizeAssignment_0 ) ) ) ) | ({...}? => ( ( ( rule__WindowOptions__Group_1__0 ) ) ) ) )
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( LA23_0 >=33 && LA23_0<=34 && getUnorderedGroupHelper().canSelect(grammarAccess.getWindowOptionsAccess().getUnorderedGroup(), 0) ) {
                alt23=1;
            }
            else if ( LA23_0 ==37 && getUnorderedGroupHelper().canSelect(grammarAccess.getWindowOptionsAccess().getUnorderedGroup(), 1) ) {
                alt23=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 23, 0, input);

                throw nvae;
            }
            switch (alt23) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2992:4: ({...}? => ( ( ( rule__WindowOptions__SizeAssignment_0 ) ) ) )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2992:4: ({...}? => ( ( ( rule__WindowOptions__SizeAssignment_0 ) ) ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2993:5: {...}? => ( ( ( rule__WindowOptions__SizeAssignment_0 ) ) )
                    {
                    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getWindowOptionsAccess().getUnorderedGroup(), 0) ) {
                        throw new FailedPredicateException(input, "rule__WindowOptions__UnorderedGroup__Impl", "getUnorderedGroupHelper().canSelect(grammarAccess.getWindowOptionsAccess().getUnorderedGroup(), 0)");
                    }
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2993:108: ( ( ( rule__WindowOptions__SizeAssignment_0 ) ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:2994:6: ( ( rule__WindowOptions__SizeAssignment_0 ) )
                    {
                     
                    	 				  getUnorderedGroupHelper().select(grammarAccess.getWindowOptionsAccess().getUnorderedGroup(), 0);
                    	 				

                    	 				  selected = true;
                    	 				
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3000:6: ( ( rule__WindowOptions__SizeAssignment_0 ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3002:7: ( rule__WindowOptions__SizeAssignment_0 )
                    {
                     before(grammarAccess.getWindowOptionsAccess().getSizeAssignment_0()); 
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3003:7: ( rule__WindowOptions__SizeAssignment_0 )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3003:8: rule__WindowOptions__SizeAssignment_0
                    {
                    pushFollow(FOLLOW_rule__WindowOptions__SizeAssignment_0_in_rule__WindowOptions__UnorderedGroup__Impl6347);
                    rule__WindowOptions__SizeAssignment_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getWindowOptionsAccess().getSizeAssignment_0()); 

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3009:4: ({...}? => ( ( ( rule__WindowOptions__Group_1__0 ) ) ) )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3009:4: ({...}? => ( ( ( rule__WindowOptions__Group_1__0 ) ) ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3010:5: {...}? => ( ( ( rule__WindowOptions__Group_1__0 ) ) )
                    {
                    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getWindowOptionsAccess().getUnorderedGroup(), 1) ) {
                        throw new FailedPredicateException(input, "rule__WindowOptions__UnorderedGroup__Impl", "getUnorderedGroupHelper().canSelect(grammarAccess.getWindowOptionsAccess().getUnorderedGroup(), 1)");
                    }
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3010:108: ( ( ( rule__WindowOptions__Group_1__0 ) ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3011:6: ( ( rule__WindowOptions__Group_1__0 ) )
                    {
                     
                    	 				  getUnorderedGroupHelper().select(grammarAccess.getWindowOptionsAccess().getUnorderedGroup(), 1);
                    	 				

                    	 				  selected = true;
                    	 				
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3017:6: ( ( rule__WindowOptions__Group_1__0 ) )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3019:7: ( rule__WindowOptions__Group_1__0 )
                    {
                     before(grammarAccess.getWindowOptionsAccess().getGroup_1()); 
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3020:7: ( rule__WindowOptions__Group_1__0 )
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3020:8: rule__WindowOptions__Group_1__0
                    {
                    pushFollow(FOLLOW_rule__WindowOptions__Group_1__0_in_rule__WindowOptions__UnorderedGroup__Impl6438);
                    rule__WindowOptions__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getWindowOptionsAccess().getGroup_1()); 

                    }


                    }


                    }


                    }
                    break;

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	if (selected)
            		getUnorderedGroupHelper().returnFromSelection(grammarAccess.getWindowOptionsAccess().getUnorderedGroup());
            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__WindowOptions__UnorderedGroup__Impl"


    // $ANTLR start "rule__WindowOptions__UnorderedGroup__0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3035:1: rule__WindowOptions__UnorderedGroup__0 : rule__WindowOptions__UnorderedGroup__Impl ( rule__WindowOptions__UnorderedGroup__1 )? ;
    public final void rule__WindowOptions__UnorderedGroup__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3039:1: ( rule__WindowOptions__UnorderedGroup__Impl ( rule__WindowOptions__UnorderedGroup__1 )? )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3040:2: rule__WindowOptions__UnorderedGroup__Impl ( rule__WindowOptions__UnorderedGroup__1 )?
            {
            pushFollow(FOLLOW_rule__WindowOptions__UnorderedGroup__Impl_in_rule__WindowOptions__UnorderedGroup__06497);
            rule__WindowOptions__UnorderedGroup__Impl();

            state._fsp--;

            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3041:2: ( rule__WindowOptions__UnorderedGroup__1 )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( LA24_0 >=33 && LA24_0<=34 && getUnorderedGroupHelper().canSelect(grammarAccess.getWindowOptionsAccess().getUnorderedGroup(), 0) ) {
                alt24=1;
            }
            else if ( LA24_0 ==37 && getUnorderedGroupHelper().canSelect(grammarAccess.getWindowOptionsAccess().getUnorderedGroup(), 1) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3041:2: rule__WindowOptions__UnorderedGroup__1
                    {
                    pushFollow(FOLLOW_rule__WindowOptions__UnorderedGroup__1_in_rule__WindowOptions__UnorderedGroup__06500);
                    rule__WindowOptions__UnorderedGroup__1();

                    state._fsp--;


                    }
                    break;

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__WindowOptions__UnorderedGroup__0"


    // $ANTLR start "rule__WindowOptions__UnorderedGroup__1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3048:1: rule__WindowOptions__UnorderedGroup__1 : rule__WindowOptions__UnorderedGroup__Impl ;
    public final void rule__WindowOptions__UnorderedGroup__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3052:1: ( rule__WindowOptions__UnorderedGroup__Impl )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3053:2: rule__WindowOptions__UnorderedGroup__Impl
            {
            pushFollow(FOLLOW_rule__WindowOptions__UnorderedGroup__Impl_in_rule__WindowOptions__UnorderedGroup__16525);
            rule__WindowOptions__UnorderedGroup__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__WindowOptions__UnorderedGroup__1"


    // $ANTLR start "rule__Model__PackageAssignment_0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3064:1: rule__Model__PackageAssignment_0 : ( rulePackage ) ;
    public final void rule__Model__PackageAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3068:1: ( ( rulePackage ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3069:1: ( rulePackage )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3069:1: ( rulePackage )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3070:1: rulePackage
            {
             before(grammarAccess.getModelAccess().getPackagePackageParserRuleCall_0_0()); 
            pushFollow(FOLLOW_rulePackage_in_rule__Model__PackageAssignment_06557);
            rulePackage();

            state._fsp--;

             after(grammarAccess.getModelAccess().getPackagePackageParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__PackageAssignment_0"


    // $ANTLR start "rule__Model__EntitytypesAssignment_1_0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3079:1: rule__Model__EntitytypesAssignment_1_0 : ( ruleEntitytype ) ;
    public final void rule__Model__EntitytypesAssignment_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3083:1: ( ( ruleEntitytype ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3084:1: ( ruleEntitytype )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3084:1: ( ruleEntitytype )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3085:1: ruleEntitytype
            {
             before(grammarAccess.getModelAccess().getEntitytypesEntitytypeParserRuleCall_1_0_0()); 
            pushFollow(FOLLOW_ruleEntitytype_in_rule__Model__EntitytypesAssignment_1_06588);
            ruleEntitytype();

            state._fsp--;

             after(grammarAccess.getModelAccess().getEntitytypesEntitytypeParserRuleCall_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__EntitytypesAssignment_1_0"


    // $ANTLR start "rule__Model__UiwindowsAssignment_1_1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3094:1: rule__Model__UiwindowsAssignment_1_1 : ( ruleUIWindow ) ;
    public final void rule__Model__UiwindowsAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3098:1: ( ( ruleUIWindow ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3099:1: ( ruleUIWindow )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3099:1: ( ruleUIWindow )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3100:1: ruleUIWindow
            {
             before(grammarAccess.getModelAccess().getUiwindowsUIWindowParserRuleCall_1_1_0()); 
            pushFollow(FOLLOW_ruleUIWindow_in_rule__Model__UiwindowsAssignment_1_16619);
            ruleUIWindow();

            state._fsp--;

             after(grammarAccess.getModelAccess().getUiwindowsUIWindowParserRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__UiwindowsAssignment_1_1"


    // $ANTLR start "rule__Package__NameAssignment_1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3109:1: rule__Package__NameAssignment_1 : ( ruleQualifiedName ) ;
    public final void rule__Package__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3113:1: ( ( ruleQualifiedName ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3114:1: ( ruleQualifiedName )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3114:1: ( ruleQualifiedName )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3115:1: ruleQualifiedName
            {
             before(grammarAccess.getPackageAccess().getNameQualifiedNameParserRuleCall_1_0()); 
            pushFollow(FOLLOW_ruleQualifiedName_in_rule__Package__NameAssignment_16650);
            ruleQualifiedName();

            state._fsp--;

             after(grammarAccess.getPackageAccess().getNameQualifiedNameParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__NameAssignment_1"


    // $ANTLR start "rule__Entitytype__AbstractAssignment_0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3124:1: rule__Entitytype__AbstractAssignment_0 : ( ( 'abstract' ) ) ;
    public final void rule__Entitytype__AbstractAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3128:1: ( ( ( 'abstract' ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3129:1: ( ( 'abstract' ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3129:1: ( ( 'abstract' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3130:1: ( 'abstract' )
            {
             before(grammarAccess.getEntitytypeAccess().getAbstractAbstractKeyword_0_0()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3131:1: ( 'abstract' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3132:1: 'abstract'
            {
             before(grammarAccess.getEntitytypeAccess().getAbstractAbstractKeyword_0_0()); 
            match(input,38,FOLLOW_38_in_rule__Entitytype__AbstractAssignment_06686); 
             after(grammarAccess.getEntitytypeAccess().getAbstractAbstractKeyword_0_0()); 

            }

             after(grammarAccess.getEntitytypeAccess().getAbstractAbstractKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__AbstractAssignment_0"


    // $ANTLR start "rule__Entitytype__NameAssignment_2"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3147:1: rule__Entitytype__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__Entitytype__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3151:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3152:1: ( RULE_ID )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3152:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3153:1: RULE_ID
            {
             before(grammarAccess.getEntitytypeAccess().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Entitytype__NameAssignment_26725); 
             after(grammarAccess.getEntitytypeAccess().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__NameAssignment_2"


    // $ANTLR start "rule__Entitytype__SupertypeAssignment_3_1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3162:1: rule__Entitytype__SupertypeAssignment_3_1 : ( ( RULE_ID ) ) ;
    public final void rule__Entitytype__SupertypeAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3166:1: ( ( ( RULE_ID ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3167:1: ( ( RULE_ID ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3167:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3168:1: ( RULE_ID )
            {
             before(grammarAccess.getEntitytypeAccess().getSupertypeEntitytypeCrossReference_3_1_0()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3169:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3170:1: RULE_ID
            {
             before(grammarAccess.getEntitytypeAccess().getSupertypeEntitytypeIDTerminalRuleCall_3_1_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Entitytype__SupertypeAssignment_3_16760); 
             after(grammarAccess.getEntitytypeAccess().getSupertypeEntitytypeIDTerminalRuleCall_3_1_0_1()); 

            }

             after(grammarAccess.getEntitytypeAccess().getSupertypeEntitytypeCrossReference_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__SupertypeAssignment_3_1"


    // $ANTLR start "rule__Entitytype__PropertiesAssignment_5"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3181:1: rule__Entitytype__PropertiesAssignment_5 : ( ruleProperty ) ;
    public final void rule__Entitytype__PropertiesAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3185:1: ( ( ruleProperty ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3186:1: ( ruleProperty )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3186:1: ( ruleProperty )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3187:1: ruleProperty
            {
             before(grammarAccess.getEntitytypeAccess().getPropertiesPropertyParserRuleCall_5_0()); 
            pushFollow(FOLLOW_ruleProperty_in_rule__Entitytype__PropertiesAssignment_56795);
            ruleProperty();

            state._fsp--;

             after(grammarAccess.getEntitytypeAccess().getPropertiesPropertyParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entitytype__PropertiesAssignment_5"


    // $ANTLR start "rule__Attribute__TypeAssignment_1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3196:1: rule__Attribute__TypeAssignment_1 : ( ruleBasicType ) ;
    public final void rule__Attribute__TypeAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3200:1: ( ( ruleBasicType ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3201:1: ( ruleBasicType )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3201:1: ( ruleBasicType )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3202:1: ruleBasicType
            {
             before(grammarAccess.getAttributeAccess().getTypeBasicTypeEnumRuleCall_1_0()); 
            pushFollow(FOLLOW_ruleBasicType_in_rule__Attribute__TypeAssignment_16826);
            ruleBasicType();

            state._fsp--;

             after(grammarAccess.getAttributeAccess().getTypeBasicTypeEnumRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__TypeAssignment_1"


    // $ANTLR start "rule__Attribute__NameAssignment_2"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3211:1: rule__Attribute__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__Attribute__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3215:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3216:1: ( RULE_ID )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3216:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3217:1: RULE_ID
            {
             before(grammarAccess.getAttributeAccess().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Attribute__NameAssignment_26857); 
             after(grammarAccess.getAttributeAccess().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__NameAssignment_2"


    // $ANTLR start "rule__Attribute__OptionalAssignment_3"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3226:1: rule__Attribute__OptionalAssignment_3 : ( ( 'optional' ) ) ;
    public final void rule__Attribute__OptionalAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3230:1: ( ( ( 'optional' ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3231:1: ( ( 'optional' ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3231:1: ( ( 'optional' ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3232:1: ( 'optional' )
            {
             before(grammarAccess.getAttributeAccess().getOptionalOptionalKeyword_3_0()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3233:1: ( 'optional' )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3234:1: 'optional'
            {
             before(grammarAccess.getAttributeAccess().getOptionalOptionalKeyword_3_0()); 
            match(input,39,FOLLOW_39_in_rule__Attribute__OptionalAssignment_36893); 
             after(grammarAccess.getAttributeAccess().getOptionalOptionalKeyword_3_0()); 

            }

             after(grammarAccess.getAttributeAccess().getOptionalOptionalKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__OptionalAssignment_3"


    // $ANTLR start "rule__Reference__ReferencesAssignment_1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3249:1: rule__Reference__ReferencesAssignment_1 : ( ( RULE_ID ) ) ;
    public final void rule__Reference__ReferencesAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3253:1: ( ( ( RULE_ID ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3254:1: ( ( RULE_ID ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3254:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3255:1: ( RULE_ID )
            {
             before(grammarAccess.getReferenceAccess().getReferencesEntitytypeCrossReference_1_0()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3256:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3257:1: RULE_ID
            {
             before(grammarAccess.getReferenceAccess().getReferencesEntitytypeIDTerminalRuleCall_1_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Reference__ReferencesAssignment_16936); 
             after(grammarAccess.getReferenceAccess().getReferencesEntitytypeIDTerminalRuleCall_1_0_1()); 

            }

             after(grammarAccess.getReferenceAccess().getReferencesEntitytypeCrossReference_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__ReferencesAssignment_1"


    // $ANTLR start "rule__Reference__NameAssignment_2"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3268:1: rule__Reference__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__Reference__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3272:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3273:1: ( RULE_ID )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3273:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3274:1: RULE_ID
            {
             before(grammarAccess.getReferenceAccess().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Reference__NameAssignment_26971); 
             after(grammarAccess.getReferenceAccess().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__NameAssignment_2"


    // $ANTLR start "rule__Reference__MultiplicityAssignment_3"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3283:1: rule__Reference__MultiplicityAssignment_3 : ( ruleMultiplicity ) ;
    public final void rule__Reference__MultiplicityAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3287:1: ( ( ruleMultiplicity ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3288:1: ( ruleMultiplicity )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3288:1: ( ruleMultiplicity )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3289:1: ruleMultiplicity
            {
             before(grammarAccess.getReferenceAccess().getMultiplicityMultiplicityEnumRuleCall_3_0()); 
            pushFollow(FOLLOW_ruleMultiplicity_in_rule__Reference__MultiplicityAssignment_37002);
            ruleMultiplicity();

            state._fsp--;

             after(grammarAccess.getReferenceAccess().getMultiplicityMultiplicityEnumRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__MultiplicityAssignment_3"


    // $ANTLR start "rule__ListWindow__NameAssignment_1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3298:1: rule__ListWindow__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__ListWindow__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3302:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3303:1: ( RULE_ID )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3303:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3304:1: RULE_ID
            {
             before(grammarAccess.getListWindowAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__ListWindow__NameAssignment_17033); 
             after(grammarAccess.getListWindowAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__NameAssignment_1"


    // $ANTLR start "rule__ListWindow__EntitytypeAssignment_3"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3313:1: rule__ListWindow__EntitytypeAssignment_3 : ( ( RULE_ID ) ) ;
    public final void rule__ListWindow__EntitytypeAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3317:1: ( ( ( RULE_ID ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3318:1: ( ( RULE_ID ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3318:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3319:1: ( RULE_ID )
            {
             before(grammarAccess.getListWindowAccess().getEntitytypeEntitytypeCrossReference_3_0()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3320:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3321:1: RULE_ID
            {
             before(grammarAccess.getListWindowAccess().getEntitytypeEntitytypeIDTerminalRuleCall_3_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__ListWindow__EntitytypeAssignment_37068); 
             after(grammarAccess.getListWindowAccess().getEntitytypeEntitytypeIDTerminalRuleCall_3_0_1()); 

            }

             after(grammarAccess.getListWindowAccess().getEntitytypeEntitytypeCrossReference_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__EntitytypeAssignment_3"


    // $ANTLR start "rule__ListWindow__OptionsAssignment_5"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3332:1: rule__ListWindow__OptionsAssignment_5 : ( ruleWindowOptions ) ;
    public final void rule__ListWindow__OptionsAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3336:1: ( ( ruleWindowOptions ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3337:1: ( ruleWindowOptions )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3337:1: ( ruleWindowOptions )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3338:1: ruleWindowOptions
            {
             before(grammarAccess.getListWindowAccess().getOptionsWindowOptionsParserRuleCall_5_0()); 
            pushFollow(FOLLOW_ruleWindowOptions_in_rule__ListWindow__OptionsAssignment_57103);
            ruleWindowOptions();

            state._fsp--;

             after(grammarAccess.getListWindowAccess().getOptionsWindowOptionsParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListWindow__OptionsAssignment_5"


    // $ANTLR start "rule__EntryWindow__NameAssignment_1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3347:1: rule__EntryWindow__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__EntryWindow__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3351:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3352:1: ( RULE_ID )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3352:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3353:1: RULE_ID
            {
             before(grammarAccess.getEntryWindowAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__EntryWindow__NameAssignment_17134); 
             after(grammarAccess.getEntryWindowAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__NameAssignment_1"


    // $ANTLR start "rule__EntryWindow__EntitytypeAssignment_3"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3362:1: rule__EntryWindow__EntitytypeAssignment_3 : ( ( RULE_ID ) ) ;
    public final void rule__EntryWindow__EntitytypeAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3366:1: ( ( ( RULE_ID ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3367:1: ( ( RULE_ID ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3367:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3368:1: ( RULE_ID )
            {
             before(grammarAccess.getEntryWindowAccess().getEntitytypeEntitytypeCrossReference_3_0()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3369:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3370:1: RULE_ID
            {
             before(grammarAccess.getEntryWindowAccess().getEntitytypeEntitytypeIDTerminalRuleCall_3_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__EntryWindow__EntitytypeAssignment_37169); 
             after(grammarAccess.getEntryWindowAccess().getEntitytypeEntitytypeIDTerminalRuleCall_3_0_1()); 

            }

             after(grammarAccess.getEntryWindowAccess().getEntitytypeEntitytypeCrossReference_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__EntitytypeAssignment_3"


    // $ANTLR start "rule__EntryWindow__OptionsAssignment_5"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3381:1: rule__EntryWindow__OptionsAssignment_5 : ( ruleWindowOptions ) ;
    public final void rule__EntryWindow__OptionsAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3385:1: ( ( ruleWindowOptions ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3386:1: ( ruleWindowOptions )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3386:1: ( ruleWindowOptions )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3387:1: ruleWindowOptions
            {
             before(grammarAccess.getEntryWindowAccess().getOptionsWindowOptionsParserRuleCall_5_0()); 
            pushFollow(FOLLOW_ruleWindowOptions_in_rule__EntryWindow__OptionsAssignment_57204);
            ruleWindowOptions();

            state._fsp--;

             after(grammarAccess.getEntryWindowAccess().getOptionsWindowOptionsParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__OptionsAssignment_5"


    // $ANTLR start "rule__EntryWindow__ElementsAssignment_6"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3396:1: rule__EntryWindow__ElementsAssignment_6 : ( ruleUIElement ) ;
    public final void rule__EntryWindow__ElementsAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3400:1: ( ( ruleUIElement ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3401:1: ( ruleUIElement )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3401:1: ( ruleUIElement )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3402:1: ruleUIElement
            {
             before(grammarAccess.getEntryWindowAccess().getElementsUIElementParserRuleCall_6_0()); 
            pushFollow(FOLLOW_ruleUIElement_in_rule__EntryWindow__ElementsAssignment_67235);
            ruleUIElement();

            state._fsp--;

             after(grammarAccess.getEntryWindowAccess().getElementsUIElementParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EntryWindow__ElementsAssignment_6"


    // $ANTLR start "rule__UIElement__UiOptionsAssignment_1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3411:1: rule__UIElement__UiOptionsAssignment_1 : ( ruleUIOptions ) ;
    public final void rule__UIElement__UiOptionsAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3415:1: ( ( ruleUIOptions ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3416:1: ( ruleUIOptions )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3416:1: ( ruleUIOptions )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3417:1: ruleUIOptions
            {
             before(grammarAccess.getUIElementAccess().getUiOptionsUIOptionsParserRuleCall_1_0()); 
            pushFollow(FOLLOW_ruleUIOptions_in_rule__UIElement__UiOptionsAssignment_17266);
            ruleUIOptions();

            state._fsp--;

             after(grammarAccess.getUIElementAccess().getUiOptionsUIOptionsParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UIElement__UiOptionsAssignment_1"


    // $ANTLR start "rule__UIOptions__PositionAssignment_0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3426:1: rule__UIOptions__PositionAssignment_0 : ( rulePosition ) ;
    public final void rule__UIOptions__PositionAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3430:1: ( ( rulePosition ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3431:1: ( rulePosition )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3431:1: ( rulePosition )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3432:1: rulePosition
            {
             before(grammarAccess.getUIOptionsAccess().getPositionPositionParserRuleCall_0_0()); 
            pushFollow(FOLLOW_rulePosition_in_rule__UIOptions__PositionAssignment_07297);
            rulePosition();

            state._fsp--;

             after(grammarAccess.getUIOptionsAccess().getPositionPositionParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UIOptions__PositionAssignment_0"


    // $ANTLR start "rule__UIOptions__SizeAssignment_1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3441:1: rule__UIOptions__SizeAssignment_1 : ( ruleSize ) ;
    public final void rule__UIOptions__SizeAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3445:1: ( ( ruleSize ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3446:1: ( ruleSize )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3446:1: ( ruleSize )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3447:1: ruleSize
            {
             before(grammarAccess.getUIOptionsAccess().getSizeSizeParserRuleCall_1_0()); 
            pushFollow(FOLLOW_ruleSize_in_rule__UIOptions__SizeAssignment_17328);
            ruleSize();

            state._fsp--;

             after(grammarAccess.getUIOptionsAccess().getSizeSizeParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UIOptions__SizeAssignment_1"


    // $ANTLR start "rule__Label__NameAssignment_1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3456:1: rule__Label__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Label__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3460:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3461:1: ( RULE_ID )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3461:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3462:1: RULE_ID
            {
             before(grammarAccess.getLabelAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Label__NameAssignment_17359); 
             after(grammarAccess.getLabelAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__NameAssignment_1"


    // $ANTLR start "rule__Label__TextAssignment_2"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3471:1: rule__Label__TextAssignment_2 : ( RULE_STRING ) ;
    public final void rule__Label__TextAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3475:1: ( ( RULE_STRING ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3476:1: ( RULE_STRING )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3476:1: ( RULE_STRING )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3477:1: RULE_STRING
            {
             before(grammarAccess.getLabelAccess().getTextSTRINGTerminalRuleCall_2_0()); 
            match(input,RULE_STRING,FOLLOW_RULE_STRING_in_rule__Label__TextAssignment_27390); 
             after(grammarAccess.getLabelAccess().getTextSTRINGTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__TextAssignment_2"


    // $ANTLR start "rule__Field__PropertyAssignment_1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3486:1: rule__Field__PropertyAssignment_1 : ( ( RULE_ID ) ) ;
    public final void rule__Field__PropertyAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3490:1: ( ( ( RULE_ID ) ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3491:1: ( ( RULE_ID ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3491:1: ( ( RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3492:1: ( RULE_ID )
            {
             before(grammarAccess.getFieldAccess().getPropertyPropertyCrossReference_1_0()); 
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3493:1: ( RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3494:1: RULE_ID
            {
             before(grammarAccess.getFieldAccess().getPropertyPropertyIDTerminalRuleCall_1_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Field__PropertyAssignment_17425); 
             after(grammarAccess.getFieldAccess().getPropertyPropertyIDTerminalRuleCall_1_0_1()); 

            }

             after(grammarAccess.getFieldAccess().getPropertyPropertyCrossReference_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__PropertyAssignment_1"


    // $ANTLR start "rule__Button__InscriptionAssignment_1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3505:1: rule__Button__InscriptionAssignment_1 : ( ruleInscription ) ;
    public final void rule__Button__InscriptionAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3509:1: ( ( ruleInscription ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3510:1: ( ruleInscription )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3510:1: ( ruleInscription )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3511:1: ruleInscription
            {
             before(grammarAccess.getButtonAccess().getInscriptionInscriptionEnumRuleCall_1_0()); 
            pushFollow(FOLLOW_ruleInscription_in_rule__Button__InscriptionAssignment_17460);
            ruleInscription();

            state._fsp--;

             after(grammarAccess.getButtonAccess().getInscriptionInscriptionEnumRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Button__InscriptionAssignment_1"


    // $ANTLR start "rule__Size__WidthAssignment_0_1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3520:1: rule__Size__WidthAssignment_0_1 : ( RULE_INT ) ;
    public final void rule__Size__WidthAssignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3524:1: ( ( RULE_INT ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3525:1: ( RULE_INT )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3525:1: ( RULE_INT )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3526:1: RULE_INT
            {
             before(grammarAccess.getSizeAccess().getWidthINTTerminalRuleCall_0_1_0()); 
            match(input,RULE_INT,FOLLOW_RULE_INT_in_rule__Size__WidthAssignment_0_17491); 
             after(grammarAccess.getSizeAccess().getWidthINTTerminalRuleCall_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__WidthAssignment_0_1"


    // $ANTLR start "rule__Size__HeightAssignment_1_1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3535:1: rule__Size__HeightAssignment_1_1 : ( RULE_INT ) ;
    public final void rule__Size__HeightAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3539:1: ( ( RULE_INT ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3540:1: ( RULE_INT )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3540:1: ( RULE_INT )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3541:1: RULE_INT
            {
             before(grammarAccess.getSizeAccess().getHeightINTTerminalRuleCall_1_1_0()); 
            match(input,RULE_INT,FOLLOW_RULE_INT_in_rule__Size__HeightAssignment_1_17522); 
             after(grammarAccess.getSizeAccess().getHeightINTTerminalRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Size__HeightAssignment_1_1"


    // $ANTLR start "rule__Position__XAssignment_0_1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3550:1: rule__Position__XAssignment_0_1 : ( RULE_INT ) ;
    public final void rule__Position__XAssignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3554:1: ( ( RULE_INT ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3555:1: ( RULE_INT )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3555:1: ( RULE_INT )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3556:1: RULE_INT
            {
             before(grammarAccess.getPositionAccess().getXINTTerminalRuleCall_0_1_0()); 
            match(input,RULE_INT,FOLLOW_RULE_INT_in_rule__Position__XAssignment_0_17553); 
             after(grammarAccess.getPositionAccess().getXINTTerminalRuleCall_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__XAssignment_0_1"


    // $ANTLR start "rule__Position__YAssignment_1_1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3565:1: rule__Position__YAssignment_1_1 : ( RULE_INT ) ;
    public final void rule__Position__YAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3569:1: ( ( RULE_INT ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3570:1: ( RULE_INT )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3570:1: ( RULE_INT )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3571:1: RULE_INT
            {
             before(grammarAccess.getPositionAccess().getYINTTerminalRuleCall_1_1_0()); 
            match(input,RULE_INT,FOLLOW_RULE_INT_in_rule__Position__YAssignment_1_17584); 
             after(grammarAccess.getPositionAccess().getYINTTerminalRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Position__YAssignment_1_1"


    // $ANTLR start "rule__WindowOptions__SizeAssignment_0"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3580:1: rule__WindowOptions__SizeAssignment_0 : ( ruleSize ) ;
    public final void rule__WindowOptions__SizeAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3584:1: ( ( ruleSize ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3585:1: ( ruleSize )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3585:1: ( ruleSize )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3586:1: ruleSize
            {
             before(grammarAccess.getWindowOptionsAccess().getSizeSizeParserRuleCall_0_0()); 
            pushFollow(FOLLOW_ruleSize_in_rule__WindowOptions__SizeAssignment_07615);
            ruleSize();

            state._fsp--;

             after(grammarAccess.getWindowOptionsAccess().getSizeSizeParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__WindowOptions__SizeAssignment_0"


    // $ANTLR start "rule__WindowOptions__TitleAssignment_1_1"
    // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3595:1: rule__WindowOptions__TitleAssignment_1_1 : ( RULE_STRING ) ;
    public final void rule__WindowOptions__TitleAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3599:1: ( ( RULE_STRING ) )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3600:1: ( RULE_STRING )
            {
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3600:1: ( RULE_STRING )
            // ../de.wwu.pi.mdsd.group05DSL.ui/src-gen/de/wwu/pi/mdsd05/ui/contentassist/antlr/internal/InternalGroup05DSL.g:3601:1: RULE_STRING
            {
             before(grammarAccess.getWindowOptionsAccess().getTitleSTRINGTerminalRuleCall_1_1_0()); 
            match(input,RULE_STRING,FOLLOW_RULE_STRING_in_rule__WindowOptions__TitleAssignment_1_17646); 
             after(grammarAccess.getWindowOptionsAccess().getTitleSTRINGTerminalRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__WindowOptions__TitleAssignment_1_1"

    // Delegated rules


 

    public static final BitSet FOLLOW_ruleModel_in_entryRuleModel61 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleModel68 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__Group__0_in_ruleModel94 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePackage_in_entryRulePackage121 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRulePackage128 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Package__Group__0_in_rulePackage154 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleQualifiedName_in_entryRuleQualifiedName181 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleQualifiedName188 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group__0_in_ruleQualifiedName214 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEntitytype_in_entryRuleEntitytype241 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleEntitytype248 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entitytype__Group__0_in_ruleEntitytype274 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleProperty_in_entryRuleProperty301 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleProperty308 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Property__Alternatives_in_ruleProperty334 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAttribute_in_entryRuleAttribute361 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleAttribute368 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__Group__0_in_ruleAttribute394 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleReference_in_entryRuleReference421 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleReference428 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__Group__0_in_ruleReference454 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleUIWindow_in_entryRuleUIWindow481 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleUIWindow488 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__UIWindow__Alternatives_in_ruleUIWindow514 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleListWindow_in_entryRuleListWindow541 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleListWindow548 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__0_in_ruleListWindow574 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEntryWindow_in_entryRuleEntryWindow601 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleEntryWindow608 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__0_in_ruleEntryWindow634 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleUIElement_in_entryRuleUIElement661 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleUIElement668 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__UIElement__Group__0_in_ruleUIElement694 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleUIOptions_in_entryRuleUIOptions721 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleUIOptions728 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__UIOptions__UnorderedGroup_in_ruleUIOptions754 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleLabel_in_entryRuleLabel781 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleLabel788 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Label__Group__0_in_ruleLabel814 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleField_in_entryRuleField841 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleField848 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Field__Group__0_in_ruleField874 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleButton_in_entryRuleButton901 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleButton908 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Button__Group__0_in_ruleButton934 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleSize_in_entryRuleSize961 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleSize968 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__UnorderedGroup_in_ruleSize994 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePosition_in_entryRulePosition1021 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRulePosition1028 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Position__UnorderedGroup_in_rulePosition1054 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleWindowOptions_in_entryRuleWindowOptions1081 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleWindowOptions1088 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__WindowOptions__UnorderedGroup_in_ruleWindowOptions1114 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__BasicType__Alternatives_in_ruleBasicType1151 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Multiplicity__Alternatives_in_ruleMultiplicity1187 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Inscription__Alternatives_in_ruleInscription1223 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__EntitytypesAssignment_1_0_in_rule__Model__Alternatives_11258 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__UiwindowsAssignment_1_1_in_rule__Model__Alternatives_11276 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAttribute_in_rule__Property__Alternatives1309 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleReference_in_rule__Property__Alternatives1326 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleListWindow_in_rule__UIWindow__Alternatives1358 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEntryWindow_in_rule__UIWindow__Alternatives1375 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleLabel_in_rule__UIElement__Alternatives_01407 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleField_in_rule__UIElement__Alternatives_01424 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleButton_in_rule__UIElement__Alternatives_01441 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_11_in_rule__BasicType__Alternatives1474 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_12_in_rule__BasicType__Alternatives1495 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_13_in_rule__BasicType__Alternatives1516 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_14_in_rule__Multiplicity__Alternatives1552 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_15_in_rule__Multiplicity__Alternatives1573 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_16_in_rule__Inscription__Alternatives1609 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_17_in_rule__Inscription__Alternatives1630 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_18_in_rule__Inscription__Alternatives1651 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__Group__0__Impl_in_rule__Model__Group__01684 = new BitSet(new long[]{0x0000004028200000L});
    public static final BitSet FOLLOW_rule__Model__Group__1_in_rule__Model__Group__01687 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__PackageAssignment_0_in_rule__Model__Group__0__Impl1714 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__Group__1__Impl_in_rule__Model__Group__11744 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__Alternatives_1_in_rule__Model__Group__1__Impl1771 = new BitSet(new long[]{0x0000004028200002L});
    public static final BitSet FOLLOW_rule__Package__Group__0__Impl_in_rule__Package__Group__01806 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Package__Group__1_in_rule__Package__Group__01809 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_19_in_rule__Package__Group__0__Impl1837 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Package__Group__1__Impl_in_rule__Package__Group__11868 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Package__NameAssignment_1_in_rule__Package__Group__1__Impl1895 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group__0__Impl_in_rule__QualifiedName__Group__01929 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group__1_in_rule__QualifiedName__Group__01932 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__QualifiedName__Group__0__Impl1959 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group__1__Impl_in_rule__QualifiedName__Group__11988 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group_1__0_in_rule__QualifiedName__Group__1__Impl2015 = new BitSet(new long[]{0x0000000000100002L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group_1__0__Impl_in_rule__QualifiedName__Group_1__02050 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group_1__1_in_rule__QualifiedName__Group_1__02053 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_20_in_rule__QualifiedName__Group_1__0__Impl2081 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group_1__1__Impl_in_rule__QualifiedName__Group_1__12112 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__QualifiedName__Group_1__1__Impl2139 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entitytype__Group__0__Impl_in_rule__Entitytype__Group__02172 = new BitSet(new long[]{0x0000004000200000L});
    public static final BitSet FOLLOW_rule__Entitytype__Group__1_in_rule__Entitytype__Group__02175 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entitytype__AbstractAssignment_0_in_rule__Entitytype__Group__0__Impl2202 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entitytype__Group__1__Impl_in_rule__Entitytype__Group__12233 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Entitytype__Group__2_in_rule__Entitytype__Group__12236 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_21_in_rule__Entitytype__Group__1__Impl2264 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entitytype__Group__2__Impl_in_rule__Entitytype__Group__22295 = new BitSet(new long[]{0x0000000001400000L});
    public static final BitSet FOLLOW_rule__Entitytype__Group__3_in_rule__Entitytype__Group__22298 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entitytype__NameAssignment_2_in_rule__Entitytype__Group__2__Impl2325 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entitytype__Group__3__Impl_in_rule__Entitytype__Group__32355 = new BitSet(new long[]{0x0000000001400000L});
    public static final BitSet FOLLOW_rule__Entitytype__Group__4_in_rule__Entitytype__Group__32358 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entitytype__Group_3__0_in_rule__Entitytype__Group__3__Impl2385 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entitytype__Group__4__Impl_in_rule__Entitytype__Group__42416 = new BitSet(new long[]{0x0000000006000000L});
    public static final BitSet FOLLOW_rule__Entitytype__Group__5_in_rule__Entitytype__Group__42419 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_22_in_rule__Entitytype__Group__4__Impl2447 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entitytype__Group__5__Impl_in_rule__Entitytype__Group__52478 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_rule__Entitytype__Group__6_in_rule__Entitytype__Group__52481 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entitytype__PropertiesAssignment_5_in_rule__Entitytype__Group__5__Impl2510 = new BitSet(new long[]{0x0000000006000002L});
    public static final BitSet FOLLOW_rule__Entitytype__PropertiesAssignment_5_in_rule__Entitytype__Group__5__Impl2522 = new BitSet(new long[]{0x0000000006000002L});
    public static final BitSet FOLLOW_rule__Entitytype__Group__6__Impl_in_rule__Entitytype__Group__62555 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_23_in_rule__Entitytype__Group__6__Impl2583 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entitytype__Group_3__0__Impl_in_rule__Entitytype__Group_3__02628 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Entitytype__Group_3__1_in_rule__Entitytype__Group_3__02631 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_24_in_rule__Entitytype__Group_3__0__Impl2659 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entitytype__Group_3__1__Impl_in_rule__Entitytype__Group_3__12690 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entitytype__SupertypeAssignment_3_1_in_rule__Entitytype__Group_3__1__Impl2717 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__Group__0__Impl_in_rule__Attribute__Group__02751 = new BitSet(new long[]{0x0000000000003800L});
    public static final BitSet FOLLOW_rule__Attribute__Group__1_in_rule__Attribute__Group__02754 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_25_in_rule__Attribute__Group__0__Impl2782 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__Group__1__Impl_in_rule__Attribute__Group__12813 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Attribute__Group__2_in_rule__Attribute__Group__12816 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__TypeAssignment_1_in_rule__Attribute__Group__1__Impl2843 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__Group__2__Impl_in_rule__Attribute__Group__22873 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_rule__Attribute__Group__3_in_rule__Attribute__Group__22876 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__NameAssignment_2_in_rule__Attribute__Group__2__Impl2903 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__Group__3__Impl_in_rule__Attribute__Group__32933 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__OptionalAssignment_3_in_rule__Attribute__Group__3__Impl2960 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__Group__0__Impl_in_rule__Reference__Group__02999 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Reference__Group__1_in_rule__Reference__Group__03002 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_26_in_rule__Reference__Group__0__Impl3030 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__Group__1__Impl_in_rule__Reference__Group__13061 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Reference__Group__2_in_rule__Reference__Group__13064 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__ReferencesAssignment_1_in_rule__Reference__Group__1__Impl3091 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__Group__2__Impl_in_rule__Reference__Group__23121 = new BitSet(new long[]{0x000000000000C000L});
    public static final BitSet FOLLOW_rule__Reference__Group__3_in_rule__Reference__Group__23124 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__NameAssignment_2_in_rule__Reference__Group__2__Impl3151 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__Group__3__Impl_in_rule__Reference__Group__33181 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Reference__MultiplicityAssignment_3_in_rule__Reference__Group__3__Impl3208 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__0__Impl_in_rule__ListWindow__Group__03247 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__1_in_rule__ListWindow__Group__03250 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_27_in_rule__ListWindow__Group__0__Impl3278 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__1__Impl_in_rule__ListWindow__Group__13309 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__2_in_rule__ListWindow__Group__13312 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__NameAssignment_1_in_rule__ListWindow__Group__1__Impl3339 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__2__Impl_in_rule__ListWindow__Group__23369 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__3_in_rule__ListWindow__Group__23372 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_28_in_rule__ListWindow__Group__2__Impl3400 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__3__Impl_in_rule__ListWindow__Group__33431 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__4_in_rule__ListWindow__Group__33434 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__EntitytypeAssignment_3_in_rule__ListWindow__Group__3__Impl3461 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__4__Impl_in_rule__ListWindow__Group__43491 = new BitSet(new long[]{0x0000002600000000L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__5_in_rule__ListWindow__Group__43494 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_22_in_rule__ListWindow__Group__4__Impl3522 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__5__Impl_in_rule__ListWindow__Group__53553 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__6_in_rule__ListWindow__Group__53556 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__OptionsAssignment_5_in_rule__ListWindow__Group__5__Impl3583 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListWindow__Group__6__Impl_in_rule__ListWindow__Group__63613 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_23_in_rule__ListWindow__Group__6__Impl3641 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__0__Impl_in_rule__EntryWindow__Group__03686 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__1_in_rule__EntryWindow__Group__03689 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_29_in_rule__EntryWindow__Group__0__Impl3717 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__1__Impl_in_rule__EntryWindow__Group__13748 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__2_in_rule__EntryWindow__Group__13751 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__NameAssignment_1_in_rule__EntryWindow__Group__1__Impl3778 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__2__Impl_in_rule__EntryWindow__Group__23808 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__3_in_rule__EntryWindow__Group__23811 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_28_in_rule__EntryWindow__Group__2__Impl3839 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__3__Impl_in_rule__EntryWindow__Group__33870 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__4_in_rule__EntryWindow__Group__33873 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__EntitytypeAssignment_3_in_rule__EntryWindow__Group__3__Impl3900 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__4__Impl_in_rule__EntryWindow__Group__43930 = new BitSet(new long[]{0x0000002600000000L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__5_in_rule__EntryWindow__Group__43933 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_22_in_rule__EntryWindow__Group__4__Impl3961 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__5__Impl_in_rule__EntryWindow__Group__53992 = new BitSet(new long[]{0x00000001C0000000L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__6_in_rule__EntryWindow__Group__53995 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__OptionsAssignment_5_in_rule__EntryWindow__Group__5__Impl4022 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__6__Impl_in_rule__EntryWindow__Group__64052 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__7_in_rule__EntryWindow__Group__64055 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__ElementsAssignment_6_in_rule__EntryWindow__Group__6__Impl4084 = new BitSet(new long[]{0x00000001C0000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__ElementsAssignment_6_in_rule__EntryWindow__Group__6__Impl4096 = new BitSet(new long[]{0x00000001C0000002L});
    public static final BitSet FOLLOW_rule__EntryWindow__Group__7__Impl_in_rule__EntryWindow__Group__74129 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_23_in_rule__EntryWindow__Group__7__Impl4157 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__UIElement__Group__0__Impl_in_rule__UIElement__Group__04204 = new BitSet(new long[]{0x0000001E00000000L});
    public static final BitSet FOLLOW_rule__UIElement__Group__1_in_rule__UIElement__Group__04207 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__UIElement__Alternatives_0_in_rule__UIElement__Group__0__Impl4234 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__UIElement__Group__1__Impl_in_rule__UIElement__Group__14264 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__UIElement__UiOptionsAssignment_1_in_rule__UIElement__Group__1__Impl4291 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Label__Group__0__Impl_in_rule__Label__Group__04325 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Label__Group__1_in_rule__Label__Group__04328 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_30_in_rule__Label__Group__0__Impl4356 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Label__Group__1__Impl_in_rule__Label__Group__14387 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_rule__Label__Group__2_in_rule__Label__Group__14390 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Label__NameAssignment_1_in_rule__Label__Group__1__Impl4417 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Label__Group__2__Impl_in_rule__Label__Group__24447 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Label__TextAssignment_2_in_rule__Label__Group__2__Impl4474 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Field__Group__0__Impl_in_rule__Field__Group__04511 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Field__Group__1_in_rule__Field__Group__04514 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_31_in_rule__Field__Group__0__Impl4542 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Field__Group__1__Impl_in_rule__Field__Group__14573 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Field__PropertyAssignment_1_in_rule__Field__Group__1__Impl4600 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Button__Group__0__Impl_in_rule__Button__Group__04634 = new BitSet(new long[]{0x0000000000070000L});
    public static final BitSet FOLLOW_rule__Button__Group__1_in_rule__Button__Group__04637 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_32_in_rule__Button__Group__0__Impl4665 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Button__Group__1__Impl_in_rule__Button__Group__14696 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Button__InscriptionAssignment_1_in_rule__Button__Group__1__Impl4723 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__Group_0__0__Impl_in_rule__Size__Group_0__04757 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_rule__Size__Group_0__1_in_rule__Size__Group_0__04760 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_rule__Size__Group_0__0__Impl4788 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__Group_0__1__Impl_in_rule__Size__Group_0__14819 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__WidthAssignment_0_1_in_rule__Size__Group_0__1__Impl4846 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__Group_1__0__Impl_in_rule__Size__Group_1__04880 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_rule__Size__Group_1__1_in_rule__Size__Group_1__04883 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_34_in_rule__Size__Group_1__0__Impl4911 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__Group_1__1__Impl_in_rule__Size__Group_1__14942 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__HeightAssignment_1_1_in_rule__Size__Group_1__1__Impl4969 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Position__Group_0__0__Impl_in_rule__Position__Group_0__05003 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_rule__Position__Group_0__1_in_rule__Position__Group_0__05006 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_35_in_rule__Position__Group_0__0__Impl5034 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Position__Group_0__1__Impl_in_rule__Position__Group_0__15065 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Position__XAssignment_0_1_in_rule__Position__Group_0__1__Impl5092 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Position__Group_1__0__Impl_in_rule__Position__Group_1__05126 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_rule__Position__Group_1__1_in_rule__Position__Group_1__05129 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_36_in_rule__Position__Group_1__0__Impl5157 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Position__Group_1__1__Impl_in_rule__Position__Group_1__15188 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Position__YAssignment_1_1_in_rule__Position__Group_1__1__Impl5215 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__WindowOptions__Group_1__0__Impl_in_rule__WindowOptions__Group_1__05249 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_rule__WindowOptions__Group_1__1_in_rule__WindowOptions__Group_1__05252 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_37_in_rule__WindowOptions__Group_1__0__Impl5280 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__WindowOptions__Group_1__1__Impl_in_rule__WindowOptions__Group_1__15311 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__WindowOptions__TitleAssignment_1_1_in_rule__WindowOptions__Group_1__1__Impl5338 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__UIOptions__UnorderedGroup__0_in_rule__UIOptions__UnorderedGroup5373 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__UIOptions__PositionAssignment_0_in_rule__UIOptions__UnorderedGroup__Impl5462 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__UIOptions__SizeAssignment_1_in_rule__UIOptions__UnorderedGroup__Impl5553 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__UIOptions__UnorderedGroup__Impl_in_rule__UIOptions__UnorderedGroup__05612 = new BitSet(new long[]{0x0000001E00000002L});
    public static final BitSet FOLLOW_rule__UIOptions__UnorderedGroup__1_in_rule__UIOptions__UnorderedGroup__05615 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__UIOptions__UnorderedGroup__Impl_in_rule__UIOptions__UnorderedGroup__15640 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__UnorderedGroup__0_in_rule__Size__UnorderedGroup5668 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__Group_0__0_in_rule__Size__UnorderedGroup__Impl5757 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__Group_1__0_in_rule__Size__UnorderedGroup__Impl5848 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__UnorderedGroup__Impl_in_rule__Size__UnorderedGroup__05907 = new BitSet(new long[]{0x0000000600000002L});
    public static final BitSet FOLLOW_rule__Size__UnorderedGroup__1_in_rule__Size__UnorderedGroup__05910 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Size__UnorderedGroup__Impl_in_rule__Size__UnorderedGroup__15935 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Position__UnorderedGroup__0_in_rule__Position__UnorderedGroup5963 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Position__Group_0__0_in_rule__Position__UnorderedGroup__Impl6052 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Position__Group_1__0_in_rule__Position__UnorderedGroup__Impl6143 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Position__UnorderedGroup__Impl_in_rule__Position__UnorderedGroup__06202 = new BitSet(new long[]{0x0000001800000002L});
    public static final BitSet FOLLOW_rule__Position__UnorderedGroup__1_in_rule__Position__UnorderedGroup__06205 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Position__UnorderedGroup__Impl_in_rule__Position__UnorderedGroup__16230 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__WindowOptions__UnorderedGroup__0_in_rule__WindowOptions__UnorderedGroup6258 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__WindowOptions__SizeAssignment_0_in_rule__WindowOptions__UnorderedGroup__Impl6347 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__WindowOptions__Group_1__0_in_rule__WindowOptions__UnorderedGroup__Impl6438 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__WindowOptions__UnorderedGroup__Impl_in_rule__WindowOptions__UnorderedGroup__06497 = new BitSet(new long[]{0x0000002600000002L});
    public static final BitSet FOLLOW_rule__WindowOptions__UnorderedGroup__1_in_rule__WindowOptions__UnorderedGroup__06500 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__WindowOptions__UnorderedGroup__Impl_in_rule__WindowOptions__UnorderedGroup__16525 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePackage_in_rule__Model__PackageAssignment_06557 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEntitytype_in_rule__Model__EntitytypesAssignment_1_06588 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleUIWindow_in_rule__Model__UiwindowsAssignment_1_16619 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleQualifiedName_in_rule__Package__NameAssignment_16650 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_38_in_rule__Entitytype__AbstractAssignment_06686 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Entitytype__NameAssignment_26725 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Entitytype__SupertypeAssignment_3_16760 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleProperty_in_rule__Entitytype__PropertiesAssignment_56795 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleBasicType_in_rule__Attribute__TypeAssignment_16826 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Attribute__NameAssignment_26857 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_39_in_rule__Attribute__OptionalAssignment_36893 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Reference__ReferencesAssignment_16936 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Reference__NameAssignment_26971 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleMultiplicity_in_rule__Reference__MultiplicityAssignment_37002 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__ListWindow__NameAssignment_17033 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__ListWindow__EntitytypeAssignment_37068 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleWindowOptions_in_rule__ListWindow__OptionsAssignment_57103 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__EntryWindow__NameAssignment_17134 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__EntryWindow__EntitytypeAssignment_37169 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleWindowOptions_in_rule__EntryWindow__OptionsAssignment_57204 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleUIElement_in_rule__EntryWindow__ElementsAssignment_67235 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleUIOptions_in_rule__UIElement__UiOptionsAssignment_17266 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePosition_in_rule__UIOptions__PositionAssignment_07297 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleSize_in_rule__UIOptions__SizeAssignment_17328 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Label__NameAssignment_17359 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_STRING_in_rule__Label__TextAssignment_27390 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Field__PropertyAssignment_17425 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleInscription_in_rule__Button__InscriptionAssignment_17460 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_INT_in_rule__Size__WidthAssignment_0_17491 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_INT_in_rule__Size__HeightAssignment_1_17522 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_INT_in_rule__Position__XAssignment_0_17553 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_INT_in_rule__Position__YAssignment_1_17584 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleSize_in_rule__WindowOptions__SizeAssignment_07615 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_STRING_in_rule__WindowOptions__TitleAssignment_1_17646 = new BitSet(new long[]{0x0000000000000002L});

}
