/**
 */
package de.wwu.pi.mdsd05.group05DSL;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.Model#getPackage <em>Package</em>}</li>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.Model#getEntitytypes <em>Entitytypes</em>}</li>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.Model#getUiwindows <em>Uiwindows</em>}</li>
 * </ul>
 * </p>
 *
 * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getModel()
 * @model
 * @generated
 */
public interface Model extends EObject
{
  /**
   * Returns the value of the '<em><b>Package</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Package</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Package</em>' containment reference.
   * @see #setPackage(de.wwu.pi.mdsd05.group05DSL.Package)
   * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getModel_Package()
   * @model containment="true"
   * @generated
   */
  de.wwu.pi.mdsd05.group05DSL.Package getPackage();

  /**
   * Sets the value of the '{@link de.wwu.pi.mdsd05.group05DSL.Model#getPackage <em>Package</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Package</em>' containment reference.
   * @see #getPackage()
   * @generated
   */
  void setPackage(de.wwu.pi.mdsd05.group05DSL.Package value);

  /**
   * Returns the value of the '<em><b>Entitytypes</b></em>' containment reference list.
   * The list contents are of type {@link de.wwu.pi.mdsd05.group05DSL.Entitytype}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Entitytypes</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Entitytypes</em>' containment reference list.
   * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getModel_Entitytypes()
   * @model containment="true"
   * @generated
   */
  EList<Entitytype> getEntitytypes();

  /**
   * Returns the value of the '<em><b>Uiwindows</b></em>' containment reference list.
   * The list contents are of type {@link de.wwu.pi.mdsd05.group05DSL.UIWindow}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Uiwindows</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Uiwindows</em>' containment reference list.
   * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getModel_Uiwindows()
   * @model containment="true"
   * @generated
   */
  EList<UIWindow> getUiwindows();

} // Model
