/**
 */
package de.wwu.pi.mdsd05.group05DSL.impl;

import de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage;
import de.wwu.pi.mdsd05.group05DSL.ListWindow;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>List Window</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class ListWindowImpl extends UIWindowImpl implements ListWindow
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ListWindowImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Group05DSLPackage.Literals.LIST_WINDOW;
  }

} //ListWindowImpl
