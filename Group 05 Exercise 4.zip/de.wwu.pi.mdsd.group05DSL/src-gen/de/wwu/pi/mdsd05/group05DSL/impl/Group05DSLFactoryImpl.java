/**
 */
package de.wwu.pi.mdsd05.group05DSL.impl;

import de.wwu.pi.mdsd05.group05DSL.Attribute;
import de.wwu.pi.mdsd05.group05DSL.BasicType;
import de.wwu.pi.mdsd05.group05DSL.Button;
import de.wwu.pi.mdsd05.group05DSL.Entitytype;
import de.wwu.pi.mdsd05.group05DSL.EntryWindow;
import de.wwu.pi.mdsd05.group05DSL.Field;
import de.wwu.pi.mdsd05.group05DSL.Group05DSLFactory;
import de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage;
import de.wwu.pi.mdsd05.group05DSL.Inscription;
import de.wwu.pi.mdsd05.group05DSL.Label;
import de.wwu.pi.mdsd05.group05DSL.ListWindow;
import de.wwu.pi.mdsd05.group05DSL.Model;
import de.wwu.pi.mdsd05.group05DSL.Multiplicity;
import de.wwu.pi.mdsd05.group05DSL.Position;
import de.wwu.pi.mdsd05.group05DSL.Property;
import de.wwu.pi.mdsd05.group05DSL.Reference;
import de.wwu.pi.mdsd05.group05DSL.Size;
import de.wwu.pi.mdsd05.group05DSL.UIElement;
import de.wwu.pi.mdsd05.group05DSL.UIOptions;
import de.wwu.pi.mdsd05.group05DSL.UIWindow;
import de.wwu.pi.mdsd05.group05DSL.WindowOptions;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Group05DSLFactoryImpl extends EFactoryImpl implements Group05DSLFactory
{
  /**
   * Creates the default factory implementation.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static Group05DSLFactory init()
  {
    try
    {
      Group05DSLFactory theGroup05DSLFactory = (Group05DSLFactory)EPackage.Registry.INSTANCE.getEFactory(Group05DSLPackage.eNS_URI);
      if (theGroup05DSLFactory != null)
      {
        return theGroup05DSLFactory;
      }
    }
    catch (Exception exception)
    {
      EcorePlugin.INSTANCE.log(exception);
    }
    return new Group05DSLFactoryImpl();
  }

  /**
   * Creates an instance of the factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Group05DSLFactoryImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public EObject create(EClass eClass)
  {
    switch (eClass.getClassifierID())
    {
      case Group05DSLPackage.MODEL: return createModel();
      case Group05DSLPackage.PACKAGE: return createPackage();
      case Group05DSLPackage.ENTITYTYPE: return createEntitytype();
      case Group05DSLPackage.PROPERTY: return createProperty();
      case Group05DSLPackage.ATTRIBUTE: return createAttribute();
      case Group05DSLPackage.REFERENCE: return createReference();
      case Group05DSLPackage.UI_WINDOW: return createUIWindow();
      case Group05DSLPackage.LIST_WINDOW: return createListWindow();
      case Group05DSLPackage.ENTRY_WINDOW: return createEntryWindow();
      case Group05DSLPackage.UI_ELEMENT: return createUIElement();
      case Group05DSLPackage.UI_OPTIONS: return createUIOptions();
      case Group05DSLPackage.LABEL: return createLabel();
      case Group05DSLPackage.FIELD: return createField();
      case Group05DSLPackage.BUTTON: return createButton();
      case Group05DSLPackage.SIZE: return createSize();
      case Group05DSLPackage.POSITION: return createPosition();
      case Group05DSLPackage.WINDOW_OPTIONS: return createWindowOptions();
      default:
        throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object createFromString(EDataType eDataType, String initialValue)
  {
    switch (eDataType.getClassifierID())
    {
      case Group05DSLPackage.BASIC_TYPE:
        return createBasicTypeFromString(eDataType, initialValue);
      case Group05DSLPackage.MULTIPLICITY:
        return createMultiplicityFromString(eDataType, initialValue);
      case Group05DSLPackage.INSCRIPTION:
        return createInscriptionFromString(eDataType, initialValue);
      default:
        throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String convertToString(EDataType eDataType, Object instanceValue)
  {
    switch (eDataType.getClassifierID())
    {
      case Group05DSLPackage.BASIC_TYPE:
        return convertBasicTypeToString(eDataType, instanceValue);
      case Group05DSLPackage.MULTIPLICITY:
        return convertMultiplicityToString(eDataType, instanceValue);
      case Group05DSLPackage.INSCRIPTION:
        return convertInscriptionToString(eDataType, instanceValue);
      default:
        throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Model createModel()
  {
    ModelImpl model = new ModelImpl();
    return model;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public de.wwu.pi.mdsd05.group05DSL.Package createPackage()
  {
    PackageImpl package_ = new PackageImpl();
    return package_;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Entitytype createEntitytype()
  {
    EntitytypeImpl entitytype = new EntitytypeImpl();
    return entitytype;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Property createProperty()
  {
    PropertyImpl property = new PropertyImpl();
    return property;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Attribute createAttribute()
  {
    AttributeImpl attribute = new AttributeImpl();
    return attribute;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Reference createReference()
  {
    ReferenceImpl reference = new ReferenceImpl();
    return reference;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public UIWindow createUIWindow()
  {
    UIWindowImpl uiWindow = new UIWindowImpl();
    return uiWindow;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ListWindow createListWindow()
  {
    ListWindowImpl listWindow = new ListWindowImpl();
    return listWindow;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EntryWindow createEntryWindow()
  {
    EntryWindowImpl entryWindow = new EntryWindowImpl();
    return entryWindow;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public UIElement createUIElement()
  {
    UIElementImpl uiElement = new UIElementImpl();
    return uiElement;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public UIOptions createUIOptions()
  {
    UIOptionsImpl uiOptions = new UIOptionsImpl();
    return uiOptions;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Label createLabel()
  {
    LabelImpl label = new LabelImpl();
    return label;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Field createField()
  {
    FieldImpl field = new FieldImpl();
    return field;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Button createButton()
  {
    ButtonImpl button = new ButtonImpl();
    return button;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Size createSize()
  {
    SizeImpl size = new SizeImpl();
    return size;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Position createPosition()
  {
    PositionImpl position = new PositionImpl();
    return position;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public WindowOptions createWindowOptions()
  {
    WindowOptionsImpl windowOptions = new WindowOptionsImpl();
    return windowOptions;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BasicType createBasicTypeFromString(EDataType eDataType, String initialValue)
  {
    BasicType result = BasicType.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertBasicTypeToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Multiplicity createMultiplicityFromString(EDataType eDataType, String initialValue)
  {
    Multiplicity result = Multiplicity.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertMultiplicityToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Inscription createInscriptionFromString(EDataType eDataType, String initialValue)
  {
    Inscription result = Inscription.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertInscriptionToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Group05DSLPackage getGroup05DSLPackage()
  {
    return (Group05DSLPackage)getEPackage();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @deprecated
   * @generated
   */
  @Deprecated
  public static Group05DSLPackage getPackage()
  {
    return Group05DSLPackage.eINSTANCE;
  }

} //Group05DSLFactoryImpl
