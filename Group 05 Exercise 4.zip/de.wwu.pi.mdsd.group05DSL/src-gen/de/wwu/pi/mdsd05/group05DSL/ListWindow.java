/**
 */
package de.wwu.pi.mdsd05.group05DSL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>List Window</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getListWindow()
 * @model
 * @generated
 */
public interface ListWindow extends UIWindow
{
} // ListWindow
