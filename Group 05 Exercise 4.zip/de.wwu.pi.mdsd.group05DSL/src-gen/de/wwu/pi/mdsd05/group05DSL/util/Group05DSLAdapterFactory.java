/**
 */
package de.wwu.pi.mdsd05.group05DSL.util;

import de.wwu.pi.mdsd05.group05DSL.Attribute;
import de.wwu.pi.mdsd05.group05DSL.Button;
import de.wwu.pi.mdsd05.group05DSL.Entitytype;
import de.wwu.pi.mdsd05.group05DSL.EntryWindow;
import de.wwu.pi.mdsd05.group05DSL.Field;
import de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage;
import de.wwu.pi.mdsd05.group05DSL.Label;
import de.wwu.pi.mdsd05.group05DSL.ListWindow;
import de.wwu.pi.mdsd05.group05DSL.Model;
import de.wwu.pi.mdsd05.group05DSL.Position;
import de.wwu.pi.mdsd05.group05DSL.Property;
import de.wwu.pi.mdsd05.group05DSL.Reference;
import de.wwu.pi.mdsd05.group05DSL.Size;
import de.wwu.pi.mdsd05.group05DSL.UIElement;
import de.wwu.pi.mdsd05.group05DSL.UIOptions;
import de.wwu.pi.mdsd05.group05DSL.UIWindow;
import de.wwu.pi.mdsd05.group05DSL.WindowOptions;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage
 * @generated
 */
public class Group05DSLAdapterFactory extends AdapterFactoryImpl
{
  /**
   * The cached model package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected static Group05DSLPackage modelPackage;

  /**
   * Creates an instance of the adapter factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Group05DSLAdapterFactory()
  {
    if (modelPackage == null)
    {
      modelPackage = Group05DSLPackage.eINSTANCE;
    }
  }

  /**
   * Returns whether this factory is applicable for the type of the object.
   * <!-- begin-user-doc -->
   * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
   * <!-- end-user-doc -->
   * @return whether this factory is applicable for the type of the object.
   * @generated
   */
  @Override
  public boolean isFactoryForType(Object object)
  {
    if (object == modelPackage)
    {
      return true;
    }
    if (object instanceof EObject)
    {
      return ((EObject)object).eClass().getEPackage() == modelPackage;
    }
    return false;
  }

  /**
   * The switch that delegates to the <code>createXXX</code> methods.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Group05DSLSwitch<Adapter> modelSwitch =
    new Group05DSLSwitch<Adapter>()
    {
      @Override
      public Adapter caseModel(Model object)
      {
        return createModelAdapter();
      }
      @Override
      public Adapter casePackage(de.wwu.pi.mdsd05.group05DSL.Package object)
      {
        return createPackageAdapter();
      }
      @Override
      public Adapter caseEntitytype(Entitytype object)
      {
        return createEntitytypeAdapter();
      }
      @Override
      public Adapter caseProperty(Property object)
      {
        return createPropertyAdapter();
      }
      @Override
      public Adapter caseAttribute(Attribute object)
      {
        return createAttributeAdapter();
      }
      @Override
      public Adapter caseReference(Reference object)
      {
        return createReferenceAdapter();
      }
      @Override
      public Adapter caseUIWindow(UIWindow object)
      {
        return createUIWindowAdapter();
      }
      @Override
      public Adapter caseListWindow(ListWindow object)
      {
        return createListWindowAdapter();
      }
      @Override
      public Adapter caseEntryWindow(EntryWindow object)
      {
        return createEntryWindowAdapter();
      }
      @Override
      public Adapter caseUIElement(UIElement object)
      {
        return createUIElementAdapter();
      }
      @Override
      public Adapter caseUIOptions(UIOptions object)
      {
        return createUIOptionsAdapter();
      }
      @Override
      public Adapter caseLabel(Label object)
      {
        return createLabelAdapter();
      }
      @Override
      public Adapter caseField(Field object)
      {
        return createFieldAdapter();
      }
      @Override
      public Adapter caseButton(Button object)
      {
        return createButtonAdapter();
      }
      @Override
      public Adapter caseSize(Size object)
      {
        return createSizeAdapter();
      }
      @Override
      public Adapter casePosition(Position object)
      {
        return createPositionAdapter();
      }
      @Override
      public Adapter caseWindowOptions(WindowOptions object)
      {
        return createWindowOptionsAdapter();
      }
      @Override
      public Adapter defaultCase(EObject object)
      {
        return createEObjectAdapter();
      }
    };

  /**
   * Creates an adapter for the <code>target</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param target the object to adapt.
   * @return the adapter for the <code>target</code>.
   * @generated
   */
  @Override
  public Adapter createAdapter(Notifier target)
  {
    return modelSwitch.doSwitch((EObject)target);
  }


  /**
   * Creates a new adapter for an object of class '{@link de.wwu.pi.mdsd05.group05DSL.Model <em>Model</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see de.wwu.pi.mdsd05.group05DSL.Model
   * @generated
   */
  public Adapter createModelAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link de.wwu.pi.mdsd05.group05DSL.Package <em>Package</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see de.wwu.pi.mdsd05.group05DSL.Package
   * @generated
   */
  public Adapter createPackageAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link de.wwu.pi.mdsd05.group05DSL.Entitytype <em>Entitytype</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see de.wwu.pi.mdsd05.group05DSL.Entitytype
   * @generated
   */
  public Adapter createEntitytypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link de.wwu.pi.mdsd05.group05DSL.Property <em>Property</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see de.wwu.pi.mdsd05.group05DSL.Property
   * @generated
   */
  public Adapter createPropertyAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link de.wwu.pi.mdsd05.group05DSL.Attribute <em>Attribute</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see de.wwu.pi.mdsd05.group05DSL.Attribute
   * @generated
   */
  public Adapter createAttributeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link de.wwu.pi.mdsd05.group05DSL.Reference <em>Reference</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see de.wwu.pi.mdsd05.group05DSL.Reference
   * @generated
   */
  public Adapter createReferenceAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link de.wwu.pi.mdsd05.group05DSL.UIWindow <em>UI Window</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see de.wwu.pi.mdsd05.group05DSL.UIWindow
   * @generated
   */
  public Adapter createUIWindowAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link de.wwu.pi.mdsd05.group05DSL.ListWindow <em>List Window</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see de.wwu.pi.mdsd05.group05DSL.ListWindow
   * @generated
   */
  public Adapter createListWindowAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link de.wwu.pi.mdsd05.group05DSL.EntryWindow <em>Entry Window</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see de.wwu.pi.mdsd05.group05DSL.EntryWindow
   * @generated
   */
  public Adapter createEntryWindowAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link de.wwu.pi.mdsd05.group05DSL.UIElement <em>UI Element</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see de.wwu.pi.mdsd05.group05DSL.UIElement
   * @generated
   */
  public Adapter createUIElementAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link de.wwu.pi.mdsd05.group05DSL.UIOptions <em>UI Options</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see de.wwu.pi.mdsd05.group05DSL.UIOptions
   * @generated
   */
  public Adapter createUIOptionsAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link de.wwu.pi.mdsd05.group05DSL.Label <em>Label</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see de.wwu.pi.mdsd05.group05DSL.Label
   * @generated
   */
  public Adapter createLabelAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link de.wwu.pi.mdsd05.group05DSL.Field <em>Field</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see de.wwu.pi.mdsd05.group05DSL.Field
   * @generated
   */
  public Adapter createFieldAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link de.wwu.pi.mdsd05.group05DSL.Button <em>Button</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see de.wwu.pi.mdsd05.group05DSL.Button
   * @generated
   */
  public Adapter createButtonAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link de.wwu.pi.mdsd05.group05DSL.Size <em>Size</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see de.wwu.pi.mdsd05.group05DSL.Size
   * @generated
   */
  public Adapter createSizeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link de.wwu.pi.mdsd05.group05DSL.Position <em>Position</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see de.wwu.pi.mdsd05.group05DSL.Position
   * @generated
   */
  public Adapter createPositionAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link de.wwu.pi.mdsd05.group05DSL.WindowOptions <em>Window Options</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see de.wwu.pi.mdsd05.group05DSL.WindowOptions
   * @generated
   */
  public Adapter createWindowOptionsAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for the default case.
   * <!-- begin-user-doc -->
   * This default implementation returns null.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @generated
   */
  public Adapter createEObjectAdapter()
  {
    return null;
  }

} //Group05DSLAdapterFactory
