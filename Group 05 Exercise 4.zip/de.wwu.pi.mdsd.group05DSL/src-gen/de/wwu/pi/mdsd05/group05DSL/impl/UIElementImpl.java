/**
 */
package de.wwu.pi.mdsd05.group05DSL.impl;

import de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage;
import de.wwu.pi.mdsd05.group05DSL.UIElement;
import de.wwu.pi.mdsd05.group05DSL.UIOptions;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>UI Element</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.impl.UIElementImpl#getUiOptions <em>Ui Options</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class UIElementImpl extends MinimalEObjectImpl.Container implements UIElement
{
  /**
   * The cached value of the '{@link #getUiOptions() <em>Ui Options</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUiOptions()
   * @generated
   * @ordered
   */
  protected UIOptions uiOptions;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected UIElementImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Group05DSLPackage.Literals.UI_ELEMENT;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public UIOptions getUiOptions()
  {
    return uiOptions;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetUiOptions(UIOptions newUiOptions, NotificationChain msgs)
  {
    UIOptions oldUiOptions = uiOptions;
    uiOptions = newUiOptions;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Group05DSLPackage.UI_ELEMENT__UI_OPTIONS, oldUiOptions, newUiOptions);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setUiOptions(UIOptions newUiOptions)
  {
    if (newUiOptions != uiOptions)
    {
      NotificationChain msgs = null;
      if (uiOptions != null)
        msgs = ((InternalEObject)uiOptions).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Group05DSLPackage.UI_ELEMENT__UI_OPTIONS, null, msgs);
      if (newUiOptions != null)
        msgs = ((InternalEObject)newUiOptions).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Group05DSLPackage.UI_ELEMENT__UI_OPTIONS, null, msgs);
      msgs = basicSetUiOptions(newUiOptions, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Group05DSLPackage.UI_ELEMENT__UI_OPTIONS, newUiOptions, newUiOptions));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Group05DSLPackage.UI_ELEMENT__UI_OPTIONS:
        return basicSetUiOptions(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Group05DSLPackage.UI_ELEMENT__UI_OPTIONS:
        return getUiOptions();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Group05DSLPackage.UI_ELEMENT__UI_OPTIONS:
        setUiOptions((UIOptions)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Group05DSLPackage.UI_ELEMENT__UI_OPTIONS:
        setUiOptions((UIOptions)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Group05DSLPackage.UI_ELEMENT__UI_OPTIONS:
        return uiOptions != null;
    }
    return super.eIsSet(featureID);
  }

} //UIElementImpl
