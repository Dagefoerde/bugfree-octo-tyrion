/**
 */
package de.wwu.pi.mdsd05.group05DSL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Field</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.Field#getProperty <em>Property</em>}</li>
 * </ul>
 * </p>
 *
 * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getField()
 * @model
 * @generated
 */
public interface Field extends UIElement
{
  /**
   * Returns the value of the '<em><b>Property</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Property</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Property</em>' reference.
   * @see #setProperty(Property)
   * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getField_Property()
   * @model
   * @generated
   */
  Property getProperty();

  /**
   * Sets the value of the '{@link de.wwu.pi.mdsd05.group05DSL.Field#getProperty <em>Property</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Property</em>' reference.
   * @see #getProperty()
   * @generated
   */
  void setProperty(Property value);

} // Field
