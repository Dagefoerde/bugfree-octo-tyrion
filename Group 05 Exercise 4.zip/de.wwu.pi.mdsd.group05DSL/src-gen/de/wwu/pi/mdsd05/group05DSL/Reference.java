/**
 */
package de.wwu.pi.mdsd05.group05DSL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Reference</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.Reference#getReferences <em>References</em>}</li>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.Reference#getMultiplicity <em>Multiplicity</em>}</li>
 * </ul>
 * </p>
 *
 * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getReference()
 * @model
 * @generated
 */
public interface Reference extends Property
{
  /**
   * Returns the value of the '<em><b>References</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>References</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>References</em>' reference.
   * @see #setReferences(Entitytype)
   * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getReference_References()
   * @model
   * @generated
   */
  Entitytype getReferences();

  /**
   * Sets the value of the '{@link de.wwu.pi.mdsd05.group05DSL.Reference#getReferences <em>References</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>References</em>' reference.
   * @see #getReferences()
   * @generated
   */
  void setReferences(Entitytype value);

  /**
   * Returns the value of the '<em><b>Multiplicity</b></em>' attribute.
   * The literals are from the enumeration {@link de.wwu.pi.mdsd05.group05DSL.Multiplicity}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Multiplicity</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Multiplicity</em>' attribute.
   * @see de.wwu.pi.mdsd05.group05DSL.Multiplicity
   * @see #setMultiplicity(Multiplicity)
   * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getReference_Multiplicity()
   * @model
   * @generated
   */
  Multiplicity getMultiplicity();

  /**
   * Sets the value of the '{@link de.wwu.pi.mdsd05.group05DSL.Reference#getMultiplicity <em>Multiplicity</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Multiplicity</em>' attribute.
   * @see de.wwu.pi.mdsd05.group05DSL.Multiplicity
   * @see #getMultiplicity()
   * @generated
   */
  void setMultiplicity(Multiplicity value);

} // Reference
