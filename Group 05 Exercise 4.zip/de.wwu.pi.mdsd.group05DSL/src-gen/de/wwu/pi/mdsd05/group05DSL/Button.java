/**
 */
package de.wwu.pi.mdsd05.group05DSL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Button</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.Button#getInscription <em>Inscription</em>}</li>
 * </ul>
 * </p>
 *
 * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getButton()
 * @model
 * @generated
 */
public interface Button extends UIElement
{
  /**
   * Returns the value of the '<em><b>Inscription</b></em>' attribute.
   * The literals are from the enumeration {@link de.wwu.pi.mdsd05.group05DSL.Inscription}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Inscription</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Inscription</em>' attribute.
   * @see de.wwu.pi.mdsd05.group05DSL.Inscription
   * @see #setInscription(Inscription)
   * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getButton_Inscription()
   * @model
   * @generated
   */
  Inscription getInscription();

  /**
   * Sets the value of the '{@link de.wwu.pi.mdsd05.group05DSL.Button#getInscription <em>Inscription</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Inscription</em>' attribute.
   * @see de.wwu.pi.mdsd05.group05DSL.Inscription
   * @see #getInscription()
   * @generated
   */
  void setInscription(Inscription value);

} // Button
