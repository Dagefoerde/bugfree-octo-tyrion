/**
 */
package de.wwu.pi.mdsd05.group05DSL;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>UI Element</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.UIElement#getUiOptions <em>Ui Options</em>}</li>
 * </ul>
 * </p>
 *
 * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getUIElement()
 * @model
 * @generated
 */
public interface UIElement extends EObject
{
  /**
   * Returns the value of the '<em><b>Ui Options</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Ui Options</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Ui Options</em>' containment reference.
   * @see #setUiOptions(UIOptions)
   * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getUIElement_UiOptions()
   * @model containment="true"
   * @generated
   */
  UIOptions getUiOptions();

  /**
   * Sets the value of the '{@link de.wwu.pi.mdsd05.group05DSL.UIElement#getUiOptions <em>Ui Options</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Ui Options</em>' containment reference.
   * @see #getUiOptions()
   * @generated
   */
  void setUiOptions(UIOptions value);

} // UIElement
