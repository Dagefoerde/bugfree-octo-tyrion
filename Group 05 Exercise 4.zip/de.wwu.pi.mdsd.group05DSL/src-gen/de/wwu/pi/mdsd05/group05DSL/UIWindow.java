/**
 */
package de.wwu.pi.mdsd05.group05DSL;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>UI Window</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.UIWindow#getName <em>Name</em>}</li>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.UIWindow#getEntitytype <em>Entitytype</em>}</li>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.UIWindow#getOptions <em>Options</em>}</li>
 * </ul>
 * </p>
 *
 * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getUIWindow()
 * @model
 * @generated
 */
public interface UIWindow extends EObject
{
  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute.
   * @see #setName(String)
   * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getUIWindow_Name()
   * @model
   * @generated
   */
  String getName();

  /**
   * Sets the value of the '{@link de.wwu.pi.mdsd05.group05DSL.UIWindow#getName <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' attribute.
   * @see #getName()
   * @generated
   */
  void setName(String value);

  /**
   * Returns the value of the '<em><b>Entitytype</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Entitytype</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Entitytype</em>' reference.
   * @see #setEntitytype(Entitytype)
   * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getUIWindow_Entitytype()
   * @model
   * @generated
   */
  Entitytype getEntitytype();

  /**
   * Sets the value of the '{@link de.wwu.pi.mdsd05.group05DSL.UIWindow#getEntitytype <em>Entitytype</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Entitytype</em>' reference.
   * @see #getEntitytype()
   * @generated
   */
  void setEntitytype(Entitytype value);

  /**
   * Returns the value of the '<em><b>Options</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Options</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Options</em>' containment reference.
   * @see #setOptions(WindowOptions)
   * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getUIWindow_Options()
   * @model containment="true"
   * @generated
   */
  WindowOptions getOptions();

  /**
   * Sets the value of the '{@link de.wwu.pi.mdsd05.group05DSL.UIWindow#getOptions <em>Options</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Options</em>' containment reference.
   * @see #getOptions()
   * @generated
   */
  void setOptions(WindowOptions value);

} // UIWindow
