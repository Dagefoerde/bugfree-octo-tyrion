/**
 */
package de.wwu.pi.mdsd05.group05DSL;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Entitytype</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.Entitytype#getAbstract <em>Abstract</em>}</li>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.Entitytype#getName <em>Name</em>}</li>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.Entitytype#getSupertype <em>Supertype</em>}</li>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.Entitytype#getProperties <em>Properties</em>}</li>
 * </ul>
 * </p>
 *
 * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getEntitytype()
 * @model
 * @generated
 */
public interface Entitytype extends EObject
{
  /**
   * Returns the value of the '<em><b>Abstract</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Abstract</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Abstract</em>' attribute.
   * @see #setAbstract(String)
   * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getEntitytype_Abstract()
   * @model
   * @generated
   */
  String getAbstract();

  /**
   * Sets the value of the '{@link de.wwu.pi.mdsd05.group05DSL.Entitytype#getAbstract <em>Abstract</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Abstract</em>' attribute.
   * @see #getAbstract()
   * @generated
   */
  void setAbstract(String value);

  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute.
   * @see #setName(String)
   * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getEntitytype_Name()
   * @model
   * @generated
   */
  String getName();

  /**
   * Sets the value of the '{@link de.wwu.pi.mdsd05.group05DSL.Entitytype#getName <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' attribute.
   * @see #getName()
   * @generated
   */
  void setName(String value);

  /**
   * Returns the value of the '<em><b>Supertype</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Supertype</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Supertype</em>' reference.
   * @see #setSupertype(Entitytype)
   * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getEntitytype_Supertype()
   * @model
   * @generated
   */
  Entitytype getSupertype();

  /**
   * Sets the value of the '{@link de.wwu.pi.mdsd05.group05DSL.Entitytype#getSupertype <em>Supertype</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Supertype</em>' reference.
   * @see #getSupertype()
   * @generated
   */
  void setSupertype(Entitytype value);

  /**
   * Returns the value of the '<em><b>Properties</b></em>' containment reference list.
   * The list contents are of type {@link de.wwu.pi.mdsd05.group05DSL.Property}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Properties</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Properties</em>' containment reference list.
   * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getEntitytype_Properties()
   * @model containment="true"
   * @generated
   */
  EList<Property> getProperties();

} // Entitytype
