/**
 */
package de.wwu.pi.mdsd05.group05DSL.impl;

import de.wwu.pi.mdsd05.group05DSL.Entitytype;
import de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage;
import de.wwu.pi.mdsd05.group05DSL.Model;
import de.wwu.pi.mdsd05.group05DSL.UIWindow;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.impl.ModelImpl#getPackage <em>Package</em>}</li>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.impl.ModelImpl#getEntitytypes <em>Entitytypes</em>}</li>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.impl.ModelImpl#getUiwindows <em>Uiwindows</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ModelImpl extends MinimalEObjectImpl.Container implements Model
{
  /**
   * The cached value of the '{@link #getPackage() <em>Package</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPackage()
   * @generated
   * @ordered
   */
  protected de.wwu.pi.mdsd05.group05DSL.Package package_;

  /**
   * The cached value of the '{@link #getEntitytypes() <em>Entitytypes</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getEntitytypes()
   * @generated
   * @ordered
   */
  protected EList<Entitytype> entitytypes;

  /**
   * The cached value of the '{@link #getUiwindows() <em>Uiwindows</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUiwindows()
   * @generated
   * @ordered
   */
  protected EList<UIWindow> uiwindows;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ModelImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Group05DSLPackage.Literals.MODEL;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public de.wwu.pi.mdsd05.group05DSL.Package getPackage()
  {
    return package_;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetPackage(de.wwu.pi.mdsd05.group05DSL.Package newPackage, NotificationChain msgs)
  {
    de.wwu.pi.mdsd05.group05DSL.Package oldPackage = package_;
    package_ = newPackage;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Group05DSLPackage.MODEL__PACKAGE, oldPackage, newPackage);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPackage(de.wwu.pi.mdsd05.group05DSL.Package newPackage)
  {
    if (newPackage != package_)
    {
      NotificationChain msgs = null;
      if (package_ != null)
        msgs = ((InternalEObject)package_).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Group05DSLPackage.MODEL__PACKAGE, null, msgs);
      if (newPackage != null)
        msgs = ((InternalEObject)newPackage).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Group05DSLPackage.MODEL__PACKAGE, null, msgs);
      msgs = basicSetPackage(newPackage, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, Group05DSLPackage.MODEL__PACKAGE, newPackage, newPackage));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Entitytype> getEntitytypes()
  {
    if (entitytypes == null)
    {
      entitytypes = new EObjectContainmentEList<Entitytype>(Entitytype.class, this, Group05DSLPackage.MODEL__ENTITYTYPES);
    }
    return entitytypes;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<UIWindow> getUiwindows()
  {
    if (uiwindows == null)
    {
      uiwindows = new EObjectContainmentEList<UIWindow>(UIWindow.class, this, Group05DSLPackage.MODEL__UIWINDOWS);
    }
    return uiwindows;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case Group05DSLPackage.MODEL__PACKAGE:
        return basicSetPackage(null, msgs);
      case Group05DSLPackage.MODEL__ENTITYTYPES:
        return ((InternalEList<?>)getEntitytypes()).basicRemove(otherEnd, msgs);
      case Group05DSLPackage.MODEL__UIWINDOWS:
        return ((InternalEList<?>)getUiwindows()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case Group05DSLPackage.MODEL__PACKAGE:
        return getPackage();
      case Group05DSLPackage.MODEL__ENTITYTYPES:
        return getEntitytypes();
      case Group05DSLPackage.MODEL__UIWINDOWS:
        return getUiwindows();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case Group05DSLPackage.MODEL__PACKAGE:
        setPackage((de.wwu.pi.mdsd05.group05DSL.Package)newValue);
        return;
      case Group05DSLPackage.MODEL__ENTITYTYPES:
        getEntitytypes().clear();
        getEntitytypes().addAll((Collection<? extends Entitytype>)newValue);
        return;
      case Group05DSLPackage.MODEL__UIWINDOWS:
        getUiwindows().clear();
        getUiwindows().addAll((Collection<? extends UIWindow>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case Group05DSLPackage.MODEL__PACKAGE:
        setPackage((de.wwu.pi.mdsd05.group05DSL.Package)null);
        return;
      case Group05DSLPackage.MODEL__ENTITYTYPES:
        getEntitytypes().clear();
        return;
      case Group05DSLPackage.MODEL__UIWINDOWS:
        getUiwindows().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case Group05DSLPackage.MODEL__PACKAGE:
        return package_ != null;
      case Group05DSLPackage.MODEL__ENTITYTYPES:
        return entitytypes != null && !entitytypes.isEmpty();
      case Group05DSLPackage.MODEL__UIWINDOWS:
        return uiwindows != null && !uiwindows.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //ModelImpl
