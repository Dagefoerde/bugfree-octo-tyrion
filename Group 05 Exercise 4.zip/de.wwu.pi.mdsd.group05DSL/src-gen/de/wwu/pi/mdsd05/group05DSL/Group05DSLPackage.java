/**
 */
package de.wwu.pi.mdsd05.group05DSL;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLFactory
 * @model kind="package"
 * @generated
 */
public interface Group05DSLPackage extends EPackage
{
  /**
   * The package name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNAME = "group05DSL";

  /**
   * The package namespace URI.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_URI = "http://www.wwu.de/pi/mdsd05/Group05DSL";

  /**
   * The package namespace name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_PREFIX = "group05DSL";

  /**
   * The singleton instance of the package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  Group05DSLPackage eINSTANCE = de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl.init();

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.ModelImpl <em>Model</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.impl.ModelImpl
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getModel()
   * @generated
   */
  int MODEL = 0;

  /**
   * The feature id for the '<em><b>Package</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MODEL__PACKAGE = 0;

  /**
   * The feature id for the '<em><b>Entitytypes</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MODEL__ENTITYTYPES = 1;

  /**
   * The feature id for the '<em><b>Uiwindows</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MODEL__UIWINDOWS = 2;

  /**
   * The number of structural features of the '<em>Model</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MODEL_FEATURE_COUNT = 3;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.PackageImpl <em>Package</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.impl.PackageImpl
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getPackage()
   * @generated
   */
  int PACKAGE = 1;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int PACKAGE__NAME = 0;

  /**
   * The number of structural features of the '<em>Package</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int PACKAGE_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.EntitytypeImpl <em>Entitytype</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.impl.EntitytypeImpl
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getEntitytype()
   * @generated
   */
  int ENTITYTYPE = 2;

  /**
   * The feature id for the '<em><b>Abstract</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTITYTYPE__ABSTRACT = 0;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTITYTYPE__NAME = 1;

  /**
   * The feature id for the '<em><b>Supertype</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTITYTYPE__SUPERTYPE = 2;

  /**
   * The feature id for the '<em><b>Properties</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTITYTYPE__PROPERTIES = 3;

  /**
   * The number of structural features of the '<em>Entitytype</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTITYTYPE_FEATURE_COUNT = 4;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.PropertyImpl <em>Property</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.impl.PropertyImpl
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getProperty()
   * @generated
   */
  int PROPERTY = 3;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int PROPERTY__NAME = 0;

  /**
   * The number of structural features of the '<em>Property</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int PROPERTY_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.AttributeImpl <em>Attribute</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.impl.AttributeImpl
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getAttribute()
   * @generated
   */
  int ATTRIBUTE = 4;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ATTRIBUTE__NAME = PROPERTY__NAME;

  /**
   * The feature id for the '<em><b>Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ATTRIBUTE__TYPE = PROPERTY_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Optional</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ATTRIBUTE__OPTIONAL = PROPERTY_FEATURE_COUNT + 1;

  /**
   * The number of structural features of the '<em>Attribute</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ATTRIBUTE_FEATURE_COUNT = PROPERTY_FEATURE_COUNT + 2;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.ReferenceImpl <em>Reference</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.impl.ReferenceImpl
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getReference()
   * @generated
   */
  int REFERENCE = 5;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int REFERENCE__NAME = PROPERTY__NAME;

  /**
   * The feature id for the '<em><b>References</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int REFERENCE__REFERENCES = PROPERTY_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Multiplicity</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int REFERENCE__MULTIPLICITY = PROPERTY_FEATURE_COUNT + 1;

  /**
   * The number of structural features of the '<em>Reference</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int REFERENCE_FEATURE_COUNT = PROPERTY_FEATURE_COUNT + 2;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.UIWindowImpl <em>UI Window</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.impl.UIWindowImpl
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getUIWindow()
   * @generated
   */
  int UI_WINDOW = 6;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int UI_WINDOW__NAME = 0;

  /**
   * The feature id for the '<em><b>Entitytype</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int UI_WINDOW__ENTITYTYPE = 1;

  /**
   * The feature id for the '<em><b>Options</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int UI_WINDOW__OPTIONS = 2;

  /**
   * The number of structural features of the '<em>UI Window</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int UI_WINDOW_FEATURE_COUNT = 3;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.ListWindowImpl <em>List Window</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.impl.ListWindowImpl
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getListWindow()
   * @generated
   */
  int LIST_WINDOW = 7;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LIST_WINDOW__NAME = UI_WINDOW__NAME;

  /**
   * The feature id for the '<em><b>Entitytype</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LIST_WINDOW__ENTITYTYPE = UI_WINDOW__ENTITYTYPE;

  /**
   * The feature id for the '<em><b>Options</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LIST_WINDOW__OPTIONS = UI_WINDOW__OPTIONS;

  /**
   * The number of structural features of the '<em>List Window</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LIST_WINDOW_FEATURE_COUNT = UI_WINDOW_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.EntryWindowImpl <em>Entry Window</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.impl.EntryWindowImpl
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getEntryWindow()
   * @generated
   */
  int ENTRY_WINDOW = 8;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTRY_WINDOW__NAME = UI_WINDOW__NAME;

  /**
   * The feature id for the '<em><b>Entitytype</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTRY_WINDOW__ENTITYTYPE = UI_WINDOW__ENTITYTYPE;

  /**
   * The feature id for the '<em><b>Options</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTRY_WINDOW__OPTIONS = UI_WINDOW__OPTIONS;

  /**
   * The feature id for the '<em><b>Elements</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTRY_WINDOW__ELEMENTS = UI_WINDOW_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Entry Window</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTRY_WINDOW_FEATURE_COUNT = UI_WINDOW_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.UIElementImpl <em>UI Element</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.impl.UIElementImpl
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getUIElement()
   * @generated
   */
  int UI_ELEMENT = 9;

  /**
   * The feature id for the '<em><b>Ui Options</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int UI_ELEMENT__UI_OPTIONS = 0;

  /**
   * The number of structural features of the '<em>UI Element</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int UI_ELEMENT_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.UIOptionsImpl <em>UI Options</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.impl.UIOptionsImpl
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getUIOptions()
   * @generated
   */
  int UI_OPTIONS = 10;

  /**
   * The feature id for the '<em><b>Position</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int UI_OPTIONS__POSITION = 0;

  /**
   * The feature id for the '<em><b>Size</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int UI_OPTIONS__SIZE = 1;

  /**
   * The number of structural features of the '<em>UI Options</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int UI_OPTIONS_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.LabelImpl <em>Label</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.impl.LabelImpl
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getLabel()
   * @generated
   */
  int LABEL = 11;

  /**
   * The feature id for the '<em><b>Ui Options</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LABEL__UI_OPTIONS = UI_ELEMENT__UI_OPTIONS;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LABEL__NAME = UI_ELEMENT_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Text</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LABEL__TEXT = UI_ELEMENT_FEATURE_COUNT + 1;

  /**
   * The number of structural features of the '<em>Label</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LABEL_FEATURE_COUNT = UI_ELEMENT_FEATURE_COUNT + 2;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.FieldImpl <em>Field</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.impl.FieldImpl
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getField()
   * @generated
   */
  int FIELD = 12;

  /**
   * The feature id for the '<em><b>Ui Options</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FIELD__UI_OPTIONS = UI_ELEMENT__UI_OPTIONS;

  /**
   * The feature id for the '<em><b>Property</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FIELD__PROPERTY = UI_ELEMENT_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Field</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FIELD_FEATURE_COUNT = UI_ELEMENT_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.ButtonImpl <em>Button</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.impl.ButtonImpl
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getButton()
   * @generated
   */
  int BUTTON = 13;

  /**
   * The feature id for the '<em><b>Ui Options</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BUTTON__UI_OPTIONS = UI_ELEMENT__UI_OPTIONS;

  /**
   * The feature id for the '<em><b>Inscription</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BUTTON__INSCRIPTION = UI_ELEMENT_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Button</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BUTTON_FEATURE_COUNT = UI_ELEMENT_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.SizeImpl <em>Size</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.impl.SizeImpl
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getSize()
   * @generated
   */
  int SIZE = 14;

  /**
   * The feature id for the '<em><b>Width</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SIZE__WIDTH = 0;

  /**
   * The feature id for the '<em><b>Height</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SIZE__HEIGHT = 1;

  /**
   * The number of structural features of the '<em>Size</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SIZE_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.PositionImpl <em>Position</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.impl.PositionImpl
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getPosition()
   * @generated
   */
  int POSITION = 15;

  /**
   * The feature id for the '<em><b>X</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int POSITION__X = 0;

  /**
   * The feature id for the '<em><b>Y</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int POSITION__Y = 1;

  /**
   * The number of structural features of the '<em>Position</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int POSITION_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.WindowOptionsImpl <em>Window Options</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.impl.WindowOptionsImpl
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getWindowOptions()
   * @generated
   */
  int WINDOW_OPTIONS = 16;

  /**
   * The feature id for the '<em><b>Size</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int WINDOW_OPTIONS__SIZE = 0;

  /**
   * The feature id for the '<em><b>Title</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int WINDOW_OPTIONS__TITLE = 1;

  /**
   * The number of structural features of the '<em>Window Options</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int WINDOW_OPTIONS_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.BasicType <em>Basic Type</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.BasicType
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getBasicType()
   * @generated
   */
  int BASIC_TYPE = 17;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.Multiplicity <em>Multiplicity</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.Multiplicity
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getMultiplicity()
   * @generated
   */
  int MULTIPLICITY = 18;

  /**
   * The meta object id for the '{@link de.wwu.pi.mdsd05.group05DSL.Inscription <em>Inscription</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see de.wwu.pi.mdsd05.group05DSL.Inscription
   * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getInscription()
   * @generated
   */
  int INSCRIPTION = 19;


  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd05.group05DSL.Model <em>Model</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Model</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Model
   * @generated
   */
  EClass getModel();

  /**
   * Returns the meta object for the containment reference '{@link de.wwu.pi.mdsd05.group05DSL.Model#getPackage <em>Package</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Package</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Model#getPackage()
   * @see #getModel()
   * @generated
   */
  EReference getModel_Package();

  /**
   * Returns the meta object for the containment reference list '{@link de.wwu.pi.mdsd05.group05DSL.Model#getEntitytypes <em>Entitytypes</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Entitytypes</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Model#getEntitytypes()
   * @see #getModel()
   * @generated
   */
  EReference getModel_Entitytypes();

  /**
   * Returns the meta object for the containment reference list '{@link de.wwu.pi.mdsd05.group05DSL.Model#getUiwindows <em>Uiwindows</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Uiwindows</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Model#getUiwindows()
   * @see #getModel()
   * @generated
   */
  EReference getModel_Uiwindows();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd05.group05DSL.Package <em>Package</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Package</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Package
   * @generated
   */
  EClass getPackage();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd05.group05DSL.Package#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Package#getName()
   * @see #getPackage()
   * @generated
   */
  EAttribute getPackage_Name();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd05.group05DSL.Entitytype <em>Entitytype</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Entitytype</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Entitytype
   * @generated
   */
  EClass getEntitytype();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd05.group05DSL.Entitytype#getAbstract <em>Abstract</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Abstract</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Entitytype#getAbstract()
   * @see #getEntitytype()
   * @generated
   */
  EAttribute getEntitytype_Abstract();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd05.group05DSL.Entitytype#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Entitytype#getName()
   * @see #getEntitytype()
   * @generated
   */
  EAttribute getEntitytype_Name();

  /**
   * Returns the meta object for the reference '{@link de.wwu.pi.mdsd05.group05DSL.Entitytype#getSupertype <em>Supertype</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Supertype</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Entitytype#getSupertype()
   * @see #getEntitytype()
   * @generated
   */
  EReference getEntitytype_Supertype();

  /**
   * Returns the meta object for the containment reference list '{@link de.wwu.pi.mdsd05.group05DSL.Entitytype#getProperties <em>Properties</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Properties</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Entitytype#getProperties()
   * @see #getEntitytype()
   * @generated
   */
  EReference getEntitytype_Properties();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd05.group05DSL.Property <em>Property</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Property</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Property
   * @generated
   */
  EClass getProperty();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd05.group05DSL.Property#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Property#getName()
   * @see #getProperty()
   * @generated
   */
  EAttribute getProperty_Name();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd05.group05DSL.Attribute <em>Attribute</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Attribute</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Attribute
   * @generated
   */
  EClass getAttribute();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd05.group05DSL.Attribute#getType <em>Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Type</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Attribute#getType()
   * @see #getAttribute()
   * @generated
   */
  EAttribute getAttribute_Type();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd05.group05DSL.Attribute#getOptional <em>Optional</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Optional</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Attribute#getOptional()
   * @see #getAttribute()
   * @generated
   */
  EAttribute getAttribute_Optional();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd05.group05DSL.Reference <em>Reference</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Reference</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Reference
   * @generated
   */
  EClass getReference();

  /**
   * Returns the meta object for the reference '{@link de.wwu.pi.mdsd05.group05DSL.Reference#getReferences <em>References</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>References</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Reference#getReferences()
   * @see #getReference()
   * @generated
   */
  EReference getReference_References();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd05.group05DSL.Reference#getMultiplicity <em>Multiplicity</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Multiplicity</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Reference#getMultiplicity()
   * @see #getReference()
   * @generated
   */
  EAttribute getReference_Multiplicity();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd05.group05DSL.UIWindow <em>UI Window</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>UI Window</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.UIWindow
   * @generated
   */
  EClass getUIWindow();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd05.group05DSL.UIWindow#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.UIWindow#getName()
   * @see #getUIWindow()
   * @generated
   */
  EAttribute getUIWindow_Name();

  /**
   * Returns the meta object for the reference '{@link de.wwu.pi.mdsd05.group05DSL.UIWindow#getEntitytype <em>Entitytype</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Entitytype</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.UIWindow#getEntitytype()
   * @see #getUIWindow()
   * @generated
   */
  EReference getUIWindow_Entitytype();

  /**
   * Returns the meta object for the containment reference '{@link de.wwu.pi.mdsd05.group05DSL.UIWindow#getOptions <em>Options</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Options</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.UIWindow#getOptions()
   * @see #getUIWindow()
   * @generated
   */
  EReference getUIWindow_Options();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd05.group05DSL.ListWindow <em>List Window</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>List Window</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.ListWindow
   * @generated
   */
  EClass getListWindow();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd05.group05DSL.EntryWindow <em>Entry Window</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Entry Window</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.EntryWindow
   * @generated
   */
  EClass getEntryWindow();

  /**
   * Returns the meta object for the containment reference list '{@link de.wwu.pi.mdsd05.group05DSL.EntryWindow#getElements <em>Elements</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Elements</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.EntryWindow#getElements()
   * @see #getEntryWindow()
   * @generated
   */
  EReference getEntryWindow_Elements();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd05.group05DSL.UIElement <em>UI Element</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>UI Element</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.UIElement
   * @generated
   */
  EClass getUIElement();

  /**
   * Returns the meta object for the containment reference '{@link de.wwu.pi.mdsd05.group05DSL.UIElement#getUiOptions <em>Ui Options</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Ui Options</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.UIElement#getUiOptions()
   * @see #getUIElement()
   * @generated
   */
  EReference getUIElement_UiOptions();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd05.group05DSL.UIOptions <em>UI Options</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>UI Options</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.UIOptions
   * @generated
   */
  EClass getUIOptions();

  /**
   * Returns the meta object for the containment reference '{@link de.wwu.pi.mdsd05.group05DSL.UIOptions#getPosition <em>Position</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Position</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.UIOptions#getPosition()
   * @see #getUIOptions()
   * @generated
   */
  EReference getUIOptions_Position();

  /**
   * Returns the meta object for the containment reference '{@link de.wwu.pi.mdsd05.group05DSL.UIOptions#getSize <em>Size</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Size</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.UIOptions#getSize()
   * @see #getUIOptions()
   * @generated
   */
  EReference getUIOptions_Size();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd05.group05DSL.Label <em>Label</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Label</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Label
   * @generated
   */
  EClass getLabel();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd05.group05DSL.Label#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Label#getName()
   * @see #getLabel()
   * @generated
   */
  EAttribute getLabel_Name();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd05.group05DSL.Label#getText <em>Text</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Text</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Label#getText()
   * @see #getLabel()
   * @generated
   */
  EAttribute getLabel_Text();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd05.group05DSL.Field <em>Field</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Field</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Field
   * @generated
   */
  EClass getField();

  /**
   * Returns the meta object for the reference '{@link de.wwu.pi.mdsd05.group05DSL.Field#getProperty <em>Property</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Property</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Field#getProperty()
   * @see #getField()
   * @generated
   */
  EReference getField_Property();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd05.group05DSL.Button <em>Button</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Button</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Button
   * @generated
   */
  EClass getButton();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd05.group05DSL.Button#getInscription <em>Inscription</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Inscription</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Button#getInscription()
   * @see #getButton()
   * @generated
   */
  EAttribute getButton_Inscription();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd05.group05DSL.Size <em>Size</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Size</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Size
   * @generated
   */
  EClass getSize();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd05.group05DSL.Size#getWidth <em>Width</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Width</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Size#getWidth()
   * @see #getSize()
   * @generated
   */
  EAttribute getSize_Width();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd05.group05DSL.Size#getHeight <em>Height</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Height</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Size#getHeight()
   * @see #getSize()
   * @generated
   */
  EAttribute getSize_Height();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd05.group05DSL.Position <em>Position</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Position</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Position
   * @generated
   */
  EClass getPosition();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd05.group05DSL.Position#getX <em>X</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>X</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Position#getX()
   * @see #getPosition()
   * @generated
   */
  EAttribute getPosition_X();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd05.group05DSL.Position#getY <em>Y</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Y</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Position#getY()
   * @see #getPosition()
   * @generated
   */
  EAttribute getPosition_Y();

  /**
   * Returns the meta object for class '{@link de.wwu.pi.mdsd05.group05DSL.WindowOptions <em>Window Options</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Window Options</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.WindowOptions
   * @generated
   */
  EClass getWindowOptions();

  /**
   * Returns the meta object for the containment reference '{@link de.wwu.pi.mdsd05.group05DSL.WindowOptions#getSize <em>Size</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Size</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.WindowOptions#getSize()
   * @see #getWindowOptions()
   * @generated
   */
  EReference getWindowOptions_Size();

  /**
   * Returns the meta object for the attribute '{@link de.wwu.pi.mdsd05.group05DSL.WindowOptions#getTitle <em>Title</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Title</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.WindowOptions#getTitle()
   * @see #getWindowOptions()
   * @generated
   */
  EAttribute getWindowOptions_Title();

  /**
   * Returns the meta object for enum '{@link de.wwu.pi.mdsd05.group05DSL.BasicType <em>Basic Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Basic Type</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.BasicType
   * @generated
   */
  EEnum getBasicType();

  /**
   * Returns the meta object for enum '{@link de.wwu.pi.mdsd05.group05DSL.Multiplicity <em>Multiplicity</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Multiplicity</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Multiplicity
   * @generated
   */
  EEnum getMultiplicity();

  /**
   * Returns the meta object for enum '{@link de.wwu.pi.mdsd05.group05DSL.Inscription <em>Inscription</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Inscription</em>'.
   * @see de.wwu.pi.mdsd05.group05DSL.Inscription
   * @generated
   */
  EEnum getInscription();

  /**
   * Returns the factory that creates the instances of the model.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the factory that creates the instances of the model.
   * @generated
   */
  Group05DSLFactory getGroup05DSLFactory();

  /**
   * <!-- begin-user-doc -->
   * Defines literals for the meta objects that represent
   * <ul>
   *   <li>each class,</li>
   *   <li>each feature of each class,</li>
   *   <li>each enum,</li>
   *   <li>and each data type</li>
   * </ul>
   * <!-- end-user-doc -->
   * @generated
   */
  interface Literals
  {
    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.ModelImpl <em>Model</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.impl.ModelImpl
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getModel()
     * @generated
     */
    EClass MODEL = eINSTANCE.getModel();

    /**
     * The meta object literal for the '<em><b>Package</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference MODEL__PACKAGE = eINSTANCE.getModel_Package();

    /**
     * The meta object literal for the '<em><b>Entitytypes</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference MODEL__ENTITYTYPES = eINSTANCE.getModel_Entitytypes();

    /**
     * The meta object literal for the '<em><b>Uiwindows</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference MODEL__UIWINDOWS = eINSTANCE.getModel_Uiwindows();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.PackageImpl <em>Package</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.impl.PackageImpl
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getPackage()
     * @generated
     */
    EClass PACKAGE = eINSTANCE.getPackage();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute PACKAGE__NAME = eINSTANCE.getPackage_Name();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.EntitytypeImpl <em>Entitytype</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.impl.EntitytypeImpl
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getEntitytype()
     * @generated
     */
    EClass ENTITYTYPE = eINSTANCE.getEntitytype();

    /**
     * The meta object literal for the '<em><b>Abstract</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ENTITYTYPE__ABSTRACT = eINSTANCE.getEntitytype_Abstract();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ENTITYTYPE__NAME = eINSTANCE.getEntitytype_Name();

    /**
     * The meta object literal for the '<em><b>Supertype</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference ENTITYTYPE__SUPERTYPE = eINSTANCE.getEntitytype_Supertype();

    /**
     * The meta object literal for the '<em><b>Properties</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference ENTITYTYPE__PROPERTIES = eINSTANCE.getEntitytype_Properties();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.PropertyImpl <em>Property</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.impl.PropertyImpl
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getProperty()
     * @generated
     */
    EClass PROPERTY = eINSTANCE.getProperty();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute PROPERTY__NAME = eINSTANCE.getProperty_Name();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.AttributeImpl <em>Attribute</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.impl.AttributeImpl
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getAttribute()
     * @generated
     */
    EClass ATTRIBUTE = eINSTANCE.getAttribute();

    /**
     * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ATTRIBUTE__TYPE = eINSTANCE.getAttribute_Type();

    /**
     * The meta object literal for the '<em><b>Optional</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ATTRIBUTE__OPTIONAL = eINSTANCE.getAttribute_Optional();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.ReferenceImpl <em>Reference</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.impl.ReferenceImpl
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getReference()
     * @generated
     */
    EClass REFERENCE = eINSTANCE.getReference();

    /**
     * The meta object literal for the '<em><b>References</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference REFERENCE__REFERENCES = eINSTANCE.getReference_References();

    /**
     * The meta object literal for the '<em><b>Multiplicity</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute REFERENCE__MULTIPLICITY = eINSTANCE.getReference_Multiplicity();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.UIWindowImpl <em>UI Window</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.impl.UIWindowImpl
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getUIWindow()
     * @generated
     */
    EClass UI_WINDOW = eINSTANCE.getUIWindow();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute UI_WINDOW__NAME = eINSTANCE.getUIWindow_Name();

    /**
     * The meta object literal for the '<em><b>Entitytype</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference UI_WINDOW__ENTITYTYPE = eINSTANCE.getUIWindow_Entitytype();

    /**
     * The meta object literal for the '<em><b>Options</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference UI_WINDOW__OPTIONS = eINSTANCE.getUIWindow_Options();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.ListWindowImpl <em>List Window</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.impl.ListWindowImpl
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getListWindow()
     * @generated
     */
    EClass LIST_WINDOW = eINSTANCE.getListWindow();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.EntryWindowImpl <em>Entry Window</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.impl.EntryWindowImpl
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getEntryWindow()
     * @generated
     */
    EClass ENTRY_WINDOW = eINSTANCE.getEntryWindow();

    /**
     * The meta object literal for the '<em><b>Elements</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference ENTRY_WINDOW__ELEMENTS = eINSTANCE.getEntryWindow_Elements();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.UIElementImpl <em>UI Element</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.impl.UIElementImpl
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getUIElement()
     * @generated
     */
    EClass UI_ELEMENT = eINSTANCE.getUIElement();

    /**
     * The meta object literal for the '<em><b>Ui Options</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference UI_ELEMENT__UI_OPTIONS = eINSTANCE.getUIElement_UiOptions();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.UIOptionsImpl <em>UI Options</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.impl.UIOptionsImpl
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getUIOptions()
     * @generated
     */
    EClass UI_OPTIONS = eINSTANCE.getUIOptions();

    /**
     * The meta object literal for the '<em><b>Position</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference UI_OPTIONS__POSITION = eINSTANCE.getUIOptions_Position();

    /**
     * The meta object literal for the '<em><b>Size</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference UI_OPTIONS__SIZE = eINSTANCE.getUIOptions_Size();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.LabelImpl <em>Label</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.impl.LabelImpl
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getLabel()
     * @generated
     */
    EClass LABEL = eINSTANCE.getLabel();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute LABEL__NAME = eINSTANCE.getLabel_Name();

    /**
     * The meta object literal for the '<em><b>Text</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute LABEL__TEXT = eINSTANCE.getLabel_Text();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.FieldImpl <em>Field</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.impl.FieldImpl
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getField()
     * @generated
     */
    EClass FIELD = eINSTANCE.getField();

    /**
     * The meta object literal for the '<em><b>Property</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference FIELD__PROPERTY = eINSTANCE.getField_Property();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.ButtonImpl <em>Button</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.impl.ButtonImpl
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getButton()
     * @generated
     */
    EClass BUTTON = eINSTANCE.getButton();

    /**
     * The meta object literal for the '<em><b>Inscription</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute BUTTON__INSCRIPTION = eINSTANCE.getButton_Inscription();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.SizeImpl <em>Size</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.impl.SizeImpl
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getSize()
     * @generated
     */
    EClass SIZE = eINSTANCE.getSize();

    /**
     * The meta object literal for the '<em><b>Width</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SIZE__WIDTH = eINSTANCE.getSize_Width();

    /**
     * The meta object literal for the '<em><b>Height</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SIZE__HEIGHT = eINSTANCE.getSize_Height();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.PositionImpl <em>Position</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.impl.PositionImpl
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getPosition()
     * @generated
     */
    EClass POSITION = eINSTANCE.getPosition();

    /**
     * The meta object literal for the '<em><b>X</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute POSITION__X = eINSTANCE.getPosition_X();

    /**
     * The meta object literal for the '<em><b>Y</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute POSITION__Y = eINSTANCE.getPosition_Y();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.impl.WindowOptionsImpl <em>Window Options</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.impl.WindowOptionsImpl
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getWindowOptions()
     * @generated
     */
    EClass WINDOW_OPTIONS = eINSTANCE.getWindowOptions();

    /**
     * The meta object literal for the '<em><b>Size</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference WINDOW_OPTIONS__SIZE = eINSTANCE.getWindowOptions_Size();

    /**
     * The meta object literal for the '<em><b>Title</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute WINDOW_OPTIONS__TITLE = eINSTANCE.getWindowOptions_Title();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.BasicType <em>Basic Type</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.BasicType
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getBasicType()
     * @generated
     */
    EEnum BASIC_TYPE = eINSTANCE.getBasicType();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.Multiplicity <em>Multiplicity</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.Multiplicity
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getMultiplicity()
     * @generated
     */
    EEnum MULTIPLICITY = eINSTANCE.getMultiplicity();

    /**
     * The meta object literal for the '{@link de.wwu.pi.mdsd05.group05DSL.Inscription <em>Inscription</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see de.wwu.pi.mdsd05.group05DSL.Inscription
     * @see de.wwu.pi.mdsd05.group05DSL.impl.Group05DSLPackageImpl#getInscription()
     * @generated
     */
    EEnum INSCRIPTION = eINSTANCE.getInscription();

  }

} //Group05DSLPackage
