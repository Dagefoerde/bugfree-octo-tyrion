/**
 */
package de.wwu.pi.mdsd05.group05DSL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.Attribute#getType <em>Type</em>}</li>
 *   <li>{@link de.wwu.pi.mdsd05.group05DSL.Attribute#getOptional <em>Optional</em>}</li>
 * </ul>
 * </p>
 *
 * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getAttribute()
 * @model
 * @generated
 */
public interface Attribute extends Property
{
  /**
   * Returns the value of the '<em><b>Type</b></em>' attribute.
   * The literals are from the enumeration {@link de.wwu.pi.mdsd05.group05DSL.BasicType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Type</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Type</em>' attribute.
   * @see de.wwu.pi.mdsd05.group05DSL.BasicType
   * @see #setType(BasicType)
   * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getAttribute_Type()
   * @model
   * @generated
   */
  BasicType getType();

  /**
   * Sets the value of the '{@link de.wwu.pi.mdsd05.group05DSL.Attribute#getType <em>Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Type</em>' attribute.
   * @see de.wwu.pi.mdsd05.group05DSL.BasicType
   * @see #getType()
   * @generated
   */
  void setType(BasicType value);

  /**
   * Returns the value of the '<em><b>Optional</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Optional</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Optional</em>' attribute.
   * @see #setOptional(String)
   * @see de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage#getAttribute_Optional()
   * @model
   * @generated
   */
  String getOptional();

  /**
   * Sets the value of the '{@link de.wwu.pi.mdsd05.group05DSL.Attribute#getOptional <em>Optional</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Optional</em>' attribute.
   * @see #getOptional()
   * @generated
   */
  void setOptional(String value);

} // Attribute
