package de.wwu.pi.mdsd05.serializer;

import com.google.inject.Inject;
import com.google.inject.Provider;
import de.wwu.pi.mdsd05.group05DSL.Attribute;
import de.wwu.pi.mdsd05.group05DSL.Button;
import de.wwu.pi.mdsd05.group05DSL.Entitytype;
import de.wwu.pi.mdsd05.group05DSL.EntryWindow;
import de.wwu.pi.mdsd05.group05DSL.Field;
import de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage;
import de.wwu.pi.mdsd05.group05DSL.Label;
import de.wwu.pi.mdsd05.group05DSL.ListWindow;
import de.wwu.pi.mdsd05.group05DSL.Model;
import de.wwu.pi.mdsd05.group05DSL.Position;
import de.wwu.pi.mdsd05.group05DSL.Reference;
import de.wwu.pi.mdsd05.group05DSL.Size;
import de.wwu.pi.mdsd05.group05DSL.UIOptions;
import de.wwu.pi.mdsd05.group05DSL.WindowOptions;
import de.wwu.pi.mdsd05.services.Group05DSLGrammarAccess;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.serializer.acceptor.ISemanticSequenceAcceptor;
import org.eclipse.xtext.serializer.acceptor.SequenceFeeder;
import org.eclipse.xtext.serializer.diagnostic.ISemanticSequencerDiagnosticProvider;
import org.eclipse.xtext.serializer.diagnostic.ISerializationDiagnostic.Acceptor;
import org.eclipse.xtext.serializer.sequencer.AbstractDelegatingSemanticSequencer;
import org.eclipse.xtext.serializer.sequencer.GenericSequencer;
import org.eclipse.xtext.serializer.sequencer.ISemanticNodeProvider.INodesForEObjectProvider;
import org.eclipse.xtext.serializer.sequencer.ISemanticSequencer;
import org.eclipse.xtext.serializer.sequencer.ITransientValueService;
import org.eclipse.xtext.serializer.sequencer.ITransientValueService.ValueTransient;

@SuppressWarnings("all")
public class Group05DSLSemanticSequencer extends AbstractDelegatingSemanticSequencer {

	@Inject
	private Group05DSLGrammarAccess grammarAccess;
	
	public void createSequence(EObject context, EObject semanticObject) {
		if(semanticObject.eClass().getEPackage() == Group05DSLPackage.eINSTANCE) switch(semanticObject.eClass().getClassifierID()) {
			case Group05DSLPackage.ATTRIBUTE:
				if(context == grammarAccess.getAttributeRule() ||
				   context == grammarAccess.getPropertyRule()) {
					sequence_Attribute(context, (Attribute) semanticObject); 
					return; 
				}
				else break;
			case Group05DSLPackage.BUTTON:
				if(context == grammarAccess.getButtonRule()) {
					sequence_Button(context, (Button) semanticObject); 
					return; 
				}
				else if(context == grammarAccess.getUIElementRule()) {
					sequence_Button_UIElement(context, (Button) semanticObject); 
					return; 
				}
				else break;
			case Group05DSLPackage.ENTITYTYPE:
				if(context == grammarAccess.getEntitytypeRule()) {
					sequence_Entitytype(context, (Entitytype) semanticObject); 
					return; 
				}
				else break;
			case Group05DSLPackage.ENTRY_WINDOW:
				if(context == grammarAccess.getEntryWindowRule() ||
				   context == grammarAccess.getUIWindowRule()) {
					sequence_EntryWindow(context, (EntryWindow) semanticObject); 
					return; 
				}
				else break;
			case Group05DSLPackage.FIELD:
				if(context == grammarAccess.getFieldRule()) {
					sequence_Field(context, (Field) semanticObject); 
					return; 
				}
				else if(context == grammarAccess.getUIElementRule()) {
					sequence_Field_UIElement(context, (Field) semanticObject); 
					return; 
				}
				else break;
			case Group05DSLPackage.LABEL:
				if(context == grammarAccess.getLabelRule()) {
					sequence_Label(context, (Label) semanticObject); 
					return; 
				}
				else if(context == grammarAccess.getUIElementRule()) {
					sequence_Label_UIElement(context, (Label) semanticObject); 
					return; 
				}
				else break;
			case Group05DSLPackage.LIST_WINDOW:
				if(context == grammarAccess.getListWindowRule() ||
				   context == grammarAccess.getUIWindowRule()) {
					sequence_ListWindow(context, (ListWindow) semanticObject); 
					return; 
				}
				else break;
			case Group05DSLPackage.MODEL:
				if(context == grammarAccess.getModelRule()) {
					sequence_Model(context, (Model) semanticObject); 
					return; 
				}
				else break;
			case Group05DSLPackage.PACKAGE:
				if(context == grammarAccess.getPackageRule()) {
					sequence_Package(context, (de.wwu.pi.mdsd05.group05DSL.Package) semanticObject); 
					return; 
				}
				else break;
			case Group05DSLPackage.POSITION:
				if(context == grammarAccess.getPositionRule()) {
					sequence_Position(context, (Position) semanticObject); 
					return; 
				}
				else break;
			case Group05DSLPackage.REFERENCE:
				if(context == grammarAccess.getPropertyRule() ||
				   context == grammarAccess.getReferenceRule()) {
					sequence_Reference(context, (Reference) semanticObject); 
					return; 
				}
				else break;
			case Group05DSLPackage.SIZE:
				if(context == grammarAccess.getSizeRule()) {
					sequence_Size(context, (Size) semanticObject); 
					return; 
				}
				else break;
			case Group05DSLPackage.UI_OPTIONS:
				if(context == grammarAccess.getUIOptionsRule()) {
					sequence_UIOptions(context, (UIOptions) semanticObject); 
					return; 
				}
				else break;
			case Group05DSLPackage.WINDOW_OPTIONS:
				if(context == grammarAccess.getWindowOptionsRule()) {
					sequence_WindowOptions(context, (WindowOptions) semanticObject); 
					return; 
				}
				else break;
			}
		if (errorAcceptor != null) errorAcceptor.accept(diagnosticProvider.createInvalidContextOrTypeDiagnostic(semanticObject, context));
	}
	
	/**
	 * Constraint:
	 *     (type=BasicType name=ID optional='optional'?)
	 */
	protected void sequence_Attribute(EObject context, Attribute semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     inscription=Inscription
	 */
	protected void sequence_Button(EObject context, Button semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (inscription=Inscription uiOptions=UIOptions)
	 */
	protected void sequence_Button_UIElement(EObject context, Button semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, Group05DSLPackage.Literals.UI_ELEMENT__UI_OPTIONS) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, Group05DSLPackage.Literals.UI_ELEMENT__UI_OPTIONS));
			if(transientValues.isValueTransient(semanticObject, Group05DSLPackage.Literals.BUTTON__INSCRIPTION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, Group05DSLPackage.Literals.BUTTON__INSCRIPTION));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getButtonAccess().getInscriptionInscriptionEnumRuleCall_1_0(), semanticObject.getInscription());
		feeder.accept(grammarAccess.getUIElementAccess().getUiOptionsUIOptionsParserRuleCall_1_0(), semanticObject.getUiOptions());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (abstract='abstract'? name=ID supertype=[Entitytype|ID]? properties+=Property+)
	 */
	protected void sequence_Entitytype(EObject context, Entitytype semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID entitytype=[Entitytype|ID] options=WindowOptions elements+=UIElement+)
	 */
	protected void sequence_EntryWindow(EObject context, EntryWindow semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     property=[Property|ID]
	 */
	protected void sequence_Field(EObject context, Field semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (property=[Property|ID] uiOptions=UIOptions)
	 */
	protected void sequence_Field_UIElement(EObject context, Field semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, Group05DSLPackage.Literals.UI_ELEMENT__UI_OPTIONS) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, Group05DSLPackage.Literals.UI_ELEMENT__UI_OPTIONS));
			if(transientValues.isValueTransient(semanticObject, Group05DSLPackage.Literals.FIELD__PROPERTY) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, Group05DSLPackage.Literals.FIELD__PROPERTY));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getFieldAccess().getPropertyPropertyIDTerminalRuleCall_1_0_1(), semanticObject.getProperty());
		feeder.accept(grammarAccess.getUIElementAccess().getUiOptionsUIOptionsParserRuleCall_1_0(), semanticObject.getUiOptions());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID text=STRING?)
	 */
	protected void sequence_Label(EObject context, Label semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID text=STRING? uiOptions=UIOptions)
	 */
	protected void sequence_Label_UIElement(EObject context, Label semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID entitytype=[Entitytype|ID] options=WindowOptions)
	 */
	protected void sequence_ListWindow(EObject context, ListWindow semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, Group05DSLPackage.Literals.UI_WINDOW__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, Group05DSLPackage.Literals.UI_WINDOW__NAME));
			if(transientValues.isValueTransient(semanticObject, Group05DSLPackage.Literals.UI_WINDOW__ENTITYTYPE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, Group05DSLPackage.Literals.UI_WINDOW__ENTITYTYPE));
			if(transientValues.isValueTransient(semanticObject, Group05DSLPackage.Literals.UI_WINDOW__OPTIONS) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, Group05DSLPackage.Literals.UI_WINDOW__OPTIONS));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getListWindowAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.accept(grammarAccess.getListWindowAccess().getEntitytypeEntitytypeIDTerminalRuleCall_3_0_1(), semanticObject.getEntitytype());
		feeder.accept(grammarAccess.getListWindowAccess().getOptionsWindowOptionsParserRuleCall_5_0(), semanticObject.getOptions());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (package=Package (entitytypes+=Entitytype | uiwindows+=UIWindow)*)
	 */
	protected void sequence_Model(EObject context, Model semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     name=QualifiedName
	 */
	protected void sequence_Package(EObject context, de.wwu.pi.mdsd05.group05DSL.Package semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, Group05DSLPackage.Literals.PACKAGE__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, Group05DSLPackage.Literals.PACKAGE__NAME));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getPackageAccess().getNameQualifiedNameParserRuleCall_1_0(), semanticObject.getName());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (x=INT y=INT)
	 */
	protected void sequence_Position(EObject context, Position semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (references=[Entitytype|ID] name=ID multiplicity=Multiplicity?)
	 */
	protected void sequence_Reference(EObject context, Reference semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (width=INT height=INT)
	 */
	protected void sequence_Size(EObject context, Size semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (position=Position size=Size)
	 */
	protected void sequence_UIOptions(EObject context, UIOptions semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (size=Size title=STRING?)
	 */
	protected void sequence_WindowOptions(EObject context, WindowOptions semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
}
