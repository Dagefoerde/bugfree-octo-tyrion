package de.wwu.pi.mdsd05.parser.antlr.internal; 

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import de.wwu.pi.mdsd05.services.Group05DSLGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalGroup05DSLParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Package'", "'.'", "'abstract'", "'Entitytype'", "'extends'", "'{'", "'}'", "'Attribute'", "'optional'", "'Reference'", "'ListWindow'", "'for'", "'EntryWindow'", "'Label'", "'Field'", "'Button'", "'width'", "'height'", "'x_value'", "'y_value'", "'title'", "'String'", "'Integer'", "'Date'", "'one'", "'multiple'", "'Create/Edit'", "'Delete'", "'Cancel'"
    };
    public static final int RULE_ID=4;
    public static final int T__29=29;
    public static final int T__28=28;
    public static final int T__27=27;
    public static final int T__26=26;
    public static final int T__25=25;
    public static final int T__24=24;
    public static final int T__23=23;
    public static final int T__22=22;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__21=21;
    public static final int T__20=20;
    public static final int RULE_SL_COMMENT=8;
    public static final int EOF=-1;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__30=30;
    public static final int T__19=19;
    public static final int T__31=31;
    public static final int RULE_STRING=5;
    public static final int T__32=32;
    public static final int T__33=33;
    public static final int T__16=16;
    public static final int T__34=34;
    public static final int T__15=15;
    public static final int T__35=35;
    public static final int T__18=18;
    public static final int T__36=36;
    public static final int T__17=17;
    public static final int T__37=37;
    public static final int T__12=12;
    public static final int T__38=38;
    public static final int T__11=11;
    public static final int T__39=39;
    public static final int T__14=14;
    public static final int T__13=13;
    public static final int RULE_INT=6;
    public static final int RULE_WS=9;

    // delegates
    // delegators


        public InternalGroup05DSLParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalGroup05DSLParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalGroup05DSLParser.tokenNames; }
    public String getGrammarFileName() { return "../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g"; }



     	private Group05DSLGrammarAccess grammarAccess;
     	
        public InternalGroup05DSLParser(TokenStream input, Group05DSLGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }
        
        @Override
        protected String getFirstRuleName() {
        	return "Model";	
       	}
       	
       	@Override
       	protected Group05DSLGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}



    // $ANTLR start "entryRuleModel"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:68:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:69:2: (iv_ruleModel= ruleModel EOF )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:70:2: iv_ruleModel= ruleModel EOF
            {
             newCompositeNode(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_ruleModel_in_entryRuleModel75);
            iv_ruleModel=ruleModel();

            state._fsp--;

             current =iv_ruleModel; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleModel85); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:77:1: ruleModel returns [EObject current=null] : ( ( (lv_package_0_0= rulePackage ) ) ( ( (lv_entitytypes_1_0= ruleEntitytype ) ) | ( (lv_uiwindows_2_0= ruleUIWindow ) ) )* ) ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        EObject lv_package_0_0 = null;

        EObject lv_entitytypes_1_0 = null;

        EObject lv_uiwindows_2_0 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:80:28: ( ( ( (lv_package_0_0= rulePackage ) ) ( ( (lv_entitytypes_1_0= ruleEntitytype ) ) | ( (lv_uiwindows_2_0= ruleUIWindow ) ) )* ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:81:1: ( ( (lv_package_0_0= rulePackage ) ) ( ( (lv_entitytypes_1_0= ruleEntitytype ) ) | ( (lv_uiwindows_2_0= ruleUIWindow ) ) )* )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:81:1: ( ( (lv_package_0_0= rulePackage ) ) ( ( (lv_entitytypes_1_0= ruleEntitytype ) ) | ( (lv_uiwindows_2_0= ruleUIWindow ) ) )* )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:81:2: ( (lv_package_0_0= rulePackage ) ) ( ( (lv_entitytypes_1_0= ruleEntitytype ) ) | ( (lv_uiwindows_2_0= ruleUIWindow ) ) )*
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:81:2: ( (lv_package_0_0= rulePackage ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:82:1: (lv_package_0_0= rulePackage )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:82:1: (lv_package_0_0= rulePackage )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:83:3: lv_package_0_0= rulePackage
            {
             
            	        newCompositeNode(grammarAccess.getModelAccess().getPackagePackageParserRuleCall_0_0()); 
            	    
            pushFollow(FOLLOW_rulePackage_in_ruleModel131);
            lv_package_0_0=rulePackage();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getModelRule());
            	        }
                   		set(
                   			current, 
                   			"package",
                    		lv_package_0_0, 
                    		"Package");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:99:2: ( ( (lv_entitytypes_1_0= ruleEntitytype ) ) | ( (lv_uiwindows_2_0= ruleUIWindow ) ) )*
            loop1:
            do {
                int alt1=3;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=13 && LA1_0<=14)) ) {
                    alt1=1;
                }
                else if ( (LA1_0==21||LA1_0==23) ) {
                    alt1=2;
                }


                switch (alt1) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:99:3: ( (lv_entitytypes_1_0= ruleEntitytype ) )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:99:3: ( (lv_entitytypes_1_0= ruleEntitytype ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:100:1: (lv_entitytypes_1_0= ruleEntitytype )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:100:1: (lv_entitytypes_1_0= ruleEntitytype )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:101:3: lv_entitytypes_1_0= ruleEntitytype
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getModelAccess().getEntitytypesEntitytypeParserRuleCall_1_0_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleEntitytype_in_ruleModel153);
            	    lv_entitytypes_1_0=ruleEntitytype();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getModelRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"entitytypes",
            	            		lv_entitytypes_1_0, 
            	            		"Entitytype");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }
            	    break;
            	case 2 :
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:118:6: ( (lv_uiwindows_2_0= ruleUIWindow ) )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:118:6: ( (lv_uiwindows_2_0= ruleUIWindow ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:119:1: (lv_uiwindows_2_0= ruleUIWindow )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:119:1: (lv_uiwindows_2_0= ruleUIWindow )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:120:3: lv_uiwindows_2_0= ruleUIWindow
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getModelAccess().getUiwindowsUIWindowParserRuleCall_1_1_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleUIWindow_in_ruleModel180);
            	    lv_uiwindows_2_0=ruleUIWindow();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getModelRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"uiwindows",
            	            		lv_uiwindows_2_0, 
            	            		"UIWindow");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRulePackage"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:144:1: entryRulePackage returns [EObject current=null] : iv_rulePackage= rulePackage EOF ;
    public final EObject entryRulePackage() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePackage = null;


        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:145:2: (iv_rulePackage= rulePackage EOF )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:146:2: iv_rulePackage= rulePackage EOF
            {
             newCompositeNode(grammarAccess.getPackageRule()); 
            pushFollow(FOLLOW_rulePackage_in_entryRulePackage218);
            iv_rulePackage=rulePackage();

            state._fsp--;

             current =iv_rulePackage; 
            match(input,EOF,FOLLOW_EOF_in_entryRulePackage228); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePackage"


    // $ANTLR start "rulePackage"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:153:1: rulePackage returns [EObject current=null] : (otherlv_0= 'Package' ( (lv_name_1_0= ruleQualifiedName ) ) ) ;
    public final EObject rulePackage() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:156:28: ( (otherlv_0= 'Package' ( (lv_name_1_0= ruleQualifiedName ) ) ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:157:1: (otherlv_0= 'Package' ( (lv_name_1_0= ruleQualifiedName ) ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:157:1: (otherlv_0= 'Package' ( (lv_name_1_0= ruleQualifiedName ) ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:157:3: otherlv_0= 'Package' ( (lv_name_1_0= ruleQualifiedName ) )
            {
            otherlv_0=(Token)match(input,11,FOLLOW_11_in_rulePackage265); 

                	newLeafNode(otherlv_0, grammarAccess.getPackageAccess().getPackageKeyword_0());
                
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:161:1: ( (lv_name_1_0= ruleQualifiedName ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:162:1: (lv_name_1_0= ruleQualifiedName )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:162:1: (lv_name_1_0= ruleQualifiedName )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:163:3: lv_name_1_0= ruleQualifiedName
            {
             
            	        newCompositeNode(grammarAccess.getPackageAccess().getNameQualifiedNameParserRuleCall_1_0()); 
            	    
            pushFollow(FOLLOW_ruleQualifiedName_in_rulePackage286);
            lv_name_1_0=ruleQualifiedName();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getPackageRule());
            	        }
                   		set(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"QualifiedName");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePackage"


    // $ANTLR start "entryRuleQualifiedName"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:187:1: entryRuleQualifiedName returns [String current=null] : iv_ruleQualifiedName= ruleQualifiedName EOF ;
    public final String entryRuleQualifiedName() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleQualifiedName = null;


        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:188:2: (iv_ruleQualifiedName= ruleQualifiedName EOF )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:189:2: iv_ruleQualifiedName= ruleQualifiedName EOF
            {
             newCompositeNode(grammarAccess.getQualifiedNameRule()); 
            pushFollow(FOLLOW_ruleQualifiedName_in_entryRuleQualifiedName323);
            iv_ruleQualifiedName=ruleQualifiedName();

            state._fsp--;

             current =iv_ruleQualifiedName.getText(); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleQualifiedName334); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleQualifiedName"


    // $ANTLR start "ruleQualifiedName"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:196:1: ruleQualifiedName returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* ) ;
    public final AntlrDatatypeRuleToken ruleQualifiedName() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_ID_0=null;
        Token kw=null;
        Token this_ID_2=null;

         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:199:28: ( (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:200:1: (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:200:1: (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:200:6: this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )*
            {
            this_ID_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleQualifiedName374); 

            		current.merge(this_ID_0);
                
             
                newLeafNode(this_ID_0, grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_0()); 
                
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:207:1: (kw= '.' this_ID_2= RULE_ID )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==12) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:208:2: kw= '.' this_ID_2= RULE_ID
            	    {
            	    kw=(Token)match(input,12,FOLLOW_12_in_ruleQualifiedName393); 

            	            current.merge(kw);
            	            newLeafNode(kw, grammarAccess.getQualifiedNameAccess().getFullStopKeyword_1_0()); 
            	        
            	    this_ID_2=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleQualifiedName408); 

            	    		current.merge(this_ID_2);
            	        
            	     
            	        newLeafNode(this_ID_2, grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_1_1()); 
            	        

            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleQualifiedName"


    // $ANTLR start "entryRuleEntitytype"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:228:1: entryRuleEntitytype returns [EObject current=null] : iv_ruleEntitytype= ruleEntitytype EOF ;
    public final EObject entryRuleEntitytype() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEntitytype = null;


        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:229:2: (iv_ruleEntitytype= ruleEntitytype EOF )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:230:2: iv_ruleEntitytype= ruleEntitytype EOF
            {
             newCompositeNode(grammarAccess.getEntitytypeRule()); 
            pushFollow(FOLLOW_ruleEntitytype_in_entryRuleEntitytype455);
            iv_ruleEntitytype=ruleEntitytype();

            state._fsp--;

             current =iv_ruleEntitytype; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleEntitytype465); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEntitytype"


    // $ANTLR start "ruleEntitytype"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:237:1: ruleEntitytype returns [EObject current=null] : ( ( (lv_abstract_0_0= 'abstract' ) )? otherlv_1= 'Entitytype' ( (lv_name_2_0= RULE_ID ) ) (otherlv_3= 'extends' ( (otherlv_4= RULE_ID ) ) )? otherlv_5= '{' ( (lv_properties_6_0= ruleProperty ) )+ otherlv_7= '}' ) ;
    public final EObject ruleEntitytype() throws RecognitionException {
        EObject current = null;

        Token lv_abstract_0_0=null;
        Token otherlv_1=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        EObject lv_properties_6_0 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:240:28: ( ( ( (lv_abstract_0_0= 'abstract' ) )? otherlv_1= 'Entitytype' ( (lv_name_2_0= RULE_ID ) ) (otherlv_3= 'extends' ( (otherlv_4= RULE_ID ) ) )? otherlv_5= '{' ( (lv_properties_6_0= ruleProperty ) )+ otherlv_7= '}' ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:241:1: ( ( (lv_abstract_0_0= 'abstract' ) )? otherlv_1= 'Entitytype' ( (lv_name_2_0= RULE_ID ) ) (otherlv_3= 'extends' ( (otherlv_4= RULE_ID ) ) )? otherlv_5= '{' ( (lv_properties_6_0= ruleProperty ) )+ otherlv_7= '}' )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:241:1: ( ( (lv_abstract_0_0= 'abstract' ) )? otherlv_1= 'Entitytype' ( (lv_name_2_0= RULE_ID ) ) (otherlv_3= 'extends' ( (otherlv_4= RULE_ID ) ) )? otherlv_5= '{' ( (lv_properties_6_0= ruleProperty ) )+ otherlv_7= '}' )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:241:2: ( (lv_abstract_0_0= 'abstract' ) )? otherlv_1= 'Entitytype' ( (lv_name_2_0= RULE_ID ) ) (otherlv_3= 'extends' ( (otherlv_4= RULE_ID ) ) )? otherlv_5= '{' ( (lv_properties_6_0= ruleProperty ) )+ otherlv_7= '}'
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:241:2: ( (lv_abstract_0_0= 'abstract' ) )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==13) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:242:1: (lv_abstract_0_0= 'abstract' )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:242:1: (lv_abstract_0_0= 'abstract' )
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:243:3: lv_abstract_0_0= 'abstract'
                    {
                    lv_abstract_0_0=(Token)match(input,13,FOLLOW_13_in_ruleEntitytype508); 

                            newLeafNode(lv_abstract_0_0, grammarAccess.getEntitytypeAccess().getAbstractAbstractKeyword_0_0());
                        

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getEntitytypeRule());
                    	        }
                           		setWithLastConsumed(current, "abstract", lv_abstract_0_0, "abstract");
                    	    

                    }


                    }
                    break;

            }

            otherlv_1=(Token)match(input,14,FOLLOW_14_in_ruleEntitytype534); 

                	newLeafNode(otherlv_1, grammarAccess.getEntitytypeAccess().getEntitytypeKeyword_1());
                
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:260:1: ( (lv_name_2_0= RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:261:1: (lv_name_2_0= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:261:1: (lv_name_2_0= RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:262:3: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleEntitytype551); 

            			newLeafNode(lv_name_2_0, grammarAccess.getEntitytypeAccess().getNameIDTerminalRuleCall_2_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getEntitytypeRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_2_0, 
                    		"ID");
            	    

            }


            }

            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:278:2: (otherlv_3= 'extends' ( (otherlv_4= RULE_ID ) ) )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==15) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:278:4: otherlv_3= 'extends' ( (otherlv_4= RULE_ID ) )
                    {
                    otherlv_3=(Token)match(input,15,FOLLOW_15_in_ruleEntitytype569); 

                        	newLeafNode(otherlv_3, grammarAccess.getEntitytypeAccess().getExtendsKeyword_3_0());
                        
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:282:1: ( (otherlv_4= RULE_ID ) )
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:283:1: (otherlv_4= RULE_ID )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:283:1: (otherlv_4= RULE_ID )
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:284:3: otherlv_4= RULE_ID
                    {

                    			if (current==null) {
                    	            current = createModelElement(grammarAccess.getEntitytypeRule());
                    	        }
                            
                    otherlv_4=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleEntitytype589); 

                    		newLeafNode(otherlv_4, grammarAccess.getEntitytypeAccess().getSupertypeEntitytypeCrossReference_3_1_0()); 
                    	

                    }


                    }


                    }
                    break;

            }

            otherlv_5=(Token)match(input,16,FOLLOW_16_in_ruleEntitytype603); 

                	newLeafNode(otherlv_5, grammarAccess.getEntitytypeAccess().getLeftCurlyBracketKeyword_4());
                
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:299:1: ( (lv_properties_6_0= ruleProperty ) )+
            int cnt5=0;
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==18||LA5_0==20) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:300:1: (lv_properties_6_0= ruleProperty )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:300:1: (lv_properties_6_0= ruleProperty )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:301:3: lv_properties_6_0= ruleProperty
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getEntitytypeAccess().getPropertiesPropertyParserRuleCall_5_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleProperty_in_ruleEntitytype624);
            	    lv_properties_6_0=ruleProperty();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getEntitytypeRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"properties",
            	            		lv_properties_6_0, 
            	            		"Property");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt5 >= 1 ) break loop5;
                        EarlyExitException eee =
                            new EarlyExitException(5, input);
                        throw eee;
                }
                cnt5++;
            } while (true);

            otherlv_7=(Token)match(input,17,FOLLOW_17_in_ruleEntitytype637); 

                	newLeafNode(otherlv_7, grammarAccess.getEntitytypeAccess().getRightCurlyBracketKeyword_6());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEntitytype"


    // $ANTLR start "entryRuleProperty"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:329:1: entryRuleProperty returns [EObject current=null] : iv_ruleProperty= ruleProperty EOF ;
    public final EObject entryRuleProperty() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProperty = null;


        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:330:2: (iv_ruleProperty= ruleProperty EOF )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:331:2: iv_ruleProperty= ruleProperty EOF
            {
             newCompositeNode(grammarAccess.getPropertyRule()); 
            pushFollow(FOLLOW_ruleProperty_in_entryRuleProperty673);
            iv_ruleProperty=ruleProperty();

            state._fsp--;

             current =iv_ruleProperty; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleProperty683); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:338:1: ruleProperty returns [EObject current=null] : (this_Attribute_0= ruleAttribute | this_Reference_1= ruleReference ) ;
    public final EObject ruleProperty() throws RecognitionException {
        EObject current = null;

        EObject this_Attribute_0 = null;

        EObject this_Reference_1 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:341:28: ( (this_Attribute_0= ruleAttribute | this_Reference_1= ruleReference ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:342:1: (this_Attribute_0= ruleAttribute | this_Reference_1= ruleReference )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:342:1: (this_Attribute_0= ruleAttribute | this_Reference_1= ruleReference )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==18) ) {
                alt6=1;
            }
            else if ( (LA6_0==20) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:343:5: this_Attribute_0= ruleAttribute
                    {
                     
                            newCompositeNode(grammarAccess.getPropertyAccess().getAttributeParserRuleCall_0()); 
                        
                    pushFollow(FOLLOW_ruleAttribute_in_ruleProperty730);
                    this_Attribute_0=ruleAttribute();

                    state._fsp--;

                     
                            current = this_Attribute_0; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:353:5: this_Reference_1= ruleReference
                    {
                     
                            newCompositeNode(grammarAccess.getPropertyAccess().getReferenceParserRuleCall_1()); 
                        
                    pushFollow(FOLLOW_ruleReference_in_ruleProperty757);
                    this_Reference_1=ruleReference();

                    state._fsp--;

                     
                            current = this_Reference_1; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRuleAttribute"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:369:1: entryRuleAttribute returns [EObject current=null] : iv_ruleAttribute= ruleAttribute EOF ;
    public final EObject entryRuleAttribute() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAttribute = null;


        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:370:2: (iv_ruleAttribute= ruleAttribute EOF )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:371:2: iv_ruleAttribute= ruleAttribute EOF
            {
             newCompositeNode(grammarAccess.getAttributeRule()); 
            pushFollow(FOLLOW_ruleAttribute_in_entryRuleAttribute792);
            iv_ruleAttribute=ruleAttribute();

            state._fsp--;

             current =iv_ruleAttribute; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleAttribute802); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAttribute"


    // $ANTLR start "ruleAttribute"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:378:1: ruleAttribute returns [EObject current=null] : (otherlv_0= 'Attribute' ( (lv_type_1_0= ruleBasicType ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_optional_3_0= 'optional' ) )? ) ;
    public final EObject ruleAttribute() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_2_0=null;
        Token lv_optional_3_0=null;
        Enumerator lv_type_1_0 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:381:28: ( (otherlv_0= 'Attribute' ( (lv_type_1_0= ruleBasicType ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_optional_3_0= 'optional' ) )? ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:382:1: (otherlv_0= 'Attribute' ( (lv_type_1_0= ruleBasicType ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_optional_3_0= 'optional' ) )? )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:382:1: (otherlv_0= 'Attribute' ( (lv_type_1_0= ruleBasicType ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_optional_3_0= 'optional' ) )? )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:382:3: otherlv_0= 'Attribute' ( (lv_type_1_0= ruleBasicType ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_optional_3_0= 'optional' ) )?
            {
            otherlv_0=(Token)match(input,18,FOLLOW_18_in_ruleAttribute839); 

                	newLeafNode(otherlv_0, grammarAccess.getAttributeAccess().getAttributeKeyword_0());
                
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:386:1: ( (lv_type_1_0= ruleBasicType ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:387:1: (lv_type_1_0= ruleBasicType )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:387:1: (lv_type_1_0= ruleBasicType )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:388:3: lv_type_1_0= ruleBasicType
            {
             
            	        newCompositeNode(grammarAccess.getAttributeAccess().getTypeBasicTypeEnumRuleCall_1_0()); 
            	    
            pushFollow(FOLLOW_ruleBasicType_in_ruleAttribute860);
            lv_type_1_0=ruleBasicType();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getAttributeRule());
            	        }
                   		set(
                   			current, 
                   			"type",
                    		lv_type_1_0, 
                    		"BasicType");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:404:2: ( (lv_name_2_0= RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:405:1: (lv_name_2_0= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:405:1: (lv_name_2_0= RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:406:3: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleAttribute877); 

            			newLeafNode(lv_name_2_0, grammarAccess.getAttributeAccess().getNameIDTerminalRuleCall_2_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getAttributeRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_2_0, 
                    		"ID");
            	    

            }


            }

            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:422:2: ( (lv_optional_3_0= 'optional' ) )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==19) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:423:1: (lv_optional_3_0= 'optional' )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:423:1: (lv_optional_3_0= 'optional' )
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:424:3: lv_optional_3_0= 'optional'
                    {
                    lv_optional_3_0=(Token)match(input,19,FOLLOW_19_in_ruleAttribute900); 

                            newLeafNode(lv_optional_3_0, grammarAccess.getAttributeAccess().getOptionalOptionalKeyword_3_0());
                        

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getAttributeRule());
                    	        }
                           		setWithLastConsumed(current, "optional", lv_optional_3_0, "optional");
                    	    

                    }


                    }
                    break;

            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAttribute"


    // $ANTLR start "entryRuleReference"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:445:1: entryRuleReference returns [EObject current=null] : iv_ruleReference= ruleReference EOF ;
    public final EObject entryRuleReference() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleReference = null;


        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:446:2: (iv_ruleReference= ruleReference EOF )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:447:2: iv_ruleReference= ruleReference EOF
            {
             newCompositeNode(grammarAccess.getReferenceRule()); 
            pushFollow(FOLLOW_ruleReference_in_entryRuleReference950);
            iv_ruleReference=ruleReference();

            state._fsp--;

             current =iv_ruleReference; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleReference960); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleReference"


    // $ANTLR start "ruleReference"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:454:1: ruleReference returns [EObject current=null] : (otherlv_0= 'Reference' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_multiplicity_3_0= ruleMultiplicity ) )? ) ;
    public final EObject ruleReference() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_name_2_0=null;
        Enumerator lv_multiplicity_3_0 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:457:28: ( (otherlv_0= 'Reference' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_multiplicity_3_0= ruleMultiplicity ) )? ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:458:1: (otherlv_0= 'Reference' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_multiplicity_3_0= ruleMultiplicity ) )? )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:458:1: (otherlv_0= 'Reference' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_multiplicity_3_0= ruleMultiplicity ) )? )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:458:3: otherlv_0= 'Reference' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_multiplicity_3_0= ruleMultiplicity ) )?
            {
            otherlv_0=(Token)match(input,20,FOLLOW_20_in_ruleReference997); 

                	newLeafNode(otherlv_0, grammarAccess.getReferenceAccess().getReferenceKeyword_0());
                
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:462:1: ( (otherlv_1= RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:463:1: (otherlv_1= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:463:1: (otherlv_1= RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:464:3: otherlv_1= RULE_ID
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getReferenceRule());
            	        }
                    
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleReference1017); 

            		newLeafNode(otherlv_1, grammarAccess.getReferenceAccess().getReferencesEntitytypeCrossReference_1_0()); 
            	

            }


            }

            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:475:2: ( (lv_name_2_0= RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:476:1: (lv_name_2_0= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:476:1: (lv_name_2_0= RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:477:3: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleReference1034); 

            			newLeafNode(lv_name_2_0, grammarAccess.getReferenceAccess().getNameIDTerminalRuleCall_2_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getReferenceRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_2_0, 
                    		"ID");
            	    

            }


            }

            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:493:2: ( (lv_multiplicity_3_0= ruleMultiplicity ) )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( ((LA8_0>=35 && LA8_0<=36)) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:494:1: (lv_multiplicity_3_0= ruleMultiplicity )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:494:1: (lv_multiplicity_3_0= ruleMultiplicity )
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:495:3: lv_multiplicity_3_0= ruleMultiplicity
                    {
                     
                    	        newCompositeNode(grammarAccess.getReferenceAccess().getMultiplicityMultiplicityEnumRuleCall_3_0()); 
                    	    
                    pushFollow(FOLLOW_ruleMultiplicity_in_ruleReference1060);
                    lv_multiplicity_3_0=ruleMultiplicity();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getReferenceRule());
                    	        }
                           		set(
                           			current, 
                           			"multiplicity",
                            		lv_multiplicity_3_0, 
                            		"Multiplicity");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }
                    break;

            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleReference"


    // $ANTLR start "entryRuleUIWindow"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:519:1: entryRuleUIWindow returns [EObject current=null] : iv_ruleUIWindow= ruleUIWindow EOF ;
    public final EObject entryRuleUIWindow() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUIWindow = null;


        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:520:2: (iv_ruleUIWindow= ruleUIWindow EOF )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:521:2: iv_ruleUIWindow= ruleUIWindow EOF
            {
             newCompositeNode(grammarAccess.getUIWindowRule()); 
            pushFollow(FOLLOW_ruleUIWindow_in_entryRuleUIWindow1097);
            iv_ruleUIWindow=ruleUIWindow();

            state._fsp--;

             current =iv_ruleUIWindow; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleUIWindow1107); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUIWindow"


    // $ANTLR start "ruleUIWindow"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:528:1: ruleUIWindow returns [EObject current=null] : (this_ListWindow_0= ruleListWindow | this_EntryWindow_1= ruleEntryWindow ) ;
    public final EObject ruleUIWindow() throws RecognitionException {
        EObject current = null;

        EObject this_ListWindow_0 = null;

        EObject this_EntryWindow_1 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:531:28: ( (this_ListWindow_0= ruleListWindow | this_EntryWindow_1= ruleEntryWindow ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:532:1: (this_ListWindow_0= ruleListWindow | this_EntryWindow_1= ruleEntryWindow )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:532:1: (this_ListWindow_0= ruleListWindow | this_EntryWindow_1= ruleEntryWindow )
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==21) ) {
                alt9=1;
            }
            else if ( (LA9_0==23) ) {
                alt9=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }
            switch (alt9) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:533:5: this_ListWindow_0= ruleListWindow
                    {
                     
                            newCompositeNode(grammarAccess.getUIWindowAccess().getListWindowParserRuleCall_0()); 
                        
                    pushFollow(FOLLOW_ruleListWindow_in_ruleUIWindow1154);
                    this_ListWindow_0=ruleListWindow();

                    state._fsp--;

                     
                            current = this_ListWindow_0; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:543:5: this_EntryWindow_1= ruleEntryWindow
                    {
                     
                            newCompositeNode(grammarAccess.getUIWindowAccess().getEntryWindowParserRuleCall_1()); 
                        
                    pushFollow(FOLLOW_ruleEntryWindow_in_ruleUIWindow1181);
                    this_EntryWindow_1=ruleEntryWindow();

                    state._fsp--;

                     
                            current = this_EntryWindow_1; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUIWindow"


    // $ANTLR start "entryRuleListWindow"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:559:1: entryRuleListWindow returns [EObject current=null] : iv_ruleListWindow= ruleListWindow EOF ;
    public final EObject entryRuleListWindow() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleListWindow = null;


        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:560:2: (iv_ruleListWindow= ruleListWindow EOF )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:561:2: iv_ruleListWindow= ruleListWindow EOF
            {
             newCompositeNode(grammarAccess.getListWindowRule()); 
            pushFollow(FOLLOW_ruleListWindow_in_entryRuleListWindow1216);
            iv_ruleListWindow=ruleListWindow();

            state._fsp--;

             current =iv_ruleListWindow; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleListWindow1226); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleListWindow"


    // $ANTLR start "ruleListWindow"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:568:1: ruleListWindow returns [EObject current=null] : (otherlv_0= 'ListWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) otherlv_4= '{' ( (lv_options_5_0= ruleWindowOptions ) ) otherlv_6= '}' ) ;
    public final EObject ruleListWindow() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        EObject lv_options_5_0 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:571:28: ( (otherlv_0= 'ListWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) otherlv_4= '{' ( (lv_options_5_0= ruleWindowOptions ) ) otherlv_6= '}' ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:572:1: (otherlv_0= 'ListWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) otherlv_4= '{' ( (lv_options_5_0= ruleWindowOptions ) ) otherlv_6= '}' )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:572:1: (otherlv_0= 'ListWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) otherlv_4= '{' ( (lv_options_5_0= ruleWindowOptions ) ) otherlv_6= '}' )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:572:3: otherlv_0= 'ListWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) otherlv_4= '{' ( (lv_options_5_0= ruleWindowOptions ) ) otherlv_6= '}'
            {
            otherlv_0=(Token)match(input,21,FOLLOW_21_in_ruleListWindow1263); 

                	newLeafNode(otherlv_0, grammarAccess.getListWindowAccess().getListWindowKeyword_0());
                
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:576:1: ( (lv_name_1_0= RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:577:1: (lv_name_1_0= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:577:1: (lv_name_1_0= RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:578:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleListWindow1280); 

            			newLeafNode(lv_name_1_0, grammarAccess.getListWindowAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getListWindowRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,22,FOLLOW_22_in_ruleListWindow1297); 

                	newLeafNode(otherlv_2, grammarAccess.getListWindowAccess().getForKeyword_2());
                
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:598:1: ( (otherlv_3= RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:599:1: (otherlv_3= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:599:1: (otherlv_3= RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:600:3: otherlv_3= RULE_ID
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getListWindowRule());
            	        }
                    
            otherlv_3=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleListWindow1317); 

            		newLeafNode(otherlv_3, grammarAccess.getListWindowAccess().getEntitytypeEntitytypeCrossReference_3_0()); 
            	

            }


            }

            otherlv_4=(Token)match(input,16,FOLLOW_16_in_ruleListWindow1329); 

                	newLeafNode(otherlv_4, grammarAccess.getListWindowAccess().getLeftCurlyBracketKeyword_4());
                
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:615:1: ( (lv_options_5_0= ruleWindowOptions ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:616:1: (lv_options_5_0= ruleWindowOptions )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:616:1: (lv_options_5_0= ruleWindowOptions )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:617:3: lv_options_5_0= ruleWindowOptions
            {
             
            	        newCompositeNode(grammarAccess.getListWindowAccess().getOptionsWindowOptionsParserRuleCall_5_0()); 
            	    
            pushFollow(FOLLOW_ruleWindowOptions_in_ruleListWindow1350);
            lv_options_5_0=ruleWindowOptions();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getListWindowRule());
            	        }
                   		set(
                   			current, 
                   			"options",
                    		lv_options_5_0, 
                    		"WindowOptions");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_6=(Token)match(input,17,FOLLOW_17_in_ruleListWindow1362); 

                	newLeafNode(otherlv_6, grammarAccess.getListWindowAccess().getRightCurlyBracketKeyword_6());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleListWindow"


    // $ANTLR start "entryRuleEntryWindow"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:645:1: entryRuleEntryWindow returns [EObject current=null] : iv_ruleEntryWindow= ruleEntryWindow EOF ;
    public final EObject entryRuleEntryWindow() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEntryWindow = null;


        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:646:2: (iv_ruleEntryWindow= ruleEntryWindow EOF )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:647:2: iv_ruleEntryWindow= ruleEntryWindow EOF
            {
             newCompositeNode(grammarAccess.getEntryWindowRule()); 
            pushFollow(FOLLOW_ruleEntryWindow_in_entryRuleEntryWindow1398);
            iv_ruleEntryWindow=ruleEntryWindow();

            state._fsp--;

             current =iv_ruleEntryWindow; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleEntryWindow1408); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEntryWindow"


    // $ANTLR start "ruleEntryWindow"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:654:1: ruleEntryWindow returns [EObject current=null] : (otherlv_0= 'EntryWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) otherlv_4= '{' ( (lv_options_5_0= ruleWindowOptions ) ) ( (lv_elements_6_0= ruleUIElement ) )+ otherlv_7= '}' ) ;
    public final EObject ruleEntryWindow() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_7=null;
        EObject lv_options_5_0 = null;

        EObject lv_elements_6_0 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:657:28: ( (otherlv_0= 'EntryWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) otherlv_4= '{' ( (lv_options_5_0= ruleWindowOptions ) ) ( (lv_elements_6_0= ruleUIElement ) )+ otherlv_7= '}' ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:658:1: (otherlv_0= 'EntryWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) otherlv_4= '{' ( (lv_options_5_0= ruleWindowOptions ) ) ( (lv_elements_6_0= ruleUIElement ) )+ otherlv_7= '}' )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:658:1: (otherlv_0= 'EntryWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) otherlv_4= '{' ( (lv_options_5_0= ruleWindowOptions ) ) ( (lv_elements_6_0= ruleUIElement ) )+ otherlv_7= '}' )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:658:3: otherlv_0= 'EntryWindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'for' ( (otherlv_3= RULE_ID ) ) otherlv_4= '{' ( (lv_options_5_0= ruleWindowOptions ) ) ( (lv_elements_6_0= ruleUIElement ) )+ otherlv_7= '}'
            {
            otherlv_0=(Token)match(input,23,FOLLOW_23_in_ruleEntryWindow1445); 

                	newLeafNode(otherlv_0, grammarAccess.getEntryWindowAccess().getEntryWindowKeyword_0());
                
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:662:1: ( (lv_name_1_0= RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:663:1: (lv_name_1_0= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:663:1: (lv_name_1_0= RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:664:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleEntryWindow1462); 

            			newLeafNode(lv_name_1_0, grammarAccess.getEntryWindowAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getEntryWindowRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,22,FOLLOW_22_in_ruleEntryWindow1479); 

                	newLeafNode(otherlv_2, grammarAccess.getEntryWindowAccess().getForKeyword_2());
                
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:684:1: ( (otherlv_3= RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:685:1: (otherlv_3= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:685:1: (otherlv_3= RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:686:3: otherlv_3= RULE_ID
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getEntryWindowRule());
            	        }
                    
            otherlv_3=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleEntryWindow1499); 

            		newLeafNode(otherlv_3, grammarAccess.getEntryWindowAccess().getEntitytypeEntitytypeCrossReference_3_0()); 
            	

            }


            }

            otherlv_4=(Token)match(input,16,FOLLOW_16_in_ruleEntryWindow1511); 

                	newLeafNode(otherlv_4, grammarAccess.getEntryWindowAccess().getLeftCurlyBracketKeyword_4());
                
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:701:1: ( (lv_options_5_0= ruleWindowOptions ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:702:1: (lv_options_5_0= ruleWindowOptions )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:702:1: (lv_options_5_0= ruleWindowOptions )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:703:3: lv_options_5_0= ruleWindowOptions
            {
             
            	        newCompositeNode(grammarAccess.getEntryWindowAccess().getOptionsWindowOptionsParserRuleCall_5_0()); 
            	    
            pushFollow(FOLLOW_ruleWindowOptions_in_ruleEntryWindow1532);
            lv_options_5_0=ruleWindowOptions();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getEntryWindowRule());
            	        }
                   		set(
                   			current, 
                   			"options",
                    		lv_options_5_0, 
                    		"WindowOptions");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:719:2: ( (lv_elements_6_0= ruleUIElement ) )+
            int cnt10=0;
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( ((LA10_0>=24 && LA10_0<=26)) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:720:1: (lv_elements_6_0= ruleUIElement )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:720:1: (lv_elements_6_0= ruleUIElement )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:721:3: lv_elements_6_0= ruleUIElement
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getEntryWindowAccess().getElementsUIElementParserRuleCall_6_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleUIElement_in_ruleEntryWindow1553);
            	    lv_elements_6_0=ruleUIElement();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getEntryWindowRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"elements",
            	            		lv_elements_6_0, 
            	            		"UIElement");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt10 >= 1 ) break loop10;
                        EarlyExitException eee =
                            new EarlyExitException(10, input);
                        throw eee;
                }
                cnt10++;
            } while (true);

            otherlv_7=(Token)match(input,17,FOLLOW_17_in_ruleEntryWindow1566); 

                	newLeafNode(otherlv_7, grammarAccess.getEntryWindowAccess().getRightCurlyBracketKeyword_7());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEntryWindow"


    // $ANTLR start "entryRuleUIElement"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:749:1: entryRuleUIElement returns [EObject current=null] : iv_ruleUIElement= ruleUIElement EOF ;
    public final EObject entryRuleUIElement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUIElement = null;


        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:750:2: (iv_ruleUIElement= ruleUIElement EOF )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:751:2: iv_ruleUIElement= ruleUIElement EOF
            {
             newCompositeNode(grammarAccess.getUIElementRule()); 
            pushFollow(FOLLOW_ruleUIElement_in_entryRuleUIElement1602);
            iv_ruleUIElement=ruleUIElement();

            state._fsp--;

             current =iv_ruleUIElement; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleUIElement1612); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUIElement"


    // $ANTLR start "ruleUIElement"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:758:1: ruleUIElement returns [EObject current=null] : ( (this_Label_0= ruleLabel | this_Field_1= ruleField | this_Button_2= ruleButton ) ( (lv_uiOptions_3_0= ruleUIOptions ) ) ) ;
    public final EObject ruleUIElement() throws RecognitionException {
        EObject current = null;

        EObject this_Label_0 = null;

        EObject this_Field_1 = null;

        EObject this_Button_2 = null;

        EObject lv_uiOptions_3_0 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:761:28: ( ( (this_Label_0= ruleLabel | this_Field_1= ruleField | this_Button_2= ruleButton ) ( (lv_uiOptions_3_0= ruleUIOptions ) ) ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:762:1: ( (this_Label_0= ruleLabel | this_Field_1= ruleField | this_Button_2= ruleButton ) ( (lv_uiOptions_3_0= ruleUIOptions ) ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:762:1: ( (this_Label_0= ruleLabel | this_Field_1= ruleField | this_Button_2= ruleButton ) ( (lv_uiOptions_3_0= ruleUIOptions ) ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:762:2: (this_Label_0= ruleLabel | this_Field_1= ruleField | this_Button_2= ruleButton ) ( (lv_uiOptions_3_0= ruleUIOptions ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:762:2: (this_Label_0= ruleLabel | this_Field_1= ruleField | this_Button_2= ruleButton )
            int alt11=3;
            switch ( input.LA(1) ) {
            case 24:
                {
                alt11=1;
                }
                break;
            case 25:
                {
                alt11=2;
                }
                break;
            case 26:
                {
                alt11=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }

            switch (alt11) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:763:5: this_Label_0= ruleLabel
                    {
                     
                            newCompositeNode(grammarAccess.getUIElementAccess().getLabelParserRuleCall_0_0()); 
                        
                    pushFollow(FOLLOW_ruleLabel_in_ruleUIElement1660);
                    this_Label_0=ruleLabel();

                    state._fsp--;

                     
                            current = this_Label_0; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:773:5: this_Field_1= ruleField
                    {
                     
                            newCompositeNode(grammarAccess.getUIElementAccess().getFieldParserRuleCall_0_1()); 
                        
                    pushFollow(FOLLOW_ruleField_in_ruleUIElement1687);
                    this_Field_1=ruleField();

                    state._fsp--;

                     
                            current = this_Field_1; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 3 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:783:5: this_Button_2= ruleButton
                    {
                     
                            newCompositeNode(grammarAccess.getUIElementAccess().getButtonParserRuleCall_0_2()); 
                        
                    pushFollow(FOLLOW_ruleButton_in_ruleUIElement1714);
                    this_Button_2=ruleButton();

                    state._fsp--;

                     
                            current = this_Button_2; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;

            }

            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:791:2: ( (lv_uiOptions_3_0= ruleUIOptions ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:792:1: (lv_uiOptions_3_0= ruleUIOptions )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:792:1: (lv_uiOptions_3_0= ruleUIOptions )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:793:3: lv_uiOptions_3_0= ruleUIOptions
            {
             
            	        newCompositeNode(grammarAccess.getUIElementAccess().getUiOptionsUIOptionsParserRuleCall_1_0()); 
            	    
            pushFollow(FOLLOW_ruleUIOptions_in_ruleUIElement1735);
            lv_uiOptions_3_0=ruleUIOptions();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getUIElementRule());
            	        }
                   		set(
                   			current, 
                   			"uiOptions",
                    		lv_uiOptions_3_0, 
                    		"UIOptions");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUIElement"


    // $ANTLR start "entryRuleUIOptions"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:817:1: entryRuleUIOptions returns [EObject current=null] : iv_ruleUIOptions= ruleUIOptions EOF ;
    public final EObject entryRuleUIOptions() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUIOptions = null;


        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:818:2: (iv_ruleUIOptions= ruleUIOptions EOF )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:819:2: iv_ruleUIOptions= ruleUIOptions EOF
            {
             newCompositeNode(grammarAccess.getUIOptionsRule()); 
            pushFollow(FOLLOW_ruleUIOptions_in_entryRuleUIOptions1771);
            iv_ruleUIOptions=ruleUIOptions();

            state._fsp--;

             current =iv_ruleUIOptions; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleUIOptions1781); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUIOptions"


    // $ANTLR start "ruleUIOptions"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:826:1: ruleUIOptions returns [EObject current=null] : ( ( ( ( ({...}? => ( ({...}? => ( (lv_position_1_0= rulePosition ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_2_0= ruleSize ) ) ) ) ) )+ {...}?) ) ) ;
    public final EObject ruleUIOptions() throws RecognitionException {
        EObject current = null;

        EObject lv_position_1_0 = null;

        EObject lv_size_2_0 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:829:28: ( ( ( ( ( ({...}? => ( ({...}? => ( (lv_position_1_0= rulePosition ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_2_0= ruleSize ) ) ) ) ) )+ {...}?) ) ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:830:1: ( ( ( ( ({...}? => ( ({...}? => ( (lv_position_1_0= rulePosition ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_2_0= ruleSize ) ) ) ) ) )+ {...}?) ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:830:1: ( ( ( ( ({...}? => ( ({...}? => ( (lv_position_1_0= rulePosition ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_2_0= ruleSize ) ) ) ) ) )+ {...}?) ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:832:1: ( ( ( ({...}? => ( ({...}? => ( (lv_position_1_0= rulePosition ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_2_0= ruleSize ) ) ) ) ) )+ {...}?) )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:832:1: ( ( ( ({...}? => ( ({...}? => ( (lv_position_1_0= rulePosition ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_2_0= ruleSize ) ) ) ) ) )+ {...}?) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:833:2: ( ( ({...}? => ( ({...}? => ( (lv_position_1_0= rulePosition ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_2_0= ruleSize ) ) ) ) ) )+ {...}?)
            {
             
            	  getUnorderedGroupHelper().enter(grammarAccess.getUIOptionsAccess().getUnorderedGroup());
            	
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:836:2: ( ( ({...}? => ( ({...}? => ( (lv_position_1_0= rulePosition ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_2_0= ruleSize ) ) ) ) ) )+ {...}?)
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:837:3: ( ({...}? => ( ({...}? => ( (lv_position_1_0= rulePosition ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_2_0= ruleSize ) ) ) ) ) )+ {...}?
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:837:3: ( ({...}? => ( ({...}? => ( (lv_position_1_0= rulePosition ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_size_2_0= ruleSize ) ) ) ) ) )+
            int cnt12=0;
            loop12:
            do {
                int alt12=3;
                int LA12_0 = input.LA(1);

                if ( LA12_0 >=29 && LA12_0<=30 && getUnorderedGroupHelper().canSelect(grammarAccess.getUIOptionsAccess().getUnorderedGroup(), 0) ) {
                    alt12=1;
                }
                else if ( LA12_0 >=27 && LA12_0<=28 && getUnorderedGroupHelper().canSelect(grammarAccess.getUIOptionsAccess().getUnorderedGroup(), 1) ) {
                    alt12=2;
                }


                switch (alt12) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:839:4: ({...}? => ( ({...}? => ( (lv_position_1_0= rulePosition ) ) ) ) )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:839:4: ({...}? => ( ({...}? => ( (lv_position_1_0= rulePosition ) ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:840:5: {...}? => ( ({...}? => ( (lv_position_1_0= rulePosition ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getUIOptionsAccess().getUnorderedGroup(), 0) ) {
            	        throw new FailedPredicateException(input, "ruleUIOptions", "getUnorderedGroupHelper().canSelect(grammarAccess.getUIOptionsAccess().getUnorderedGroup(), 0)");
            	    }
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:840:104: ( ({...}? => ( (lv_position_1_0= rulePosition ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:841:6: ({...}? => ( (lv_position_1_0= rulePosition ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getUIOptionsAccess().getUnorderedGroup(), 0);
            	    	 				
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:844:6: ({...}? => ( (lv_position_1_0= rulePosition ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:844:7: {...}? => ( (lv_position_1_0= rulePosition ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "ruleUIOptions", "true");
            	    }
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:844:16: ( (lv_position_1_0= rulePosition ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:845:1: (lv_position_1_0= rulePosition )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:845:1: (lv_position_1_0= rulePosition )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:846:3: lv_position_1_0= rulePosition
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getUIOptionsAccess().getPositionPositionParserRuleCall_0_0()); 
            	    	    
            	    pushFollow(FOLLOW_rulePosition_in_ruleUIOptions1871);
            	    lv_position_1_0=rulePosition();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getUIOptionsRule());
            	    	        }
            	           		set(
            	           			current, 
            	           			"position",
            	            		lv_position_1_0, 
            	            		"Position");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getUIOptionsAccess().getUnorderedGroup());
            	    	 				

            	    }


            	    }


            	    }
            	    break;
            	case 2 :
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:869:4: ({...}? => ( ({...}? => ( (lv_size_2_0= ruleSize ) ) ) ) )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:869:4: ({...}? => ( ({...}? => ( (lv_size_2_0= ruleSize ) ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:870:5: {...}? => ( ({...}? => ( (lv_size_2_0= ruleSize ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getUIOptionsAccess().getUnorderedGroup(), 1) ) {
            	        throw new FailedPredicateException(input, "ruleUIOptions", "getUnorderedGroupHelper().canSelect(grammarAccess.getUIOptionsAccess().getUnorderedGroup(), 1)");
            	    }
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:870:104: ( ({...}? => ( (lv_size_2_0= ruleSize ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:871:6: ({...}? => ( (lv_size_2_0= ruleSize ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getUIOptionsAccess().getUnorderedGroup(), 1);
            	    	 				
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:874:6: ({...}? => ( (lv_size_2_0= ruleSize ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:874:7: {...}? => ( (lv_size_2_0= ruleSize ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "ruleUIOptions", "true");
            	    }
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:874:16: ( (lv_size_2_0= ruleSize ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:875:1: (lv_size_2_0= ruleSize )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:875:1: (lv_size_2_0= ruleSize )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:876:3: lv_size_2_0= ruleSize
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getUIOptionsAccess().getSizeSizeParserRuleCall_1_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleSize_in_ruleUIOptions1946);
            	    lv_size_2_0=ruleSize();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getUIOptionsRule());
            	    	        }
            	           		set(
            	           			current, 
            	           			"size",
            	            		lv_size_2_0, 
            	            		"Size");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getUIOptionsAccess().getUnorderedGroup());
            	    	 				

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt12 >= 1 ) break loop12;
                        EarlyExitException eee =
                            new EarlyExitException(12, input);
                        throw eee;
                }
                cnt12++;
            } while (true);

            if ( ! getUnorderedGroupHelper().canLeave(grammarAccess.getUIOptionsAccess().getUnorderedGroup()) ) {
                throw new FailedPredicateException(input, "ruleUIOptions", "getUnorderedGroupHelper().canLeave(grammarAccess.getUIOptionsAccess().getUnorderedGroup())");
            }

            }


            }

             
            	  getUnorderedGroupHelper().leave(grammarAccess.getUIOptionsAccess().getUnorderedGroup());
            	

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUIOptions"


    // $ANTLR start "entryRuleLabel"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:915:1: entryRuleLabel returns [EObject current=null] : iv_ruleLabel= ruleLabel EOF ;
    public final EObject entryRuleLabel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLabel = null;


        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:916:2: (iv_ruleLabel= ruleLabel EOF )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:917:2: iv_ruleLabel= ruleLabel EOF
            {
             newCompositeNode(grammarAccess.getLabelRule()); 
            pushFollow(FOLLOW_ruleLabel_in_entryRuleLabel2027);
            iv_ruleLabel=ruleLabel();

            state._fsp--;

             current =iv_ruleLabel; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleLabel2037); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLabel"


    // $ANTLR start "ruleLabel"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:924:1: ruleLabel returns [EObject current=null] : (otherlv_0= 'Label' ( (lv_name_1_0= RULE_ID ) ) ( (lv_text_2_0= RULE_STRING ) )? ) ;
    public final EObject ruleLabel() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token lv_text_2_0=null;

         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:927:28: ( (otherlv_0= 'Label' ( (lv_name_1_0= RULE_ID ) ) ( (lv_text_2_0= RULE_STRING ) )? ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:928:1: (otherlv_0= 'Label' ( (lv_name_1_0= RULE_ID ) ) ( (lv_text_2_0= RULE_STRING ) )? )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:928:1: (otherlv_0= 'Label' ( (lv_name_1_0= RULE_ID ) ) ( (lv_text_2_0= RULE_STRING ) )? )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:928:3: otherlv_0= 'Label' ( (lv_name_1_0= RULE_ID ) ) ( (lv_text_2_0= RULE_STRING ) )?
            {
            otherlv_0=(Token)match(input,24,FOLLOW_24_in_ruleLabel2074); 

                	newLeafNode(otherlv_0, grammarAccess.getLabelAccess().getLabelKeyword_0());
                
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:932:1: ( (lv_name_1_0= RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:933:1: (lv_name_1_0= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:933:1: (lv_name_1_0= RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:934:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleLabel2091); 

            			newLeafNode(lv_name_1_0, grammarAccess.getLabelAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getLabelRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"ID");
            	    

            }


            }

            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:950:2: ( (lv_text_2_0= RULE_STRING ) )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==RULE_STRING) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:951:1: (lv_text_2_0= RULE_STRING )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:951:1: (lv_text_2_0= RULE_STRING )
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:952:3: lv_text_2_0= RULE_STRING
                    {
                    lv_text_2_0=(Token)match(input,RULE_STRING,FOLLOW_RULE_STRING_in_ruleLabel2113); 

                    			newLeafNode(lv_text_2_0, grammarAccess.getLabelAccess().getTextSTRINGTerminalRuleCall_2_0()); 
                    		

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getLabelRule());
                    	        }
                           		setWithLastConsumed(
                           			current, 
                           			"text",
                            		lv_text_2_0, 
                            		"STRING");
                    	    

                    }


                    }
                    break;

            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLabel"


    // $ANTLR start "entryRuleField"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:976:1: entryRuleField returns [EObject current=null] : iv_ruleField= ruleField EOF ;
    public final EObject entryRuleField() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleField = null;


        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:977:2: (iv_ruleField= ruleField EOF )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:978:2: iv_ruleField= ruleField EOF
            {
             newCompositeNode(grammarAccess.getFieldRule()); 
            pushFollow(FOLLOW_ruleField_in_entryRuleField2155);
            iv_ruleField=ruleField();

            state._fsp--;

             current =iv_ruleField; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleField2165); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleField"


    // $ANTLR start "ruleField"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:985:1: ruleField returns [EObject current=null] : (otherlv_0= 'Field' ( (otherlv_1= RULE_ID ) ) ) ;
    public final EObject ruleField() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;

         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:988:28: ( (otherlv_0= 'Field' ( (otherlv_1= RULE_ID ) ) ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:989:1: (otherlv_0= 'Field' ( (otherlv_1= RULE_ID ) ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:989:1: (otherlv_0= 'Field' ( (otherlv_1= RULE_ID ) ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:989:3: otherlv_0= 'Field' ( (otherlv_1= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,25,FOLLOW_25_in_ruleField2202); 

                	newLeafNode(otherlv_0, grammarAccess.getFieldAccess().getFieldKeyword_0());
                
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:993:1: ( (otherlv_1= RULE_ID ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:994:1: (otherlv_1= RULE_ID )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:994:1: (otherlv_1= RULE_ID )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:995:3: otherlv_1= RULE_ID
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getFieldRule());
            	        }
                    
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleField2222); 

            		newLeafNode(otherlv_1, grammarAccess.getFieldAccess().getPropertyPropertyCrossReference_1_0()); 
            	

            }


            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleField"


    // $ANTLR start "entryRuleButton"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1014:1: entryRuleButton returns [EObject current=null] : iv_ruleButton= ruleButton EOF ;
    public final EObject entryRuleButton() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleButton = null;


        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1015:2: (iv_ruleButton= ruleButton EOF )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1016:2: iv_ruleButton= ruleButton EOF
            {
             newCompositeNode(grammarAccess.getButtonRule()); 
            pushFollow(FOLLOW_ruleButton_in_entryRuleButton2258);
            iv_ruleButton=ruleButton();

            state._fsp--;

             current =iv_ruleButton; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleButton2268); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleButton"


    // $ANTLR start "ruleButton"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1023:1: ruleButton returns [EObject current=null] : (otherlv_0= 'Button' ( (lv_inscription_1_0= ruleInscription ) ) ) ;
    public final EObject ruleButton() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Enumerator lv_inscription_1_0 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1026:28: ( (otherlv_0= 'Button' ( (lv_inscription_1_0= ruleInscription ) ) ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1027:1: (otherlv_0= 'Button' ( (lv_inscription_1_0= ruleInscription ) ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1027:1: (otherlv_0= 'Button' ( (lv_inscription_1_0= ruleInscription ) ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1027:3: otherlv_0= 'Button' ( (lv_inscription_1_0= ruleInscription ) )
            {
            otherlv_0=(Token)match(input,26,FOLLOW_26_in_ruleButton2305); 

                	newLeafNode(otherlv_0, grammarAccess.getButtonAccess().getButtonKeyword_0());
                
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1031:1: ( (lv_inscription_1_0= ruleInscription ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1032:1: (lv_inscription_1_0= ruleInscription )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1032:1: (lv_inscription_1_0= ruleInscription )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1033:3: lv_inscription_1_0= ruleInscription
            {
             
            	        newCompositeNode(grammarAccess.getButtonAccess().getInscriptionInscriptionEnumRuleCall_1_0()); 
            	    
            pushFollow(FOLLOW_ruleInscription_in_ruleButton2326);
            lv_inscription_1_0=ruleInscription();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getButtonRule());
            	        }
                   		set(
                   			current, 
                   			"inscription",
                    		lv_inscription_1_0, 
                    		"Inscription");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleButton"


    // $ANTLR start "entryRuleSize"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1057:1: entryRuleSize returns [EObject current=null] : iv_ruleSize= ruleSize EOF ;
    public final EObject entryRuleSize() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSize = null;


        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1058:2: (iv_ruleSize= ruleSize EOF )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1059:2: iv_ruleSize= ruleSize EOF
            {
             newCompositeNode(grammarAccess.getSizeRule()); 
            pushFollow(FOLLOW_ruleSize_in_entryRuleSize2362);
            iv_ruleSize=ruleSize();

            state._fsp--;

             current =iv_ruleSize; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleSize2372); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSize"


    // $ANTLR start "ruleSize"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1066:1: ruleSize returns [EObject current=null] : ( ( ( ( ({...}? => ( ({...}? => (otherlv_1= 'width' ( (lv_width_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'height' ( (lv_height_4_0= RULE_INT ) ) ) ) ) ) )+ {...}?) ) ) ;
    public final EObject ruleSize() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token lv_width_2_0=null;
        Token otherlv_3=null;
        Token lv_height_4_0=null;

         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1069:28: ( ( ( ( ( ({...}? => ( ({...}? => (otherlv_1= 'width' ( (lv_width_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'height' ( (lv_height_4_0= RULE_INT ) ) ) ) ) ) )+ {...}?) ) ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1070:1: ( ( ( ( ({...}? => ( ({...}? => (otherlv_1= 'width' ( (lv_width_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'height' ( (lv_height_4_0= RULE_INT ) ) ) ) ) ) )+ {...}?) ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1070:1: ( ( ( ( ({...}? => ( ({...}? => (otherlv_1= 'width' ( (lv_width_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'height' ( (lv_height_4_0= RULE_INT ) ) ) ) ) ) )+ {...}?) ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1072:1: ( ( ( ({...}? => ( ({...}? => (otherlv_1= 'width' ( (lv_width_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'height' ( (lv_height_4_0= RULE_INT ) ) ) ) ) ) )+ {...}?) )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1072:1: ( ( ( ({...}? => ( ({...}? => (otherlv_1= 'width' ( (lv_width_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'height' ( (lv_height_4_0= RULE_INT ) ) ) ) ) ) )+ {...}?) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1073:2: ( ( ({...}? => ( ({...}? => (otherlv_1= 'width' ( (lv_width_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'height' ( (lv_height_4_0= RULE_INT ) ) ) ) ) ) )+ {...}?)
            {
             
            	  getUnorderedGroupHelper().enter(grammarAccess.getSizeAccess().getUnorderedGroup());
            	
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1076:2: ( ( ({...}? => ( ({...}? => (otherlv_1= 'width' ( (lv_width_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'height' ( (lv_height_4_0= RULE_INT ) ) ) ) ) ) )+ {...}?)
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1077:3: ( ({...}? => ( ({...}? => (otherlv_1= 'width' ( (lv_width_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'height' ( (lv_height_4_0= RULE_INT ) ) ) ) ) ) )+ {...}?
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1077:3: ( ({...}? => ( ({...}? => (otherlv_1= 'width' ( (lv_width_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'height' ( (lv_height_4_0= RULE_INT ) ) ) ) ) ) )+
            int cnt14=0;
            loop14:
            do {
                int alt14=3;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==27) ) {
                    int LA14_2 = input.LA(2);

                    if ( getUnorderedGroupHelper().canSelect(grammarAccess.getSizeAccess().getUnorderedGroup(), 0) ) {
                        alt14=1;
                    }


                }
                else if ( (LA14_0==28) ) {
                    int LA14_3 = input.LA(2);

                    if ( getUnorderedGroupHelper().canSelect(grammarAccess.getSizeAccess().getUnorderedGroup(), 1) ) {
                        alt14=2;
                    }


                }


                switch (alt14) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1079:4: ({...}? => ( ({...}? => (otherlv_1= 'width' ( (lv_width_2_0= RULE_INT ) ) ) ) ) )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1079:4: ({...}? => ( ({...}? => (otherlv_1= 'width' ( (lv_width_2_0= RULE_INT ) ) ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1080:5: {...}? => ( ({...}? => (otherlv_1= 'width' ( (lv_width_2_0= RULE_INT ) ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getSizeAccess().getUnorderedGroup(), 0) ) {
            	        throw new FailedPredicateException(input, "ruleSize", "getUnorderedGroupHelper().canSelect(grammarAccess.getSizeAccess().getUnorderedGroup(), 0)");
            	    }
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1080:99: ( ({...}? => (otherlv_1= 'width' ( (lv_width_2_0= RULE_INT ) ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1081:6: ({...}? => (otherlv_1= 'width' ( (lv_width_2_0= RULE_INT ) ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getSizeAccess().getUnorderedGroup(), 0);
            	    	 				
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1084:6: ({...}? => (otherlv_1= 'width' ( (lv_width_2_0= RULE_INT ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1084:7: {...}? => (otherlv_1= 'width' ( (lv_width_2_0= RULE_INT ) ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "ruleSize", "true");
            	    }
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1084:16: (otherlv_1= 'width' ( (lv_width_2_0= RULE_INT ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1084:18: otherlv_1= 'width' ( (lv_width_2_0= RULE_INT ) )
            	    {
            	    otherlv_1=(Token)match(input,27,FOLLOW_27_in_ruleSize2454); 

            	        	newLeafNode(otherlv_1, grammarAccess.getSizeAccess().getWidthKeyword_0_0());
            	        
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1088:1: ( (lv_width_2_0= RULE_INT ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1089:1: (lv_width_2_0= RULE_INT )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1089:1: (lv_width_2_0= RULE_INT )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1090:3: lv_width_2_0= RULE_INT
            	    {
            	    lv_width_2_0=(Token)match(input,RULE_INT,FOLLOW_RULE_INT_in_ruleSize2471); 

            	    			newLeafNode(lv_width_2_0, grammarAccess.getSizeAccess().getWidthINTTerminalRuleCall_0_1_0()); 
            	    		

            	    	        if (current==null) {
            	    	            current = createModelElement(grammarAccess.getSizeRule());
            	    	        }
            	           		setWithLastConsumed(
            	           			current, 
            	           			"width",
            	            		lv_width_2_0, 
            	            		"INT");
            	    	    

            	    }


            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getSizeAccess().getUnorderedGroup());
            	    	 				

            	    }


            	    }


            	    }
            	    break;
            	case 2 :
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1113:4: ({...}? => ( ({...}? => (otherlv_3= 'height' ( (lv_height_4_0= RULE_INT ) ) ) ) ) )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1113:4: ({...}? => ( ({...}? => (otherlv_3= 'height' ( (lv_height_4_0= RULE_INT ) ) ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1114:5: {...}? => ( ({...}? => (otherlv_3= 'height' ( (lv_height_4_0= RULE_INT ) ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getSizeAccess().getUnorderedGroup(), 1) ) {
            	        throw new FailedPredicateException(input, "ruleSize", "getUnorderedGroupHelper().canSelect(grammarAccess.getSizeAccess().getUnorderedGroup(), 1)");
            	    }
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1114:99: ( ({...}? => (otherlv_3= 'height' ( (lv_height_4_0= RULE_INT ) ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1115:6: ({...}? => (otherlv_3= 'height' ( (lv_height_4_0= RULE_INT ) ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getSizeAccess().getUnorderedGroup(), 1);
            	    	 				
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1118:6: ({...}? => (otherlv_3= 'height' ( (lv_height_4_0= RULE_INT ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1118:7: {...}? => (otherlv_3= 'height' ( (lv_height_4_0= RULE_INT ) ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "ruleSize", "true");
            	    }
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1118:16: (otherlv_3= 'height' ( (lv_height_4_0= RULE_INT ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1118:18: otherlv_3= 'height' ( (lv_height_4_0= RULE_INT ) )
            	    {
            	    otherlv_3=(Token)match(input,28,FOLLOW_28_in_ruleSize2544); 

            	        	newLeafNode(otherlv_3, grammarAccess.getSizeAccess().getHeightKeyword_1_0());
            	        
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1122:1: ( (lv_height_4_0= RULE_INT ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1123:1: (lv_height_4_0= RULE_INT )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1123:1: (lv_height_4_0= RULE_INT )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1124:3: lv_height_4_0= RULE_INT
            	    {
            	    lv_height_4_0=(Token)match(input,RULE_INT,FOLLOW_RULE_INT_in_ruleSize2561); 

            	    			newLeafNode(lv_height_4_0, grammarAccess.getSizeAccess().getHeightINTTerminalRuleCall_1_1_0()); 
            	    		

            	    	        if (current==null) {
            	    	            current = createModelElement(grammarAccess.getSizeRule());
            	    	        }
            	           		setWithLastConsumed(
            	           			current, 
            	           			"height",
            	            		lv_height_4_0, 
            	            		"INT");
            	    	    

            	    }


            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getSizeAccess().getUnorderedGroup());
            	    	 				

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt14 >= 1 ) break loop14;
                        EarlyExitException eee =
                            new EarlyExitException(14, input);
                        throw eee;
                }
                cnt14++;
            } while (true);

            if ( ! getUnorderedGroupHelper().canLeave(grammarAccess.getSizeAccess().getUnorderedGroup()) ) {
                throw new FailedPredicateException(input, "ruleSize", "getUnorderedGroupHelper().canLeave(grammarAccess.getSizeAccess().getUnorderedGroup())");
            }

            }


            }

             
            	  getUnorderedGroupHelper().leave(grammarAccess.getSizeAccess().getUnorderedGroup());
            	

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSize"


    // $ANTLR start "entryRulePosition"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1163:1: entryRulePosition returns [EObject current=null] : iv_rulePosition= rulePosition EOF ;
    public final EObject entryRulePosition() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePosition = null;


        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1164:2: (iv_rulePosition= rulePosition EOF )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1165:2: iv_rulePosition= rulePosition EOF
            {
             newCompositeNode(grammarAccess.getPositionRule()); 
            pushFollow(FOLLOW_rulePosition_in_entryRulePosition2648);
            iv_rulePosition=rulePosition();

            state._fsp--;

             current =iv_rulePosition; 
            match(input,EOF,FOLLOW_EOF_in_entryRulePosition2658); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePosition"


    // $ANTLR start "rulePosition"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1172:1: rulePosition returns [EObject current=null] : ( ( ( ( ({...}? => ( ({...}? => (otherlv_1= 'x_value' ( (lv_x_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'y_value' ( (lv_y_4_0= RULE_INT ) ) ) ) ) ) )+ {...}?) ) ) ;
    public final EObject rulePosition() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token lv_x_2_0=null;
        Token otherlv_3=null;
        Token lv_y_4_0=null;

         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1175:28: ( ( ( ( ( ({...}? => ( ({...}? => (otherlv_1= 'x_value' ( (lv_x_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'y_value' ( (lv_y_4_0= RULE_INT ) ) ) ) ) ) )+ {...}?) ) ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1176:1: ( ( ( ( ({...}? => ( ({...}? => (otherlv_1= 'x_value' ( (lv_x_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'y_value' ( (lv_y_4_0= RULE_INT ) ) ) ) ) ) )+ {...}?) ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1176:1: ( ( ( ( ({...}? => ( ({...}? => (otherlv_1= 'x_value' ( (lv_x_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'y_value' ( (lv_y_4_0= RULE_INT ) ) ) ) ) ) )+ {...}?) ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1178:1: ( ( ( ({...}? => ( ({...}? => (otherlv_1= 'x_value' ( (lv_x_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'y_value' ( (lv_y_4_0= RULE_INT ) ) ) ) ) ) )+ {...}?) )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1178:1: ( ( ( ({...}? => ( ({...}? => (otherlv_1= 'x_value' ( (lv_x_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'y_value' ( (lv_y_4_0= RULE_INT ) ) ) ) ) ) )+ {...}?) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1179:2: ( ( ({...}? => ( ({...}? => (otherlv_1= 'x_value' ( (lv_x_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'y_value' ( (lv_y_4_0= RULE_INT ) ) ) ) ) ) )+ {...}?)
            {
             
            	  getUnorderedGroupHelper().enter(grammarAccess.getPositionAccess().getUnorderedGroup());
            	
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1182:2: ( ( ({...}? => ( ({...}? => (otherlv_1= 'x_value' ( (lv_x_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'y_value' ( (lv_y_4_0= RULE_INT ) ) ) ) ) ) )+ {...}?)
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1183:3: ( ({...}? => ( ({...}? => (otherlv_1= 'x_value' ( (lv_x_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'y_value' ( (lv_y_4_0= RULE_INT ) ) ) ) ) ) )+ {...}?
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1183:3: ( ({...}? => ( ({...}? => (otherlv_1= 'x_value' ( (lv_x_2_0= RULE_INT ) ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_3= 'y_value' ( (lv_y_4_0= RULE_INT ) ) ) ) ) ) )+
            int cnt15=0;
            loop15:
            do {
                int alt15=3;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==29) ) {
                    int LA15_2 = input.LA(2);

                    if ( getUnorderedGroupHelper().canSelect(grammarAccess.getPositionAccess().getUnorderedGroup(), 0) ) {
                        alt15=1;
                    }


                }
                else if ( (LA15_0==30) ) {
                    int LA15_3 = input.LA(2);

                    if ( getUnorderedGroupHelper().canSelect(grammarAccess.getPositionAccess().getUnorderedGroup(), 1) ) {
                        alt15=2;
                    }


                }


                switch (alt15) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1185:4: ({...}? => ( ({...}? => (otherlv_1= 'x_value' ( (lv_x_2_0= RULE_INT ) ) ) ) ) )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1185:4: ({...}? => ( ({...}? => (otherlv_1= 'x_value' ( (lv_x_2_0= RULE_INT ) ) ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1186:5: {...}? => ( ({...}? => (otherlv_1= 'x_value' ( (lv_x_2_0= RULE_INT ) ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getPositionAccess().getUnorderedGroup(), 0) ) {
            	        throw new FailedPredicateException(input, "rulePosition", "getUnorderedGroupHelper().canSelect(grammarAccess.getPositionAccess().getUnorderedGroup(), 0)");
            	    }
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1186:103: ( ({...}? => (otherlv_1= 'x_value' ( (lv_x_2_0= RULE_INT ) ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1187:6: ({...}? => (otherlv_1= 'x_value' ( (lv_x_2_0= RULE_INT ) ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getPositionAccess().getUnorderedGroup(), 0);
            	    	 				
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1190:6: ({...}? => (otherlv_1= 'x_value' ( (lv_x_2_0= RULE_INT ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1190:7: {...}? => (otherlv_1= 'x_value' ( (lv_x_2_0= RULE_INT ) ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "rulePosition", "true");
            	    }
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1190:16: (otherlv_1= 'x_value' ( (lv_x_2_0= RULE_INT ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1190:18: otherlv_1= 'x_value' ( (lv_x_2_0= RULE_INT ) )
            	    {
            	    otherlv_1=(Token)match(input,29,FOLLOW_29_in_rulePosition2740); 

            	        	newLeafNode(otherlv_1, grammarAccess.getPositionAccess().getX_valueKeyword_0_0());
            	        
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1194:1: ( (lv_x_2_0= RULE_INT ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1195:1: (lv_x_2_0= RULE_INT )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1195:1: (lv_x_2_0= RULE_INT )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1196:3: lv_x_2_0= RULE_INT
            	    {
            	    lv_x_2_0=(Token)match(input,RULE_INT,FOLLOW_RULE_INT_in_rulePosition2757); 

            	    			newLeafNode(lv_x_2_0, grammarAccess.getPositionAccess().getXINTTerminalRuleCall_0_1_0()); 
            	    		

            	    	        if (current==null) {
            	    	            current = createModelElement(grammarAccess.getPositionRule());
            	    	        }
            	           		setWithLastConsumed(
            	           			current, 
            	           			"x",
            	            		lv_x_2_0, 
            	            		"INT");
            	    	    

            	    }


            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getPositionAccess().getUnorderedGroup());
            	    	 				

            	    }


            	    }


            	    }
            	    break;
            	case 2 :
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1219:4: ({...}? => ( ({...}? => (otherlv_3= 'y_value' ( (lv_y_4_0= RULE_INT ) ) ) ) ) )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1219:4: ({...}? => ( ({...}? => (otherlv_3= 'y_value' ( (lv_y_4_0= RULE_INT ) ) ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1220:5: {...}? => ( ({...}? => (otherlv_3= 'y_value' ( (lv_y_4_0= RULE_INT ) ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getPositionAccess().getUnorderedGroup(), 1) ) {
            	        throw new FailedPredicateException(input, "rulePosition", "getUnorderedGroupHelper().canSelect(grammarAccess.getPositionAccess().getUnorderedGroup(), 1)");
            	    }
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1220:103: ( ({...}? => (otherlv_3= 'y_value' ( (lv_y_4_0= RULE_INT ) ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1221:6: ({...}? => (otherlv_3= 'y_value' ( (lv_y_4_0= RULE_INT ) ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getPositionAccess().getUnorderedGroup(), 1);
            	    	 				
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1224:6: ({...}? => (otherlv_3= 'y_value' ( (lv_y_4_0= RULE_INT ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1224:7: {...}? => (otherlv_3= 'y_value' ( (lv_y_4_0= RULE_INT ) ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "rulePosition", "true");
            	    }
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1224:16: (otherlv_3= 'y_value' ( (lv_y_4_0= RULE_INT ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1224:18: otherlv_3= 'y_value' ( (lv_y_4_0= RULE_INT ) )
            	    {
            	    otherlv_3=(Token)match(input,30,FOLLOW_30_in_rulePosition2830); 

            	        	newLeafNode(otherlv_3, grammarAccess.getPositionAccess().getY_valueKeyword_1_0());
            	        
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1228:1: ( (lv_y_4_0= RULE_INT ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1229:1: (lv_y_4_0= RULE_INT )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1229:1: (lv_y_4_0= RULE_INT )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1230:3: lv_y_4_0= RULE_INT
            	    {
            	    lv_y_4_0=(Token)match(input,RULE_INT,FOLLOW_RULE_INT_in_rulePosition2847); 

            	    			newLeafNode(lv_y_4_0, grammarAccess.getPositionAccess().getYINTTerminalRuleCall_1_1_0()); 
            	    		

            	    	        if (current==null) {
            	    	            current = createModelElement(grammarAccess.getPositionRule());
            	    	        }
            	           		setWithLastConsumed(
            	           			current, 
            	           			"y",
            	            		lv_y_4_0, 
            	            		"INT");
            	    	    

            	    }


            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getPositionAccess().getUnorderedGroup());
            	    	 				

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt15 >= 1 ) break loop15;
                        EarlyExitException eee =
                            new EarlyExitException(15, input);
                        throw eee;
                }
                cnt15++;
            } while (true);

            if ( ! getUnorderedGroupHelper().canLeave(grammarAccess.getPositionAccess().getUnorderedGroup()) ) {
                throw new FailedPredicateException(input, "rulePosition", "getUnorderedGroupHelper().canLeave(grammarAccess.getPositionAccess().getUnorderedGroup())");
            }

            }


            }

             
            	  getUnorderedGroupHelper().leave(grammarAccess.getPositionAccess().getUnorderedGroup());
            	

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePosition"


    // $ANTLR start "entryRuleWindowOptions"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1269:1: entryRuleWindowOptions returns [EObject current=null] : iv_ruleWindowOptions= ruleWindowOptions EOF ;
    public final EObject entryRuleWindowOptions() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleWindowOptions = null;


        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1270:2: (iv_ruleWindowOptions= ruleWindowOptions EOF )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1271:2: iv_ruleWindowOptions= ruleWindowOptions EOF
            {
             newCompositeNode(grammarAccess.getWindowOptionsRule()); 
            pushFollow(FOLLOW_ruleWindowOptions_in_entryRuleWindowOptions2934);
            iv_ruleWindowOptions=ruleWindowOptions();

            state._fsp--;

             current =iv_ruleWindowOptions; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleWindowOptions2944); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleWindowOptions"


    // $ANTLR start "ruleWindowOptions"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1278:1: ruleWindowOptions returns [EObject current=null] : ( ( ( ( ({...}? => ( ({...}? => ( (lv_size_1_0= ruleSize ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_2= 'title' ( (lv_title_3_0= RULE_STRING ) ) ) ) ) ) )+ {...}?) ) ) ;
    public final EObject ruleWindowOptions() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        Token lv_title_3_0=null;
        EObject lv_size_1_0 = null;


         enterRule(); 
            
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1281:28: ( ( ( ( ( ({...}? => ( ({...}? => ( (lv_size_1_0= ruleSize ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_2= 'title' ( (lv_title_3_0= RULE_STRING ) ) ) ) ) ) )+ {...}?) ) ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1282:1: ( ( ( ( ({...}? => ( ({...}? => ( (lv_size_1_0= ruleSize ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_2= 'title' ( (lv_title_3_0= RULE_STRING ) ) ) ) ) ) )+ {...}?) ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1282:1: ( ( ( ( ({...}? => ( ({...}? => ( (lv_size_1_0= ruleSize ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_2= 'title' ( (lv_title_3_0= RULE_STRING ) ) ) ) ) ) )+ {...}?) ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1284:1: ( ( ( ({...}? => ( ({...}? => ( (lv_size_1_0= ruleSize ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_2= 'title' ( (lv_title_3_0= RULE_STRING ) ) ) ) ) ) )+ {...}?) )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1284:1: ( ( ( ({...}? => ( ({...}? => ( (lv_size_1_0= ruleSize ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_2= 'title' ( (lv_title_3_0= RULE_STRING ) ) ) ) ) ) )+ {...}?) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1285:2: ( ( ({...}? => ( ({...}? => ( (lv_size_1_0= ruleSize ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_2= 'title' ( (lv_title_3_0= RULE_STRING ) ) ) ) ) ) )+ {...}?)
            {
             
            	  getUnorderedGroupHelper().enter(grammarAccess.getWindowOptionsAccess().getUnorderedGroup());
            	
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1288:2: ( ( ({...}? => ( ({...}? => ( (lv_size_1_0= ruleSize ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_2= 'title' ( (lv_title_3_0= RULE_STRING ) ) ) ) ) ) )+ {...}?)
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1289:3: ( ({...}? => ( ({...}? => ( (lv_size_1_0= ruleSize ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_2= 'title' ( (lv_title_3_0= RULE_STRING ) ) ) ) ) ) )+ {...}?
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1289:3: ( ({...}? => ( ({...}? => ( (lv_size_1_0= ruleSize ) ) ) ) ) | ({...}? => ( ({...}? => (otherlv_2= 'title' ( (lv_title_3_0= RULE_STRING ) ) ) ) ) ) )+
            int cnt16=0;
            loop16:
            do {
                int alt16=3;
                int LA16_0 = input.LA(1);

                if ( LA16_0 >=27 && LA16_0<=28 && getUnorderedGroupHelper().canSelect(grammarAccess.getWindowOptionsAccess().getUnorderedGroup(), 0) ) {
                    alt16=1;
                }
                else if ( LA16_0 ==31 && getUnorderedGroupHelper().canSelect(grammarAccess.getWindowOptionsAccess().getUnorderedGroup(), 1) ) {
                    alt16=2;
                }


                switch (alt16) {
            	case 1 :
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1291:4: ({...}? => ( ({...}? => ( (lv_size_1_0= ruleSize ) ) ) ) )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1291:4: ({...}? => ( ({...}? => ( (lv_size_1_0= ruleSize ) ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1292:5: {...}? => ( ({...}? => ( (lv_size_1_0= ruleSize ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getWindowOptionsAccess().getUnorderedGroup(), 0) ) {
            	        throw new FailedPredicateException(input, "ruleWindowOptions", "getUnorderedGroupHelper().canSelect(grammarAccess.getWindowOptionsAccess().getUnorderedGroup(), 0)");
            	    }
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1292:108: ( ({...}? => ( (lv_size_1_0= ruleSize ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1293:6: ({...}? => ( (lv_size_1_0= ruleSize ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getWindowOptionsAccess().getUnorderedGroup(), 0);
            	    	 				
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1296:6: ({...}? => ( (lv_size_1_0= ruleSize ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1296:7: {...}? => ( (lv_size_1_0= ruleSize ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "ruleWindowOptions", "true");
            	    }
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1296:16: ( (lv_size_1_0= ruleSize ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1297:1: (lv_size_1_0= ruleSize )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1297:1: (lv_size_1_0= ruleSize )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1298:3: lv_size_1_0= ruleSize
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getWindowOptionsAccess().getSizeSizeParserRuleCall_0_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleSize_in_ruleWindowOptions3034);
            	    lv_size_1_0=ruleSize();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getWindowOptionsRule());
            	    	        }
            	           		set(
            	           			current, 
            	           			"size",
            	            		lv_size_1_0, 
            	            		"Size");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getWindowOptionsAccess().getUnorderedGroup());
            	    	 				

            	    }


            	    }


            	    }
            	    break;
            	case 2 :
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1321:4: ({...}? => ( ({...}? => (otherlv_2= 'title' ( (lv_title_3_0= RULE_STRING ) ) ) ) ) )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1321:4: ({...}? => ( ({...}? => (otherlv_2= 'title' ( (lv_title_3_0= RULE_STRING ) ) ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1322:5: {...}? => ( ({...}? => (otherlv_2= 'title' ( (lv_title_3_0= RULE_STRING ) ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getWindowOptionsAccess().getUnorderedGroup(), 1) ) {
            	        throw new FailedPredicateException(input, "ruleWindowOptions", "getUnorderedGroupHelper().canSelect(grammarAccess.getWindowOptionsAccess().getUnorderedGroup(), 1)");
            	    }
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1322:108: ( ({...}? => (otherlv_2= 'title' ( (lv_title_3_0= RULE_STRING ) ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1323:6: ({...}? => (otherlv_2= 'title' ( (lv_title_3_0= RULE_STRING ) ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getWindowOptionsAccess().getUnorderedGroup(), 1);
            	    	 				
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1326:6: ({...}? => (otherlv_2= 'title' ( (lv_title_3_0= RULE_STRING ) ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1326:7: {...}? => (otherlv_2= 'title' ( (lv_title_3_0= RULE_STRING ) ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "ruleWindowOptions", "true");
            	    }
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1326:16: (otherlv_2= 'title' ( (lv_title_3_0= RULE_STRING ) ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1326:18: otherlv_2= 'title' ( (lv_title_3_0= RULE_STRING ) )
            	    {
            	    otherlv_2=(Token)match(input,31,FOLLOW_31_in_ruleWindowOptions3101); 

            	        	newLeafNode(otherlv_2, grammarAccess.getWindowOptionsAccess().getTitleKeyword_1_0());
            	        
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1330:1: ( (lv_title_3_0= RULE_STRING ) )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1331:1: (lv_title_3_0= RULE_STRING )
            	    {
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1331:1: (lv_title_3_0= RULE_STRING )
            	    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1332:3: lv_title_3_0= RULE_STRING
            	    {
            	    lv_title_3_0=(Token)match(input,RULE_STRING,FOLLOW_RULE_STRING_in_ruleWindowOptions3118); 

            	    			newLeafNode(lv_title_3_0, grammarAccess.getWindowOptionsAccess().getTitleSTRINGTerminalRuleCall_1_1_0()); 
            	    		

            	    	        if (current==null) {
            	    	            current = createModelElement(grammarAccess.getWindowOptionsRule());
            	    	        }
            	           		setWithLastConsumed(
            	           			current, 
            	           			"title",
            	            		lv_title_3_0, 
            	            		"STRING");
            	    	    

            	    }


            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getWindowOptionsAccess().getUnorderedGroup());
            	    	 				

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt16 >= 1 ) break loop16;
                        EarlyExitException eee =
                            new EarlyExitException(16, input);
                        throw eee;
                }
                cnt16++;
            } while (true);

            if ( ! getUnorderedGroupHelper().canLeave(grammarAccess.getWindowOptionsAccess().getUnorderedGroup()) ) {
                throw new FailedPredicateException(input, "ruleWindowOptions", "getUnorderedGroupHelper().canLeave(grammarAccess.getWindowOptionsAccess().getUnorderedGroup())");
            }

            }


            }

             
            	  getUnorderedGroupHelper().leave(grammarAccess.getWindowOptionsAccess().getUnorderedGroup());
            	

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleWindowOptions"


    // $ANTLR start "ruleBasicType"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1371:1: ruleBasicType returns [Enumerator current=null] : ( (enumLiteral_0= 'String' ) | (enumLiteral_1= 'Integer' ) | (enumLiteral_2= 'Date' ) ) ;
    public final Enumerator ruleBasicType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;

         enterRule(); 
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1373:28: ( ( (enumLiteral_0= 'String' ) | (enumLiteral_1= 'Integer' ) | (enumLiteral_2= 'Date' ) ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1374:1: ( (enumLiteral_0= 'String' ) | (enumLiteral_1= 'Integer' ) | (enumLiteral_2= 'Date' ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1374:1: ( (enumLiteral_0= 'String' ) | (enumLiteral_1= 'Integer' ) | (enumLiteral_2= 'Date' ) )
            int alt17=3;
            switch ( input.LA(1) ) {
            case 32:
                {
                alt17=1;
                }
                break;
            case 33:
                {
                alt17=2;
                }
                break;
            case 34:
                {
                alt17=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }

            switch (alt17) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1374:2: (enumLiteral_0= 'String' )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1374:2: (enumLiteral_0= 'String' )
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1374:4: enumLiteral_0= 'String'
                    {
                    enumLiteral_0=(Token)match(input,32,FOLLOW_32_in_ruleBasicType3219); 

                            current = grammarAccess.getBasicTypeAccess().getSTRINGEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_0, grammarAccess.getBasicTypeAccess().getSTRINGEnumLiteralDeclaration_0()); 
                        

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1380:6: (enumLiteral_1= 'Integer' )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1380:6: (enumLiteral_1= 'Integer' )
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1380:8: enumLiteral_1= 'Integer'
                    {
                    enumLiteral_1=(Token)match(input,33,FOLLOW_33_in_ruleBasicType3236); 

                            current = grammarAccess.getBasicTypeAccess().getINTEGEREnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_1, grammarAccess.getBasicTypeAccess().getINTEGEREnumLiteralDeclaration_1()); 
                        

                    }


                    }
                    break;
                case 3 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1386:6: (enumLiteral_2= 'Date' )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1386:6: (enumLiteral_2= 'Date' )
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1386:8: enumLiteral_2= 'Date'
                    {
                    enumLiteral_2=(Token)match(input,34,FOLLOW_34_in_ruleBasicType3253); 

                            current = grammarAccess.getBasicTypeAccess().getDATEEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_2, grammarAccess.getBasicTypeAccess().getDATEEnumLiteralDeclaration_2()); 
                        

                    }


                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBasicType"


    // $ANTLR start "ruleMultiplicity"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1396:1: ruleMultiplicity returns [Enumerator current=null] : ( (enumLiteral_0= 'one' ) | (enumLiteral_1= 'multiple' ) ) ;
    public final Enumerator ruleMultiplicity() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;

         enterRule(); 
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1398:28: ( ( (enumLiteral_0= 'one' ) | (enumLiteral_1= 'multiple' ) ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1399:1: ( (enumLiteral_0= 'one' ) | (enumLiteral_1= 'multiple' ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1399:1: ( (enumLiteral_0= 'one' ) | (enumLiteral_1= 'multiple' ) )
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==35) ) {
                alt18=1;
            }
            else if ( (LA18_0==36) ) {
                alt18=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 18, 0, input);

                throw nvae;
            }
            switch (alt18) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1399:2: (enumLiteral_0= 'one' )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1399:2: (enumLiteral_0= 'one' )
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1399:4: enumLiteral_0= 'one'
                    {
                    enumLiteral_0=(Token)match(input,35,FOLLOW_35_in_ruleMultiplicity3298); 

                            current = grammarAccess.getMultiplicityAccess().getONEEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_0, grammarAccess.getMultiplicityAccess().getONEEnumLiteralDeclaration_0()); 
                        

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1405:6: (enumLiteral_1= 'multiple' )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1405:6: (enumLiteral_1= 'multiple' )
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1405:8: enumLiteral_1= 'multiple'
                    {
                    enumLiteral_1=(Token)match(input,36,FOLLOW_36_in_ruleMultiplicity3315); 

                            current = grammarAccess.getMultiplicityAccess().getMULTIPLEEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_1, grammarAccess.getMultiplicityAccess().getMULTIPLEEnumLiteralDeclaration_1()); 
                        

                    }


                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMultiplicity"


    // $ANTLR start "ruleInscription"
    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1415:1: ruleInscription returns [Enumerator current=null] : ( (enumLiteral_0= 'Create/Edit' ) | (enumLiteral_1= 'Delete' ) | (enumLiteral_2= 'Cancel' ) ) ;
    public final Enumerator ruleInscription() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;

         enterRule(); 
        try {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1417:28: ( ( (enumLiteral_0= 'Create/Edit' ) | (enumLiteral_1= 'Delete' ) | (enumLiteral_2= 'Cancel' ) ) )
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1418:1: ( (enumLiteral_0= 'Create/Edit' ) | (enumLiteral_1= 'Delete' ) | (enumLiteral_2= 'Cancel' ) )
            {
            // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1418:1: ( (enumLiteral_0= 'Create/Edit' ) | (enumLiteral_1= 'Delete' ) | (enumLiteral_2= 'Cancel' ) )
            int alt19=3;
            switch ( input.LA(1) ) {
            case 37:
                {
                alt19=1;
                }
                break;
            case 38:
                {
                alt19=2;
                }
                break;
            case 39:
                {
                alt19=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }

            switch (alt19) {
                case 1 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1418:2: (enumLiteral_0= 'Create/Edit' )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1418:2: (enumLiteral_0= 'Create/Edit' )
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1418:4: enumLiteral_0= 'Create/Edit'
                    {
                    enumLiteral_0=(Token)match(input,37,FOLLOW_37_in_ruleInscription3360); 

                            current = grammarAccess.getInscriptionAccess().getCREATE_EDITEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_0, grammarAccess.getInscriptionAccess().getCREATE_EDITEnumLiteralDeclaration_0()); 
                        

                    }


                    }
                    break;
                case 2 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1424:6: (enumLiteral_1= 'Delete' )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1424:6: (enumLiteral_1= 'Delete' )
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1424:8: enumLiteral_1= 'Delete'
                    {
                    enumLiteral_1=(Token)match(input,38,FOLLOW_38_in_ruleInscription3377); 

                            current = grammarAccess.getInscriptionAccess().getDELETEEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_1, grammarAccess.getInscriptionAccess().getDELETEEnumLiteralDeclaration_1()); 
                        

                    }


                    }
                    break;
                case 3 :
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1430:6: (enumLiteral_2= 'Cancel' )
                    {
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1430:6: (enumLiteral_2= 'Cancel' )
                    // ../de.wwu.pi.mdsd.group05DSL/src-gen/de/wwu/pi/mdsd05/parser/antlr/internal/InternalGroup05DSL.g:1430:8: enumLiteral_2= 'Cancel'
                    {
                    enumLiteral_2=(Token)match(input,39,FOLLOW_39_in_ruleInscription3394); 

                            current = grammarAccess.getInscriptionAccess().getCANCELEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_2, grammarAccess.getInscriptionAccess().getCANCELEnumLiteralDeclaration_2()); 
                        

                    }


                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInscription"

    // Delegated rules


 

    public static final BitSet FOLLOW_ruleModel_in_entryRuleModel75 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleModel85 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePackage_in_ruleModel131 = new BitSet(new long[]{0x0000000000A06002L});
    public static final BitSet FOLLOW_ruleEntitytype_in_ruleModel153 = new BitSet(new long[]{0x0000000000A06002L});
    public static final BitSet FOLLOW_ruleUIWindow_in_ruleModel180 = new BitSet(new long[]{0x0000000000A06002L});
    public static final BitSet FOLLOW_rulePackage_in_entryRulePackage218 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRulePackage228 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_11_in_rulePackage265 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ruleQualifiedName_in_rulePackage286 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleQualifiedName_in_entryRuleQualifiedName323 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleQualifiedName334 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleQualifiedName374 = new BitSet(new long[]{0x0000000000001002L});
    public static final BitSet FOLLOW_12_in_ruleQualifiedName393 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleQualifiedName408 = new BitSet(new long[]{0x0000000000001002L});
    public static final BitSet FOLLOW_ruleEntitytype_in_entryRuleEntitytype455 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleEntitytype465 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_13_in_ruleEntitytype508 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_14_in_ruleEntitytype534 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleEntitytype551 = new BitSet(new long[]{0x0000000000018000L});
    public static final BitSet FOLLOW_15_in_ruleEntitytype569 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleEntitytype589 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_ruleEntitytype603 = new BitSet(new long[]{0x0000000000140000L});
    public static final BitSet FOLLOW_ruleProperty_in_ruleEntitytype624 = new BitSet(new long[]{0x0000000000160000L});
    public static final BitSet FOLLOW_17_in_ruleEntitytype637 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleProperty_in_entryRuleProperty673 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleProperty683 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAttribute_in_ruleProperty730 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleReference_in_ruleProperty757 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAttribute_in_entryRuleAttribute792 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleAttribute802 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_18_in_ruleAttribute839 = new BitSet(new long[]{0x0000000700000000L});
    public static final BitSet FOLLOW_ruleBasicType_in_ruleAttribute860 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleAttribute877 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_19_in_ruleAttribute900 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleReference_in_entryRuleReference950 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleReference960 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_20_in_ruleReference997 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleReference1017 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleReference1034 = new BitSet(new long[]{0x0000001800000002L});
    public static final BitSet FOLLOW_ruleMultiplicity_in_ruleReference1060 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleUIWindow_in_entryRuleUIWindow1097 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleUIWindow1107 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleListWindow_in_ruleUIWindow1154 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEntryWindow_in_ruleUIWindow1181 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleListWindow_in_entryRuleListWindow1216 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleListWindow1226 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_21_in_ruleListWindow1263 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleListWindow1280 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_22_in_ruleListWindow1297 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleListWindow1317 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_ruleListWindow1329 = new BitSet(new long[]{0x0000000098000000L});
    public static final BitSet FOLLOW_ruleWindowOptions_in_ruleListWindow1350 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_17_in_ruleListWindow1362 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEntryWindow_in_entryRuleEntryWindow1398 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleEntryWindow1408 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_23_in_ruleEntryWindow1445 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleEntryWindow1462 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_22_in_ruleEntryWindow1479 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleEntryWindow1499 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_ruleEntryWindow1511 = new BitSet(new long[]{0x0000000098000000L});
    public static final BitSet FOLLOW_ruleWindowOptions_in_ruleEntryWindow1532 = new BitSet(new long[]{0x0000000007000000L});
    public static final BitSet FOLLOW_ruleUIElement_in_ruleEntryWindow1553 = new BitSet(new long[]{0x0000000007020000L});
    public static final BitSet FOLLOW_17_in_ruleEntryWindow1566 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleUIElement_in_entryRuleUIElement1602 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleUIElement1612 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleLabel_in_ruleUIElement1660 = new BitSet(new long[]{0x0000000078000000L});
    public static final BitSet FOLLOW_ruleField_in_ruleUIElement1687 = new BitSet(new long[]{0x0000000078000000L});
    public static final BitSet FOLLOW_ruleButton_in_ruleUIElement1714 = new BitSet(new long[]{0x0000000078000000L});
    public static final BitSet FOLLOW_ruleUIOptions_in_ruleUIElement1735 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleUIOptions_in_entryRuleUIOptions1771 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleUIOptions1781 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePosition_in_ruleUIOptions1871 = new BitSet(new long[]{0x0000000078000002L});
    public static final BitSet FOLLOW_ruleSize_in_ruleUIOptions1946 = new BitSet(new long[]{0x0000000078000002L});
    public static final BitSet FOLLOW_ruleLabel_in_entryRuleLabel2027 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleLabel2037 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_24_in_ruleLabel2074 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleLabel2091 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_RULE_STRING_in_ruleLabel2113 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleField_in_entryRuleField2155 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleField2165 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_25_in_ruleField2202 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleField2222 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleButton_in_entryRuleButton2258 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleButton2268 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_26_in_ruleButton2305 = new BitSet(new long[]{0x000000E000000000L});
    public static final BitSet FOLLOW_ruleInscription_in_ruleButton2326 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleSize_in_entryRuleSize2362 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleSize2372 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_27_in_ruleSize2454 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_RULE_INT_in_ruleSize2471 = new BitSet(new long[]{0x0000000018000002L});
    public static final BitSet FOLLOW_28_in_ruleSize2544 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_RULE_INT_in_ruleSize2561 = new BitSet(new long[]{0x0000000018000002L});
    public static final BitSet FOLLOW_rulePosition_in_entryRulePosition2648 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRulePosition2658 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_29_in_rulePosition2740 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_RULE_INT_in_rulePosition2757 = new BitSet(new long[]{0x0000000060000002L});
    public static final BitSet FOLLOW_30_in_rulePosition2830 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_RULE_INT_in_rulePosition2847 = new BitSet(new long[]{0x0000000060000002L});
    public static final BitSet FOLLOW_ruleWindowOptions_in_entryRuleWindowOptions2934 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleWindowOptions2944 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleSize_in_ruleWindowOptions3034 = new BitSet(new long[]{0x0000000098000002L});
    public static final BitSet FOLLOW_31_in_ruleWindowOptions3101 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_RULE_STRING_in_ruleWindowOptions3118 = new BitSet(new long[]{0x0000000098000002L});
    public static final BitSet FOLLOW_32_in_ruleBasicType3219 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_ruleBasicType3236 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_34_in_ruleBasicType3253 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_35_in_ruleMultiplicity3298 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_36_in_ruleMultiplicity3315 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_37_in_ruleInscription3360 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_38_in_ruleInscription3377 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_39_in_ruleInscription3394 = new BitSet(new long[]{0x0000000000000002L});

}
