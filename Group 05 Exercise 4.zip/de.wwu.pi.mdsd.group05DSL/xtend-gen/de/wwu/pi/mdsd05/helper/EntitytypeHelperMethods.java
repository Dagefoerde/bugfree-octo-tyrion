package de.wwu.pi.mdsd05.helper;

import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import de.wwu.pi.mdsd05.group05DSL.Entitytype;
import de.wwu.pi.mdsd05.group05DSL.Model;
import de.wwu.pi.mdsd05.group05DSL.Multiplicity;
import de.wwu.pi.mdsd05.group05DSL.Property;
import de.wwu.pi.mdsd05.group05DSL.Reference;
import java.util.HashSet;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class EntitytypeHelperMethods {
  public static BasicEList<Property> getAllPropertiesIncludingSuperproperties(final Entitytype type) {
    HashSet<Entitytype> _hashSet = new HashSet<Entitytype>();
    final HashSet<Entitytype> visitedEntitytypes = _hashSet;
    Entitytype entitytype = type;
    BasicEList<Property> _basicEList = new BasicEList<Property>();
    BasicEList<Property> properties = _basicEList;
    boolean _and = false;
    boolean _notEquals = (!Objects.equal(entitytype, null));
    if (!_notEquals) {
      _and = false;
    } else {
      boolean _contains = visitedEntitytypes.contains(entitytype);
      boolean _not = (!_contains);
      _and = (_notEquals && _not);
    }
    boolean _while = _and;
    while (_while) {
      {
        visitedEntitytypes.add(entitytype);
        EList<Property> _properties = entitytype.getProperties();
        Iterables.<Property>addAll(properties, _properties);
        Entitytype _supertype = entitytype.getSupertype();
        entitytype = _supertype;
      }
      boolean _and_1 = false;
      boolean _notEquals_1 = (!Objects.equal(entitytype, null));
      if (!_notEquals_1) {
        _and_1 = false;
      } else {
        boolean _contains_1 = visitedEntitytypes.contains(entitytype);
        boolean _not_1 = (!_contains_1);
        _and_1 = (_notEquals_1 && _not_1);
      }
      _while = _and_1;
    }
    return properties;
  }
  
  public static boolean hasCyclicInheritance(final Entitytype entity) {
    HashSet<Entitytype> _hashSet = new HashSet<Entitytype>();
    final HashSet<Entitytype> visitedEntitytypes = _hashSet;
    Entitytype entitytype = entity;
    boolean _notEquals = (!Objects.equal(entitytype, null));
    boolean _while = _notEquals;
    while (_while) {
      {
        boolean _contains = visitedEntitytypes.contains(entitytype);
        if (_contains) {
          return true;
        }
        visitedEntitytypes.add(entitytype);
        Entitytype _supertype = entitytype.getSupertype();
        entitytype = _supertype;
      }
      boolean _notEquals_1 = (!Objects.equal(entitytype, null));
      _while = _notEquals_1;
    }
    return false;
  }
  
  public static boolean hasWrongOppositeReference(final Reference ref) {
    EObject _eContainer = ref.eContainer();
    final Entitytype entity = ((Entitytype) _eContainer);
    final Multiplicity mult = ref.getMultiplicity();
    Entitytype _references = ref.getReferences();
    EList<Property> _properties = _references.getProperties();
    final Function1<Property,Boolean> _function = new Function1<Property,Boolean>() {
        public Boolean apply(final Property re) {
          return Boolean.valueOf((re instanceof Reference));
        }
      };
    Iterable<Property> _filter = IterableExtensions.<Property>filter(_properties, _function);
    final Function1<Property,Reference> _function_1 = new Function1<Property,Reference>() {
        public Reference apply(final Property re) {
          return ((Reference) re);
        }
      };
    Iterable<Reference> _map = IterableExtensions.<Property, Reference>map(_filter, _function_1);
    final Function1<Reference,Boolean> _function_2 = new Function1<Reference,Boolean>() {
        public Boolean apply(final Reference re) {
          boolean _and = false;
          Entitytype _references = re.getReferences();
          boolean _equals = Objects.equal(_references, entity);
          if (!_equals) {
            _and = false;
          } else {
            Multiplicity _multiplicity = re.getMultiplicity();
            boolean _equals_1 = mult.equals(_multiplicity);
            boolean _not = (!_equals_1);
            _and = (_equals && _not);
          }
          return Boolean.valueOf(_and);
        }
      };
    final Iterable<Reference> opposite = IterableExtensions.<Reference>filter(_map, _function_2);
    int _size = IterableExtensions.size(opposite);
    boolean _lessThan = (_size < 1);
    if (_lessThan) {
      return true;
    }
    return false;
  }
  
  public static boolean isSuperClassAnywhere(final Entitytype entitytype) {
    EObject _eContainer = entitytype.eContainer();
    EList<Entitytype> entitytypes = ((Model) _eContainer).getEntitytypes();
    for (final Entitytype e : entitytypes) {
      boolean _and = false;
      Entitytype _supertype = e.getSupertype();
      boolean _notEquals = (!Objects.equal(_supertype, null));
      if (!_notEquals) {
        _and = false;
      } else {
        Entitytype _supertype_1 = e.getSupertype();
        boolean _equals = _supertype_1.equals(entitytype);
        _and = (_notEquals && _equals);
      }
      if (_and) {
        return true;
      }
    }
    return false;
  }
  
  public static boolean referencesItself(final Reference ref) {
    EObject _eContainer = ref.eContainer();
    final Entitytype entity = ((Entitytype) _eContainer);
    Entitytype _references = ref.getReferences();
    boolean _equals = _references.equals(entity);
    if (_equals) {
      return true;
    }
    return false;
  }
  
  public static boolean referencesSubOrSuperclass(final Reference ref) {
    EObject _eContainer = ref.eContainer();
    final Entitytype entity = ((Entitytype) _eContainer);
    Entitytype loopEntity = entity;
    HashSet<Entitytype> _hashSet = new HashSet<Entitytype>();
    final HashSet<Entitytype> superClasses = _hashSet;
    boolean _and = false;
    Entitytype _supertype = loopEntity.getSupertype();
    boolean _notEquals = (!Objects.equal(_supertype, null));
    if (!_notEquals) {
      _and = false;
    } else {
      boolean _contains = superClasses.contains(loopEntity);
      boolean _not = (!_contains);
      _and = (_notEquals && _not);
    }
    boolean _while = _and;
    while (_while) {
      {
        Entitytype _supertype_1 = loopEntity.getSupertype();
        superClasses.add(_supertype_1);
        Entitytype _supertype_2 = loopEntity.getSupertype();
        loopEntity = _supertype_2;
      }
      boolean _and_1 = false;
      Entitytype _supertype_1 = loopEntity.getSupertype();
      boolean _notEquals_1 = (!Objects.equal(_supertype_1, null));
      if (!_notEquals_1) {
        _and_1 = false;
      } else {
        boolean _contains_1 = superClasses.contains(loopEntity);
        boolean _not_1 = (!_contains_1);
        _and_1 = (_notEquals_1 && _not_1);
      }
      _while = _and_1;
    }
    HashSet<Entitytype> _hashSet_1 = new HashSet<Entitytype>();
    final HashSet<Entitytype> subClasses = _hashSet_1;
    subClasses.add(entity);
    HashSet<Entitytype> _hashSet_2 = new HashSet<Entitytype>();
    final HashSet<Entitytype> leftClasses = _hashSet_2;
    EObject _eContainer_1 = entity.eContainer();
    EList<Entitytype> _entitytypes = ((Model) _eContainer_1).getEntitytypes();
    final Function1<Entitytype,Boolean> _function = new Function1<Entitytype,Boolean>() {
        public Boolean apply(final Entitytype c) {
          boolean _and = false;
          boolean _equals = c.equals(entity);
          boolean _not = (!_equals);
          if (!_not) {
            _and = false;
          } else {
            boolean _contains = superClasses.contains(c);
            boolean _not_1 = (!_contains);
            _and = (_not && _not_1);
          }
          return Boolean.valueOf(_and);
        }
      };
    Iterable<Entitytype> _filter = IterableExtensions.<Entitytype>filter(_entitytypes, _function);
    Iterables.<Entitytype>addAll(leftClasses, _filter);
    boolean foundSomething = true;
    boolean _while_1 = foundSomething;
    while (_while_1) {
      {
        foundSomething = false;
        for (final Entitytype clazz : leftClasses) {
          boolean _and_1 = false;
          boolean _and_2 = false;
          boolean _contains_1 = subClasses.contains(clazz);
          boolean _not_1 = (!_contains_1);
          if (!_not_1) {
            _and_2 = false;
          } else {
            Entitytype _supertype_1 = clazz.getSupertype();
            boolean _notEquals_1 = (!Objects.equal(_supertype_1, null));
            _and_2 = (_not_1 && _notEquals_1);
          }
          if (!_and_2) {
            _and_1 = false;
          } else {
            Entitytype _supertype_2 = clazz.getSupertype();
            boolean _contains_2 = subClasses.contains(_supertype_2);
            _and_1 = (_and_2 && _contains_2);
          }
          if (_and_1) {
            subClasses.add(clazz);
            foundSomething = true;
          }
        }
      }
      _while_1 = foundSomething;
    }
    subClasses.remove(entity);
    Entitytype _references = ref.getReferences();
    boolean _contains_1 = superClasses.contains(_references);
    if (_contains_1) {
      return true;
    }
    Entitytype _references_1 = ref.getReferences();
    boolean _contains_2 = subClasses.contains(_references_1);
    if (_contains_2) {
      return true;
    }
    return false;
  }
  
  public static boolean hasDoubleReference(final Reference ref) {
    EObject _eContainer = ref.eContainer();
    final Entitytype entity = ((Entitytype) _eContainer);
    EList<Property> _properties = entity.getProperties();
    final Function1<Property,Boolean> _function = new Function1<Property,Boolean>() {
        public Boolean apply(final Property prop) {
          return Boolean.valueOf((prop instanceof Reference));
        }
      };
    Iterable<Property> _filter = IterableExtensions.<Property>filter(_properties, _function);
    final Function1<Property,Reference> _function_1 = new Function1<Property,Reference>() {
        public Reference apply(final Property prop) {
          return ((Reference) prop);
        }
      };
    Iterable<Reference> _map = IterableExtensions.<Property, Reference>map(_filter, _function_1);
    for (final Reference re : _map) {
      boolean _and = false;
      boolean _and_1 = false;
      boolean _equals = re.equals(ref);
      boolean _not = (!_equals);
      if (!_not) {
        _and_1 = false;
      } else {
        Entitytype _references = re.getReferences();
        Entitytype _references_1 = ref.getReferences();
        boolean _equals_1 = _references.equals(_references_1);
        _and_1 = (_not && _equals_1);
      }
      if (!_and_1) {
        _and = false;
      } else {
        Multiplicity _multiplicity = re.getMultiplicity();
        Multiplicity _multiplicity_1 = ref.getMultiplicity();
        boolean _equals_2 = _multiplicity.equals(_multiplicity_1);
        _and = (_and_1 && _equals_2);
      }
      if (_and) {
        return true;
      }
    }
    return false;
  }
}
