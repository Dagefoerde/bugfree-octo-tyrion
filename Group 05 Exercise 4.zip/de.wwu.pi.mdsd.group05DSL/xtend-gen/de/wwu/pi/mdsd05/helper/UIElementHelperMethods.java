package de.wwu.pi.mdsd05.helper;

import de.wwu.pi.mdsd05.group05DSL.Position;
import de.wwu.pi.mdsd05.group05DSL.Size;
import de.wwu.pi.mdsd05.group05DSL.UIElement;
import de.wwu.pi.mdsd05.group05DSL.UIOptions;

@SuppressWarnings("all")
public class UIElementHelperMethods {
  public static boolean overlapping(final UIElement element, final UIElement element2) {
    final UIOptions options1 = element.getUiOptions();
    final UIOptions options2 = element2.getUiOptions();
    Position _position = options1.getPosition();
    int _x = _position.getX();
    Size _size = options1.getSize();
    int _width = _size.getWidth();
    int _plus = (_x + _width);
    Position _position_1 = options2.getPosition();
    int _x_1 = _position_1.getX();
    boolean _lessThan = (_plus < _x_1);
    if (_lessThan) {
      return false;
    }
    Position _position_2 = options1.getPosition();
    int _y = _position_2.getY();
    Size _size_1 = options1.getSize();
    int _height = _size_1.getHeight();
    int _plus_1 = (_y + _height);
    Position _position_3 = options2.getPosition();
    int _y_1 = _position_3.getY();
    boolean _lessThan_1 = (_plus_1 < _y_1);
    if (_lessThan_1) {
      return false;
    }
    Position _position_4 = options2.getPosition();
    int _y_2 = _position_4.getY();
    Size _size_2 = options2.getSize();
    int _height_1 = _size_2.getHeight();
    int _plus_2 = (_y_2 + _height_1);
    Position _position_5 = options1.getPosition();
    int _y_3 = _position_5.getY();
    boolean _lessThan_2 = (_plus_2 < _y_3);
    if (_lessThan_2) {
      return false;
    }
    Position _position_6 = options2.getPosition();
    int _x_2 = _position_6.getX();
    Size _size_3 = options2.getSize();
    int _width_1 = _size_3.getWidth();
    int _plus_3 = (_x_2 + _width_1);
    Position _position_7 = options1.getPosition();
    int _x_3 = _position_7.getX();
    boolean _lessThan_3 = (_plus_3 < _x_3);
    if (_lessThan_3) {
      return false;
    }
    return true;
  }
}
