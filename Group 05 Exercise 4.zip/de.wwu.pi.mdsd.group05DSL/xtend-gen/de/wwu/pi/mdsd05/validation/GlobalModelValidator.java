package de.wwu.pi.mdsd05.validation;

import com.google.common.base.Objects;
import de.wwu.pi.mdsd05.group05DSL.Entitytype;
import de.wwu.pi.mdsd05.group05DSL.EntryWindow;
import de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage.Literals;
import de.wwu.pi.mdsd05.group05DSL.Label;
import de.wwu.pi.mdsd05.group05DSL.Model;
import de.wwu.pi.mdsd05.group05DSL.Property;
import de.wwu.pi.mdsd05.group05DSL.UIElement;
import de.wwu.pi.mdsd05.group05DSL.UIWindow;
import de.wwu.pi.mdsd05.helper.EntitytypeHelperMethods;
import de.wwu.pi.mdsd05.validation.AbstractGroup05DSLValidator;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.validation.Check;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

/**
 * Custom validation rules.
 * 
 * see http://www.eclipse.org/Xtext/documentation.html#validation
 */
@SuppressWarnings("all")
public class GlobalModelValidator extends AbstractGroup05DSLValidator {
  @Check
  public void checkMinEntityAndWindow(final Model model) {
    boolean _or = false;
    EList<Entitytype> _entitytypes = model.getEntitytypes();
    int _size = _entitytypes.size();
    boolean _equals = (_size == 0);
    if (_equals) {
      _or = true;
    } else {
      EList<UIWindow> _uiwindows = model.getUiwindows();
      int _size_1 = _uiwindows.size();
      boolean _equals_1 = (_size_1 == 0);
      _or = (_equals || _equals_1);
    }
    if (_or) {
      this.warning("At least one Entitytype and one UIWindow should be modeled.", 
        Literals.MODEL__PACKAGE);
    }
  }
  
  @Check
  public void EntitytypesHaveTheSameName(final Entitytype entitytype) {
    EObject _eContainer = entitytype.eContainer();
    EList<Entitytype> entitytypes = ((Model) _eContainer).getEntitytypes();
    for (final Entitytype e : entitytypes) {
      boolean _and = false;
      boolean _and_1 = false;
      String _name = e.getName();
      boolean _notEquals = (!Objects.equal(_name, null));
      if (!_notEquals) {
        _and_1 = false;
      } else {
        boolean _notEquals_1 = (!Objects.equal(e, entitytype));
        _and_1 = (_notEquals && _notEquals_1);
      }
      if (!_and_1) {
        _and = false;
      } else {
        String _name_1 = e.getName();
        String _name_2 = entitytype.getName();
        boolean _equals = _name_1.equals(_name_2);
        _and = (_and_1 && _equals);
      }
      if (_and) {
        this.error("Entitytype with the same name already exists", Literals.ENTITYTYPE__NAME);
      }
    }
  }
  
  @Check
  public void PropertiesHaveTheSameName(final Property property) {
    EObject _eContainer = property.eContainer();
    BasicEList<Property> properties = EntitytypeHelperMethods.getAllPropertiesIncludingSuperproperties(((Entitytype) _eContainer));
    for (final Property p : properties) {
      boolean _and = false;
      boolean _and_1 = false;
      String _name = p.getName();
      boolean _notEquals = (!Objects.equal(_name, null));
      if (!_notEquals) {
        _and_1 = false;
      } else {
        boolean _notEquals_1 = (!Objects.equal(p, property));
        _and_1 = (_notEquals && _notEquals_1);
      }
      if (!_and_1) {
        _and = false;
      } else {
        String _name_1 = p.getName();
        String _name_2 = property.getName();
        boolean _equals = _name_1.equals(_name_2);
        _and = (_and_1 && _equals);
      }
      if (_and) {
        this.error("A property with the same name already exists in this class or in a superclass.", 
          Literals.PROPERTY__NAME);
      }
    }
  }
  
  @Check
  public void LabelsHaveTheSameName(final Label label) {
    EObject _eContainer = label.eContainer();
    EList<UIElement> _elements = ((EntryWindow) _eContainer).getElements();
    final Function1<UIElement,Boolean> _function = new Function1<UIElement,Boolean>() {
        public Boolean apply(final UIElement l) {
          return Boolean.valueOf((l instanceof Label));
        }
      };
    Iterable<UIElement> _filter = IterableExtensions.<UIElement>filter(_elements, _function);
    final Function1<UIElement,Label> _function_1 = new Function1<UIElement,Label>() {
        public Label apply(final UIElement l) {
          return ((Label) l);
        }
      };
    Iterable<Label> labels = IterableExtensions.<UIElement, Label>map(_filter, _function_1);
    for (final Label l : labels) {
      boolean _and = false;
      boolean _and_1 = false;
      String _name = l.getName();
      boolean _notEquals = (!Objects.equal(_name, null));
      if (!_notEquals) {
        _and_1 = false;
      } else {
        boolean _notEquals_1 = (!Objects.equal(l, label));
        _and_1 = (_notEquals && _notEquals_1);
      }
      if (!_and_1) {
        _and = false;
      } else {
        String _name_1 = l.getName();
        String _name_2 = label.getName();
        boolean _equals = _name_1.equals(_name_2);
        _and = (_and_1 && _equals);
      }
      if (_and) {
        this.error("A label with the same name already exists", Literals.LABEL__NAME);
      }
    }
  }
  
  @Check
  public void WindowsHaveTheSameName(final UIWindow window) {
    EObject _eContainer = window.eContainer();
    EList<UIWindow> windows = ((Model) _eContainer).getUiwindows();
    for (final UIWindow w : windows) {
      boolean _and = false;
      boolean _and_1 = false;
      String _name = w.getName();
      boolean _notEquals = (!Objects.equal(_name, null));
      if (!_notEquals) {
        _and_1 = false;
      } else {
        boolean _notEquals_1 = (!Objects.equal(w, window));
        _and_1 = (_notEquals && _notEquals_1);
      }
      if (!_and_1) {
        _and = false;
      } else {
        String _name_1 = w.getName();
        String _name_2 = window.getName();
        boolean _equals = _name_1.equals(_name_2);
        _and = (_and_1 && _equals);
      }
      if (_and) {
        this.error("A window with the same name already exists", Literals.UI_WINDOW__NAME);
      }
    }
  }
}
