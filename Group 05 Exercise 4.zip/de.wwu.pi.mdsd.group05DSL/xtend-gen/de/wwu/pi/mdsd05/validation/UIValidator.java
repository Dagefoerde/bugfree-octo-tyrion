package de.wwu.pi.mdsd05.validation;

import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import de.wwu.pi.mdsd05.group05DSL.Attribute;
import de.wwu.pi.mdsd05.group05DSL.Button;
import de.wwu.pi.mdsd05.group05DSL.Entitytype;
import de.wwu.pi.mdsd05.group05DSL.EntryWindow;
import de.wwu.pi.mdsd05.group05DSL.Field;
import de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage.Literals;
import de.wwu.pi.mdsd05.group05DSL.Inscription;
import de.wwu.pi.mdsd05.group05DSL.ListWindow;
import de.wwu.pi.mdsd05.group05DSL.Model;
import de.wwu.pi.mdsd05.group05DSL.Property;
import de.wwu.pi.mdsd05.group05DSL.UIElement;
import de.wwu.pi.mdsd05.group05DSL.UIWindow;
import de.wwu.pi.mdsd05.helper.EntitytypeHelperMethods;
import de.wwu.pi.mdsd05.helper.UIElementHelperMethods;
import de.wwu.pi.mdsd05.validation.AbstractGroup05DSLValidator;
import java.util.ArrayList;
import java.util.List;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.validation.Check;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;

/**
 * Custom validation rules.
 * 
 * see http://www.eclipse.org/Xtext/documentation.html#validation
 */
@SuppressWarnings("all")
public class UIValidator extends AbstractGroup05DSLValidator {
  @Check
  public void checkWindowLimit(final Entitytype entitytype) {
    EObject _eContainer = entitytype.eContainer();
    final Model model = ((Model) _eContainer);
    EList<UIWindow> _uiwindows = model.getUiwindows();
    final Function1<UIWindow,Boolean> _function = new Function1<UIWindow,Boolean>() {
        public Boolean apply(final UIWindow it) {
          boolean _and = false;
          if (!(it instanceof EntryWindow)) {
            _and = false;
          } else {
            Entitytype _entitytype = it.getEntitytype();
            boolean _equals = Objects.equal(_entitytype, entitytype);
            _and = ((it instanceof EntryWindow) && _equals);
          }
          return Boolean.valueOf(_and);
        }
      };
    Iterable<UIWindow> entryWindows = IterableExtensions.<UIWindow>filter(_uiwindows, _function);
    EList<UIWindow> _uiwindows_1 = model.getUiwindows();
    final Function1<UIWindow,Boolean> _function_1 = new Function1<UIWindow,Boolean>() {
        public Boolean apply(final UIWindow it) {
          boolean _and = false;
          if (!(it instanceof ListWindow)) {
            _and = false;
          } else {
            Entitytype _entitytype = it.getEntitytype();
            boolean _equals = Objects.equal(_entitytype, entitytype);
            _and = ((it instanceof ListWindow) && _equals);
          }
          return Boolean.valueOf(_and);
        }
      };
    Iterable<UIWindow> listWindows = IterableExtensions.<UIWindow>filter(_uiwindows_1, _function_1);
    int _size = IterableExtensions.size(entryWindows);
    boolean _greaterThan = (_size > 1);
    if (_greaterThan) {
      String _name = entitytype.getName();
      String _plus = ("Entitytype " + _name);
      String _plus_1 = (_plus + " has more than one entry window.");
      this.error(_plus_1, entitytype, 
        Literals.ENTITYTYPE__NAME);
    }
    int _size_1 = IterableExtensions.size(listWindows);
    boolean _greaterThan_1 = (_size_1 > 1);
    if (_greaterThan_1) {
      String _name_1 = entitytype.getName();
      String _plus_2 = ("Entitytype " + _name_1);
      String _plus_3 = (_plus_2 + " has more than one list window.");
      this.error(_plus_3, entitytype, 
        Literals.ENTITYTYPE__NAME);
    }
  }
  
  @Check
  public void checkUIElementOverlapping(final UIElement uiElement) {
    EObject _eContainer = uiElement.eContainer();
    final EntryWindow window = ((EntryWindow) _eContainer);
    EList<UIElement> _elements = window.getElements();
    final Function1<UIElement,Boolean> _function = new Function1<UIElement,Boolean>() {
        public Boolean apply(final UIElement elem) {
          boolean _equals = elem.equals(uiElement);
          boolean _not = (!_equals);
          return Boolean.valueOf(_not);
        }
      };
    Iterable<UIElement> _filter = IterableExtensions.<UIElement>filter(_elements, _function);
    for (final UIElement element : _filter) {
      boolean _overlapping = UIElementHelperMethods.overlapping(element, uiElement);
      if (_overlapping) {
        this.warning("A UI Element is overlapping with another UI Element.", Literals.UI_ELEMENT__UI_OPTIONS);
      }
    }
  }
  
  @Check
  public void areAllPropertiesIncludedInTheEntrywindow(final EntryWindow entryWindow) {
    Entitytype _entitytype = entryWindow.getEntitytype();
    BasicEList<Property> _allPropertiesIncludingSuperproperties = EntitytypeHelperMethods.getAllPropertiesIncludingSuperproperties(_entitytype);
    final Function1<Property,Boolean> _function = new Function1<Property,Boolean>() {
        public Boolean apply(final Property prop) {
          boolean _or = false;
          boolean _not = (!(prop instanceof Attribute));
          if (_not) {
            _or = true;
          } else {
            String _optional = ((Attribute) prop).getOptional();
            boolean _equals = Objects.equal(_optional, null);
            _or = (_not || _equals);
          }
          return Boolean.valueOf(_or);
        }
      };
    final Iterable<Property> allProperties = IterableExtensions.<Property>filter(_allPropertiesIncludingSuperproperties, _function);
    ArrayList<Field> _arrayList = new ArrayList<Field>();
    final ArrayList<Field> fields = _arrayList;
    EList<UIElement> _elements = entryWindow.getElements();
    final Function1<UIElement,Boolean> _function_1 = new Function1<UIElement,Boolean>() {
        public Boolean apply(final UIElement elem) {
          return Boolean.valueOf((elem instanceof Field));
        }
      };
    Iterable<UIElement> _filter = IterableExtensions.<UIElement>filter(_elements, _function_1);
    final Function1<UIElement,Field> _function_2 = new Function1<UIElement,Field>() {
        public Field apply(final UIElement elem) {
          return ((Field) elem);
        }
      };
    Iterable<Field> _map = IterableExtensions.<UIElement, Field>map(_filter, _function_2);
    Iterables.<Field>addAll(fields, _map);
    for (final Property property : allProperties) {
      final Function1<Field,Property> _function_3 = new Function1<Field,Property>() {
          public Property apply(final Field field) {
            Property _property = field.getProperty();
            return _property;
          }
        };
      List<Property> _map_1 = ListExtensions.<Field, Property>map(fields, _function_3);
      boolean _contains = _map_1.contains(property);
      boolean _not = (!_contains);
      if (_not) {
        String _name = property.getName();
        String _plus = ("The property " + _name);
        String _plus_1 = (_plus + " has no corresponding field in the entryWindow ");
        String _name_1 = entryWindow.getName();
        String _plus_2 = (_plus_1 + _name_1);
        String _plus_3 = (_plus_2 + ".");
        this.error(_plus_3, Literals.UI_WINDOW__NAME);
      }
    }
  }
  
  @Check
  public void areAllOptionalPropertiesIncludedInTheEntrywindow(final EntryWindow entryWindow) {
    Entitytype _entitytype = entryWindow.getEntitytype();
    BasicEList<Property> _allPropertiesIncludingSuperproperties = EntitytypeHelperMethods.getAllPropertiesIncludingSuperproperties(_entitytype);
    final Function1<Property,Boolean> _function = new Function1<Property,Boolean>() {
        public Boolean apply(final Property prop) {
          boolean _and = false;
          if (!(prop instanceof Attribute)) {
            _and = false;
          } else {
            String _optional = ((Attribute) prop).getOptional();
            boolean _notEquals = (!Objects.equal(_optional, null));
            _and = ((prop instanceof Attribute) && _notEquals);
          }
          return Boolean.valueOf(_and);
        }
      };
    final Iterable<Property> allProperties = IterableExtensions.<Property>filter(_allPropertiesIncludingSuperproperties, _function);
    ArrayList<Field> _arrayList = new ArrayList<Field>();
    final ArrayList<Field> fields = _arrayList;
    EList<UIElement> _elements = entryWindow.getElements();
    final Function1<UIElement,Boolean> _function_1 = new Function1<UIElement,Boolean>() {
        public Boolean apply(final UIElement elem) {
          return Boolean.valueOf((elem instanceof Field));
        }
      };
    Iterable<UIElement> _filter = IterableExtensions.<UIElement>filter(_elements, _function_1);
    final Function1<UIElement,Field> _function_2 = new Function1<UIElement,Field>() {
        public Field apply(final UIElement elem) {
          return ((Field) elem);
        }
      };
    Iterable<Field> _map = IterableExtensions.<UIElement, Field>map(_filter, _function_2);
    Iterables.<Field>addAll(fields, _map);
    for (final Property property : allProperties) {
      final Function1<Field,Property> _function_3 = new Function1<Field,Property>() {
          public Property apply(final Field field) {
            Property _property = field.getProperty();
            return _property;
          }
        };
      List<Property> _map_1 = ListExtensions.<Field, Property>map(fields, _function_3);
      boolean _contains = _map_1.contains(property);
      boolean _not = (!_contains);
      if (_not) {
        String _name = property.getName();
        String _plus = ("The optional property " + _name);
        String _plus_1 = (_plus + " has no corresponding field in the entryWindow ");
        String _name_1 = entryWindow.getName();
        String _plus_2 = (_plus_1 + _name_1);
        String _plus_3 = (_plus_2 + ".");
        this.warning(_plus_3, Literals.UI_WINDOW__NAME);
      }
    }
  }
  
  @Check
  public void isAPropertyImplementedMultipleTimesAsAField(final Field field) {
    EObject _eContainer = field.eContainer();
    final EntryWindow entryWindow = ((EntryWindow) _eContainer);
    EList<UIElement> _elements = entryWindow.getElements();
    final Function1<UIElement,Boolean> _function = new Function1<UIElement,Boolean>() {
        public Boolean apply(final UIElement elem) {
          boolean _and = false;
          if (!(elem instanceof Field)) {
            _and = false;
          } else {
            boolean _equals = elem.equals(field);
            boolean _not = (!_equals);
            _and = ((elem instanceof Field) && _not);
          }
          return Boolean.valueOf(_and);
        }
      };
    Iterable<UIElement> _filter = IterableExtensions.<UIElement>filter(_elements, _function);
    final Function1<UIElement,Field> _function_1 = new Function1<UIElement,Field>() {
        public Field apply(final UIElement elem) {
          return ((Field) elem);
        }
      };
    Iterable<Field> _map = IterableExtensions.<UIElement, Field>map(_filter, _function_1);
    for (final Field windowField : _map) {
      Property _property = windowField.getProperty();
      Property _property_1 = field.getProperty();
      boolean _equals = _property.equals(_property_1);
      if (_equals) {
        Property _property_2 = field.getProperty();
        String _name = _property_2.getName();
        String _plus = ("The property " + _name);
        String _plus_1 = (_plus + " is referenced in multiple Fields.");
        this.warning(_plus_1, 
          Literals.FIELD__PROPERTY);
      }
    }
  }
  
  @Check
  public void missingCeateEditButton(final EntryWindow window) {
    Boolean exists = Boolean.valueOf(false);
    EList<UIElement> _elements = window.getElements();
    final Function1<UIElement,Boolean> _function = new Function1<UIElement,Boolean>() {
        public Boolean apply(final UIElement e) {
          return Boolean.valueOf((e instanceof Button));
        }
      };
    Iterable<UIElement> _filter = IterableExtensions.<UIElement>filter(_elements, _function);
    for (final UIElement elem : _filter) {
      {
        Button btn = ((Button) elem);
        Inscription _inscription = btn.getInscription();
        boolean _equals = _inscription.equals(Inscription.CREATE_EDIT);
        if (_equals) {
          exists = Boolean.valueOf(true);
        }
      }
    }
    boolean _not = (!(exists).booleanValue());
    if (_not) {
      this.error("EntryWindow requires Create/Edit Button", Literals.UI_WINDOW__NAME);
    }
  }
}
