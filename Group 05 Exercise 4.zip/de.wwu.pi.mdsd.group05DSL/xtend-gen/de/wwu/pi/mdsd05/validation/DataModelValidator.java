package de.wwu.pi.mdsd05.validation;

import com.google.common.base.Objects;
import de.wwu.pi.mdsd05.group05DSL.Entitytype;
import de.wwu.pi.mdsd05.group05DSL.Group05DSLPackage.Literals;
import de.wwu.pi.mdsd05.group05DSL.Reference;
import de.wwu.pi.mdsd05.helper.EntitytypeHelperMethods;
import de.wwu.pi.mdsd05.validation.AbstractGroup05DSLValidator;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.validation.Check;

/**
 * Custom validation rules.
 * 
 * see http://www.eclipse.org/Xtext/documentation.html#validation
 */
@SuppressWarnings("all")
public class DataModelValidator extends AbstractGroup05DSLValidator {
  @Check
  public void checkAbtractFeatures(final Entitytype entitytype) {
    boolean _and = false;
    String _abstract = entitytype.getAbstract();
    boolean _notEquals = (!Objects.equal(_abstract, null));
    if (!_notEquals) {
      _and = false;
    } else {
      boolean _isSuperClassAnywhere = EntitytypeHelperMethods.isSuperClassAnywhere(entitytype);
      boolean _not = (!_isSuperClassAnywhere);
      _and = (_notEquals && _not);
    }
    if (_and) {
      String _name = entitytype.getName();
      String _plus = ("Class " + _name);
      String _plus_1 = (_plus + " has no subclass and may therefore not be abstract.");
      this.error(_plus_1, 
        Literals.ENTITYTYPE__ABSTRACT);
    }
  }
  
  @Check
  public void checkReference(final Reference reference) {
    EObject _eContainer = reference.eContainer();
    final Entitytype entity = ((Entitytype) _eContainer);
    boolean _hasDoubleReference = EntitytypeHelperMethods.hasDoubleReference(reference);
    if (_hasDoubleReference) {
      String _name = entity.getName();
      String _plus = (_name + " has two references with the same multiplicity to ");
      Entitytype _references = reference.getReferences();
      String _name_1 = _references.getName();
      String _plus_1 = (_plus + _name_1);
      String _plus_2 = (_plus_1 + ". A distinction among the opposite references is not possible.");
      this.error(_plus_2, reference, 
        Literals.REFERENCE__REFERENCES);
    }
    boolean _hasWrongOppositeReference = EntitytypeHelperMethods.hasWrongOppositeReference(reference);
    if (_hasWrongOppositeReference) {
      String _name_2 = entity.getName();
      String _plus_3 = (_name_2 + " is not correctly referenced. Check for opposite reference in ");
      Entitytype _references_1 = reference.getReferences();
      String _name_3 = _references_1.getName();
      String _plus_4 = (_plus_3 + _name_3);
      String _plus_5 = (_plus_4 + ".");
      this.error(_plus_5, reference, 
        Literals.REFERENCE__REFERENCES);
    }
    boolean _referencesItself = EntitytypeHelperMethods.referencesItself(reference);
    if (_referencesItself) {
      String _name_4 = entity.getName();
      String _plus_6 = (_name_4 + " references itself.");
      this.warning(_plus_6, reference, Literals.REFERENCE__REFERENCES);
    }
    boolean _referencesSubOrSuperclass = EntitytypeHelperMethods.referencesSubOrSuperclass(reference);
    if (_referencesSubOrSuperclass) {
      String _name_5 = entity.getName();
      String _plus_7 = (_name_5 + " references a subclass or superclass");
      this.warning(_plus_7, reference, Literals.REFERENCE__REFERENCES);
    }
  }
  
  @Check
  public void checkCyclicInheritance(final Entitytype entity) {
    boolean _hasCyclicInheritance = EntitytypeHelperMethods.hasCyclicInheritance(entity);
    if (_hasCyclicInheritance) {
      this.error("Cyclic inheritance is not allowed", entity, Literals.ENTITYTYPE__NAME);
    }
  }
}
