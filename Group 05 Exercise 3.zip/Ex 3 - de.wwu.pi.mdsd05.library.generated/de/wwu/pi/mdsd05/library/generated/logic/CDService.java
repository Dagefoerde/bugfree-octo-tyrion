package de.wwu.pi.mdsd05.library.generated.logic;

import de.wwu.pi.mdsd.framework.logic.AbstractServiceProvider;
import de.wwu.pi.mdsd.framework.logic.ValidationException;

import de.wwu.pi.mdsd05.library.generated.data.CD;

public class CDService extends AbstractServiceProvider<CD> {

	protected CDService() {
		super();
	}
	

	public boolean validateCD(String Interpreter, Integer ASIN, String Name, Integer MediumID) throws ValidationException {
		if(Interpreter == null)
			throw new ValidationException("Interpreter", "cannot be empty");
		if(ASIN == null)
			throw new ValidationException("ASIN", "cannot be empty");
		if(Name == null)
			throw new ValidationException("Name", "cannot be empty");
		if(MediumID == null)
			throw new ValidationException("MediumID", "cannot be empty");
		return true;
	}


	
	public CD saveCD(int id, String Interpreter, Integer ASIN, String Name, Integer MediumID){
		CD elem = getByOId(id);
		if(elem == null) elem = new CD();
		
		elem.setInterpreter(Interpreter);
		elem.setASIN(ASIN);
		elem.setName(Name);
		elem.setMediumID(MediumID);
		persist(elem);
		return elem;
	}
	


}

