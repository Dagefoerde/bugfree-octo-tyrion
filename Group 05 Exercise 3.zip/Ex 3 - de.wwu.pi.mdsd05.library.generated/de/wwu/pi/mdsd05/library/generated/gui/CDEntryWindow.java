	
package de.wwu.pi.mdsd05.library.generated.gui;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.*;

import javax.swing.*;

import de.wwu.pi.mdsd.framework.gui.*;
import de.wwu.pi.mdsd.framework.logic.ValidationException;

import de.wwu.pi.mdsd05.library.generated.data.CD;
import de.wwu.pi.mdsd05.library.generated.data.Copy;	
import de.wwu.pi.mdsd05.library.generated.logic.CDService;
import de.wwu.pi.mdsd05.library.generated.logic.ServiceInitializer;

public class CDEntryWindow extends AbstractEntryWindow<CD> implements CopyListingInterface {
	private JList<Copy> li_copys;
	private JTextField tf_Interpreter;
	private JTextField tf_ASIN;
	private JTextField tf_Name;
	private JTextField tf_MediumID;
	private CDService service;
	
	public CDEntryWindow(AbstractWindow parent, CD currentEntity) {
		super(parent, currentEntity);
		service = ServiceInitializer.getProvider().getCDService();
	}

	@Override
	protected void createFields() {
		int gridy = 0;
		
		
		//set new Line
		gridy = getNextGridYValue();
		
		JLabel lblInterpreter = new JLabel("Interpreter*");
		GridBagConstraints gbc_lblInterpreter = new GridBagConstraints();
		gbc_lblInterpreter.insets = new Insets(0, 0, 5, 5);
		gbc_lblInterpreter.anchor = GridBagConstraints.NORTHEAST;
		gbc_lblInterpreter.gridx = 0;
		gbc_lblInterpreter.gridy = gridy;
		getPanel().add(lblInterpreter, gbc_lblInterpreter);
		
		tf_Interpreter = new JTextField(currentEntity.getInterpreter()==null?"":currentEntity.getInterpreter().toString());
		GridBagConstraints gbc_tf_Interpreter = new GridBagConstraints();
		gbc_tf_Interpreter.gridwidth = 3;
		gbc_tf_Interpreter.insets = new Insets(0, 0, 5, 5);
		gbc_tf_Interpreter.anchor = GridBagConstraints.NORTHWEST;
		gbc_tf_Interpreter.fill = GridBagConstraints.HORIZONTAL;
		gbc_tf_Interpreter.gridx = 1;
		gbc_tf_Interpreter.weighty = .2;
		gbc_tf_Interpreter.gridy = gridy;
		getPanel().add(tf_Interpreter, gbc_tf_Interpreter);
		//set new Line
		gridy = getNextGridYValue();
		
		JLabel lblASIN = new JLabel("ASIN*");
		GridBagConstraints gbc_lblASIN = new GridBagConstraints();
		gbc_lblASIN.insets = new Insets(0, 0, 5, 5);
		gbc_lblASIN.anchor = GridBagConstraints.NORTHEAST;
		gbc_lblASIN.gridx = 0;
		gbc_lblASIN.gridy = gridy;
		getPanel().add(lblASIN, gbc_lblASIN);
		
		tf_ASIN = new JTextField(currentEntity.getASIN()==null?"":currentEntity.getASIN().toString());
		GridBagConstraints gbc_tf_ASIN = new GridBagConstraints();
		gbc_tf_ASIN.gridwidth = 3;
		gbc_tf_ASIN.insets = new Insets(0, 0, 5, 5);
		gbc_tf_ASIN.anchor = GridBagConstraints.NORTHWEST;
		gbc_tf_ASIN.fill = GridBagConstraints.HORIZONTAL;
		gbc_tf_ASIN.gridx = 1;
		gbc_tf_ASIN.weighty = .2;
		gbc_tf_ASIN.gridy = gridy;
		getPanel().add(tf_ASIN, gbc_tf_ASIN);
		//set new Line
		gridy = getNextGridYValue();
		
		JLabel lblName = new JLabel("Name*");
		GridBagConstraints gbc_lblName = new GridBagConstraints();
		gbc_lblName.insets = new Insets(0, 0, 5, 5);
		gbc_lblName.anchor = GridBagConstraints.NORTHEAST;
		gbc_lblName.gridx = 0;
		gbc_lblName.gridy = gridy;
		getPanel().add(lblName, gbc_lblName);
		
		tf_Name = new JTextField(currentEntity.getName()==null?"":currentEntity.getName().toString());
		GridBagConstraints gbc_tf_Name = new GridBagConstraints();
		gbc_tf_Name.gridwidth = 3;
		gbc_tf_Name.insets = new Insets(0, 0, 5, 5);
		gbc_tf_Name.anchor = GridBagConstraints.NORTHWEST;
		gbc_tf_Name.fill = GridBagConstraints.HORIZONTAL;
		gbc_tf_Name.gridx = 1;
		gbc_tf_Name.weighty = .2;
		gbc_tf_Name.gridy = gridy;
		getPanel().add(tf_Name, gbc_tf_Name);
		//set new Line
		gridy = getNextGridYValue();
		
		JLabel lblMediumID = new JLabel("MediumID*");
		GridBagConstraints gbc_lblMediumID = new GridBagConstraints();
		gbc_lblMediumID.insets = new Insets(0, 0, 5, 5);
		gbc_lblMediumID.anchor = GridBagConstraints.NORTHEAST;
		gbc_lblMediumID.gridx = 0;
		gbc_lblMediumID.gridy = gridy;
		getPanel().add(lblMediumID, gbc_lblMediumID);
		
		tf_MediumID = new JTextField(currentEntity.getMediumID()==null?"":currentEntity.getMediumID().toString());
		GridBagConstraints gbc_tf_MediumID = new GridBagConstraints();
		gbc_tf_MediumID.gridwidth = 3;
		gbc_tf_MediumID.insets = new Insets(0, 0, 5, 5);
		gbc_tf_MediumID.anchor = GridBagConstraints.NORTHWEST;
		gbc_tf_MediumID.fill = GridBagConstraints.HORIZONTAL;
		gbc_tf_MediumID.gridx = 1;
		gbc_tf_MediumID.weighty = .2;
		gbc_tf_MediumID.gridy = gridy;
		getPanel().add(tf_MediumID, gbc_tf_MediumID);
	}
	
	@Override
	protected void createLists() {
		int gridy = 0;
		JButton btn;
		GridBagConstraints gbc_btn;
		gridy = getNextGridYValue();
		JLabel lblcopys = new JLabel("Copys");
		GridBagConstraints gbc_lblcopys = new GridBagConstraints();
		gbc_lblcopys.insets = new Insets(0, 0, 5, 5);
		gbc_lblcopys.anchor = GridBagConstraints.NORTHEAST;
		gbc_lblcopys.gridx = 0;
		gbc_lblcopys.gridy = gridy;
		getPanel().add(lblcopys, gbc_lblcopys);
		
		li_copys = new JList<Copy>();
		initializeLiCopys();
		GridBagConstraints gbc_li_copys = new GridBagConstraints();
		gbc_li_copys.gridwidth = 3;
		gbc_li_copys.insets = new Insets(0, 0, 5, 5);
		gbc_li_copys.fill = GridBagConstraints.BOTH;
		gbc_li_copys.gridx = 1;
		gbc_li_copys.weighty = .5;
		gbc_li_copys.gridy = gridy;
		getPanel().add(li_copys, gbc_li_copys);
		
		//Button for List Element
		btn = new JButton("Add");
		btn.setEnabled(!currentEntity.isNew());
		gbc_btn = new GridBagConstraints();
		gbc_btn.insets = new Insets(0, 0, 5, 0);
		gbc_btn.gridx = 1;
		gbc_btn.gridy = getNextGridYValue();;
		getPanel().add(btn, gbc_btn);
		btn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new CopyEntryWindow(CDEntryWindow.this, new Copy(currentEntity)).open();
			}
		});
		
		btn = new JButton("Edit");
		gbc_btn.gridx = 2;
		btn.setEnabled(!currentEntity.isNew());
		getPanel().add(btn, gbc_btn);
		btn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Copy selected = CDEntryWindow.this.li_copys.getSelectedValue();
				if(selected == null)
					Util.showNothingSelected();
				else
					new CopyEntryWindow(CDEntryWindow.this, selected).open();
			}
		});
		
		btn = new JButton("Delete");
		btn.setEnabled(false);
		gbc_btn.gridx = 3;
		getPanel().add(btn, gbc_btn);
	}


	public void initializeLiCopys() {
		li_copys.setListData(new Vector<Copy>(currentEntity.getCopys()));
	}
	
	@Override
	public void initializeCopyListings() {
		initializeLiCopys();
	}
	
	@Override
	protected boolean saveAction() throws ParseException {
		//Read values from different fields 
		String Interpreter = tf_Interpreter.getText().isEmpty() ? null : String.valueOf(tf_Interpreter.getText());
		Integer ASIN = tf_ASIN.getText().isEmpty() ? null : Integer.valueOf(tf_ASIN.getText());
		String Name = tf_Name.getText().isEmpty() ? null : String.valueOf(tf_Name.getText());
		Integer MediumID = tf_MediumID.getText().isEmpty() ? null : Integer.valueOf(tf_MediumID.getText());
		
		//validation
		try {
			service.validateCD(Interpreter,
			ASIN,
			Name,
			MediumID
			);
		} catch (ValidationException e) {
			Util.showUserMessage("Validation error for " + e.getField(), "Validation error for " + e.getField() + ": " + e.getMessage());
			return false;
		}
		
		//persist
		currentEntity = service.saveCD(currentEntity.getOid(), Interpreter, ASIN, Name, MediumID);
		
		//reload the listing in the parent window to make changes visible
		if(getParent() instanceof MediumListingInterface)
			(( MediumListingInterface) getParent()).initializeMediumListings();
		if(getParent() instanceof CDListingInterface)
			((CDListingInterface) getParent()).initializeCDListings();
		return true;
	}
}
	
	
	
