package de.wwu.pi.mdsd05.library.generated.data;

import de.wwu.pi.mdsd.framework.data.AbstractDataClass;
import java.util.List;
import java.util.ArrayList;

public class Medium extends AbstractDataClass {
	private String Name;
	private Integer MediumID;
	public List<Copy> copys = new ArrayList<Copy>();	

	public String getName(){
		return Name;
	}
	
	public void setName(String Name){
		this.Name = Name;
		
	}
	
	public Integer getMediumID(){
		return MediumID;
	}
	
	public void setMediumID(Integer MediumID){
		this.MediumID = MediumID;
		
	}
	
	public List<Copy> getCopys(){
		return copys;
	}
	
	//called only by friend method
	protected void addCopy(Copy copy){
		copys.add(copy);
	}
		
	public Medium() {
		super();	
	}
	
	public Medium (
		String Name,
		Integer MediumID
	) {
		super();
		this.Name=Name;
		this.MediumID=MediumID;
	}

	@Override
	public String toString() {
		return (""
		+ getName() + "," 
		+ getMediumID()
		);
	}
}

