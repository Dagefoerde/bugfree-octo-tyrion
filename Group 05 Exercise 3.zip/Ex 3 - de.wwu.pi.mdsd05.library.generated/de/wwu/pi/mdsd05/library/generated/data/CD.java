package de.wwu.pi.mdsd05.library.generated.data;


public class CD extends Medium {
	private String Interpreter;
	private Integer ASIN;

	public String getInterpreter(){
		return Interpreter;
	}
	
	public void setInterpreter(String Interpreter){
		this.Interpreter = Interpreter;
		
	}
	
	public Integer getASIN(){
		return ASIN;
	}
	
	public void setASIN(Integer ASIN){
		this.ASIN = ASIN;
		
	}
	
	public CD() {
		super();	
	}
	
	public CD (
		String Interpreter,
		Integer ASIN,
		String Name,
		Integer MediumID
	) {
		super(Name,MediumID);
		this.Interpreter=Interpreter;
		this.ASIN=ASIN;
	}

	@Override
	public String toString() {
		return (""
		+ super.toString() + ","
		+ getInterpreter() + "," 
		+ getASIN()
		);
	}
}

