package de.wwu.pi.mdsd05.library.generated.gui;

import java.util.Vector;

import de.wwu.pi.mdsd.framework.gui.AbstractListWindow;
import de.wwu.pi.mdsd.framework.gui.AbstractWindow;
import de.wwu.pi.mdsd05.library.generated.logic.ServiceInitializer;
import de.wwu.pi.mdsd05.library.generated.data.Medium;
import de.wwu.pi.mdsd05.library.generated.data.Book;
import de.wwu.pi.mdsd05.library.generated.data.CD;
	
public class MediumListWindow extends AbstractListWindow<Medium> implements MediumListingInterface{

	public MediumListWindow(AbstractWindow parent) {
		super(parent);
	}

	@Override
	public void showEntryWindow(Medium entity) {
		//If entity is null -> initialize entity as new entity
		//show Entity Edit Window
		if(entity == null) {
			if(cb_select.getSelectedItem().equals("Book"))
				entity = new Book();
			if(cb_select.getSelectedItem().equals("CD"))
				entity = new CD();
		}
		if(entity instanceof Book)
			new BookEntryWindow(this, (Book) entity).open();
		if(entity instanceof CD)
			new CDEntryWindow(this, (CD) entity).open();
	}
	
	javax.swing.JComboBox<String> cb_select;
	@Override //overrides superclass method to add a select box to the window
	public void createContents() {
		super.createContents();
		cb_select = new javax.swing.JComboBox<>();
		cb_select.addItem("Book");
		cb_select.addItem("CD");
		java.awt.GridBagConstraints gbc_btnAdd = new java.awt.GridBagConstraints();
		gbc_btnAdd.insets = new java.awt.Insets(0, 0, 5, 5);
		gbc_btnAdd.gridx = 1;
		gbc_btnAdd.gridy = 2;
		getPanel().add(cb_select, gbc_btnAdd);
	}

	@Override
	public Vector<Medium> getElements() {
		return new Vector<Medium>(ServiceInitializer.getProvider().getMediumService().getAll());
	}
	
	@Override
	public void initializeMediumListings() {
		initializeList();
	}
}

interface MediumListingInterface {
	public void initializeMediumListings();
}
