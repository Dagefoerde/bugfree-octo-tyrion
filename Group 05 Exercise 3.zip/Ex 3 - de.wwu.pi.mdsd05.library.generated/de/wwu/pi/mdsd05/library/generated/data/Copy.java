package de.wwu.pi.mdsd05.library.generated.data;

import de.wwu.pi.mdsd.framework.data.AbstractDataClass;
import java.util.List;
import java.util.ArrayList;

public class Copy extends AbstractDataClass {
	private Integer InventoryNumber;
	public List<Loan> loans = new ArrayList<Loan>();	
	public Medium medium;

	public Integer getInventoryNumber(){
		return InventoryNumber;
	}
	
	public void setInventoryNumber(Integer InventoryNumber){
		this.InventoryNumber = InventoryNumber;
		
	}
	
	public List<Loan> getLoans(){
		return loans;
	}
	
	//called only by friend method
	protected void addLoan(Loan loan){
		loans.add(loan);
	}
		
	public Medium getMedium(){
		return medium;
	}
	
	public void setMedium(Medium medium){
		//do nothing, if medium is the same
		if(this.medium == medium) return;
		//remove old Copy from opposite
		if(this.medium != null) this.medium.getCopys().remove(this);
		//unless new medium is null add 
		if(medium != null) medium.addCopy(this);
		this.medium = medium;
		
	}
	
	public Copy() {
		super();	
	}
	
	public Copy (
		Integer InventoryNumber,
		Medium medium
	) {
		super();
		this.InventoryNumber=InventoryNumber;
		this.medium=medium;
	}

	public Copy(Medium medium) {
		super();
		this.medium=medium;
	}
	
	@Override
	public String toString() {
		return (""
		+ getInventoryNumber() + "," 
		+ getMedium()
		);
	}
}

