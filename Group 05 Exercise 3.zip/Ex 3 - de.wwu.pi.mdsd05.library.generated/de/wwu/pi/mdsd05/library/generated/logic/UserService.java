package de.wwu.pi.mdsd05.library.generated.logic;

import de.wwu.pi.mdsd.framework.logic.AbstractServiceProvider;
import de.wwu.pi.mdsd.framework.logic.ValidationException;

import de.wwu.pi.mdsd05.library.generated.data.User;

public class UserService extends AbstractServiceProvider<User> {

	protected UserService() {
		super();
	}
	

	public boolean validateUser(String Name, String Address, Integer UserID) throws ValidationException {
		if(Name == null)
			throw new ValidationException("Name", "cannot be empty");
		if(Address == null)
			throw new ValidationException("Address", "cannot be empty");
		if(UserID == null)
			throw new ValidationException("UserID", "cannot be empty");
		return true;
	}


	
	public User saveUser(int id, String Name, String Address, Integer UserID){
		User elem = getByOId(id);
		if(elem == null) elem = new User();
		
		elem.setName(Name);
		elem.setAddress(Address);
		elem.setUserID(UserID);
		persist(elem);
		return elem;
	}
	


}

