package de.wwu.pi.mdsd05.library.generated.logic;

import de.wwu.pi.mdsd.framework.logic.AbstractServiceProvider;
import de.wwu.pi.mdsd.framework.logic.ValidationException;

import de.wwu.pi.mdsd05.library.generated.data.Copy;
import de.wwu.pi.mdsd05.library.generated.data.Medium; 

public class CopyService extends AbstractServiceProvider<Copy> {

	protected CopyService() {
		super();
	}
	

	public boolean validateCopy(Integer InventoryNumber, Medium medium) throws ValidationException {
		if(InventoryNumber == null)
			throw new ValidationException("InventoryNumber", "cannot be empty");
		if(medium == null)
			throw new ValidationException("medium", "cannot be empty");
		return true;
	}


	
	public Copy saveCopy(int id, Integer InventoryNumber, Medium medium){
		Copy elem = getByOId(id);
		if(elem == null) elem = new Copy();
		
		elem.setInventoryNumber(InventoryNumber);
		elem.setMedium(medium);
		persist(elem);
		return elem;
	}
	


}

