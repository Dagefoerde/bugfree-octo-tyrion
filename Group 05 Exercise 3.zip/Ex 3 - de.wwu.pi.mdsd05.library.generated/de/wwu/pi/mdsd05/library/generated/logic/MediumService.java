package de.wwu.pi.mdsd05.library.generated.logic;

import de.wwu.pi.mdsd.framework.logic.AbstractServiceProvider;
import de.wwu.pi.mdsd.framework.logic.ValidationException;
import java.util.Collection;
import java.util.LinkedList;

import de.wwu.pi.mdsd05.library.generated.data.Medium;

public class MediumService extends AbstractServiceProvider<Medium> {

	protected MediumService() {
		super();
	}
	

	public boolean validateMedium(String Name, Integer MediumID) throws ValidationException {
		if(Name == null)
			throw new ValidationException("Name", "cannot be empty");
		if(MediumID == null)
			throw new ValidationException("MediumID", "cannot be empty");
		return true;
	}


	
	public Medium saveMedium(int id, String Name, Integer MediumID){
		Medium elem = getByOId(id);
		if(elem == null) elem = new Medium();
		
		elem.setName(Name);
		elem.setMediumID(MediumID);
		persist(elem);
		return elem;
	}
	
	@Override
	public Collection<Medium> getAll() {
		Collection<Medium> result = new LinkedList<Medium>();
		result.addAll(ServiceInitializer.getProvider().getBookService().getAll());
		result.addAll(ServiceInitializer.getProvider().getCDService().getAll());
		return result;
	}	


}

