	
package de.wwu.pi.mdsd05.library.generated.gui;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.*;

import javax.swing.*;

import de.wwu.pi.mdsd.framework.gui.*;
import de.wwu.pi.mdsd.framework.logic.ValidationException;

import de.wwu.pi.mdsd05.library.generated.data.Book;
import de.wwu.pi.mdsd05.library.generated.data.Copy;	
import de.wwu.pi.mdsd05.library.generated.logic.BookService;
import de.wwu.pi.mdsd05.library.generated.logic.ServiceInitializer;

public class BookEntryWindow extends AbstractEntryWindow<Book> implements CopyListingInterface {
	private JList<Copy> li_copys;
	private JTextField tf_Author;
	private JTextField tf_ISBN;
	private JTextField tf_Name;
	private JTextField tf_MediumID;
	private BookService service;
	
	public BookEntryWindow(AbstractWindow parent, Book currentEntity) {
		super(parent, currentEntity);
		service = ServiceInitializer.getProvider().getBookService();
	}

	@Override
	protected void createFields() {
		int gridy = 0;
		
		
		//set new Line
		gridy = getNextGridYValue();
		
		JLabel lblAuthor = new JLabel("Author*");
		GridBagConstraints gbc_lblAuthor = new GridBagConstraints();
		gbc_lblAuthor.insets = new Insets(0, 0, 5, 5);
		gbc_lblAuthor.anchor = GridBagConstraints.NORTHEAST;
		gbc_lblAuthor.gridx = 0;
		gbc_lblAuthor.gridy = gridy;
		getPanel().add(lblAuthor, gbc_lblAuthor);
		
		tf_Author = new JTextField(currentEntity.getAuthor()==null?"":currentEntity.getAuthor().toString());
		GridBagConstraints gbc_tf_Author = new GridBagConstraints();
		gbc_tf_Author.gridwidth = 3;
		gbc_tf_Author.insets = new Insets(0, 0, 5, 5);
		gbc_tf_Author.anchor = GridBagConstraints.NORTHWEST;
		gbc_tf_Author.fill = GridBagConstraints.HORIZONTAL;
		gbc_tf_Author.gridx = 1;
		gbc_tf_Author.weighty = .2;
		gbc_tf_Author.gridy = gridy;
		getPanel().add(tf_Author, gbc_tf_Author);
		//set new Line
		gridy = getNextGridYValue();
		
		JLabel lblISBN = new JLabel("ISBN*");
		GridBagConstraints gbc_lblISBN = new GridBagConstraints();
		gbc_lblISBN.insets = new Insets(0, 0, 5, 5);
		gbc_lblISBN.anchor = GridBagConstraints.NORTHEAST;
		gbc_lblISBN.gridx = 0;
		gbc_lblISBN.gridy = gridy;
		getPanel().add(lblISBN, gbc_lblISBN);
		
		tf_ISBN = new JTextField(currentEntity.getISBN()==null?"":currentEntity.getISBN().toString());
		GridBagConstraints gbc_tf_ISBN = new GridBagConstraints();
		gbc_tf_ISBN.gridwidth = 3;
		gbc_tf_ISBN.insets = new Insets(0, 0, 5, 5);
		gbc_tf_ISBN.anchor = GridBagConstraints.NORTHWEST;
		gbc_tf_ISBN.fill = GridBagConstraints.HORIZONTAL;
		gbc_tf_ISBN.gridx = 1;
		gbc_tf_ISBN.weighty = .2;
		gbc_tf_ISBN.gridy = gridy;
		getPanel().add(tf_ISBN, gbc_tf_ISBN);
		//set new Line
		gridy = getNextGridYValue();
		
		JLabel lblName = new JLabel("Name*");
		GridBagConstraints gbc_lblName = new GridBagConstraints();
		gbc_lblName.insets = new Insets(0, 0, 5, 5);
		gbc_lblName.anchor = GridBagConstraints.NORTHEAST;
		gbc_lblName.gridx = 0;
		gbc_lblName.gridy = gridy;
		getPanel().add(lblName, gbc_lblName);
		
		tf_Name = new JTextField(currentEntity.getName()==null?"":currentEntity.getName().toString());
		GridBagConstraints gbc_tf_Name = new GridBagConstraints();
		gbc_tf_Name.gridwidth = 3;
		gbc_tf_Name.insets = new Insets(0, 0, 5, 5);
		gbc_tf_Name.anchor = GridBagConstraints.NORTHWEST;
		gbc_tf_Name.fill = GridBagConstraints.HORIZONTAL;
		gbc_tf_Name.gridx = 1;
		gbc_tf_Name.weighty = .2;
		gbc_tf_Name.gridy = gridy;
		getPanel().add(tf_Name, gbc_tf_Name);
		//set new Line
		gridy = getNextGridYValue();
		
		JLabel lblMediumID = new JLabel("MediumID*");
		GridBagConstraints gbc_lblMediumID = new GridBagConstraints();
		gbc_lblMediumID.insets = new Insets(0, 0, 5, 5);
		gbc_lblMediumID.anchor = GridBagConstraints.NORTHEAST;
		gbc_lblMediumID.gridx = 0;
		gbc_lblMediumID.gridy = gridy;
		getPanel().add(lblMediumID, gbc_lblMediumID);
		
		tf_MediumID = new JTextField(currentEntity.getMediumID()==null?"":currentEntity.getMediumID().toString());
		GridBagConstraints gbc_tf_MediumID = new GridBagConstraints();
		gbc_tf_MediumID.gridwidth = 3;
		gbc_tf_MediumID.insets = new Insets(0, 0, 5, 5);
		gbc_tf_MediumID.anchor = GridBagConstraints.NORTHWEST;
		gbc_tf_MediumID.fill = GridBagConstraints.HORIZONTAL;
		gbc_tf_MediumID.gridx = 1;
		gbc_tf_MediumID.weighty = .2;
		gbc_tf_MediumID.gridy = gridy;
		getPanel().add(tf_MediumID, gbc_tf_MediumID);
	}
	
	@Override
	protected void createLists() {
		int gridy = 0;
		JButton btn;
		GridBagConstraints gbc_btn;
		gridy = getNextGridYValue();
		JLabel lblcopys = new JLabel("Copys");
		GridBagConstraints gbc_lblcopys = new GridBagConstraints();
		gbc_lblcopys.insets = new Insets(0, 0, 5, 5);
		gbc_lblcopys.anchor = GridBagConstraints.NORTHEAST;
		gbc_lblcopys.gridx = 0;
		gbc_lblcopys.gridy = gridy;
		getPanel().add(lblcopys, gbc_lblcopys);
		
		li_copys = new JList<Copy>();
		initializeLiCopys();
		GridBagConstraints gbc_li_copys = new GridBagConstraints();
		gbc_li_copys.gridwidth = 3;
		gbc_li_copys.insets = new Insets(0, 0, 5, 5);
		gbc_li_copys.fill = GridBagConstraints.BOTH;
		gbc_li_copys.gridx = 1;
		gbc_li_copys.weighty = .5;
		gbc_li_copys.gridy = gridy;
		getPanel().add(li_copys, gbc_li_copys);
		
		//Button for List Element
		btn = new JButton("Add");
		btn.setEnabled(!currentEntity.isNew());
		gbc_btn = new GridBagConstraints();
		gbc_btn.insets = new Insets(0, 0, 5, 0);
		gbc_btn.gridx = 1;
		gbc_btn.gridy = getNextGridYValue();;
		getPanel().add(btn, gbc_btn);
		btn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new CopyEntryWindow(BookEntryWindow.this, new Copy(currentEntity)).open();
			}
		});
		
		btn = new JButton("Edit");
		gbc_btn.gridx = 2;
		btn.setEnabled(!currentEntity.isNew());
		getPanel().add(btn, gbc_btn);
		btn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Copy selected = BookEntryWindow.this.li_copys.getSelectedValue();
				if(selected == null)
					Util.showNothingSelected();
				else
					new CopyEntryWindow(BookEntryWindow.this, selected).open();
			}
		});
		
		btn = new JButton("Delete");
		btn.setEnabled(false);
		gbc_btn.gridx = 3;
		getPanel().add(btn, gbc_btn);
	}


	public void initializeLiCopys() {
		li_copys.setListData(new Vector<Copy>(currentEntity.getCopys()));
	}
	
	@Override
	public void initializeCopyListings() {
		initializeLiCopys();
	}
	
	@Override
	protected boolean saveAction() throws ParseException {
		//Read values from different fields 
		String Author = tf_Author.getText().isEmpty() ? null : String.valueOf(tf_Author.getText());
		Integer ISBN = tf_ISBN.getText().isEmpty() ? null : Integer.valueOf(tf_ISBN.getText());
		String Name = tf_Name.getText().isEmpty() ? null : String.valueOf(tf_Name.getText());
		Integer MediumID = tf_MediumID.getText().isEmpty() ? null : Integer.valueOf(tf_MediumID.getText());
		
		//validation
		try {
			service.validateBook(Author,
			ISBN,
			Name,
			MediumID
			);
		} catch (ValidationException e) {
			Util.showUserMessage("Validation error for " + e.getField(), "Validation error for " + e.getField() + ": " + e.getMessage());
			return false;
		}
		
		//persist
		currentEntity = service.saveBook(currentEntity.getOid(), Author, ISBN, Name, MediumID);
		
		//reload the listing in the parent window to make changes visible
		if(getParent() instanceof MediumListingInterface)
			(( MediumListingInterface) getParent()).initializeMediumListings();
		if(getParent() instanceof BookListingInterface)
			((BookListingInterface) getParent()).initializeBookListings();
		return true;
	}
}
	
	
	
