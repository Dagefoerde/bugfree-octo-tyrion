	
package de.wwu.pi.mdsd05.library.generated.gui;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.*;

import javax.swing.*;

import de.wwu.pi.mdsd.framework.gui.*;
import de.wwu.pi.mdsd.framework.logic.ValidationException;

import de.wwu.pi.mdsd05.library.generated.data.Copy;
import de.wwu.pi.mdsd05.library.generated.data.Loan;	
import de.wwu.pi.mdsd05.library.generated.data.Medium;	
import de.wwu.pi.mdsd05.library.generated.logic.CopyService;
import de.wwu.pi.mdsd05.library.generated.logic.ServiceInitializer;

public class CopyEntryWindow extends AbstractEntryWindow<Copy> implements LoanListingInterface {
	private JList<Loan> li_loans;
	private JComboBox<Medium> cb_medium;
	private JTextField tf_InventoryNumber;
	private CopyService service;
	
	public CopyEntryWindow(AbstractWindow parent, Copy currentEntity) {
		super(parent, currentEntity);
		service = ServiceInitializer.getProvider().getCopyService();
	}

	@Override
	protected void createFields() {
		int gridy = 0;
		
		
		//set new Line
		gridy = getNextGridYValue();
		
		JLabel lblInventoryNumber = new JLabel("InventoryNumber*");
		GridBagConstraints gbc_lblInventoryNumber = new GridBagConstraints();
		gbc_lblInventoryNumber.insets = new Insets(0, 0, 5, 5);
		gbc_lblInventoryNumber.anchor = GridBagConstraints.NORTHEAST;
		gbc_lblInventoryNumber.gridx = 0;
		gbc_lblInventoryNumber.gridy = gridy;
		getPanel().add(lblInventoryNumber, gbc_lblInventoryNumber);
		
		tf_InventoryNumber = new JTextField(currentEntity.getInventoryNumber()==null?"":currentEntity.getInventoryNumber().toString());
		GridBagConstraints gbc_tf_InventoryNumber = new GridBagConstraints();
		gbc_tf_InventoryNumber.gridwidth = 3;
		gbc_tf_InventoryNumber.insets = new Insets(0, 0, 5, 5);
		gbc_tf_InventoryNumber.anchor = GridBagConstraints.NORTHWEST;
		gbc_tf_InventoryNumber.fill = GridBagConstraints.HORIZONTAL;
		gbc_tf_InventoryNumber.gridx = 1;
		gbc_tf_InventoryNumber.weighty = .2;
		gbc_tf_InventoryNumber.gridy = gridy;
		getPanel().add(tf_InventoryNumber, gbc_tf_InventoryNumber);
		//set new Line
		gridy = getNextGridYValue();
		
		JLabel lblmedium = new JLabel("Medium*");
		GridBagConstraints gbc_lblmedium = new GridBagConstraints();
		gbc_lblmedium.insets = new Insets(0, 0, 5, 5);
		gbc_lblmedium.anchor = GridBagConstraints.NORTHEAST;
		gbc_lblmedium.gridx = 0;
		gbc_lblmedium.gridy = gridy;
		getPanel().add(lblmedium, gbc_lblmedium);
		
		cb_medium = new JComboBox<Medium>(new Vector<>(ServiceInitializer.getProvider().getMediumService().getAll()));
		cb_medium.setSelectedItem(currentEntity.getMedium());
		GridBagConstraints gbc_cb_medium = new GridBagConstraints();
		gbc_cb_medium.gridwidth = 3;
		gbc_cb_medium.insets = new Insets(0, 0, 5, 5);
		gbc_cb_medium.anchor = GridBagConstraints.NORTHWEST;
		gbc_cb_medium.fill = GridBagConstraints.HORIZONTAL;
		gbc_cb_medium.gridx = 1;
		gbc_cb_medium.weighty = .2;
		gbc_cb_medium.gridy = gridy;
		getPanel().add(cb_medium, gbc_cb_medium);
	}
	
	@Override
	protected void createLists() {
		int gridy = 0;
		JButton btn;
		GridBagConstraints gbc_btn;
		gridy = getNextGridYValue();
		JLabel lblloans = new JLabel("Loans");
		GridBagConstraints gbc_lblloans = new GridBagConstraints();
		gbc_lblloans.insets = new Insets(0, 0, 5, 5);
		gbc_lblloans.anchor = GridBagConstraints.NORTHEAST;
		gbc_lblloans.gridx = 0;
		gbc_lblloans.gridy = gridy;
		getPanel().add(lblloans, gbc_lblloans);
		
		li_loans = new JList<Loan>();
		initializeLiLoans();
		GridBagConstraints gbc_li_loans = new GridBagConstraints();
		gbc_li_loans.gridwidth = 3;
		gbc_li_loans.insets = new Insets(0, 0, 5, 5);
		gbc_li_loans.fill = GridBagConstraints.BOTH;
		gbc_li_loans.gridx = 1;
		gbc_li_loans.weighty = .5;
		gbc_li_loans.gridy = gridy;
		getPanel().add(li_loans, gbc_li_loans);
		
		//Button for List Element
		btn = new JButton("Add");
		btn.setEnabled(!currentEntity.isNew());
		gbc_btn = new GridBagConstraints();
		gbc_btn.insets = new Insets(0, 0, 5, 0);
		gbc_btn.gridx = 1;
		gbc_btn.gridy = getNextGridYValue();;
		getPanel().add(btn, gbc_btn);
		btn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new LoanEntryWindow(CopyEntryWindow.this, new Loan(currentEntity)).open();
			}
		});
		
		btn = new JButton("Edit");
		gbc_btn.gridx = 2;
		btn.setEnabled(!currentEntity.isNew());
		getPanel().add(btn, gbc_btn);
		btn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Loan selected = CopyEntryWindow.this.li_loans.getSelectedValue();
				if(selected == null)
					Util.showNothingSelected();
				else
					new LoanEntryWindow(CopyEntryWindow.this, selected).open();
			}
		});
		
		btn = new JButton("Delete");
		btn.setEnabled(false);
		gbc_btn.gridx = 3;
		getPanel().add(btn, gbc_btn);
	}


	public void initializeLiLoans() {
		li_loans.setListData(new Vector<Loan>(currentEntity.getLoans()));
	}
	
	@Override
	public void initializeLoanListings() {
		initializeLiLoans();
	}
	
	@Override
	protected boolean saveAction() throws ParseException {
		//Read values from different fields 
		Integer InventoryNumber = tf_InventoryNumber.getText().isEmpty() ? null : Integer.valueOf(tf_InventoryNumber.getText());
		Medium medium = cb_medium.getItemAt(cb_medium.getSelectedIndex());
		
		//validation
		try {
			service.validateCopy(InventoryNumber,
			medium
			);
		} catch (ValidationException e) {
			Util.showUserMessage("Validation error for " + e.getField(), "Validation error for " + e.getField() + ": " + e.getMessage());
			return false;
		}
		
		//persist
		currentEntity = service.saveCopy(currentEntity.getOid(), InventoryNumber, medium);
		
		//reload the listing in the parent window to make changes visible
		if(getParent() instanceof CopyListingInterface)
			((CopyListingInterface) getParent()).initializeCopyListings();
		return true;
	}
}
	
	
	
