package de.wwu.pi.mdsd05.library.generated.gui;

import java.util.Vector;

import de.wwu.pi.mdsd.framework.gui.AbstractListWindow;
import de.wwu.pi.mdsd.framework.gui.AbstractWindow;
import de.wwu.pi.mdsd05.library.generated.logic.ServiceInitializer;
import de.wwu.pi.mdsd05.library.generated.data.Loan;
	
public class LoanListWindow extends AbstractListWindow<Loan> implements LoanListingInterface{

	public LoanListWindow(AbstractWindow parent) {
		super(parent);
	}

	@Override
	public void showEntryWindow(Loan entity) {
		//If entity is null -> initialize entity as new entity
		//show Entity Edit Window
		if(entity == null)
			entity = new Loan();
		new LoanEntryWindow(this,entity).open();
	}
	

	@Override
	public Vector<Loan> getElements() {
		return new Vector<Loan>(ServiceInitializer.getProvider().getLoanService().getAll());
	}
	
	@Override
	public void initializeLoanListings() {
		initializeList();
	}
}

interface LoanListingInterface {
	public void initializeLoanListings();
}
