package de.wwu.pi.mdsd05.library.generated.logic;

import de.wwu.pi.mdsd.framework.logic.AbstractServiceProvider;
import de.wwu.pi.mdsd.framework.logic.ValidationException;

import de.wwu.pi.mdsd05.library.generated.data.Book;

public class BookService extends AbstractServiceProvider<Book> {

	protected BookService() {
		super();
	}
	

	public boolean validateBook(String Author, Integer ISBN, String Name, Integer MediumID) throws ValidationException {
		if(Author == null)
			throw new ValidationException("Author", "cannot be empty");
		if(ISBN == null)
			throw new ValidationException("ISBN", "cannot be empty");
		if(Name == null)
			throw new ValidationException("Name", "cannot be empty");
		if(MediumID == null)
			throw new ValidationException("MediumID", "cannot be empty");
		return true;
	}


	
	public Book saveBook(int id, String Author, Integer ISBN, String Name, Integer MediumID){
		Book elem = getByOId(id);
		if(elem == null) elem = new Book();
		
		elem.setAuthor(Author);
		elem.setISBN(ISBN);
		elem.setName(Name);
		elem.setMediumID(MediumID);
		persist(elem);
		return elem;
	}
	


}

