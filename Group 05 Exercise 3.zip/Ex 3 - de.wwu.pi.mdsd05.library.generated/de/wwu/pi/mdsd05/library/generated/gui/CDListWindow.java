package de.wwu.pi.mdsd05.library.generated.gui;

import java.util.Vector;

import de.wwu.pi.mdsd.framework.gui.AbstractListWindow;
import de.wwu.pi.mdsd.framework.gui.AbstractWindow;
import de.wwu.pi.mdsd05.library.generated.logic.ServiceInitializer;
import de.wwu.pi.mdsd05.library.generated.data.CD;
	
public class CDListWindow extends AbstractListWindow<CD> implements CDListingInterface{

	public CDListWindow(AbstractWindow parent) {
		super(parent);
	}

	@Override
	public void showEntryWindow(CD entity) {
		//If entity is null -> initialize entity as new entity
		//show Entity Edit Window
		if(entity == null)
			entity = new CD();
		new CDEntryWindow(this,entity).open();
	}
	

	@Override
	public Vector<CD> getElements() {
		return new Vector<CD>(ServiceInitializer.getProvider().getCDService().getAll());
	}
	
	@Override
	public void initializeCDListings() {
		initializeList();
	}
}

interface CDListingInterface {
	public void initializeCDListings();
}
