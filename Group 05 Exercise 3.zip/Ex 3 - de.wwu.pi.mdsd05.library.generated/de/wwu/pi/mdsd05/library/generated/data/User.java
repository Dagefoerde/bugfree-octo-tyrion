package de.wwu.pi.mdsd05.library.generated.data;

import de.wwu.pi.mdsd.framework.data.AbstractDataClass;
import java.util.List;
import java.util.ArrayList;

public class User extends AbstractDataClass {
	private String Name;
	private String Address;
	private Integer UserID;
	public List<Loan> loans = new ArrayList<Loan>();	

	public String getName(){
		return Name;
	}
	
	public void setName(String Name){
		this.Name = Name;
		
	}
	
	public String getAddress(){
		return Address;
	}
	
	public void setAddress(String Address){
		this.Address = Address;
		
	}
	
	public Integer getUserID(){
		return UserID;
	}
	
	public void setUserID(Integer UserID){
		this.UserID = UserID;
		
	}
	
	public List<Loan> getLoans(){
		return loans;
	}
	
	//called only by friend method
	protected void addLoan(Loan loan){
		loans.add(loan);
	}
		
	public User() {
		super();	
	}
	
	public User (
		String Name,
		String Address,
		Integer UserID
	) {
		super();
		this.Name=Name;
		this.Address=Address;
		this.UserID=UserID;
	}

	@Override
	public String toString() {
		return (""
		+ getName() + "," 
		+ getAddress() + "," 
		+ getUserID()
		);
	}
}

