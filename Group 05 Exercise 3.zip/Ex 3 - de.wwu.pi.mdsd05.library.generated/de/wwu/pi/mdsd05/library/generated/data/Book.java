package de.wwu.pi.mdsd05.library.generated.data;


public class Book extends Medium {
	private String Author;
	private Integer ISBN;

	public String getAuthor(){
		return Author;
	}
	
	public void setAuthor(String Author){
		this.Author = Author;
		
	}
	
	public Integer getISBN(){
		return ISBN;
	}
	
	public void setISBN(Integer ISBN){
		this.ISBN = ISBN;
		
	}
	
	public Book() {
		super();	
	}
	
	public Book (
		String Author,
		Integer ISBN,
		String Name,
		Integer MediumID
	) {
		super(Name,MediumID);
		this.Author=Author;
		this.ISBN=ISBN;
	}

	@Override
	public String toString() {
		return (""
		+ super.toString() + ","
		+ getAuthor() + "," 
		+ getISBN()
		);
	}
}

