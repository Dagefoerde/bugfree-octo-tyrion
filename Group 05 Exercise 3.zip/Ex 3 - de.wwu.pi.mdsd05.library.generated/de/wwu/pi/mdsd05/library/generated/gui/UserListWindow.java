package de.wwu.pi.mdsd05.library.generated.gui;

import java.util.Vector;

import de.wwu.pi.mdsd.framework.gui.AbstractListWindow;
import de.wwu.pi.mdsd.framework.gui.AbstractWindow;
import de.wwu.pi.mdsd05.library.generated.logic.ServiceInitializer;
import de.wwu.pi.mdsd05.library.generated.data.User;
	
public class UserListWindow extends AbstractListWindow<User> implements UserListingInterface{

	public UserListWindow(AbstractWindow parent) {
		super(parent);
	}

	@Override
	public void showEntryWindow(User entity) {
		//If entity is null -> initialize entity as new entity
		//show Entity Edit Window
		if(entity == null)
			entity = new User();
		new UserEntryWindow(this,entity).open();
	}
	

	@Override
	public Vector<User> getElements() {
		return new Vector<User>(ServiceInitializer.getProvider().getUserService().getAll());
	}
	
	@Override
	public void initializeUserListings() {
		initializeList();
	}
}

interface UserListingInterface {
	public void initializeUserListings();
}
