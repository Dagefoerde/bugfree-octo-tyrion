package de.wwu.pi.mdsd05.library.generated.gui;

import java.util.Vector;

import de.wwu.pi.mdsd.framework.gui.AbstractListWindow;
import de.wwu.pi.mdsd.framework.gui.AbstractWindow;
import de.wwu.pi.mdsd05.library.generated.logic.ServiceInitializer;
import de.wwu.pi.mdsd05.library.generated.data.Book;
	
public class BookListWindow extends AbstractListWindow<Book> implements BookListingInterface{

	public BookListWindow(AbstractWindow parent) {
		super(parent);
	}

	@Override
	public void showEntryWindow(Book entity) {
		//If entity is null -> initialize entity as new entity
		//show Entity Edit Window
		if(entity == null)
			entity = new Book();
		new BookEntryWindow(this,entity).open();
	}
	

	@Override
	public Vector<Book> getElements() {
		return new Vector<Book>(ServiceInitializer.getProvider().getBookService().getAll());
	}
	
	@Override
	public void initializeBookListings() {
		initializeList();
	}
}

interface BookListingInterface {
	public void initializeBookListings();
}
