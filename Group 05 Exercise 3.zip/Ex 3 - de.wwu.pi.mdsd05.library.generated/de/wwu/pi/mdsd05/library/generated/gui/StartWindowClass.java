package de.wwu.pi.mdsd05.library.generated.gui;
	
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import de.wwu.pi.mdsd.framework.gui.AbstractStartWindow;
import de.wwu.pi.mdsd05.library.generated.logic.ServiceInitializer;	

public class StartWindowClass extends AbstractStartWindow {
	
	@Override
	protected void ListChoices() {
		
		JButton MediumListWindow = new JButton("List Medium Elements");
		GridBagConstraints gbc_MediumListWindow = new GridBagConstraints();
		gbc_MediumListWindow.insets = new Insets(0, 0, 5, 5);
		gbc_MediumListWindow.gridx = 1;
		gbc_MediumListWindow.gridy = getNextGridY();
		getPanel().add(MediumListWindow, gbc_MediumListWindow);
		MediumListWindow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new MediumListWindow(StartWindowClass.this).open();
			}
		});
		JButton BookListWindow = new JButton("List Book Elements");
		GridBagConstraints gbc_BookListWindow = new GridBagConstraints();
		gbc_BookListWindow.insets = new Insets(0, 0, 5, 5);
		gbc_BookListWindow.gridx = 1;
		gbc_BookListWindow.gridy = getNextGridY();
		getPanel().add(BookListWindow, gbc_BookListWindow);
		BookListWindow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new BookListWindow(StartWindowClass.this).open();
			}
		});
		JButton CDListWindow = new JButton("List CD Elements");
		GridBagConstraints gbc_CDListWindow = new GridBagConstraints();
		gbc_CDListWindow.insets = new Insets(0, 0, 5, 5);
		gbc_CDListWindow.gridx = 1;
		gbc_CDListWindow.gridy = getNextGridY();
		getPanel().add(CDListWindow, gbc_CDListWindow);
		CDListWindow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new CDListWindow(StartWindowClass.this).open();
			}
		});
		JButton CopyListWindow = new JButton("List Copy Elements");
		GridBagConstraints gbc_CopyListWindow = new GridBagConstraints();
		gbc_CopyListWindow.insets = new Insets(0, 0, 5, 5);
		gbc_CopyListWindow.gridx = 1;
		gbc_CopyListWindow.gridy = getNextGridY();
		getPanel().add(CopyListWindow, gbc_CopyListWindow);
		CopyListWindow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new CopyListWindow(StartWindowClass.this).open();
			}
		});
		JButton LoanListWindow = new JButton("List Loan Elements");
		GridBagConstraints gbc_LoanListWindow = new GridBagConstraints();
		gbc_LoanListWindow.insets = new Insets(0, 0, 5, 5);
		gbc_LoanListWindow.gridx = 1;
		gbc_LoanListWindow.gridy = getNextGridY();
		getPanel().add(LoanListWindow, gbc_LoanListWindow);
		LoanListWindow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new LoanListWindow(StartWindowClass.this).open();
			}
		});
		JButton UserListWindow = new JButton("List User Elements");
		GridBagConstraints gbc_UserListWindow = new GridBagConstraints();
		gbc_UserListWindow.insets = new Insets(0, 0, 5, 5);
		gbc_UserListWindow.gridx = 1;
		gbc_UserListWindow.gridy = getNextGridY();
		getPanel().add(UserListWindow, gbc_UserListWindow);
		UserListWindow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new UserListWindow(StartWindowClass.this).open();
			}
		});
		}
		
	@Override
	protected void closeWindow()  {
		ServiceInitializer.serialize();
		super.closeWindow();
	}

	
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
		UIManager.setLookAndFeel(
			UIManager.getSystemLookAndFeelClassName());
			//"com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		new StartWindowClass().open();
	}
}
	
