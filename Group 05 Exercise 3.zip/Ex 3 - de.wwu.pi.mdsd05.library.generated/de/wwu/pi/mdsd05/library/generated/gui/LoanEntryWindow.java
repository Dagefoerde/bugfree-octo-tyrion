	
package de.wwu.pi.mdsd05.library.generated.gui;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.*;

import javax.swing.*;

import de.wwu.pi.mdsd.framework.gui.*;
import de.wwu.pi.mdsd.framework.logic.ValidationException;

import de.wwu.pi.mdsd05.library.generated.data.Loan;
import de.wwu.pi.mdsd05.library.generated.data.User;	
import de.wwu.pi.mdsd05.library.generated.data.Copy;	
import de.wwu.pi.mdsd05.library.generated.logic.LoanService;
import de.wwu.pi.mdsd05.library.generated.logic.ServiceInitializer;

public class LoanEntryWindow extends AbstractEntryWindow<Loan>   {
	private JComboBox<User> cb_user;
	private JComboBox<Copy> cb_copy;
	private JTextField tf_IssueDate;
	private JTextField tf_ReturnDate;
	private LoanService service;
	
	public LoanEntryWindow(AbstractWindow parent, Loan currentEntity) {
		super(parent, currentEntity);
		service = ServiceInitializer.getProvider().getLoanService();
	}

	@Override
	protected void createFields() {
		int gridy = 0;
		
		
		//set new Line
		gridy = getNextGridYValue();
		
		JLabel lblIssueDate = new JLabel("IssueDate*");
		GridBagConstraints gbc_lblIssueDate = new GridBagConstraints();
		gbc_lblIssueDate.insets = new Insets(0, 0, 5, 5);
		gbc_lblIssueDate.anchor = GridBagConstraints.NORTHEAST;
		gbc_lblIssueDate.gridx = 0;
		gbc_lblIssueDate.gridy = gridy;
		getPanel().add(lblIssueDate, gbc_lblIssueDate);
		
		tf_IssueDate = new JTextField(Util.DATE_TIME_FORMATTER.format(currentEntity.getIssueDate()));
		GridBagConstraints gbc_tf_IssueDate = new GridBagConstraints();
		gbc_tf_IssueDate.gridwidth = 3;
		gbc_tf_IssueDate.insets = new Insets(0, 0, 5, 5);
		gbc_tf_IssueDate.anchor = GridBagConstraints.NORTHWEST;
		gbc_tf_IssueDate.fill = GridBagConstraints.HORIZONTAL;
		gbc_tf_IssueDate.gridx = 1;
		gbc_tf_IssueDate.weighty = .2;
		gbc_tf_IssueDate.gridy = gridy;
		getPanel().add(tf_IssueDate, gbc_tf_IssueDate);
		//set new Line
		gridy = getNextGridYValue();
		
		JLabel lblReturnDate = new JLabel("ReturnDate");
		GridBagConstraints gbc_lblReturnDate = new GridBagConstraints();
		gbc_lblReturnDate.insets = new Insets(0, 0, 5, 5);
		gbc_lblReturnDate.anchor = GridBagConstraints.NORTHEAST;
		gbc_lblReturnDate.gridx = 0;
		gbc_lblReturnDate.gridy = gridy;
		getPanel().add(lblReturnDate, gbc_lblReturnDate);
		
		tf_ReturnDate = new JTextField(Util.DATE_TIME_FORMATTER.format(currentEntity.getReturnDate()));
		GridBagConstraints gbc_tf_ReturnDate = new GridBagConstraints();
		gbc_tf_ReturnDate.gridwidth = 3;
		gbc_tf_ReturnDate.insets = new Insets(0, 0, 5, 5);
		gbc_tf_ReturnDate.anchor = GridBagConstraints.NORTHWEST;
		gbc_tf_ReturnDate.fill = GridBagConstraints.HORIZONTAL;
		gbc_tf_ReturnDate.gridx = 1;
		gbc_tf_ReturnDate.weighty = .2;
		gbc_tf_ReturnDate.gridy = gridy;
		getPanel().add(tf_ReturnDate, gbc_tf_ReturnDate);
		//set new Line
		gridy = getNextGridYValue();
		
		JLabel lbluser = new JLabel("User*");
		GridBagConstraints gbc_lbluser = new GridBagConstraints();
		gbc_lbluser.insets = new Insets(0, 0, 5, 5);
		gbc_lbluser.anchor = GridBagConstraints.NORTHEAST;
		gbc_lbluser.gridx = 0;
		gbc_lbluser.gridy = gridy;
		getPanel().add(lbluser, gbc_lbluser);
		
		cb_user = new JComboBox<User>(new Vector<>(ServiceInitializer.getProvider().getUserService().getAll()));
		cb_user.setSelectedItem(currentEntity.getUser());
		GridBagConstraints gbc_cb_user = new GridBagConstraints();
		gbc_cb_user.gridwidth = 3;
		gbc_cb_user.insets = new Insets(0, 0, 5, 5);
		gbc_cb_user.anchor = GridBagConstraints.NORTHWEST;
		gbc_cb_user.fill = GridBagConstraints.HORIZONTAL;
		gbc_cb_user.gridx = 1;
		gbc_cb_user.weighty = .2;
		gbc_cb_user.gridy = gridy;
		getPanel().add(cb_user, gbc_cb_user);
		//set new Line
		gridy = getNextGridYValue();
		
		JLabel lblcopy = new JLabel("Copy*");
		GridBagConstraints gbc_lblcopy = new GridBagConstraints();
		gbc_lblcopy.insets = new Insets(0, 0, 5, 5);
		gbc_lblcopy.anchor = GridBagConstraints.NORTHEAST;
		gbc_lblcopy.gridx = 0;
		gbc_lblcopy.gridy = gridy;
		getPanel().add(lblcopy, gbc_lblcopy);
		
		cb_copy = new JComboBox<Copy>(new Vector<>(ServiceInitializer.getProvider().getCopyService().getAll()));
		cb_copy.setSelectedItem(currentEntity.getCopy());
		GridBagConstraints gbc_cb_copy = new GridBagConstraints();
		gbc_cb_copy.gridwidth = 3;
		gbc_cb_copy.insets = new Insets(0, 0, 5, 5);
		gbc_cb_copy.anchor = GridBagConstraints.NORTHWEST;
		gbc_cb_copy.fill = GridBagConstraints.HORIZONTAL;
		gbc_cb_copy.gridx = 1;
		gbc_cb_copy.weighty = .2;
		gbc_cb_copy.gridy = gridy;
		getPanel().add(cb_copy, gbc_cb_copy);
	}
	
	@Override
	protected void createLists() {
		int gridy = 0;
		JButton btn;
		GridBagConstraints gbc_btn;
	}


	
	@Override
	protected boolean saveAction() throws ParseException {
		//Read values from different fields 
		Date IssueDate = tf_IssueDate.getText().isEmpty() ? null : Util.DATE_TIME_FORMATTER.parse(tf_IssueDate.getText());
		Date ReturnDate = tf_ReturnDate.getText().isEmpty() ? null : Util.DATE_TIME_FORMATTER.parse(tf_ReturnDate.getText());
		User user = cb_user.getItemAt(cb_user.getSelectedIndex());
		Copy copy = cb_copy.getItemAt(cb_copy.getSelectedIndex());
		
		//validation
		try {
			service.validateLoan(IssueDate,
			ReturnDate,
			user,
			copy
			);
		} catch (ValidationException e) {
			Util.showUserMessage("Validation error for " + e.getField(), "Validation error for " + e.getField() + ": " + e.getMessage());
			return false;
		}
		
		//persist
		currentEntity = service.saveLoan(currentEntity.getOid(), IssueDate, ReturnDate, user, copy);
		
		//reload the listing in the parent window to make changes visible
		if(getParent() instanceof LoanListingInterface)
			((LoanListingInterface) getParent()).initializeLoanListings();
		return true;
	}
}
	
	
	
