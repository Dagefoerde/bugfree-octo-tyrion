package de.wwu.pi.mdsd05.library.generated.gui;

import java.util.Vector;

import de.wwu.pi.mdsd.framework.gui.AbstractListWindow;
import de.wwu.pi.mdsd.framework.gui.AbstractWindow;
import de.wwu.pi.mdsd05.library.generated.logic.ServiceInitializer;
import de.wwu.pi.mdsd05.library.generated.data.Copy;
	
public class CopyListWindow extends AbstractListWindow<Copy> implements CopyListingInterface{

	public CopyListWindow(AbstractWindow parent) {
		super(parent);
	}

	@Override
	public void showEntryWindow(Copy entity) {
		//If entity is null -> initialize entity as new entity
		//show Entity Edit Window
		if(entity == null)
			entity = new Copy();
		new CopyEntryWindow(this,entity).open();
	}
	

	@Override
	public Vector<Copy> getElements() {
		return new Vector<Copy>(ServiceInitializer.getProvider().getCopyService().getAll());
	}
	
	@Override
	public void initializeCopyListings() {
		initializeList();
	}
}

interface CopyListingInterface {
	public void initializeCopyListings();
}
