package de.wwu.pi.mdsd05.library.generated.logic;

import java.util.Date; 
import de.wwu.pi.mdsd.framework.logic.AbstractServiceProvider;
import de.wwu.pi.mdsd.framework.logic.ValidationException;

import de.wwu.pi.mdsd05.library.generated.data.Loan;
import de.wwu.pi.mdsd05.library.generated.data.User; 
import de.wwu.pi.mdsd05.library.generated.data.Copy; 

public class LoanService extends AbstractServiceProvider<Loan> {

	protected LoanService() {
		super();
	}
	

	public boolean validateLoan(Date IssueDate, Date ReturnDate, User user, Copy copy) throws ValidationException {
		if(IssueDate == null)
			throw new ValidationException("IssueDate", "cannot be empty");
		if(user == null)
			throw new ValidationException("user", "cannot be empty");
		if(copy == null)
			throw new ValidationException("copy", "cannot be empty");
		return true;
	}


	
	public Loan saveLoan(int id, Date IssueDate, Date ReturnDate, User user, Copy copy){
		Loan elem = getByOId(id);
		if(elem == null) elem = new Loan();
		
		elem.setIssueDate(IssueDate);
		elem.setReturnDate(ReturnDate);
		elem.setUser(user);
		elem.setCopy(copy);
		persist(elem);
		return elem;
	}
	


}

