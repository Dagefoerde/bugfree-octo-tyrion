package de.wwu.pi.mdsd05.library.generated.data;

import de.wwu.pi.mdsd.framework.data.AbstractDataClass;
import java.util.Date;

public class Loan extends AbstractDataClass {
	private Date IssueDate;
	private Date ReturnDate;
	public User user;
	public Copy copy;

	public Date getIssueDate(){
		return IssueDate;
	}
	
	public void setIssueDate(Date IssueDate){
		this.IssueDate = IssueDate;
		
	}
	
	public Date getReturnDate(){
		return ReturnDate;
	}
	
	public void setReturnDate(Date ReturnDate){
		this.ReturnDate = ReturnDate;
		
	}
	
	public User getUser(){
		return user;
	}
	
	public void setUser(User user){
		//do nothing, if user is the same
		if(this.user == user) return;
		//remove old Loan from opposite
		if(this.user != null) this.user.getLoans().remove(this);
		//unless new user is null add 
		if(user != null) user.addLoan(this);
		this.user = user;
		
	}
	
	public Copy getCopy(){
		return copy;
	}
	
	public void setCopy(Copy copy){
		//do nothing, if copy is the same
		if(this.copy == copy) return;
		//remove old Loan from opposite
		if(this.copy != null) this.copy.getLoans().remove(this);
		//unless new copy is null add 
		if(copy != null) copy.addLoan(this);
		this.copy = copy;
		
	}
	
	public Loan() {
		super();	
	}
	
	public Loan (
		Date IssueDate,
		Date ReturnDate,
		User user,
		Copy copy
	) {
		super();
		this.IssueDate=IssueDate;
		this.ReturnDate=ReturnDate;
		this.user=user;
		this.copy=copy;
	}

	public Loan(User user) {
		super();
		this.user=user;
	}
	
	public Loan(Copy copy) {
		super();
		this.copy=copy;
	}
	
	@Override
	public String toString() {
		return (""
		+ getIssueDate() + "," 
		+ ( getReturnDate() == null ? "-" : getReturnDate() ) + "," 
		+ getUser() + "," 
		+ getCopy()
		);
	}
}

