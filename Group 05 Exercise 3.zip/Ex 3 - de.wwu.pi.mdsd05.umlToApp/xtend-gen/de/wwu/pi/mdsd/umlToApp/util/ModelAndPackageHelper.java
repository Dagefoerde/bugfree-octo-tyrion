package de.wwu.pi.mdsd.umlToApp.util;

import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import java.util.Set;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.uml2.uml.Classifier;
import org.eclipse.uml2.uml.Element;
import org.eclipse.uml2.uml.Generalization;
import org.eclipse.uml2.uml.Model;
import org.eclipse.uml2.uml.Property;
import org.eclipse.uml2.uml.Stereotype;
import org.eclipse.uml2.uml.Type;
import org.eclipse.uml2.uml.VisibilityKind;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class ModelAndPackageHelper {
  public final static String PACKAGE_STRING = "de.wwu.pi.mdsd05.library.generated";
  
  public static Iterable<org.eclipse.uml2.uml.Class> allEntities(final Model model) {
    EList<Element> _allOwnedElements = model.allOwnedElements();
    Iterable<org.eclipse.uml2.uml.Class> _filter = Iterables.<org.eclipse.uml2.uml.Class>filter(_allOwnedElements, org.eclipse.uml2.uml.Class.class);
    final Function1<org.eclipse.uml2.uml.Class,Boolean> _function = new Function1<org.eclipse.uml2.uml.Class,Boolean>() {
        public Boolean apply(final org.eclipse.uml2.uml.Class c) {
          EList<Stereotype> _appliedStereotypes = c.getAppliedStereotypes();
          final Function1<Stereotype,Boolean> _function = new Function1<Stereotype,Boolean>() {
              public Boolean apply(final Stereotype it) {
                String _name = it.getName();
                boolean _equals = "Entity".equals(_name);
                return Boolean.valueOf(_equals);
              }
            };
          boolean _exists = IterableExtensions.<Stereotype>exists(_appliedStereotypes, _function);
          return Boolean.valueOf(_exists);
        }
      };
    Iterable<org.eclipse.uml2.uml.Class> _filter_1 = IterableExtensions.<org.eclipse.uml2.uml.Class>filter(_filter, _function);
    return _filter_1;
  }
  
  public static String visibilityInJava(final VisibilityKind kind) {
    String _switchResult = null;
    boolean _matched = false;
    if (!_matched) {
      if (Objects.equal(kind,VisibilityKind.PACKAGE)) {
        _matched=true;
        _switchResult = "package";
      }
    }
    if (!_matched) {
      if (Objects.equal(kind,VisibilityKind.PROTECTED)) {
        _matched=true;
        _switchResult = "protected";
      }
    }
    if (!_matched) {
      if (Objects.equal(kind,VisibilityKind.PUBLIC)) {
        _matched=true;
        _switchResult = "public";
      }
    }
    if (!_matched) {
      if (Objects.equal(kind,VisibilityKind.PRIVATE)) {
        _matched=true;
        _switchResult = "private";
      }
    }
    return _switchResult;
  }
  
  public static String visibilityInJava(final Property p) {
    VisibilityKind _visibility = p.getVisibility();
    String _visibilityInJava = ModelAndPackageHelper.visibilityInJava(_visibility);
    return _visibilityInJava;
  }
  
  public static boolean isGeneralized(final org.eclipse.uml2.uml.Class c) {
    EList<Generalization> _generalizations = c.getGeneralizations();
    int _size = _generalizations.size();
    boolean _greaterThan = (_size > 0);
    return _greaterThan;
  }
  
  public static EList<Property> listOfSuperAttributes(final org.eclipse.uml2.uml.Class c) {
    BasicEList<Property> _basicEList = new BasicEList<Property>();
    EList<Property> listOfSuperAttributes = _basicEList;
    boolean _isGeneralized = ModelAndPackageHelper.isGeneralized(c);
    if (_isGeneralized) {
      EList<Generalization> _generalizations = c.getGeneralizations();
      Generalization _get = _generalizations.get(0);
      Classifier _general = _get.getGeneral();
      EList<Property> _attributes = _general.getAttributes();
      listOfSuperAttributes = _attributes;
    }
    return listOfSuperAttributes;
  }
  
  public static Set<Property> listOfAllAttributes(final org.eclipse.uml2.uml.Class c) {
    EList<Property> _attributes = c.getAttributes();
    final Set<Property> allAttributes = IterableExtensions.<Property>toSet(_attributes);
    boolean _isGeneralized = ModelAndPackageHelper.isGeneralized(c);
    if (_isGeneralized) {
      EList<Generalization> _generalizations = c.getGeneralizations();
      Generalization _get = _generalizations.get(0);
      Classifier _general = _get.getGeneral();
      EList<Property> _attributes_1 = _general.getAttributes();
      for (final Property att : _attributes_1) {
        allAttributes.add(att);
      }
    }
    return allAttributes;
  }
  
  public static Iterable<Property> listOfNotMultivaluedAttributes(final org.eclipse.uml2.uml.Class c) {
    Set<Property> _listOfAllAttributes = ModelAndPackageHelper.listOfAllAttributes(c);
    final Function1<Property,Boolean> _function = new Function1<Property,Boolean>() {
        public Boolean apply(final Property at) {
          boolean _isMultivalued = at.isMultivalued();
          boolean _not = (!_isMultivalued);
          return Boolean.valueOf(_not);
        }
      };
    Iterable<Property> _filter = IterableExtensions.<Property>filter(_listOfAllAttributes, _function);
    return _filter;
  }
  
  public static Iterable<Property> listOfClassAttributes(final org.eclipse.uml2.uml.Class c) {
    Set<Property> _listOfAllAttributes = ModelAndPackageHelper.listOfAllAttributes(c);
    final Function1<Property,Boolean> _function = new Function1<Property,Boolean>() {
        public Boolean apply(final Property at) {
          Type _type = at.getType();
          return Boolean.valueOf((_type instanceof org.eclipse.uml2.uml.Class));
        }
      };
    Iterable<Property> _filter = IterableExtensions.<Property>filter(_listOfAllAttributes, _function);
    return _filter;
  }
  
  public static Iterable<Property> listOfMultivaluedClassAttributes(final org.eclipse.uml2.uml.Class c) {
    Set<Property> _listOfAllAttributes = ModelAndPackageHelper.listOfAllAttributes(c);
    final Function1<Property,Boolean> _function = new Function1<Property,Boolean>() {
        public Boolean apply(final Property at) {
          boolean _and = false;
          boolean _isMultivalued = at.isMultivalued();
          if (!_isMultivalued) {
            _and = false;
          } else {
            Type _type = at.getType();
            _and = (_isMultivalued && (_type instanceof org.eclipse.uml2.uml.Class));
          }
          return Boolean.valueOf(_and);
        }
      };
    Iterable<Property> _filter = IterableExtensions.<Property>filter(_listOfAllAttributes, _function);
    return _filter;
  }
  
  public static Iterable<Property> listOfNotMultivaluedClassAttributes(final org.eclipse.uml2.uml.Class c) {
    Set<Property> _listOfAllAttributes = ModelAndPackageHelper.listOfAllAttributes(c);
    final Function1<Property,Boolean> _function = new Function1<Property,Boolean>() {
        public Boolean apply(final Property at) {
          boolean _and = false;
          boolean _isMultivalued = at.isMultivalued();
          boolean _not = (!_isMultivalued);
          if (!_not) {
            _and = false;
          } else {
            Type _type = at.getType();
            _and = (_not && (_type instanceof org.eclipse.uml2.uml.Class));
          }
          return Boolean.valueOf(_and);
        }
      };
    Iterable<Property> _filter = IterableExtensions.<Property>filter(_listOfAllAttributes, _function);
    return _filter;
  }
  
  public static Iterable<Property> listOfNotMultivaluedNonClassAttributes(final org.eclipse.uml2.uml.Class c) {
    Set<Property> _listOfAllAttributes = ModelAndPackageHelper.listOfAllAttributes(c);
    final Function1<Property,Boolean> _function = new Function1<Property,Boolean>() {
        public Boolean apply(final Property at) {
          boolean _and = false;
          boolean _isMultivalued = at.isMultivalued();
          boolean _not = (!_isMultivalued);
          if (!_not) {
            _and = false;
          } else {
            Type _type = at.getType();
            boolean _not_1 = (!(_type instanceof org.eclipse.uml2.uml.Class));
            _and = (_not && _not_1);
          }
          return Boolean.valueOf(_and);
        }
      };
    Iterable<Property> _filter = IterableExtensions.<Property>filter(_listOfAllAttributes, _function);
    return _filter;
  }
  
  public static Iterable<org.eclipse.uml2.uml.Class> listOfExtendingClasses(final org.eclipse.uml2.uml.Class c) {
    Model _model = c.getModel();
    Iterable<org.eclipse.uml2.uml.Class> _allEntities = ModelAndPackageHelper.allEntities(_model);
    final Function1<org.eclipse.uml2.uml.Class,Boolean> _function = new Function1<org.eclipse.uml2.uml.Class,Boolean>() {
        public Boolean apply(final org.eclipse.uml2.uml.Class ent) {
          EList<Generalization> _generalizations = ent.getGeneralizations();
          final Function1<Generalization,Boolean> _function = new Function1<Generalization,Boolean>() {
              public Boolean apply(final Generalization gen) {
                Classifier _general = gen.getGeneral();
                boolean _equals = _general.equals(c);
                return Boolean.valueOf(_equals);
              }
            };
          boolean _exists = IterableExtensions.<Generalization>exists(_generalizations, _function);
          return Boolean.valueOf(_exists);
        }
      };
    Iterable<org.eclipse.uml2.uml.Class> _filter = IterableExtensions.<org.eclipse.uml2.uml.Class>filter(_allEntities, _function);
    return _filter;
  }
}
