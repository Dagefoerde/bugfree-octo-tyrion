package de.wwu.pi.mdsd.umlToApp.logic;

import de.wwu.pi.mdsd.umlToApp.util.ModelAndPackageHelper;
import org.eclipse.emf.common.util.EList;
import org.eclipse.uml2.uml.Property;
import org.eclipse.uml2.uml.Type;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.StringExtensions;

@SuppressWarnings("all")
public class EntityServiceGenerator {
  public CharSequence generateEntityServiceClass(final org.eclipse.uml2.uml.Class clazz) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("package ");
    _builder.append(ModelAndPackageHelper.PACKAGE_STRING, "");
    _builder.append(".logic;");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    {
      EList<Property> _ownedAttributes = clazz.getOwnedAttributes();
      final Function1<Property,Boolean> _function = new Function1<Property,Boolean>() {
          public Boolean apply(final Property a) {
            Type _type = a.getType();
            String _name = _type.getName();
            boolean _equals = _name.equals("Date");
            return Boolean.valueOf(_equals);
          }
        };
      boolean _exists = IterableExtensions.<Property>exists(_ownedAttributes, _function);
      if (_exists) {
        _builder.append("import java.util.Date; ");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("import de.wwu.pi.mdsd.framework.logic.AbstractServiceProvider;");
    _builder.newLine();
    _builder.append("import de.wwu.pi.mdsd.framework.logic.ValidationException;");
    _builder.newLine();
    {
      Iterable<org.eclipse.uml2.uml.Class> _listOfExtendingClasses = ModelAndPackageHelper.listOfExtendingClasses(clazz);
      int _size = IterableExtensions.size(_listOfExtendingClasses);
      boolean _greaterThan = (_size > 0);
      if (_greaterThan) {
        _builder.append("import java.util.Collection;");
        _builder.newLine();
        _builder.append("import java.util.LinkedList;");
        _builder.newLine();
      }
    }
    _builder.newLine();
    _builder.append("import ");
    _builder.append(ModelAndPackageHelper.PACKAGE_STRING, "");
    _builder.append(".data.");
    String _name = clazz.getName();
    _builder.append(_name, "");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    {
      Iterable<Property> _listOfNotMultivaluedClassAttributes = ModelAndPackageHelper.listOfNotMultivaluedClassAttributes(clazz);
      for(final Property attribute : _listOfNotMultivaluedClassAttributes) {
        _builder.append("import ");
        _builder.append(ModelAndPackageHelper.PACKAGE_STRING, "");
        _builder.append(".data.");
        Type _type = attribute.getType();
        String _name_1 = _type.getName();
        _builder.append(_name_1, "");
        _builder.append("; ");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.newLine();
    _builder.append("public class ");
    String _name_2 = clazz.getName();
    _builder.append(_name_2, "");
    _builder.append("Service extends AbstractServiceProvider<");
    String _name_3 = clazz.getName();
    _builder.append(_name_3, "");
    _builder.append("> {");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("\t");
    _builder.append("protected ");
    String _name_4 = clazz.getName();
    _builder.append(_name_4, "	");
    _builder.append("Service() {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("super();");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.newLine();
    _builder.append("\t");
    _builder.append("public boolean validate");
    String _name_5 = clazz.getName();
    String _firstUpper = StringExtensions.toFirstUpper(_name_5);
    _builder.append(_firstUpper, "	");
    _builder.append("(");
    {
      Iterable<Property> _listOfNotMultivaluedAttributes = ModelAndPackageHelper.listOfNotMultivaluedAttributes(clazz);
      boolean _hasElements = false;
      for(final Property attribute_1 : _listOfNotMultivaluedAttributes) {
        if (!_hasElements) {
          _hasElements = true;
        } else {
          _builder.appendImmediate(", ", "	");
        }
        Type _type_1 = attribute_1.getType();
        String _name_6 = _type_1.getName();
        _builder.append(_name_6, "	");
        _builder.append(" ");
        String _name_7 = attribute_1.getName();
        _builder.append(_name_7, "	");
      }
    }
    _builder.append(") throws ValidationException {");
    _builder.newLineIfNotEmpty();
    {
      Iterable<Property> _listOfNotMultivaluedAttributes_1 = ModelAndPackageHelper.listOfNotMultivaluedAttributes(clazz);
      final Function1<Property,Boolean> _function_1 = new Function1<Property,Boolean>() {
          public Boolean apply(final Property a) {
            int _lowerBound = a.lowerBound();
            boolean _greaterThan = (_lowerBound > 0);
            return Boolean.valueOf(_greaterThan);
          }
        };
      Iterable<Property> _filter = IterableExtensions.<Property>filter(_listOfNotMultivaluedAttributes_1, _function_1);
      for(final Property attribute_2 : _filter) {
        _builder.append("\t\t");
        _builder.append("if(");
        String _name_8 = attribute_2.getName();
        _builder.append(_name_8, "		");
        _builder.append(" == null)");
        _builder.newLineIfNotEmpty();
        _builder.append("\t\t");
        _builder.append("\t");
        _builder.append("throw new ValidationException(\"");
        String _name_9 = attribute_2.getName();
        _builder.append(_name_9, "			");
        _builder.append("\", \"cannot be empty\");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t\t");
    _builder.append("return true;");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("public ");
    String _name_10 = clazz.getName();
    _builder.append(_name_10, "	");
    _builder.append(" save");
    String _name_11 = clazz.getName();
    String _firstUpper_1 = StringExtensions.toFirstUpper(_name_11);
    _builder.append(_firstUpper_1, "	");
    _builder.append("(int id, ");
    {
      Iterable<Property> _listOfNotMultivaluedAttributes_2 = ModelAndPackageHelper.listOfNotMultivaluedAttributes(clazz);
      boolean _hasElements_1 = false;
      for(final Property attribute_3 : _listOfNotMultivaluedAttributes_2) {
        if (!_hasElements_1) {
          _hasElements_1 = true;
        } else {
          _builder.appendImmediate(", ", "	");
        }
        Type _type_2 = attribute_3.getType();
        String _name_12 = _type_2.getName();
        _builder.append(_name_12, "	");
        _builder.append(" ");
        String _name_13 = attribute_3.getName();
        _builder.append(_name_13, "	");
      }
    }
    _builder.append("){");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    String _name_14 = clazz.getName();
    _builder.append(_name_14, "		");
    _builder.append(" elem = getByOId(id);");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("if(elem == null) elem = new ");
    String _name_15 = clazz.getName();
    _builder.append(_name_15, "		");
    _builder.append("();");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.newLine();
    {
      Iterable<Property> _listOfNotMultivaluedAttributes_3 = ModelAndPackageHelper.listOfNotMultivaluedAttributes(clazz);
      for(final Property attribute_4 : _listOfNotMultivaluedAttributes_3) {
        _builder.append("\t\t");
        _builder.append("elem.set");
        String _name_16 = attribute_4.getName();
        String _firstUpper_2 = StringExtensions.toFirstUpper(_name_16);
        _builder.append(_firstUpper_2, "		");
        _builder.append("(");
        String _name_17 = attribute_4.getName();
        _builder.append(_name_17, "		");
        _builder.append(");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t\t");
    _builder.append("persist(elem);");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("return elem;");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    {
      Iterable<org.eclipse.uml2.uml.Class> _listOfExtendingClasses_1 = ModelAndPackageHelper.listOfExtendingClasses(clazz);
      int _size_1 = IterableExtensions.size(_listOfExtendingClasses_1);
      boolean _greaterThan_1 = (_size_1 > 0);
      if (_greaterThan_1) {
        _builder.append("\t");
        _builder.append("@Override");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("public Collection<");
        String _name_18 = clazz.getName();
        _builder.append(_name_18, "	");
        _builder.append("> getAll() {");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("Collection<");
        String _name_19 = clazz.getName();
        _builder.append(_name_19, "		");
        _builder.append("> result = new LinkedList<");
        String _name_20 = clazz.getName();
        _builder.append(_name_20, "		");
        _builder.append(">();");
        _builder.newLineIfNotEmpty();
        {
          Iterable<org.eclipse.uml2.uml.Class> _listOfExtendingClasses_2 = ModelAndPackageHelper.listOfExtendingClasses(clazz);
          for(final org.eclipse.uml2.uml.Class ext : _listOfExtendingClasses_2) {
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("result.addAll(ServiceInitializer.getProvider().get");
            String _name_21 = ext.getName();
            String _firstUpper_3 = StringExtensions.toFirstUpper(_name_21);
            _builder.append(_firstUpper_3, "		");
            _builder.append("Service().getAll());");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("return result;");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("}\t");
        _builder.newLine();
      }
    }
    _builder.newLine();
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    return _builder;
  }
}
