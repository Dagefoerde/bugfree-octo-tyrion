package de.wwu.pi.mdsd.umlToApp;

import com.google.common.collect.Iterables;
import de.wwu.pi.mdsd.umlToApp.data.DataClassGenerator;
import de.wwu.pi.mdsd.umlToApp.gui.EntryWindowGenerator;
import de.wwu.pi.mdsd.umlToApp.gui.ListWindowGenerator;
import de.wwu.pi.mdsd.umlToApp.gui.StartWindowClassGenerator;
import de.wwu.pi.mdsd.umlToApp.logic.EntityServiceGenerator;
import de.wwu.pi.mdsd.umlToApp.logic.ServiceInitializerGenerator;
import de.wwu.pi.mdsd.umlToApp.util.ModelAndPackageHelper;
import java.io.File;
import java.util.ArrayList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.uml2.uml.Model;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.generator.IFileSystemAccess;
import org.eclipse.xtext.generator.IGenerator;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Functions.Function0;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@SuppressWarnings("all")
public class UmlToAppGenerator implements IGenerator {
  private final static ArrayList<String> INTERNAL_MODEL_EXTENSIONS = new Function0<ArrayList<String>>() {
    public ArrayList<String> apply() {
      ArrayList<String> _newArrayList = CollectionLiterals.<String>newArrayList(".library.uml", ".profile.uml", ".metamodel.uml");
      return _newArrayList;
    }
  }.apply();
  
  public static boolean isModel(final Resource input) {
    final Function1<String,Boolean> _function = new Function1<String,Boolean>() {
        public Boolean apply(final String ext) {
          URI _uRI = input.getURI();
          String _path = _uRI.path();
          boolean _endsWith = _path.endsWith(ext);
          return Boolean.valueOf(_endsWith);
        }
      };
    boolean _exists = IterableExtensions.<String>exists(UmlToAppGenerator.INTERNAL_MODEL_EXTENSIONS, _function);
    boolean _not = (!_exists);
    return _not;
  }
  
  public void doGenerate(final Resource input, final IFileSystemAccess fsa) {
    URI _uRI = input.getURI();
    String _plus = ("UmlToAppGenerator.doGenerate called with resource " + _uRI);
    InputOutput.<String>print(_plus);
    boolean _isModel = UmlToAppGenerator.isModel(input);
    if (_isModel) {
      InputOutput.<String>println(" - Generating ...");
      EList<EObject> _contents = input.getContents();
      Iterable<Model> _filter = Iterables.<Model>filter(_contents, Model.class);
      final Procedure1<Model> _function = new Procedure1<Model>() {
          public void apply(final Model it) {
            UmlToAppGenerator.this.doGenerate(it, fsa);
          }
        };
      IterableExtensions.<Model>forEach(_filter, _function);
    } else {
      InputOutput.<String>println(" - Skipped.");
    }
  }
  
  public void doGenerate(final Model model, final IFileSystemAccess fsa) {
    final String PACKAGE_DIR = ModelAndPackageHelper.PACKAGE_STRING.replace('.', File.separatorChar);
    Iterable<org.eclipse.uml2.uml.Class> _allEntities = ModelAndPackageHelper.allEntities(model);
    final Procedure1<org.eclipse.uml2.uml.Class> _function = new Procedure1<org.eclipse.uml2.uml.Class>() {
        public void apply(final org.eclipse.uml2.uml.Class clazz) {
          StringConcatenation _builder = new StringConcatenation();
          _builder.append(PACKAGE_DIR, "");
          _builder.append(File.separatorChar, "");
          _builder.append("data");
          _builder.append(File.separatorChar, "");
          String _name = clazz.getName();
          _builder.append(_name, "");
          _builder.append(".java");
          DataClassGenerator _dataClassGenerator = new DataClassGenerator();
          CharSequence _generateDataClass = _dataClassGenerator.generateDataClass(clazz);
          fsa.generateFile(_builder.toString(), _generateDataClass);
          StringConcatenation _builder_1 = new StringConcatenation();
          _builder_1.append(PACKAGE_DIR, "");
          _builder_1.append(File.separatorChar, "");
          _builder_1.append("gui");
          _builder_1.append(File.separatorChar, "");
          String _name_1 = clazz.getName();
          _builder_1.append(_name_1, "");
          _builder_1.append("ListWindow.java");
          ListWindowGenerator _listWindowGenerator = new ListWindowGenerator();
          CharSequence _generateListWindow = _listWindowGenerator.generateListWindow(clazz);
          fsa.generateFile(_builder_1.toString(), _generateListWindow);
          StringConcatenation _builder_2 = new StringConcatenation();
          _builder_2.append(PACKAGE_DIR, "");
          _builder_2.append(File.separatorChar, "");
          _builder_2.append("logic");
          _builder_2.append(File.separatorChar, "");
          String _name_2 = clazz.getName();
          _builder_2.append(_name_2, "");
          _builder_2.append("Service.java");
          EntityServiceGenerator _entityServiceGenerator = new EntityServiceGenerator();
          CharSequence _generateEntityServiceClass = _entityServiceGenerator.generateEntityServiceClass(clazz);
          fsa.generateFile(_builder_2.toString(), _generateEntityServiceClass);
          boolean _isAbstract = clazz.isAbstract();
          boolean _not = (!_isAbstract);
          if (_not) {
            StringConcatenation _builder_3 = new StringConcatenation();
            _builder_3.append(PACKAGE_DIR, "");
            _builder_3.append(File.separatorChar, "");
            _builder_3.append("gui");
            _builder_3.append(File.separatorChar, "");
            String _name_3 = clazz.getName();
            _builder_3.append(_name_3, "");
            _builder_3.append("EntryWindow.java");
            EntryWindowGenerator _entryWindowGenerator = new EntryWindowGenerator();
            CharSequence _generateEntryWindow = _entryWindowGenerator.generateEntryWindow(clazz);
            fsa.generateFile(_builder_3.toString(), _generateEntryWindow);
          }
        }
      };
    IterableExtensions.<org.eclipse.uml2.uml.Class>forEach(_allEntities, _function);
    StringConcatenation _builder = new StringConcatenation();
    _builder.append(PACKAGE_DIR, "");
    _builder.append(File.separatorChar, "");
    _builder.append("logic");
    _builder.append(File.separatorChar, "");
    _builder.append("ServiceInitializer.java");
    ServiceInitializerGenerator _serviceInitializerGenerator = new ServiceInitializerGenerator();
    Iterable<org.eclipse.uml2.uml.Class> _allEntities_1 = ModelAndPackageHelper.allEntities(model);
    CharSequence _generateServiceInitializer = _serviceInitializerGenerator.generateServiceInitializer(_allEntities_1);
    fsa.generateFile(_builder.toString(), _generateServiceInitializer);
    StringConcatenation _builder_1 = new StringConcatenation();
    _builder_1.append(PACKAGE_DIR, "");
    _builder_1.append(File.separatorChar, "");
    _builder_1.append("gui");
    _builder_1.append(File.separatorChar, "");
    _builder_1.append("StartWindowClass.java");
    StartWindowClassGenerator _startWindowClassGenerator = new StartWindowClassGenerator();
    Iterable<org.eclipse.uml2.uml.Class> _allEntities_2 = ModelAndPackageHelper.allEntities(model);
    CharSequence _generateStartWindowClass = _startWindowClassGenerator.generateStartWindowClass(_allEntities_2);
    fsa.generateFile(_builder_1.toString(), _generateStartWindowClass);
  }
}
