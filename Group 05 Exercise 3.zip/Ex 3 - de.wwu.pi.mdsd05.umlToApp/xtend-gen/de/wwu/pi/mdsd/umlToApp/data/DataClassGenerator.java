package de.wwu.pi.mdsd.umlToApp.data;

import de.wwu.pi.mdsd.umlToApp.util.ModelAndPackageHelper;
import org.eclipse.emf.common.util.EList;
import org.eclipse.uml2.uml.Classifier;
import org.eclipse.uml2.uml.Generalization;
import org.eclipse.uml2.uml.Property;
import org.eclipse.uml2.uml.Type;
import org.eclipse.uml2.uml.VisibilityKind;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.StringExtensions;

@SuppressWarnings("all")
public class DataClassGenerator {
  public CharSequence generateDataClass(final org.eclipse.uml2.uml.Class clazz) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("package ");
    _builder.append(ModelAndPackageHelper.PACKAGE_STRING, "");
    _builder.append(".data;");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    {
      EList<Generalization> _generalizations = clazz.getGeneralizations();
      int _size = _generalizations.size();
      boolean _equals = (_size == 0);
      if (_equals) {
        _builder.append("import de.wwu.pi.mdsd.framework.data.AbstractDataClass;");
        _builder.newLine();
      }
    }
    {
      EList<Property> _ownedAttributes = clazz.getOwnedAttributes();
      final Function1<Property,Boolean> _function = new Function1<Property,Boolean>() {
          public Boolean apply(final Property a) {
            boolean _isMultivalued = a.isMultivalued();
            return Boolean.valueOf(_isMultivalued);
          }
        };
      boolean _exists = IterableExtensions.<Property>exists(_ownedAttributes, _function);
      if (_exists) {
        _builder.append("import java.util.List;");
        _builder.newLineIfNotEmpty();
        _builder.append("import java.util.ArrayList;");
        _builder.newLine();
      }
    }
    {
      EList<Property> _ownedAttributes_1 = clazz.getOwnedAttributes();
      final Function1<Property,Boolean> _function_1 = new Function1<Property,Boolean>() {
          public Boolean apply(final Property a) {
            Type _type = a.getType();
            String _name = _type.getName();
            boolean _equals = _name.equals("Date");
            return Boolean.valueOf(_equals);
          }
        };
      boolean _exists_1 = IterableExtensions.<Property>exists(_ownedAttributes_1, _function_1);
      if (_exists_1) {
        _builder.append("import java.util.Date;");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.newLine();
    _builder.append("public class ");
    String _name = clazz.getName();
    _builder.append(_name, "");
    _builder.append(" extends ");
    {
      EList<Generalization> _generalizations_1 = clazz.getGeneralizations();
      int _size_1 = _generalizations_1.size();
      boolean _greaterThan = (_size_1 > 0);
      if (_greaterThan) {
        EList<Generalization> _generalizations_2 = clazz.getGeneralizations();
        Generalization _get = _generalizations_2.get(0);
        Classifier _general = _get.getGeneral();
        String _name_1 = _general.getName();
        _builder.append(_name_1, "");
      } else {
        _builder.append("AbstractDataClass");
      }
    }
    _builder.append(" {");
    _builder.newLineIfNotEmpty();
    {
      EList<Property> _ownedAttributes_2 = clazz.getOwnedAttributes();
      for(final Property attribute : _ownedAttributes_2) {
        {
          boolean _and = false;
          Type _type = attribute.getType();
          if (!(_type instanceof org.eclipse.uml2.uml.Class)) {
            _and = false;
          } else {
            boolean _isMultivalued = attribute.isMultivalued();
            _and = ((_type instanceof org.eclipse.uml2.uml.Class) && _isMultivalued);
          }
          if (_and) {
            _builder.append("\t");
            VisibilityKind _visibility = attribute.getVisibility();
            _builder.append(_visibility, "	");
            _builder.append(" List<");
            Type _type_1 = attribute.getType();
            String _name_2 = _type_1.getName();
            _builder.append(_name_2, "	");
            _builder.append("> ");
            String _name_3 = attribute.getName();
            _builder.append(_name_3, "	");
            _builder.append("s = new ArrayList<");
            Type _type_2 = attribute.getType();
            String _name_4 = _type_2.getName();
            _builder.append(_name_4, "	");
            _builder.append(">();\t");
            _builder.newLineIfNotEmpty();
          } else {
            _builder.append("\t");
            VisibilityKind _visibility_1 = attribute.getVisibility();
            _builder.append(_visibility_1, "	");
            _builder.append(" ");
            Type _type_3 = attribute.getType();
            String _name_5 = _type_3.getName();
            _builder.append(_name_5, "	");
            _builder.append(" ");
            String _name_6 = attribute.getName();
            _builder.append(_name_6, "	");
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.newLine();
    {
      EList<Property> _ownedAttributes_3 = clazz.getOwnedAttributes();
      for(final Property attribute_1 : _ownedAttributes_3) {
        {
          boolean _and_1 = false;
          Type _type_4 = attribute_1.getType();
          if (!(_type_4 instanceof org.eclipse.uml2.uml.Class)) {
            _and_1 = false;
          } else {
            boolean _isMultivalued_1 = attribute_1.isMultivalued();
            _and_1 = ((_type_4 instanceof org.eclipse.uml2.uml.Class) && _isMultivalued_1);
          }
          if (_and_1) {
            _builder.append("\t");
            _builder.append("public List<");
            Type _type_5 = attribute_1.getType();
            String _name_7 = _type_5.getName();
            _builder.append(_name_7, "	");
            _builder.append("> get");
            String _name_8 = attribute_1.getName();
            String _firstUpper = StringExtensions.toFirstUpper(_name_8);
            _builder.append(_firstUpper, "	");
            _builder.append("s(){");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("return ");
            String _name_9 = attribute_1.getName();
            _builder.append(_name_9, "		");
            _builder.append("s;");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("}");
            _builder.newLine();
            _builder.append("\t");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("//called only by friend method");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("protected void add");
            String _name_10 = attribute_1.getName();
            String _firstUpper_1 = StringExtensions.toFirstUpper(_name_10);
            _builder.append(_firstUpper_1, "	");
            _builder.append("(");
            Type _type_6 = attribute_1.getType();
            String _name_11 = _type_6.getName();
            _builder.append(_name_11, "	");
            _builder.append(" ");
            String _name_12 = attribute_1.getName();
            _builder.append(_name_12, "	");
            _builder.append("){");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("\t");
            String _name_13 = attribute_1.getName();
            _builder.append(_name_13, "		");
            _builder.append("s.add(");
            String _name_14 = attribute_1.getName();
            _builder.append(_name_14, "		");
            _builder.append(");");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("}");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("\t");
            _builder.newLine();
          } else {
            _builder.append("\t");
            _builder.append("public ");
            Type _type_7 = attribute_1.getType();
            String _name_15 = _type_7.getName();
            _builder.append(_name_15, "	");
            _builder.append(" get");
            String _name_16 = attribute_1.getName();
            String _firstUpper_2 = StringExtensions.toFirstUpper(_name_16);
            _builder.append(_firstUpper_2, "	");
            _builder.append("(){");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("return ");
            String _name_17 = attribute_1.getName();
            _builder.append(_name_17, "		");
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("}");
            _builder.newLine();
            _builder.append("\t");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("public void set");
            String _name_18 = attribute_1.getName();
            String _firstUpper_3 = StringExtensions.toFirstUpper(_name_18);
            _builder.append(_firstUpper_3, "	");
            _builder.append("(");
            Type _type_8 = attribute_1.getType();
            String _name_19 = _type_8.getName();
            _builder.append(_name_19, "	");
            _builder.append(" ");
            String _name_20 = attribute_1.getName();
            _builder.append(_name_20, "	");
            _builder.append("){");
            _builder.newLineIfNotEmpty();
            {
              Type _type_9 = attribute_1.getType();
              if ((_type_9 instanceof org.eclipse.uml2.uml.Class)) {
                _builder.append("\t");
                _builder.append("\t");
                _builder.append("//do nothing, if ");
                String _name_21 = attribute_1.getName();
                _builder.append(_name_21, "		");
                _builder.append(" is the same");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("\t");
                _builder.append("if(this.");
                String _name_22 = attribute_1.getName();
                _builder.append(_name_22, "		");
                _builder.append(" == ");
                String _name_23 = attribute_1.getName();
                _builder.append(_name_23, "		");
                _builder.append(") return;");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("\t");
                _builder.append("//remove old ");
                String _name_24 = clazz.getName();
                _builder.append(_name_24, "		");
                _builder.append(" from opposite");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("\t");
                _builder.append("if(this.");
                String _name_25 = attribute_1.getName();
                _builder.append(_name_25, "		");
                _builder.append(" != null) this.");
                String _name_26 = attribute_1.getName();
                _builder.append(_name_26, "		");
                _builder.append(".get");
                String _name_27 = clazz.getName();
                String _firstUpper_4 = StringExtensions.toFirstUpper(_name_27);
                _builder.append(_firstUpper_4, "		");
                _builder.append("s().remove(this);");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("\t");
                _builder.append("//unless new ");
                String _name_28 = attribute_1.getName();
                _builder.append(_name_28, "		");
                _builder.append(" is null add ");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("\t");
                _builder.append("if(");
                String _name_29 = attribute_1.getName();
                _builder.append(_name_29, "		");
                _builder.append(" != null) ");
                String _name_30 = attribute_1.getName();
                _builder.append(_name_30, "		");
                _builder.append(".add");
                String _name_31 = clazz.getName();
                String _firstUpper_5 = StringExtensions.toFirstUpper(_name_31);
                _builder.append(_firstUpper_5, "		");
                _builder.append("(this);");
                _builder.newLineIfNotEmpty();
              }
            }
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("this.");
            String _name_32 = attribute_1.getName();
            _builder.append(_name_32, "		");
            _builder.append(" = ");
            String _name_33 = attribute_1.getName();
            _builder.append(_name_33, "		");
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("\t");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("}");
            _builder.newLine();
            _builder.append("\t");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("\t");
    _builder.append("public ");
    String _name_34 = clazz.getName();
    _builder.append(_name_34, "	");
    _builder.append("() {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("super();\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("public ");
    String _name_35 = clazz.getName();
    _builder.append(_name_35, "	");
    _builder.append(" (");
    _builder.newLineIfNotEmpty();
    {
      Iterable<Property> _listOfNotMultivaluedAttributes = ModelAndPackageHelper.listOfNotMultivaluedAttributes(clazz);
      boolean _hasElements = false;
      for(final Property attribute_2 : _listOfNotMultivaluedAttributes) {
        if (!_hasElements) {
          _hasElements = true;
        } else {
          _builder.appendImmediate(",", "		");
        }
        _builder.append("\t\t");
        Type _type_10 = attribute_2.getType();
        String _name_36 = _type_10.getName();
        _builder.append(_name_36, "		");
        _builder.append(" ");
        String _name_37 = attribute_2.getName();
        _builder.append(_name_37, "		");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.append(") {");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("super(");
    {
      EList<Property> _listOfSuperAttributes = ModelAndPackageHelper.listOfSuperAttributes(clazz);
      final Function1<Property,Boolean> _function_2 = new Function1<Property,Boolean>() {
          public Boolean apply(final Property att) {
            boolean _isMultivalued = att.isMultivalued();
            boolean _equals = (_isMultivalued == false);
            return Boolean.valueOf(_equals);
          }
        };
      Iterable<Property> _filter = IterableExtensions.<Property>filter(_listOfSuperAttributes, _function_2);
      boolean _hasElements_1 = false;
      for(final Property attribute_3 : _filter) {
        if (!_hasElements_1) {
          _hasElements_1 = true;
        } else {
          _builder.appendImmediate(",", "		");
        }
        String _name_38 = attribute_3.getName();
        _builder.append(_name_38, "		");
      }
    }
    _builder.append(");");
    _builder.newLineIfNotEmpty();
    {
      EList<Property> _attributes = clazz.getAttributes();
      for(final Property attribute_4 : _attributes) {
        {
          boolean _and_2 = false;
          Type _type_11 = attribute_4.getType();
          if (!(_type_11 instanceof org.eclipse.uml2.uml.Class)) {
            _and_2 = false;
          } else {
            boolean _isMultivalued_2 = attribute_4.isMultivalued();
            _and_2 = ((_type_11 instanceof org.eclipse.uml2.uml.Class) && _isMultivalued_2);
          }
          boolean _not = (!_and_2);
          if (_not) {
            _builder.append("\t\t");
            _builder.append("this.");
            String _name_39 = attribute_4.getName();
            _builder.append(_name_39, "		");
            _builder.append("=");
            String _name_40 = attribute_4.getName();
            _builder.append(_name_40, "		");
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    {
      Iterable<Property> _listOfNotMultivaluedClassAttributes = ModelAndPackageHelper.listOfNotMultivaluedClassAttributes(clazz);
      for(final Property attribute_5 : _listOfNotMultivaluedClassAttributes) {
        _builder.append("\t");
        _builder.append("public ");
        String _name_41 = clazz.getName();
        _builder.append(_name_41, "	");
        _builder.append("(");
        Type _type_12 = attribute_5.getType();
        String _name_42 = _type_12.getName();
        _builder.append(_name_42, "	");
        _builder.append(" ");
        String _name_43 = attribute_5.getName();
        _builder.append(_name_43, "	");
        _builder.append(") {");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("super();");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("this.");
        String _name_44 = attribute_5.getName();
        _builder.append(_name_44, "		");
        _builder.append("=");
        String _name_45 = attribute_5.getName();
        _builder.append(_name_45, "		");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("}");
        _builder.newLine();
        _builder.append("\t");
        _builder.newLine();
      }
    }
    _builder.append("\t");
    _builder.append("@Override");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("public String toString() {");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("return (\"\"");
    _builder.newLine();
    {
      boolean _isGeneralized = ModelAndPackageHelper.isGeneralized(clazz);
      if (_isGeneralized) {
        _builder.append("\t\t");
        _builder.append("+ super.toString() ");
        {
          EList<Property> _attributes_1 = clazz.getAttributes();
          final Function1<Property,Boolean> _function_3 = new Function1<Property,Boolean>() {
              public Boolean apply(final Property att) {
                boolean _isMultivalued = att.isMultivalued();
                boolean _equals = (_isMultivalued == false);
                return Boolean.valueOf(_equals);
              }
            };
          Iterable<Property> _filter_1 = IterableExtensions.<Property>filter(_attributes_1, _function_3);
          int _size_2 = IterableExtensions.size(_filter_1);
          boolean _greaterThan_1 = (_size_2 > 0);
          if (_greaterThan_1) {
            _builder.append("+ \",\"");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    {
      EList<Property> _attributes_2 = clazz.getAttributes();
      final Function1<Property,Boolean> _function_4 = new Function1<Property,Boolean>() {
          public Boolean apply(final Property att) {
            boolean _isMultivalued = att.isMultivalued();
            boolean _equals = (_isMultivalued == false);
            return Boolean.valueOf(_equals);
          }
        };
      Iterable<Property> _filter_2 = IterableExtensions.<Property>filter(_attributes_2, _function_4);
      boolean _hasElements_2 = false;
      for(final Property attribute_6 : _filter_2) {
        if (!_hasElements_2) {
          _hasElements_2 = true;
        } else {
          _builder.appendImmediate(" + \",\" ", "		");
        }
        _builder.append("\t\t");
        _builder.append("+ ");
        {
          int _lowerBound = attribute_6.lowerBound();
          boolean _equals_1 = (_lowerBound == 0);
          if (_equals_1) {
            _builder.append("( get");
            String _name_46 = attribute_6.getName();
            String _firstUpper_6 = StringExtensions.toFirstUpper(_name_46);
            _builder.append(_firstUpper_6, "		");
            _builder.append("() == null ? \"-\" : ");
          }
        }
        _builder.append("get");
        String _name_47 = attribute_6.getName();
        String _firstUpper_7 = StringExtensions.toFirstUpper(_name_47);
        _builder.append(_firstUpper_7, "		");
        _builder.append("()");
        {
          int _lowerBound_1 = attribute_6.lowerBound();
          boolean _equals_2 = (_lowerBound_1 == 0);
          if (_equals_2) {
            _builder.append(" )");
          }
        }
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t\t");
    _builder.append(");");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    return _builder;
  }
}
