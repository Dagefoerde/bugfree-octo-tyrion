package de.wwu.pi.mdsd.umlToApp.gui;

import de.wwu.pi.mdsd.umlToApp.util.ModelAndPackageHelper;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.StringExtensions;

@SuppressWarnings("all")
public class ListWindowGenerator {
  public CharSequence generateListWindow(final org.eclipse.uml2.uml.Class clazz) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("package ");
    _builder.append(ModelAndPackageHelper.PACKAGE_STRING, "");
    _builder.append(".gui;");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("import java.util.Vector;");
    _builder.newLine();
    _builder.newLine();
    _builder.append("import de.wwu.pi.mdsd.framework.gui.AbstractListWindow;");
    _builder.newLine();
    _builder.append("import de.wwu.pi.mdsd.framework.gui.AbstractWindow;");
    _builder.newLine();
    _builder.append("import ");
    _builder.append(ModelAndPackageHelper.PACKAGE_STRING, "");
    _builder.append(".logic.ServiceInitializer;");
    _builder.newLineIfNotEmpty();
    _builder.append("import ");
    _builder.append(ModelAndPackageHelper.PACKAGE_STRING, "");
    _builder.append(".data.");
    String _name = clazz.getName();
    _builder.append(_name, "");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    {
      Iterable<org.eclipse.uml2.uml.Class> _listOfExtendingClasses = ModelAndPackageHelper.listOfExtendingClasses(clazz);
      for(final org.eclipse.uml2.uml.Class ext : _listOfExtendingClasses) {
        _builder.append("import ");
        _builder.append(ModelAndPackageHelper.PACKAGE_STRING, "");
        _builder.append(".data.");
        String _name_1 = ext.getName();
        _builder.append(_name_1, "");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.newLine();
    _builder.append("public class ");
    String _name_2 = clazz.getName();
    _builder.append(_name_2, "");
    _builder.append("ListWindow extends AbstractListWindow<");
    String _name_3 = clazz.getName();
    _builder.append(_name_3, "");
    _builder.append("> implements ");
    String _name_4 = clazz.getName();
    _builder.append(_name_4, "");
    _builder.append("ListingInterface{");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("\t");
    _builder.append("public ");
    String _name_5 = clazz.getName();
    _builder.append(_name_5, "	");
    _builder.append("ListWindow(AbstractWindow parent) {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("super(parent);");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("\t");
    _builder.append("@Override");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("public void showEntryWindow(");
    String _name_6 = clazz.getName();
    _builder.append(_name_6, "	");
    _builder.append(" entity) {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("//If entity is null -> initialize entity as new entity");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("//show Entity Edit Window");
    _builder.newLine();
    {
      Iterable<org.eclipse.uml2.uml.Class> _listOfExtendingClasses_1 = ModelAndPackageHelper.listOfExtendingClasses(clazz);
      int _size = IterableExtensions.size(_listOfExtendingClasses_1);
      boolean _equals = (_size == 0);
      if (_equals) {
        _builder.append("\t\t");
        _builder.append("if(entity == null)");
        _builder.newLine();
        _builder.append("\t\t");
        _builder.append("\t");
        _builder.append("entity = new ");
        String _name_7 = clazz.getName();
        _builder.append(_name_7, "			");
        _builder.append("();");
        _builder.newLineIfNotEmpty();
        _builder.append("\t\t");
        _builder.append("new ");
        String _name_8 = clazz.getName();
        _builder.append(_name_8, "		");
        _builder.append("EntryWindow(this,entity).open();");
        _builder.newLineIfNotEmpty();
      } else {
        _builder.append("\t\t");
        _builder.append("if(entity == null) {");
        _builder.newLine();
        {
          Iterable<org.eclipse.uml2.uml.Class> _listOfExtendingClasses_2 = ModelAndPackageHelper.listOfExtendingClasses(clazz);
          for(final org.eclipse.uml2.uml.Class ext_1 : _listOfExtendingClasses_2) {
            _builder.append("\t\t");
            _builder.append("\t");
            _builder.append("if(cb_select.getSelectedItem().equals(\"");
            String _name_9 = ext_1.getName();
            _builder.append(_name_9, "			");
            _builder.append("\"))");
            _builder.newLineIfNotEmpty();
            _builder.append("\t\t");
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("entity = new ");
            String _name_10 = ext_1.getName();
            _builder.append(_name_10, "				");
            _builder.append("();");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t\t");
        _builder.append("}");
        _builder.newLine();
        {
          Iterable<org.eclipse.uml2.uml.Class> _listOfExtendingClasses_3 = ModelAndPackageHelper.listOfExtendingClasses(clazz);
          for(final org.eclipse.uml2.uml.Class ext_2 : _listOfExtendingClasses_3) {
            _builder.append("\t\t");
            _builder.append("if(entity instanceof ");
            String _name_11 = ext_2.getName();
            _builder.append(_name_11, "		");
            _builder.append(")");
            _builder.newLineIfNotEmpty();
            _builder.append("\t\t");
            _builder.append("\t");
            _builder.append("new ");
            String _name_12 = ext_2.getName();
            _builder.append(_name_12, "			");
            _builder.append("EntryWindow(this, (");
            String _name_13 = ext_2.getName();
            _builder.append(_name_13, "			");
            _builder.append(") entity).open();");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    {
      Iterable<org.eclipse.uml2.uml.Class> _listOfExtendingClasses_4 = ModelAndPackageHelper.listOfExtendingClasses(clazz);
      int _size_1 = IterableExtensions.size(_listOfExtendingClasses_4);
      boolean _greaterThan = (_size_1 > 0);
      if (_greaterThan) {
        _builder.append("\t");
        _builder.append("javax.swing.JComboBox<String> cb_select;");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("@Override //overrides superclass method to add a select box to the window");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("public void createContents() {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("super.createContents();");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("cb_select = new javax.swing.JComboBox<>();");
        _builder.newLine();
        {
          Iterable<org.eclipse.uml2.uml.Class> _listOfExtendingClasses_5 = ModelAndPackageHelper.listOfExtendingClasses(clazz);
          for(final org.eclipse.uml2.uml.Class ext_3 : _listOfExtendingClasses_5) {
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("cb_select.addItem(\"");
            String _name_14 = ext_3.getName();
            _builder.append(_name_14, "		");
            _builder.append("\");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("java.awt.GridBagConstraints gbc_btnAdd = new java.awt.GridBagConstraints();");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("gbc_btnAdd.insets = new java.awt.Insets(0, 0, 5, 5);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("gbc_btnAdd.gridx = 1;");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("gbc_btnAdd.gridy = 2;");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("getPanel().add(cb_select, gbc_btnAdd);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("}");
        _builder.newLine();
      }
    }
    _builder.newLine();
    _builder.append("\t");
    _builder.append("@Override");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("public Vector<");
    String _name_15 = clazz.getName();
    _builder.append(_name_15, "	");
    _builder.append("> getElements() {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("return new Vector<");
    String _name_16 = clazz.getName();
    _builder.append(_name_16, "		");
    _builder.append(">(ServiceInitializer.getProvider().get");
    String _name_17 = clazz.getName();
    String _firstUpper = StringExtensions.toFirstUpper(_name_17);
    _builder.append(_firstUpper, "		");
    _builder.append("Service().getAll());");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("@Override");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("public void initialize");
    String _name_18 = clazz.getName();
    String _firstUpper_1 = StringExtensions.toFirstUpper(_name_18);
    _builder.append(_firstUpper_1, "	");
    _builder.append("Listings() {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("initializeList();");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("interface ");
    String _name_19 = clazz.getName();
    _builder.append(_name_19, "");
    _builder.append("ListingInterface {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("public void initialize");
    String _name_20 = clazz.getName();
    String _firstUpper_2 = StringExtensions.toFirstUpper(_name_20);
    _builder.append(_firstUpper_2, "	");
    _builder.append("Listings();");
    _builder.newLineIfNotEmpty();
    _builder.append("}");
    _builder.newLine();
    return _builder;
  }
}
