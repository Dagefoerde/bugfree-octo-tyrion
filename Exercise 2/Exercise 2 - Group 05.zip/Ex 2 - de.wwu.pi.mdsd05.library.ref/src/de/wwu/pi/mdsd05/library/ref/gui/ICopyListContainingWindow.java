package de.wwu.pi.mdsd05.library.ref.gui;

public interface ICopyListContainingWindow {

	public void initializeCopyListing();
}
