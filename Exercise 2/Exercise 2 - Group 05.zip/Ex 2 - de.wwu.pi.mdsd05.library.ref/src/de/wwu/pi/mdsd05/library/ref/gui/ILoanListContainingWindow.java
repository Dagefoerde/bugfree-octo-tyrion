package de.wwu.pi.mdsd05.library.ref.gui;

public interface ILoanListContainingWindow {
	
	public void initializeLoanListing();

}
